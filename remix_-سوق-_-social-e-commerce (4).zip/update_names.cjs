const fs = require('fs');

const updateFile = (path, replacements) => {
  if (!fs.existsSync(path)) return;
  let content = fs.readFileSync(path, 'utf8');
  for (const { from, to } of replacements) {
    content = content.replace(from, to);
  }
  fs.writeFileSync(path, content);
};

// 1. Login.tsx
updateFile('src/pages/Login.tsx', [
  { from: /TRENDIFY/g, to: 'سوق' }
]);

// 2. constants/policies.ts
updateFile('src/constants/policies.ts', [
  { from: /Trendify/g, to: 'سوق' }
]);

// 3. CourierApplicationPortal.tsx
updateFile('src/components/CourierApplicationPortal.tsx', [
  { from: /TrendifyAdmin/g, to: 'SouqAdmin' }
]);

// 4. Navbar.tsx
updateFile('src/components/Navbar.tsx', [
  { from: /TRENDIFY/g, to: 'سوق' }
]);

// 5. ShareModal.tsx
updateFile('src/components/ShareModal.tsx', [
  { from: /Trendify/g, to: 'سوق' }
]);

// 6. OrderVerificationModal.tsx
updateFile('src/components/OrderVerificationModal.tsx', [
  { from: /Trendify/g, to: 'سوق' }
]);

// 7. locales/ar.json
updateFile('src/locales/ar.json', [
  { from: /Trendify/g, to: 'سوق' }
]);

// 8. locales/en.json
updateFile('src/locales/en.json', [
  { from: /Trendify/g, to: 'Souq' }
]);

// 9. locales/fr.json
updateFile('src/locales/fr.json', [
  { from: /Trendify/g, to: 'Souq' }
]);

// 10. locales/es.json
updateFile('src/locales/es.json', [
  { from: /Trendify/g, to: 'Souq' }
]);

// 11. public/manifest.json
updateFile('public/manifest.json', [
  { from: /Trendify/g, to: 'سوق' }
]);

// 12. index.html
updateFile('index.html', [
  { from: /Trendify/g, to: 'سوق' }
]);

// 13. metadata.json
updateFile('metadata.json', [
  { from: /Trendify/g, to: 'سوق' }
]);

console.log("Done updating names.");
