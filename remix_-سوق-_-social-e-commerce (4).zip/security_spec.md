# Security Specification - Trendify

## Data Invariants
1. A Product must have a valid `sellerId` matching the authenticated user's UID.
2. An Order must include the correct `sellerId` and `buyerId` (authenticated user).
3. Users cannot change their own `role` after initial setup (except maybe through admin).
4. Users cannot artificially inflate their `salesCount` or `totalEarnings`.
5. Orders can only move through specific state transitions (pending -> shipped -> delivered).

## The Dirty Dozen Payloads (Rejection Targets)
1. **Privilege Escalation**: Update `User.role` to 'admin'.
2. **Identity Spoofing**: Create a Product with `sellerId` of another user.
3. **Price Manipulation**: Create an Order with a price of $0.01 for a $1000 product (Client-side price override).
4. **Commission Theft**: Create an Order with $0 commission.
5. **ID Poisoning**: Create a Product with a 2KB long ID string.
6. **Stat Inflation**: Update `salesCount` via client SDK without an actual sale.
7. **PII Leak**: Read another user's private data (email) without authorization.
8. **Shadow Field Injection**: Adding `isVerified: true` to a Product document.
9. **Spam Creation**: Create 1000 products in a loop (Size/Rate limits - rules can't do rate limiting but can do size checks).
10. **State Shortcut**: Move an Order directly from 'pending' to 'delivered' without 'shipped'.
11. **Negative Price**: Product price set to -100.
12. **Foreign Order**: Read orders that don't belong to the buyer or seller.

## Test Runner (Logic Overview)
The `firestore.rules` will be audited against these vulnerabilities.
