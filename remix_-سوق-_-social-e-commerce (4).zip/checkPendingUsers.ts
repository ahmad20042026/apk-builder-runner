import { initializeApp } from "firebase/app";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { getFirestore, collection, getDocs, query, where } from "firebase/firestore";
import fs from "fs";

const config = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
const app = initializeApp(config);
const auth = getAuth(app);
const db = getFirestore(app);

async function test() {
  await signInWithEmailAndPassword(auth, "ahmad200420181939@gmail.com", "Password123!");
  const snap = await getDocs(query(collection(db, 'users'), where('verificationStatus', '==', 'pending')));
  console.log("PENDING USERS COUNT:", snap.size);
  snap.forEach(d => console.log(d.id, d.data().verificationStatus, d.data().displayName));
}
test().then(() => process.exit(0)).catch(e => { console.error(e.message); process.exit(1); });
