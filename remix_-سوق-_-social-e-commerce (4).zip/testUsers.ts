import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs } from "firebase/firestore";
import fs from "fs";

const firebaseConfig = JSON.parse(fs.readFileSync("./firebase-applet-config.json", "utf-8"));
const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

async function test() {
  const usersRef = collection(db, "users");
  const usersSnap = await getDocs(usersRef);
  console.log("Total users:", usersSnap.docs.length);
  usersSnap.docs.forEach(d => console.log(d.id, d.data().email, d.data().verificationStatus, d.data().role));
  process.exit(0);
}
test().catch(e => {
  console.error(e);
  process.exit(1);
});
