import { initializeApp } from "firebase/app";
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { getFirestore, doc, updateDoc, serverTimestamp } from "firebase/firestore";
import fs from "fs";

const config = JSON.parse(fs.readFileSync("firebase-applet-config.json", "utf-8"));
const app = initializeApp(config);
const auth = getAuth(app);
const db = getFirestore(app);

async function test() {
  await signInWithEmailAndPassword(auth, "ahmad200420181939@gmail.com", "Password123!");
  const uid = auth.currentUser!.uid;
  try {
    await updateDoc(doc(db, "users", uid), {
      verificationStatus: 'pending',
      verificationDetails: {
        documentType: 'nationalId',
        documentFrontUrl: 'http://test',
        documentBackUrl: 'http://test',
        facePhotoUrl: 'http://test',
        legalDocumentUrl: null,
        isBrandVerification: false,
        submittedAt: new Date(),
      },
      updatedAt: new Date(),
    });
    console.log("SUCCESS with new Date()");
  } catch (e: any) {
    console.error("FAILED with new Date():", e.message);
  }

  try {
    await updateDoc(doc(db, "users", uid), {
      verificationStatus: 'pending',
      verificationDetails: {
        documentType: 'nationalId',
        documentFrontUrl: 'http://test',
        documentBackUrl: 'http://test',
        facePhotoUrl: 'http://test',
        legalDocumentUrl: null,
        isBrandVerification: false,
        submittedAt: serverTimestamp(),
      },
      updatedAt: serverTimestamp(),
    });
    console.log("SUCCESS with serverTimestamp()");
  } catch (e: any) {
    console.error("FAILED with serverTimestamp():", e.message);
  }
}
test().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
