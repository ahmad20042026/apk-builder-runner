const fs = require('fs');

const updateFile = (path, replacements) => {
  if (!fs.existsSync(path)) return;
  let content = fs.readFileSync(path, 'utf8');
  for (const { from, to } of replacements) {
    content = content.replace(from, to);
  }
  fs.writeFileSync(path, content);
};

updateFile('src/lib/firebase.ts', [
  { from: /Trendify/g, to: 'Souq' }
]);

updateFile('src/lib/mockFirebase.ts', [
  { from: /trendify/g, to: 'souq' }
]);

console.log("Done updating leftovers.");
