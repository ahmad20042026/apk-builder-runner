export interface SellerTier {
  id: string; // Used for translation keys
  name: string;
  rate: number;
  minSales?: number;
  minEarnings?: number;
  minRating?: number; // Added rating requirement
  maxProducts: number;
  color: string;
  benefits: string[];
}

export const SELLER_TIERS: SellerTier[] = [
  { 
    id: 'standard',
    name: 'Standard Seller', 
    rate: 10, 
    maxProducts: 20,
    color: 'text-bento-accent',
    benefits: ['seller.benefits.standard_support', 'seller.benefits.limit_20', 'seller.benefits.withdrawal_0']
  }
];

export const calculateSellerTier = (
  salesCount: number = 0, 
  totalEarnings: number = 0, 
  rating: number = 5.0
): SellerTier => {
  return SELLER_TIERS[0];
};

export const getNextTier = (
  salesCount: number = 0, 
  totalEarnings: number = 0,
  rating: number = 5.0
) => {
  return null;
};

// Threshold for blocking adds: If rating falls below this, seller is restricted.
export const CRITICAL_RATING_THRESHOLD = 2.5;

export const canSellerUpload = (rating: number = 5.0): { canUpload: boolean, reason?: string } => {
  if (rating < CRITICAL_RATING_THRESHOLD) {
    return { 
      canUpload: false, 
      reason: 'seller.rating_too_low'
    };
  }
  return { canUpload: true };
};
