import { 
  db, 
  doc, updateDoc, collection, query, where, runTransaction, serverTimestampResilient as serverTimestamp,
  getDoc, getDocs
} from './firebase';
import type { Transaction } from 'firebase/firestore';
import { SellerProfile, TrustStatus, ReputationTrend } from '../types';

/**
 * Trust Curve Engine (Reputation System)
 * 
 * Logic to calculate seller trust based on verified product reviews.
 */

export async function processReputationUpdate(sellerId: string) {
  try {
    await (runTransaction as any)(db, async (transaction: any) => {
      const sellerRef = doc(db, 'sellerProfiles', sellerId) as any;
      const userRef = doc(db, 'users', sellerId) as any;
      
      const sellerSnap = await transaction.get(sellerRef);
      if (!sellerSnap.exists()) return;
      
      const sellerData = sellerSnap.data() as SellerProfile;
      
      // 1. Fetch all reviews for this seller to calculate real average
      const reviewsRef = collection(db, 'reviews') as any;
      const q = query(reviewsRef, where('sellerId', '==', sellerId)) as any;
      const reviewsSnap = await (getDocs as any)(q); // Note: ideally we'd use a cloud function or keep aggregates, but for now we fetch all
      
      const allReviews = reviewsSnap.docs.map((d: any) => d.data());
      const totalReviews = allReviews.length;
      if (totalReviews === 0) return;
      
      const sumRatings = allReviews.reduce((acc: number, r: any) => acc + (r.rating || 0), 0);
      const currentAvg = sumRatings / totalReviews;
      
      // 2. Previous snapshot
      const prevAvg = sellerData.rating || 5.0; // Default to 5
      const delta = currentAvg - prevAvg;
      
      // 3. Trend Detection
      let trend: ReputationTrend = 'STABLE';
      if (delta >= 0.2) trend = 'UP';
      else if (delta <= -0.2) trend = 'DOWN';
      
      // 4. Shock Detection
      let shockEvent = sellerData.shockEvent || false;
      if (prevAvg >= 4.0 && currentAvg <= 3.0) {
        shockEvent = true;
      }
      
      // 5. Warnings and Status Logic
      let warningsCount = sellerData.warningsCount || 0;
      let trustStatus: TrustStatus = sellerData.trustStatus || 'ACTIVE';
      
      // Rule 1: Gradual descent
      if (currentAvg <= 2.5 && trend === 'DOWN') {
        warningsCount = Math.min(3, warningsCount + 1);
        trustStatus = 'WARNING';
      }
      
      // Rule 2: Persistent bad rating (if already low and not improving)
      if (currentAvg <= 2.5 && trend === 'STABLE' && trustStatus === 'WARNING') {
        warningsCount = Math.min(3, warningsCount + 1);
      }
      
      // Rule 3: Shock Event
      if (shockEvent && !sellerData.shockEvent) { // Only trigger once per shock
        warningsCount = Math.min(3, warningsCount + 2);
        trustStatus = 'RISK';
      }
      
      // Rule 4: System Suspension
      if (warningsCount >= 3) {
        trustStatus = 'SUSPENDED';
      }
      
      // Rule 5: Recovery Logic
      if (currentAvg >= 3.5 && totalReviews >= 5) { // Need some volume to recover
        if (warningsCount > 0) warningsCount -= 1;
        
        if (warningsCount === 0) trustStatus = 'ACTIVE';
        else if (warningsCount === 1) trustStatus = 'WARNING';
        else if (warningsCount === 2) trustStatus = 'RISK';
        
        shockEvent = false; // Reset shock on recovery
      }
      
      const updates: Partial<SellerProfile> = {
        rating: currentAvg,
        ratingPrevAvg: prevAvg,
        deltaRating: delta,
        trend,
        warningsCount,
        trustStatus,
        shockEvent,
        updatedAt: serverTimestamp()
      };
      
      // Sync with status
      if (trustStatus === 'SUSPENDED') {
        updates.status = 'suspended';
      } else if (sellerData.status === 'suspended') {
        updates.status = 'active';
      }
      
      transaction.update(sellerRef, updates);
      
      // Sync main rating to user profile
      transaction.update(userRef, {
        rating: currentAvg,
        updatedAt: serverTimestamp()
      });
    });
  } catch (error) {
    console.error("Trust Engine Error:", error);
  }
}
