import { initializeApp, getApp, getApps } from 'firebase/app';
import { 
  getAuth, 
  GoogleAuthProvider as firestoreGoogleAuthProvider, 
  onAuthStateChanged as firestoreOnAuthStateChanged, 
  signInWithEmailAndPassword as firestoreSignInWithEmailAndPassword, 
  createUserWithEmailAndPassword as firestoreCreateUserWithEmailAndPassword, 
  signInWithPopup as firestoreSignInWithPopup, 
  signOut as firestoreSignOut,
  updatePassword as firestoreUpdatePassword,
  reauthenticateWithCredential as firestoreReauthenticateWithCredential,
  EmailAuthProvider as firestoreEmailAuthProvider
} from 'firebase/auth';
import { 
  getFirestore, 
  initializeFirestore,
  collection as firestoreCollection, 
  query as firestoreQuery, 
  where as firestoreWhere, 
  orderBy as firestoreOrderBy, 
  limit as firestoreLimit, 
  startAfter as firestoreStartAfter, 
  doc as firestoreDoc, 
  addDoc as firestoreAddDoc,
  getDoc as firestoreGetDoc, 
  getDocs as firestoreGetDocs, 
  setDoc as firestoreSetDoc, 
  updateDoc as firestoreUpdateDoc, 
  deleteDoc as firestoreDeleteDoc, 
  onSnapshot as firestoreOnSnapshot, 
  serverTimestamp, 
  increment, 
  runTransaction as firestoreRunTransaction, 
  writeBatch as firestoreWriteBatch, 
  getDocFromCache, 
  getDocsFromCache, 
  getDocFromServer,
  getCountFromServer as firestoreGetCountFromServer
} from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';
import * as mock from './mockFirebase';

export const isMockMode = firebaseConfig.projectId === 'remixed-project-id' || !firebaseConfig.apiKey;

let app: any;
let db: any;
let auth: any;
let storage: any;

const initFirebase = () => {
  try {
    if (isMockMode) {
      console.log("🚀 Souq starting in MOCK / DEMO mode");
      app = { name: 'mock-app' };
      db = mock.mockDb;
      auth = mock.mockAuth;
      storage = {}; 
    } else {
      console.log("🚀 Souq starting in REAL Firebase mode");
      app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
      
      // Use initializeFirestore for more control over settings
      db = initializeFirestore(app, {
        experimentalAutoDetectLongPolling: true,
      }, firebaseConfig.firestoreDatabaseId);

      auth = getAuth(app);
      storage = getStorage(app);

      // Persistence often causes "INTERNAL ASSERTION FAILED" in certain container/browser environments
      // Disabling it for stability in development.
      /*
      if (typeof window !== 'undefined') {
        try {
          if (typeof enableIndexedDbPersistence === 'function') {
            enableIndexedDbPersistence(db).catch((err) => {
              console.warn('Firestore persistence failed:', err);
            });
          }
        } catch (e) {
          console.warn("Could not enable persistence", e);
        }
      }
      */
    }
  } catch (error) {
    console.error("🔥 CRITICAL ERROR INITIALIZING FIREBASE:", error);
    // Fallback to mock if real fails totally so app doesnt white-screen
    app = { name: 'mock-app' };
    db = mock.mockDb;
    auth = mock.mockAuth;
    storage = {};
  }
};

initFirebase();

// Export functional equivalents that switch between Mock and Real
export const collection = ((db: any, path: string) => isMockMode ? mock.collection(db, path) : firestoreCollection(db, path)) as any;
export const query = ((ref: any, ...constraints: any[]) => isMockMode ? mock.query(ref, ...constraints) : firestoreQuery(ref, ...constraints)) as any;
export const where = ((field: string, op: any, value: any) => isMockMode ? mock.where(field, op, value) : firestoreWhere(field, op, value)) as any;
export const orderBy = ((field: string, dir?: any) => isMockMode ? mock.orderBy(field, dir) : firestoreOrderBy(field, dir)) as any;
export const limit = ((n: number) => isMockMode ? mock.limit(n) : firestoreLimit(n)) as any;
export const startAfter = ((d: any) => isMockMode ? mock.startAfter(d) : firestoreStartAfter(d)) as any;
export const doc = ((...args: any[]) => isMockMode ? (mock.doc as any)(...args) : (firestoreDoc as any)(...args)) as any;
export const getDoc = ((ref: any) => isMockMode ? mock.getDoc(ref) : firestoreGetDoc(ref)) as any;
export const addDoc = ((ref: any, data: any) => isMockMode ? mock.addDoc(ref, data) : firestoreAddDoc(ref, data)) as any;
export const setDoc = ((ref: any, data: any, options?: any) => isMockMode ? mock.setDoc(ref, data, options) : firestoreSetDoc(ref, data, options)) as any;
export const updateDoc = ((ref: any, data: any) => isMockMode ? mock.updateDoc(ref, data) : firestoreUpdateDoc(ref, data)) as any;
export const deleteDoc = ((ref: any) => isMockMode ? mock.deleteDoc(ref) : firestoreDeleteDoc(ref)) as any;
export const getCountFromServer = ((q: any) => isMockMode ? Promise.resolve({ data: () => ({ count: 0 }) }) : firestoreGetCountFromServer(q)) as any;
export const onSnapshot = ((ref: any, ...args: any[]) => isMockMode ? (mock.onSnapshot as any)(ref, ...args) : (firestoreOnSnapshot as any)(ref, ...args)) as any;
export const runTransaction = ((db: any, fn: any) => isMockMode ? mock.runTransaction(db, fn) : firestoreRunTransaction(db, fn)) as any;
export const writeBatch = ((db: any) => isMockMode ? mock.writeBatch(db) : firestoreWriteBatch(db)) as any;
export const getDocs = ((q: any) => isMockMode ? mock.getDocs(q) : firestoreGetDocs(q)) as any;

export const onAuthStateChanged = ((...args: any[]) => {
  const cb = args.length > 1 ? args[1] : args[0];
  return isMockMode ? mock.mockAuth.onAuthStateChanged(cb) : (firestoreOnAuthStateChanged as any)(auth, cb);
}) as any;
export const signInWithEmailAndPassword = ((...args: any[]) => {
  const e = args.length > 2 ? args[1] : args[0];
  const p = args.length > 2 ? args[2] : args[1];
  return isMockMode ? mock.mockAuth.signInWithEmailAndPassword(e, p) : (firestoreSignInWithEmailAndPassword as any)(auth, e, p);
}) as any;

export const createUserWithEmailAndPassword = ((...args: any[]) => {
  const e = args.length > 2 ? args[1] : args[0];
  const p = args.length > 2 ? args[2] : args[1];
  return isMockMode ? mock.mockAuth.createUserWithEmailAndPassword(e, p) : (firestoreCreateUserWithEmailAndPassword as any)(auth, e, p);
}) as any;

export const signInWithPopup = ((...args: any[]) => {
  const p = args.length > 1 ? args[1] : args[0];
  return isMockMode ? (mock.mockAuth as any).signInWithPopup(p) : (firestoreSignInWithPopup as any)(auth, p);
}) as any;
export const updatePassword = ((user: any, password: string) => isMockMode ? Promise.resolve() : firestoreUpdatePassword(user, password)) as any;
export const reauthenticateWithCredential = ((user: any, credential: any) => isMockMode ? Promise.resolve() : firestoreReauthenticateWithCredential(user, credential)) as any;
export const EmailAuthProvider = isMockMode ? { credential: (e: string, p: string) => ({ email: e, password: p }) } : firestoreEmailAuthProvider;
export const signOut = (() => isMockMode ? mock.mockAuth.signOut() : (firestoreSignOut as any)(auth)) as any;
export const GoogleAuthProvider = isMockMode ? mock.GoogleAuthProvider : firestoreGoogleAuthProvider;

export { 
  app, db, auth, storage,
  ref, uploadBytes, getDownloadURL, deleteObject
};

// ... existing helpers ...
export const serverTimestampResilient = () => isMockMode ? mock.serverTimestamp() : serverTimestamp();
export const incrementResilient = (n: number) => isMockMode ? mock.increment(n) : increment(n);

// Aliases for convenience
export const serverTimestampResilientAlias = serverTimestampResilient;
export const incrementResilientAlias = incrementResilient;
export { serverTimestampResilient as serverTimestamp, incrementResilient as increment };

export interface FirestoreErrorInfo {
// ...
  error: string;
  operationType: 'create' | 'update' | 'delete' | 'list' | 'get' | 'write';
  path: string | null;
  authInfo: {
    userId: string;
    email: string;
    emailVerified: boolean;
    isAnonymous: boolean;
    providerInfo: { providerId: string; displayName: string; email: string; }[];
  }
}

/**
 * Resilient version of getDoc that tries server first, then cache if offline/unavailable.
 */
export const getDocResilient = async (docRef: any) => {
  if (isMockMode) return await mock.getDoc(docRef);
  try {
    return await firestoreGetDoc(docRef);
  } catch (error: any) {
    if (error?.code === 'unavailable' || error?.message?.includes('offline') || error?.message?.includes('Backend didn\'t respond')) {
      console.warn("Firestore unavailable, falling back to cache for doc:", docRef.path);
      try {
        return await getDocFromCache(docRef);
      } catch (cacheError) {
        console.error("Cache fetch also failed for doc:", cacheError);
        throw error;
      }
    }
    throw error;
  }
};

/**
 * Resilient version of getDocs that tries server first, then cache if offline/unavailable.
 */
export const getDocsResilient = async (q: any) => {
  if (isMockMode) return await mock.getDocs(q);
  try {
    return await firestoreGetDocs(q);
  } catch (error: any) {
    if (error?.code === 'unavailable' || error?.message?.includes('offline') || error?.message?.includes('Backend didn\'t respond')) {
      console.warn("Firestore unavailable, falling back to cache for query");
      try {
        return await getDocsFromCache(q);
      } catch (cacheError) {
        console.error("Cache fetch also failed for query:", cacheError);
        throw error;
      }
    }
    throw error;
  }
};

export const handleFirestoreError = (error: any, operationType: FirestoreErrorInfo['operationType'], path: string | null = null, shouldThrow: boolean = true) => {
  if (error?.code === 'permission-denied') {
    const authInfo = auth.currentUser ? {
      userId: auth.currentUser.uid,
      email: auth.currentUser.email || '',
      emailVerified: auth.currentUser.emailVerified,
      isAnonymous: auth.currentUser.isAnonymous,
      providerInfo: auth.currentUser.providerData.map(p => ({
        providerId: p.providerId,
        displayName: p.displayName || '',
        email: p.email || ''
      }))
    } : {
      userId: 'not-authenticated',
      email: '',
      emailVerified: false,
      isAnonymous: false,
      providerInfo: []
    };

    const errorInfo: FirestoreErrorInfo = {
      error: error.message,
      operationType,
      path,
      authInfo
    };

    console.warn("Firestore Permission Error:", errorInfo);
    if (shouldThrow) throw new Error(JSON.stringify(errorInfo));
    return errorInfo;
  }
  if (shouldThrow) throw error;
  return error;
};
