
// Mock Firebase implementation for Local Demo Mode
import { User } from 'firebase/auth';

const STORAGE_KEY_PREFIX = 'souq_mock_';

const getStorageData = (collection: string) => {
  const data = localStorage.getItem(STORAGE_KEY_PREFIX + collection);
  return data ? JSON.parse(data) : {};
};

const setStorageData = (collection: string, data: any) => {
  localStorage.setItem(STORAGE_KEY_PREFIX + collection, JSON.stringify(data));
};

// --- Mock Auth ---
class MockAuth {
  currentUser: User | null = null;
  onAuthStateChangedListeners: ((user: User | null) => void)[] = [];

  constructor() {
    const savedUser = localStorage.getItem(STORAGE_KEY_PREFIX + 'auth_user');
    if (savedUser) {
      this.currentUser = JSON.parse(savedUser);
    }
  }

  notify() {
    this.onAuthStateChangedListeners.forEach(l => l(this.currentUser));
  }

  onAuthStateChanged(callback: (user: User | null) => void) {
    this.onAuthStateChangedListeners.push(callback);
    callback(this.currentUser);
    return () => {
      this.onAuthStateChangedListeners = this.onAuthStateChangedListeners.filter(l => l !== callback);
    };
  }

  updateUser(user: any) {
    this.currentUser = user;
    if (user) localStorage.setItem(STORAGE_KEY_PREFIX + 'auth_user', JSON.stringify(user));
    else localStorage.removeItem(STORAGE_KEY_PREFIX + 'auth_user');
    this.notify();
  }

  async signInWithEmailAndPassword(email: string, _password?: string) {
    const user = { uid: 'mock_uid_' + email.replace(/[^a-zA-Z0-9]/g, ''), email, displayName: email.split('@')[0] };
    this.updateUser(user as any);
    return { user };
  }

  async createUserWithEmailAndPassword(email: string, _password?: string) {
    return this.signInWithEmailAndPassword(email);
  }

  async signInWithPopup() {
    return this.signInWithEmailAndPassword('demo@souq.com');
  }

  async signOut() {
    this.updateUser(null);
  }
}

export const mockAuth = new MockAuth();

export class GoogleAuthProvider {}

// ... existing firestore mock ...
class MockFirestore {
  async getDoc(docRef: any) {
    const { collectionPath, docId } = docRef;
    const data = getStorageData(collectionPath);
    const docData = data[docId];
    return {
      exists: () => !!docData,
      data: () => docData,
      id: docId
    };
  }

  async getDocs(query: any) {
    const { collectionPath, constraints } = query;
    let dataMap = getStorageData(collectionPath);
    let docs = Object.keys(dataMap).map(id => ({
      id,
      ...dataMap[id]
    }));

    // Apply basic constraints
    if (constraints) {
      constraints.forEach((c: any) => {
        if (c.type === 'where') {
          docs = docs.filter(d => {
            const val = d[c.field];
            if (c.op === '==') return val === c.value;
            if (c.op === 'in') return Array.isArray(c.value) && c.value.includes(val);
            return true;
          });
        }
        if (c.type === 'orderBy') {
          docs.sort((a, b) => {
            if (a[c.field] < b[c.field]) return c.dir === 'asc' ? -1 : 1;
            if (a[c.field] > b[c.field]) return c.dir === 'asc' ? 1 : -1;
            return 0;
          });
        }
        if (c.type === 'limit') {
          docs = docs.slice(0, c.value);
        }
      });
    }

    return {
      docs: docs.map(d => ({
        id: d.id,
        data: () => {
          const {id: _, ...rest} = d;
          return rest;
        },
        exists: () => true
      })),
      empty: docs.length === 0
    };
  }

  async setDoc(docRef: any, data: any, options: any = {}) {
    const { collectionPath, docId } = docRef;
    const allData = getStorageData(collectionPath);
    if (options.merge) {
      allData[docId] = { ...(allData[docId] || {}), ...data };
    } else {
      allData[docId] = data;
    }
    setStorageData(collectionPath, allData);
  }

  async addDoc(collectionPath: string, data: any) {
    const id = Math.random().toString(36).substring(2, 15);
    const allData = getStorageData(collectionPath);
    allData[id] = data;
    setStorageData(collectionPath, allData);
    return { id };
  }

  async updateDoc(docRef: any, data: any) {
    const { collectionPath, docId } = docRef;
    const allData = getStorageData(collectionPath);
    if (!allData[docId]) throw new Error('Document not found');
    
    // Handle field increments/serverTimestamp
    const updated = { ...allData[docId] };
    Object.keys(data).forEach(key => {
      const val = data[key];
      if (val && typeof val === 'object' && val.__increment) {
        updated[key] = (updated[key] || 0) + val.__increment;
      } else if (val && typeof val === 'object' && val.__serverTimestamp) {
        updated[key] = new Date().toISOString();
      } else {
        updated[key] = val;
      }
    });

    allData[docId] = updated;
    setStorageData(collectionPath, allData);
  }

  async deleteDoc(docRef: any) {
    const { collectionPath, docId } = docRef;
    const allData = getStorageData(collectionPath);
    delete allData[docId];
    setStorageData(collectionPath, allData);
  }

  async runTransaction(db: any, updateFunction: any) {
    const transaction = {
      get: async (docRef: any) => this.getDoc(docRef),
      set: (docRef: any, data: any) => this.setDoc(docRef, data),
      update: (docRef: any, data: any) => this.updateDoc(docRef, data),
      delete: (docRef: any) => this.deleteDoc(docRef)
    };
    return updateFunction(transaction);
  }

  writeBatch() {
    return {
      set: (docRef: any, data: any) => this.setDoc(docRef, data),
      update: (docRef: any, data: any) => this.updateDoc(docRef, data),
      delete: (docRef: any) => this.deleteDoc(docRef),
      commit: async () => {}
    };
  }

  onSnapshot(ref: any, arg2: any, arg3?: any) {
    let callback: any;
    let onError: any;

    if (typeof arg2 === 'function') {
      callback = arg2;
      onError = arg3;
    } else if (arg2 && typeof arg2.next === 'function') {
      callback = arg2.next;
      onError = arg2.error;
    }

    if (!callback) {
       console.warn("Mock onSnapshot: No valid callback provided");
       return () => {};
    }

    const q = (typeof ref === 'string') ? { collectionPath: ref } : ref;
    
    if (q && (q.collectionPath || q.docId)) {
      if (q.docId) {
        this.getDoc(q).then(callback).catch(onError);
      } else {
        this.getDocs(q).then(callback).catch(onError);
      }
    }
    return () => {};
  }
}

export const mockDb = new MockFirestore();
export const getDoc = (ref: any) => mockDb.getDoc(ref);
export const getDocs = (query: any) => mockDb.getDocs(query);
export const setDoc = (ref: any, data: any, options?: any) => mockDb.setDoc(ref, data, options);
export const addDoc = (path: any, data: any) => mockDb.addDoc(path, data);
export const updateDoc = (ref: any, data: any) => mockDb.updateDoc(ref, data);
export const deleteDoc = (ref: any) => mockDb.deleteDoc(ref);
export const onSnapshot = (ref: any, callback: any, error?: any) => mockDb.onSnapshot(ref, callback, error);
export const runTransaction = (db: any, updateFunction: any) => mockDb.runTransaction(db, updateFunction);
export const writeBatch = (db: any) => mockDb.writeBatch();

export const serverTimestamp = () => ({ __serverTimestamp: true });
export const increment = (n: number) => ({ __increment: n });

export const collection = (db: any, path: string) => ({ collectionPath: path, type: 'collection' });
export const doc = (arg1: any, arg2?: string, arg3?: string) => {
  if (arg1?.type === 'collection') {
    return { 
      collectionPath: arg1.collectionPath, 
      docId: arg2 || Math.random().toString(36).substring(2, 11) 
    };
  }
  return { 
    collectionPath: arg2 || '', 
    docId: arg3 || Math.random().toString(36).substring(2, 11) 
  };
};
export const query = (ref: any, ...constraints: any[]) => ({ 
  collectionPath: typeof ref === 'string' ? ref : ref.collectionPath, 
  constraints 
});
export const where = (field: string, op: string, value: any) => ({ type: 'where', field, op, value });
export const orderBy = (field: string, dir: 'asc' | 'desc' = 'asc') => ({ type: 'orderBy', field, dir });
export const limit = (n: number) => ({ type: 'limit', value: n });
export const startAfter = (doc: any) => ({ type: 'startAfter', value: doc });
