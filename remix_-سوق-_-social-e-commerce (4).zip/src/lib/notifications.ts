import { 
  db, 
  collection, addDoc, serverTimestampResilient as serverTimestamp, query, where, orderBy, updateDoc, doc, limit,
  getDocsResilient as getDocs
} from './firebase';
import { NotificationType } from '../types';

export const sendNotification = async (
  userId: string,
  type: NotificationType,
  title: string,
  message: string,
  link?: string
) => {
  try {
    await addDoc(collection(db, 'notifications'), {
      userId,
      type,
      title,
      message,
      link: link || null,
      read: false,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    console.error("Error sending notification:", error);
  }
};

export const markNotificationAsRead = async (notificationId: string) => {
  try {
    await updateDoc(doc(db, 'notifications', notificationId), {
      read: true
    });
  } catch (error) {
    console.error("Error marking notification as read:", error);
  }
};

export const fetchNotifications = async (userId: string, limitCount: number = 20) => {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc'),
      limit(limitCount)
    ) as any;
    const snap = await (getDocs as any)(q);
    return snap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error("Error fetching notifications:", error);
    return [];
  }
};
