import { db, collection, addDoc, serverTimestampResilient as serverTimestamp, auth } from './firebase';
import { AuditLog } from '../types';

export const logAction = async (action: string, metadata?: any) => {
  const user = auth.currentUser;
  if (!user) return;

  const log: Partial<AuditLog> = {
    userId: user.uid,
    action,
    metadata,
    userAgent: navigator.userAgent,
    createdAt: serverTimestamp()
  };

  try {
    await addDoc(collection(db, 'auditLogs'), log);
  } catch (error) {
    console.error("Failed to log action:", error);
  }
};
