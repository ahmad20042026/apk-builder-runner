import { db, collection, addDoc, getDocs, query, limit } from './firebase';

const DUMMY_PRODUCTS = [
  {
    title: "Eco-Luxe Organic Cotton Hoodie",
    description: "Premium weight organic cotton with a minimalist fit. Sustainably sourced and perfectly oversized.",
    price: 85.00,
    imageUrl: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=800",
    sellerId: "system",
    sellerName: "ecocollect",
    category: "Fashion",
    createdAt: new Date()
  },
  {
    title: "Retro Future Wireless Headphones",
    description: "Analog aesthetic meets digital precision. High fidelity audio with 40h battery life.",
    price: 249.00,
    imageUrl: "https://images.unsplash.com/photo-1546435770-a3e426da4717?auto=format&fit=crop&q=80&w=800",
    sellerId: "system",
    sellerName: "futurebeats",
    category: "Electronics",
    createdAt: new Date()
  },
  {
    title: "Handmade Ceramic Earth Vase",
    description: "Each piece is uniquely hand-thrown in our Brooklyn studio. Natural basalt finish.",
    price: 65.00,
    imageUrl: "https://images.unsplash.com/photo-1581783898377-1c85bf937427?auto=format&fit=crop&q=80&w=800",
    sellerId: "system",
    sellerName: "clayworks",
    category: "Home",
    createdAt: new Date()
  },
  {
    title: "Midnight Gravity Weightless Blanket",
    description: "Simulate a warm embrace for deeper rest. Deep navy velvet finish.",
    price: 180.00,
    imageUrl: "https://images.unsplash.com/photo-1505691938895-1758d7eaa511?auto=format&fit=crop&q=80&w=800",
    sellerId: "system",
    sellerName: "serenity",
    category: "Home",
    createdAt: new Date()
  }
];

export const seedGeography = async () => {
  const regionsSnap = await (getDocs as any)(query(collection(db, 'regions'), limit(1)) as any);
  if (regionsSnap.empty) {
    console.log("Seeding regions...");
    const regions = [
      { id: 'north', name: 'North Gaza', nameAr: 'شمال غزة', isActive: true },
      { id: 'gaza', name: 'Gaza City', nameAr: 'غزة', isActive: true },
      { id: 'middle', name: 'Middle Area', nameAr: 'الوسطى', isActive: true },
      { id: 'south', name: 'South Gaza', nameAr: 'الجنوب', isActive: true },
    ];
    for (const r of regions) {
      await addDoc(collection(db, 'regions') as any, r);
    }

    const zones = [
      { regionId: 'north', name: 'Beit Hanoun', nameAr: 'بيت حانون', isActive: true, isRestricted: false },
      { regionId: 'north', name: 'Beit Lahia', nameAr: 'بيت لاهيا', isActive: true, isRestricted: false },
      { regionId: 'gaza', name: 'Rimal', nameAr: 'الرمال', isActive: true, isRestricted: false },
      { regionId: 'gaza', name: 'Shuja\'iyya', nameAr: 'الشجاعية', isActive: true, isRestricted: true },
      { regionId: 'middle', name: 'Deir al-Balah', nameAr: 'دير البلح', isActive: true, isRestricted: false },
      { regionId: 'middle', name: 'Nuseirat', nameAr: 'النصيرات', isActive: true, isRestricted: false },
      { regionId: 'south', name: 'Khan Younis', nameAr: 'خانيونس', isActive: true, isRestricted: false },
      { regionId: 'south', name: 'Rafah', nameAr: 'رفح', isActive: true, isRestricted: false },
    ];
    for (const z of zones) {
      await addDoc(collection(db, 'zones') as any, z);
    }
    console.log("Geography seeding complete!");
  }
};

export const seedProducts = async () => {
  await seedGeography(); // Ensure geography is seeded
  const q = query(collection(db, 'products'), limit(1)) as any;
  const snap = await (getDocs as any)(q);
  
  if (snap.empty) {
    console.log("Seeding initial products...");
    for (const product of DUMMY_PRODUCTS) {
      await addDoc(collection(db, 'products'), product);
    }
    console.log("Seeding complete!");
  }
};
