import { ref, uploadBytes, getDownloadURL, deleteObject, uploadBytesResumable } from 'firebase/storage';
import { storage, isMockMode } from './firebase';

interface UploadOptions {
  maxSizeMB: number;
  maxWidthOrHeight?: number;
  path: string;
  onProgress?: (progress: number) => void;
}

// Ultra-fast client-side downscaling using HTML5 Canvas (Memory Optimized)
const downscaleImage = async (file: File, maxWidth: number, maxHeight: number): Promise<Blob> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);
    img.src = objectUrl;
    
    img.onload = () => {
      URL.revokeObjectURL(objectUrl);
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > height) {
        if (width > maxWidth) {
          height *= maxWidth / width;
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width *= maxHeight / height;
          height = maxHeight;
        }
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return reject(new Error('Canvas setup failed'));
      
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(img, 0, 0, width, height);
      canvas.toBlob((blob) => {
        if (blob) resolve(blob);
        else reject(new Error('Compression failed'));
      }, 'image/jpeg', 0.6);
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Image load failed'));
    };
  });
};

export const uploadAndCompressImage = async (file: File, options: UploadOptions): Promise<string> => {
  console.log(`[Storage] Processing background upload for ${file.name}`);
  
  if (isMockMode) {
    if (options.onProgress) options.onProgress(100);
    return `https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=800`;
  }

  try {
    // 1. Processing Phase (0-20%)
    if (options.onProgress) options.onProgress(5);

    let fileToUpload: Blob | File = file;
    
    // Always downscale if > 300KB for speed
    if (file.size > 0.3 * 1024 * 1024) { 
      console.log('[Storage] Downscaling for performance...');
      fileToUpload = await downscaleImage(file, 800, 800);
      if (options.onProgress) options.onProgress(20);
    } else {
      if (options.onProgress) options.onProgress(20);
    }
    
    const fileName = `${Date.now()}_${file.name.replace(/[^a-zA-Z0-9.]/g, '_')}`;
    const filePath = `${options.path}/${fileName}`;
    const storageRef = ref(storage, filePath);
    
    const uploadTask = uploadBytesResumable(storageRef, fileToUpload);
    
    return new Promise((resolve, reject) => {
      uploadTask.on('state_changed', 
        (snapshot) => {
          const rawPercentage = (snapshot.bytesTransferred / snapshot.totalBytes) * 80;
          // Scale upload progress into 20-100 range
          const totalProgress = 20 + rawPercentage;
          if (options.onProgress) options.onProgress(Math.min(99, totalProgress));
        }, 
        (error) => {
          console.error('[Storage] Upload error:', error);
          reject(new Error('فشل الرفع، تحقق من الاتصال'));
        }, 
        async () => {
          if (options.onProgress) options.onProgress(100);
          const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
          resolve(downloadURL);
        }
      );

      // 3 Minute timeout for a very small file (should be ~100KB)
      setTimeout(() => {
        uploadTask.cancel();
        reject(new Error('TIMEOUT'));
      }, 180000);
    });
  } catch (error: any) {
    console.error('[Storage] Critical Error:', error);
    if (error.message === 'TIMEOUT') {
      throw new Error('انتهى الوقت، إنترنت ضعيف جداً');
    }
    throw new Error(error.message || 'فشل معالجة الصورة');
  }
};

export const deleteImage = async (url: string) => {
  try {
    if (url.startsWith('data:image')) return; // Cannot delete base64 strings
    if (url.startsWith('http') && url.includes('unsplash.com')) return;
    const imageRef = ref(storage, url);
    await deleteObject(imageRef);
  } catch (error) {
    console.error('Error deleting image from storage:', error);
  }
};
