import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db, handleFirestoreError, getDocResilient, onAuthStateChanged, doc, setDoc, updateDoc, serverTimestampResilient, onSnapshot } from '../lib/firebase';
import type { User } from 'firebase/auth'; // Still need User type
import { UserProfile, SellerProfile } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({ user: null, profile: null, loading: true });

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let profileUnsubscribe: (() => void) | null = null;

    const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
      setUser(authUser);
      
      if (profileUnsubscribe) {
        profileUnsubscribe();
        profileUnsubscribe = null;
      }

      if (authUser) {
        try {
          const userRef = doc(db, 'users', authUser.uid);
          
          // Initial check/creation - Use resilient helper
          let userDoc;
          try {
            userDoc = await getDocResilient(userRef);
          } catch (e: any) {
            console.warn("Retrying user fetch with snapshot due to failure:", e);
            // If even resilient fetch fails, we let the snapshot listener handle it later
            setLoading(false);
            return;
          }

          if (!userDoc.exists()) {
            console.log("AuthContext: Creating NEW profile for:", authUser.email);
            const isAdmin = authUser.email === 'ahmad200420181939@gmail.com';
            const newProfile: UserProfile = {
              uid: authUser.uid,
              displayName: authUser.displayName || 'User',
              email: authUser.email || '',
              photoURL: authUser.photoURL,
              role: isAdmin ? 'admin' : 'buyer',
              salesCount: 0,
              totalEarnings: 0,
              maxProducts: 5,
              currentProducts: 0,
              followersCount: 0,
              followingCount: 0,
              likesCount: 0,
              receivedLikesCount: 0,
              reviewsCount: 0,
              rating: 0,
              withdrawableBalance: 0,
              disputeCount: 0,
              monthlyDisputeCount: 0,
              isVerified: isAdmin,
              emailVerified: true,
              phoneVerified: true,
              isFrozen: false,
              isBanned: false,
              verificationStatus: isAdmin ? 'verified' : 'unverified',
              language: 'ar',
              createdAt: serverTimestampResilient() as any,
              updatedAt: serverTimestampResilient() as any
            };
            try {
              // Ensure we don't overwrite if it was a false negative on existence
              await setDoc(userRef, newProfile, { merge: true });
              setProfile(newProfile);
            } catch (setErr) {
              console.error("AuthContext: Failed to create profile on server:", setErr);
              setProfile(newProfile);
            }
          } else {
            const userData = { uid: userDoc.id, ...userDoc.data() } as UserProfile;
            
            const adminEmails = ['ahmad200420181939@gmail.com', 'abn.almokhem@gmail.com', 'abn_almokhem@gmail.com'];
            const isAdminEmail = authUser.email && adminEmails.includes(authUser.email.toLowerCase());
            
            if (isAdminEmail) {
              let updated = false;
              const updatePayload: any = {};

              if (userData.role !== 'admin') {
                userData.role = 'admin';
                updatePayload.role = 'admin';
                updated = true;
              }
              
              if (!userData.isVerified || (userData.verificationStatus !== 'verified' && !userData.verificationDetails)) {
                if (userData.verificationDetails || userData.verificationStatus === 'pending' || userData.verificationStatus === 'pending_verification') {
                  if (!userData.isVerified) {
                    userData.isVerified = true;
                    updatePayload.isVerified = true;
                    updated = true;
                  }
                } else {
                  userData.isVerified = true;
                  userData.verificationStatus = 'verified';
                  updatePayload.isVerified = true;
                  updatePayload.verificationStatus = 'verified';
                  updated = true;
                }
              }

              if (updated) {
                try {
                  await updateDoc(userRef, updatePayload);
                } catch (updErr) {
                  // Ignore upgrade errors on server
                }
              }
            }
            
            setProfile(userData);
          }

          setLoading(false);

          // Listener for real-time updates
          profileUnsubscribe = onSnapshot(userRef, async (snapshot: any) => {
            if (snapshot.exists()) {
              const userData = { uid: snapshot.id, ...snapshot.data() } as UserProfile;
              
              if (userData.sellerProfileExists) {
                const sellerRef = doc(db, 'sellerProfiles', authUser.uid);
                try {
                  const sellerDoc = await getDocResilient(sellerRef);
                  if (sellerDoc && sellerDoc.exists()) {
                    userData.sellerProfile = sellerDoc.data() as SellerProfile;
                  }
                } catch (err) {
                  // Silent failure for seller details
                }
              }

              const adminEmails = ['ahmad200420181939@gmail.com', 'abn.almokhem@gmail.com', 'abn_almokhem@gmail.com'];
              const isAdminEmail = authUser.email && adminEmails.includes(authUser.email.toLowerCase());
              if (isAdminEmail) {
                 userData.role = 'admin';
                 userData.isVerified = true;
              }
              
              setProfile(userData);
              setLoading(false);
            } else {
              setLoading(false);
            }
          }, (error: any) => {
            setLoading(false);
          });
        } catch (error) {
          setLoading(false);
        }
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribe();
      if (profileUnsubscribe) profileUnsubscribe();
    };
  }, []);

  return (
    <AuthContext.Provider value={{ user, profile, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    // If context is used outside provider, return safe defaults
    return { user: null, profile: null, loading: false };
  }
  return context;
};
