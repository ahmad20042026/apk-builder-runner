import React, { createContext, useContext, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from './AuthContext';
import { db, doc, updateDoc } from '../lib/firebase';

type Language = 'ar' | 'en' | 'fr' | 'es';

interface LanguageContextType {
  language: Language;
  changeLanguage: (lang: Language) => Promise<void>;
  dir: 'rtl' | 'ltr';
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const { i18n } = useTranslation();
  const { user, profile } = useAuth();
  const [language, setLanguage] = useState<Language>((i18n.language as Language) || 'ar');
  const [dir, setDir] = useState<'rtl' | 'ltr'>(language === 'ar' ? 'rtl' : 'ltr');

  // Sync with i18n and HTML dir
  useEffect(() => {
    const currentLang = i18n.language.split('-')[0] as Language;
    setLanguage(currentLang);
    const newDir = currentLang === 'ar' ? 'rtl' : 'ltr';
    setDir(newDir);
    document.documentElement.dir = newDir;
    document.documentElement.lang = currentLang;
  }, [i18n.language]);

  // Sync with profile if available
  useEffect(() => {
    if (profile?.language && profile.language !== i18n.language) {
      i18n.changeLanguage(profile.language);
    }
  }, [profile?.language]);

  const changeLanguage = async (lang: Language) => {
    await i18n.changeLanguage(lang);
    if (user) {
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          language: lang,
          updatedAt: new Date()
        });
      } catch (error) {
        console.error('Error updating language in Firestore:', error);
      }
    }
  };

  return (
    <LanguageContext.Provider value={{ language, changeLanguage, dir }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
