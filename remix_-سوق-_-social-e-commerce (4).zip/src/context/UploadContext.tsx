import React, { createContext, useContext, useState, useCallback } from 'react';

export interface UploadTask {
  id: string;
  progress: number;
  status: 'uploading' | 'completed' | 'error';
  message?: string;
}

interface UploadContextType {
  activeUploads: Record<string, UploadTask>;
  startUpload: (id: string) => void;
  updateProgress: (id: string, progress: number) => void;
  completeUpload: (id: string) => void;
  failUpload: (id: string, message: string) => void;
  removeUpload: (id: string) => void;
}

const UploadContext = createContext<UploadContextType | undefined>(undefined);

export function UploadProvider({ children }: { children: React.ReactNode }) {
  const [activeUploads, setActiveUploads] = useState<Record<string, UploadTask>>({});

  const startUpload = useCallback((id: string) => {
    setActiveUploads(prev => ({
      ...prev,
      [id]: { id, progress: 0, status: 'uploading' }
    }));
  }, []);

  const updateProgress = useCallback((id: string, progress: number) => {
    setActiveUploads(prev => ({
      ...prev,
      [id]: { ...prev[id], progress }
    }));
  }, []);

  const completeUpload = useCallback((id: string) => {
    setActiveUploads(prev => ({
      ...prev,
      [id]: { ...prev[id], progress: 100, status: 'completed' }
    }));
    // Remove after 5 seconds
    setTimeout(() => {
      removeUpload(id);
    }, 5000);
  }, []);

  const failUpload = useCallback((id: string, message: string) => {
    setActiveUploads(prev => ({
      ...prev,
      [id]: { ...prev[id], status: 'error', message }
    }));
    // Remove after 10 seconds
    setTimeout(() => {
      removeUpload(id);
    }, 10000);
  }, []);

  const removeUpload = useCallback((id: string) => {
    setActiveUploads(prev => {
      const { [id]: _, ...rest } = prev;
      return rest;
    });
  }, []);

  return (
    <UploadContext.Provider value={{ 
      activeUploads, 
      startUpload, 
      updateProgress, 
      completeUpload, 
      failUpload, 
      removeUpload 
    }}>
      {children}
    </UploadContext.Provider>
  );
}

export function useUpload() {
  const context = useContext(UploadContext);
  if (context === undefined) {
    throw new Error('useUpload must be used within an UploadProvider');
  }
  return context;
}
