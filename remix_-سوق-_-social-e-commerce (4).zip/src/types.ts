export type UserRole = 'buyer' | 'seller' | 'admin' | 'courier';
export type SellerType = 'seller' | 'brand';

export interface PaymentMethod {
  id: string;
  type: 'bank' | 'wallet' | 'paypal';
  provider: string;
  accountNumber: string;
  accountHolderName: string;
  isDefault: boolean;
}

export interface Withdrawal {
  id: string;
  userId: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  paymentMethod: PaymentMethod;
  createdAt: any;
  processedAt?: any;
}

export type OrderConfirmationMode = 'password' | 'email_otp' | 'otp_whatsapp' | 'otp_telegram' | 'biometric' | 'off';

export interface UserProfile {
  uid: string;
  displayName: string | null;
  email: string | null;
  photoURL: string | null;
  phone?: string;
  bio?: string;
  followersCount?: number;
  followingCount?: number;
  likesCount?: number;
  receivedLikesCount?: number;
  reviewsCount?: number;
  rating?: number;
  role: UserRole;
  sellerProfileExists?: boolean;
  sellerProfile?: SellerProfile;
  salesCount: number;
  totalEarnings: number;
  withdrawableBalance?: number;
  paymentMethods?: PaymentMethod[];
  maxProducts: number;
  currentProducts: number;
  isVerified: boolean;
  emailVerified: boolean;
  phoneVerified: boolean;
  isFrozen: boolean;
  isBanned: boolean;
  verificationStatus: 'unverified' | 'pending' | 'pending_verification' | 'verified' | 'rejected';
  language?: string;
  telegramChatId?: string;
  securityPassword?: string;
  orderConfirmationMode?: OrderConfirmationMode;
  courierApplicationStatus?: 'pending' | 'approved' | 'rejected' | 'activated';
  courierActivationCode?: string;
  courierVerified?: boolean;
  courierActive?: boolean;
  courierLocation?: {
    lat: number;
    lng: number;
    lastUpdated: any;
  };
  courierNotes?: string;
  courierApprovedAt?: any;
  isCourierApplicant?: boolean;
  auditLogs?: AuditLog[];
  acceptedGeneralTerms?: boolean;
  acceptedGeneralTermsAt?: any;
  acceptedSellerTerms?: boolean;
  acceptedSellerTermsAt?: any;
  disputeCount?: number;
  monthlyDisputeCount?: number;
  isDisputeBlocked?: boolean;
  verificationDetails?: {
    documentType: 'id_card' | 'passport' | 'driver_license';
    documentFrontUrl: string;
    documentBackUrl?: string;
    facePhotoUrl: string;
    legalDocumentUrl?: string;
    isBrandVerification?: boolean;
    submittedAt: any;
    verifiedAt?: any;
    rejectionReason?: string;
  };
  createdAt: any;
  updatedAt?: any;
}

export type TrustStatus = 'ACTIVE' | 'WARNING' | 'RISK' | 'SUSPENDED';
export type ReputationTrend = 'UP' | 'STABLE' | 'DOWN';

export interface Region {
  id: string;
  name: string;
  nameAr: string;
  isActive: boolean;
}

export interface Zone {
  id: string;
  regionId: string;
  name: string;
  nameAr: string;
  isActive: boolean;
  isRestricted: boolean;
}

export interface AuditLog {
  id: string;
  userId: string;
  action: string;
  metadata?: any;
  ipAddress?: string;
  userAgent?: string;
  createdAt: any;
}

export interface SellerProfile {
  id: string;
  userId: string;
  type: SellerType;
  displayName: string;
  logo: string;
  coverImage?: string;
  description: string;
  category: string;
  regionId: string;
  zoneId: string;
  phone?: string;
  status: 'active' | 'suspended' | 'pending' | 'frozen';
  level: number;
  rating: number; // current rating_avg
  ratingPrevAvg?: number;
  deltaRating?: number;
  trend?: ReputationTrend;
  warningsCount?: number;
  trustStatus?: TrustStatus;
  shockEvent?: boolean;
  followers: number;
  following: number;
  likesCount?: number;
  disputeCount?: number;
  acceptedSellerTerms?: boolean;
  acceptedSellerTermsAt?: any;
  createdAt: any;
  updatedAt?: any;
}

export interface ProductAddOn {
  id: string;
  name: string;
  price: number;
  isMandatory: boolean;
}

export interface SelectedAddOn {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string;
  imageUrls?: string[];
  sellerId: string;
  sellerName: string;
  sellerIsVerified?: boolean;
  category: string;
  originCountry: string;
  availableCountries: string[];
  shippingMethod: 'delivery_company' | 'delivery_agent' | 'external';
  isArchived?: boolean;
  isPinned?: boolean;
  orderIndex?: number;
  lastSoldAt?: any;
  likesCount?: number;
  reviewsCount?: number;
  stockQuantity: number;
  soldQuantity?: number;
  reservedQuantity?: number;
  addOns?: ProductAddOn[];
  mealType?: string;
  itemSubtype?: string;
  deviceCondition?: 'new' | 'used';
  drinks?: string;
  deliveryArea?: 'north_gaza' | 'gaza' | 'both';
  createdAt: any;
}

export type OrderStatus = 
  | 'pending' 
  | 'confirmed' 
  | 'preparing' 
  | 'ready_for_delivery' 
  | 'courier_assigned' 
  | 'picked_up' 
  | 'on_the_way' 
  | 'delivered' 
  | 'completed' 
  | 'disputed' 
  | 'refunded' 
  | 'cancelled';
export type PaymentStatus = 'pending' | 'held' | 'released' | 'refunded';

export interface CourierLocation {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: any;
}

export interface LogisticsData {
  distanceKm: number;
  estimatedTime: number; // in minutes
  deliveryFee: number;
  baseFee: number;
  ratePerKm: number;
  surgeFee: number;
  storeLocation: {
    lat: number;
    lng: number;
    address?: string;
  };
  deliveryLocation: {
    lat: number;
    lng: number;
    address?: string;
  };
  routeInfo?: any;
}

export interface DispatchInfo {
  notifiedCourierIds: string[];
  rejectCourierIds: string[];
  dispatchedAt: any;
  lockedBy?: string | null;
}

export interface Order {
  id: string;
  productId: string;
  productTitle: string;
  productImage?: string;
  buyerId: string;
  sellerId: string;
  courierId?: string;
  price: number; // Total price including add-ons
  basePrice?: number; // Price without add-ons
  selectedAddOns?: SelectedAddOn[];
  selectedDrinks?: string[];
  commission: number;
  netAmount: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  
  logistics?: LogisticsData;
  dispatch?: DispatchInfo;
  
  trackingCode?: string;
  shippingMethod: string;
  disputeId?: string;
  idempotencyKey?: string;
  
  // Security & Verification Proofs
  pickupProofImage?: string;
  deliveryProofImage?: string;
  deliveryQrCode: string;
  scannedQrAt?: any;
  courierLocationAtDelivery?: CourierLocation;
  
  // Timestamps
  sellerProofTimestamp?: any;
  courierPickupTimestamp?: any;
  deliveryTimestamp?: any;
  autoConfirmAt?: any;
  createdAt: any;
  updatedAt?: any;
}

export interface Dispute {
  id: string;
  orderId: string;
  buyerId: string;
  sellerId: string;
  reason: string;
  description: string;
  images: string[];
  status: 'open' | 'under_review' | 'resolved_buyer' | 'resolved_seller' | 'rejected';
  adminNotes?: string;
  createdAt: any;
  updatedAt?: any;
}

export interface WishlistItem {
  id: string;
  userId: string;
  productId: string;
  productTitle: string;
  productImage: string;
  productPrice: number;
  createdAt: any;
}

export interface CommissionTier {
  salesCount?: number;
  totalSales?: number;
  rate: number;
}

export interface Review {
  id: string;
  productId: string;
  productTitle?: string;
  sellerId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: any;
}

export interface StoreAnalytics {
  id?: string;
  storeId: string;
  totalRevenue: number;
  totalProfit: number;
  totalOrders: number;
  totalViews: number;
  totalClicks: number;
  totalImpressions: number;
  totalFavorites: number;
  totalCartAdds: number;
  totalFollowers: number;
  totalRefunds: number;
  totalDisputes: number;
  last7DaysRevenue: number;
  last30DaysRevenue: number;
  conversionRate: number;
  ctr: number;
  averageOrderValue: number;
  bestSellingProducts: string[]; // array of product ids
  worstSellingProducts: string[]; // array of product ids
}

export interface ProductAnalytics {
  id?: string;
  productId: string;
  storeId: string;
  impressions: number;
  clicks: number;
  productPageViews: number;
  ctr: number;
  favorites: number;
  cartAdds: number;
  orders: number;
  sales: number;
  revenue: number;
  commission: number;
  netProfit: number;
  refunds: number;
  disputes: number;
  rating: number;
  lastSoldAt: any;
  status: 'active' | 'low_performance' | 'inactive' | 'archived';
}

export interface Report {
  id: string;
  targetType: 'product' | 'seller' | 'order' | 'user';
  targetId: string;
  reporterId: string;
  reason: string;
  description: string;
  status: 'pending' | 'resolved' | 'dismissed';
  createdAt: any;
}

export interface CartItem {
  id: string;
  userId: string;
  productId: string;
  sellerId: string;
  sellerName: string;
  title: string;
  price: number;
  imageUrl: string;
  quantity: number;
  selectedAddOns?: SelectedAddOn[];
  selectedDrinks?: string[];
  createdAt: any;
}

export type NotificationType = 'sale' | 'delivery' | 'rating' | 'comment' | 'follow' | 'system' | 'like' | 'share';

export interface Notification {
  id: string;
  userId: string; // The recipient
  type: NotificationType;
  title: string;
  message: string;
  link?: string; // Optional link to product/profile/order
  read: boolean;
  createdAt: any;
}

export interface CourierActivationCode {
  id: string;
  code: string;
  isUsed: boolean;
  createdBy: string;
  createdAt: any;
  usedBy?: string;
  usedAt?: any;
}
