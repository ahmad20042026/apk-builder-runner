import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTranslation } from 'react-i18next';
import { useLanguage } from '../context/LanguageContext';
import { 
  db, collection, query, where, orderBy, onSnapshot, 
  serverTimestampResilient as serverTimestamp, doc, updateDoc, 
  handleFirestoreError 
} from '../lib/firebase';
import { Order } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Package, Truck, MapPin, CheckCircle, QrCode, 
  Camera, Upload, Loader2, Navigation, Clock, 
  ShieldCheck, AlertCircle, ExternalLink, Smartphone, Building2, Globe, X
} from 'lucide-react';
import { OrderService } from '../services/OrderService';
import { uploadAndCompressImage } from '../lib/storage';
import { Html5QrcodeScanner } from 'html5-qrcode';

export default function CourierDashboard() {
  const { dir } = useLanguage();
  const { t } = useTranslation();
  const { user, profile } = useAuth();
  const [availableOrders, setAvailableOrders] = useState<Order[]>([]);
  const [myOrders, setMyOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'available' | 'my'>('available');
  const [loading, setLoading] = useState(true);
  const [processingOrder, setProcessingOrder] = useState<string | null>(null);
  const [scanningOrder, setScanningOrder] = useState<Order | null>(null);
  const [uploadingProof, setUploadingProof] = useState<string | null>(null);
  const [selectedJob, setSelectedJob] = useState<Order | null>(null);

  useEffect(() => {
    if (!user || profile?.role !== 'courier') return;

    // 1. Available Orders Query
    const qAvailable = query(
      collection(db, 'orders') as any,
      where('status', '==', 'ready_for_delivery'),
      orderBy('createdAt', 'desc')
    ) as any;

    // 2. My Orders Query
    const qMy = query(
      collection(db, 'orders') as any,
      where('courierId', '==', user.uid),
      orderBy('updatedAt', 'desc')
    ) as any;

    const unsubAvailable = onSnapshot(qAvailable, (snap) => {
      setAvailableOrders(snap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Order)));
      if (activeTab === 'available') setLoading(false);
    }, (error) => {
      handleFirestoreError(error, 'list', 'orders/available');
      setLoading(false);
    });

    const unsubMy = onSnapshot(qMy, (snap) => {
      setMyOrders(snap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Order)));
      if (activeTab === 'my') setLoading(false);
    }, (error) => {
      handleFirestoreError(error, 'list', 'orders/my');
      setLoading(false);
    });

    return () => {
      unsubAvailable();
      unsubMy();
    };
  }, [user, profile, activeTab]);

  const claimOrder = async (orderId: string) => {
    if (!user) return;
    setProcessingOrder(orderId);
    try {
      await OrderService.claimOrder(orderId, user.uid);
      setActiveTab('my');
    } catch (error: any) {
      alert(error.message);
    } finally {
      setProcessingOrder(null);
    }
  };

  const handlePickup = async (orderId: string) => {
    setProcessingOrder(orderId);
    try {
      await OrderService.pickupOrder(orderId);
    } catch (error: any) {
      alert(error.message);
    } finally {
      setProcessingOrder(null);
    }
  };

  const handlestartDelivery = async (orderId: string) => {
    setProcessingOrder(orderId);
    try {
      await OrderService.startDelivery(orderId);
    } catch (error: any) {
      alert(error.message);
    } finally {
      setProcessingOrder(null);
    }
  };

  const handleDeliveryVerification = async (order: Order, qrCode: string, proofUrl: string) => {
    setProcessingOrder(order.id);
    try {
      // Get Location
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: true });
      });

      const location = {
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: serverTimestamp()
      };

      await OrderService.verifyAndDeliver(order.id, qrCode, proofUrl, location);
      setScanningOrder(null);
    } catch (error: any) {
      alert(error.message);
    } finally {
      setProcessingOrder(null);
    }
  };

  const handleUploadProof = async (file: File, orderId: string) => {
    setUploadingProof(orderId);
    try {
      const url = await uploadAndCompressImage(file, {
        maxSizeMB: 1,
        maxWidthOrHeight: 1200,
        path: `proofs/${orderId}`
      });
      return url;
    } catch (error) {
      console.error("Proof upload failed:", error);
      return null;
    } finally {
      setUploadingProof(null);
    }
  };

  const handleStandaloneProofUpload = async (file: File, orderId: string) => {
    const url = await handleUploadProof(file, orderId);
    if (url) {
      try {
        const orderRef = doc(db, 'orders', orderId);
        await updateDoc(orderRef, {
          deliveryProofImage: url,
          updatedAt: serverTimestamp()
        });
        if (selectedJob?.id === orderId) {
          setSelectedJob({ ...selectedJob, deliveryProofImage: url });
        }
      } catch (error: any) {
        alert("Failed to save proof: " + error.message);
      }
    }
  };

  if (profile?.role !== 'courier' && profile?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-6 text-center" dir={dir}>
        <div className="bg-neutral-900/50 backdrop-blur-xl border border-neutral-800 p-12 rounded-[40px] max-w-md">
          <ShieldCheck size={64} className="mx-auto text-neutral-800 mb-6" />
          <h1 className="text-2xl font-black italic tracking-tighter uppercase mb-2">{dir === 'rtl' ? 'وصول محظور' : 'Access Restricted'}</h1>
          <p className="text-neutral-500 text-sm font-bold uppercase tracking-widest leading-loose">
            {dir === 'rtl' ? 'يجب أن تكون مندوباً معتمداً للوصول إلى لوحة المندوب. يرجى التقديم في الإعدادات.' : 'You must be a verified courier to access the delivery dashboard. Please apply in settings.'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6 md:p-12 max-w-5xl mx-auto pt-10 md:pt-16 pb-24 md:pb-12" dir={dir}>
      <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
          <h1 className="text-4xl md:text-6xl font-black italic tracking-tighter uppercase mb-4">{t('settings.courier_dashboard')}</h1>
          <div className="flex items-center gap-2 text-neutral-500 font-bold uppercase tracking-widest text-[10px] bg-neutral-900 w-fit px-4 py-2 rounded-full border border-neutral-800">
            <Truck size={14} className="text-bento-accent" />
            {t('settings.courier_dashboard_secure')}
          </div>
        </div>

        <div className="flex bg-neutral-900 p-1.5 rounded-[24px] border border-neutral-800">
          <button 
            onClick={() => setActiveTab('available')}
            className={`px-6 py-3 rounded-[18px] font-black uppercase tracking-widest text-[10px] transition-all ${activeTab === 'available' ? 'bg-white text-black' : 'text-neutral-500 hover:text-white'}`}
          >
            {t('settings.courier_available_jobs')} ({availableOrders.length})
          </button>
          <button 
            onClick={() => setActiveTab('my')}
            className={`px-6 py-3 rounded-[18px] font-black uppercase tracking-widest text-[10px] transition-all ${activeTab === 'my' ? 'bg-white text-black' : 'text-neutral-500 hover:text-white'}`}
          >
            {t('settings.courier_my_jobs')} ({myOrders.length})
          </button>
        </div>
      </header>

      <div className="space-y-6">
        {activeTab === 'available' ? (
          availableOrders.length === 0 ? (
            <div className="py-32 bg-neutral-900/30 rounded-[40px] border border-neutral-900 border-dashed text-center">
              <Package size={48} className="mx-auto text-neutral-800 mb-6" />
              <p className="text-neutral-500 font-black italic text-xl uppercase">{t('settings.courier_no_available')}</p>
            </div>
          ) : (
            availableOrders.map((order, idx) => (
              <JobCard 
                key={order.id || `avail-${order.productTitle?.replace(/\\s/g, '-')}-${idx}`} 
                order={order} 
                dir={dir}
                t={t}
                onAction={() => claimOrder(order.id)} 
                onClick={() => setSelectedJob(order)}
                actionText={t('settings.courier_claim_job')}
                processing={processingOrder === order.id}
              />
            ))
          )
        ) : (
          myOrders.length === 0 ? (
            <div className="py-32 bg-neutral-900/30 rounded-[40px] border border-neutral-900 border-dashed text-center">
              <Truck size={48} className="mx-auto text-neutral-800 mb-6" />
              <p className="text-neutral-500 font-black italic text-xl uppercase">{t('settings.courier_no_my_jobs')}</p>
            </div>
          ) : (
            myOrders.map((order, idx) => (
              <JobCard 
                key={order.id || `my-${idx}`} 
                order={order} 
                dir={dir}
                t={t}
                onAction={() => {
                  if (order.status === 'courier_assigned') handlePickup(order.id);
                  else if (order.status === 'picked_up') handlestartDelivery(order.id);
                  else if (order.status === 'on_the_way') setScanningOrder(order);
                }} 
                onClick={() => setSelectedJob(order)}
                actionText={
                  order.status === 'courier_assigned' ? t('settings.courier_confirm_pickup') :
                  order.status === 'picked_up' ? t('settings.courier_start_delivery') :
                  order.status === 'on_the_way' ? t('settings.courier_verify_deliver') : t('common.details', 'Details')
                }
                processing={processingOrder === order.id}
                showStatus
              />
            ))
          )
        )}
      </div>

      <AnimatePresence>
        {selectedJob && (
          <JobDetailsModal 
            order={selectedJob} 
            onClose={() => setSelectedJob(null)} 
            onUploadProof={handleStandaloneProofUpload}
            isUploading={uploadingProof === selectedJob.id}
            dir={dir}
            t={t}
          />
        )}
        
        {scanningOrder && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/90 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-neutral-900 w-full max-w-xl rounded-[40px] border border-neutral-800 overflow-hidden shadow-2xl p-8"
            >
              <div className="flex justify-between items-center mb-8">
                <h2 className="text-2xl font-black italic tracking-tighter uppercase">Verify Delivery</h2>
                <button onClick={() => setScanningOrder(null)} className="p-2 hover:bg-neutral-800 rounded-full">
                  <Smartphone />
                </button>
              </div>

              <QRScannerWrapper 
                onScanSuccess={(qr) => setProcessingOrder(qr)} // Temporary store QR in local state
                onVerify={async (qr, proofFile) => {
                  if (!proofFile) {
                    alert("Delivery photo proof is required.");
                    return;
                  }
                  const url = await handleUploadProof(proofFile, scanningOrder.id);
                  if (url) {
                    await handleDeliveryVerification(scanningOrder, qr, url);
                  }
                }}
                processing={!!processingOrder}
                uploadingProof={!!uploadingProof}
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function JobCard({ order, onAction, onClick, actionText, processing, showStatus, dir, t }: any) {
  const logistics = order.logistics;

  return (
    <div 
      onClick={onClick}
      className="bg-neutral-900/50 backdrop-blur-xl border border-neutral-800 rounded-[40px] p-6 md:p-8 transition-all hover:bg-neutral-900 group cursor-pointer"
      dir={dir}
    >
      <div className={`flex flex-col md:flex-row gap-6 items-start ${dir === 'rtl' ? 'md:flex-row-reverse' : ''}`}>
        <div className="w-full md:w-24 aspect-square rounded-[24px] overflow-hidden border border-neutral-800 shrink-0 relative">
          <img src={order.productImage || 'https://via.placeholder.com/300'} alt="" className="w-full h-full object-cover" />
        </div>

        <div className={`flex-1 w-full ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
          <div className="flex justify-between items-start gap-4 mb-4">
            <div>
              <h3 className="text-xl font-black italic tracking-tighter mb-1 uppercase">{order.productTitle}</h3>
              <p className="text-[9px] font-black uppercase tracking-widest text-neutral-600 font-mono">
                {t('common.order_id', 'Order')} #{order.id.slice(0, 8).toUpperCase()} • {order.createdAt?.toDate?.().toLocaleDateString() || 'N/A'}
              </p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-black italic text-bento-accent">
                ILS {(logistics?.deliveryFee || order.price * 0.1).toFixed(2)}
              </div>
              {logistics && (
                <div className="text-[8px] font-bold uppercase text-neutral-500 tracking-tighter">
                   {logistics.distanceKm.toFixed(1)} km • {logistics.estimatedTime} min
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <div className="flex items-start gap-3 p-3 bg-black/40 rounded-xl border border-neutral-800">
              <Building2 size={14} className="text-neutral-500 mt-1" />
              <div>
                <p className="text-[8px] font-black uppercase tracking-widest text-neutral-500">{t('settings.courier_pickup_from')}</p>
                <p className="text-[10px] font-bold uppercase truncate">
                  {logistics?.storeLocation?.address || (dir === 'rtl' ? 'متجر التاجر' : 'Seller Store')}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-black/40 rounded-xl border border-neutral-800">
              <MapPin size={14} className="text-neutral-500 mt-1" />
              <div>
                <p className="text-[8px] font-black uppercase tracking-widest text-neutral-500">{t('settings.courier_delivery_to')}</p>
                <p className="text-[10px] font-bold uppercase truncate">
                  {logistics?.deliveryLocation?.address || (dir === 'rtl' ? 'عنوان المشتري' : 'Buyer Address')}
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            {showStatus ? (
              <div className="px-4 py-2 bg-neutral-800 rounded-xl text-[10px] font-black uppercase tracking-widest text-neutral-400">
                {order.status.replace('_', ' ')}
              </div>
            ) : (
               <div className="flex items-center gap-2 text-neutral-500 font-bold uppercase tracking-widest text-[9px]">
                 <Clock size={12} /> {dir === 'rtl' ? 'جاهز للاستلام' : 'Ready for Pickup'}
               </div>
            )}
            
            <button 
              onClick={(e) => { e.stopPropagation(); onAction(); }}
              disabled={processing || order.status === 'delivered' || order.status === 'completed'}
              className="bg-white text-black px-8 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-neutral-200 transition-all disabled:opacity-50 flex items-center gap-2"
            >
              {processing ? <Loader2 size={14} className="animate-spin" /> : <Navigation size={14} className={dir === 'rtl' ? 'rotate-180' : ''} />}
              {actionText}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function QRScannerWrapper({ onScanSuccess, onVerify, processing, uploadingProof }: { 
  onScanSuccess: (qr: string) => void, 
  onVerify: (qr: string, proofFile: File | null) => void,
  processing: boolean,
  uploadingProof: boolean
}) {
  const { t } = useTranslation();
  const [qrContent, setQrContent] = useState<string | null>(null);
  const [proofFile, setProofFile] = useState<File | null>(null);

  useEffect(() => {
    let scanner: Html5QrcodeScanner | null = null;
    
    // Only init scanner if not already scanned
    if (!qrContent) {
      scanner = new Html5QrcodeScanner("reader", { 
        fps: 10, 
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1
      }, false);
      
      scanner.render((text) => {
        setQrContent(text);
        onScanSuccess(text);
        scanner?.clear();
      }, (error) => {
        // ignore errors
      });
    }

    return () => {
      scanner?.clear().catch(console.error);
    };
  }, [qrContent]);

  return (
    <div className="space-y-6">
      {!qrContent ? (
        <div id="reader" className="overflow-hidden rounded-3xl border-2 border-neutral-800 bg-black"></div>
      ) : (
        <div className="p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-3xl flex items-center gap-4">
          <CheckCircle className="text-emerald-500" />
          <div>
            <p className="text-[10px] font-black uppercase text-neutral-500">{t('settings.courier_qr_verified')}</p>
            <p className="font-mono text-sm">{qrContent}</p>
          </div>
        </div>
      )}

      <div className="space-y-4">
        <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-black block">{t('settings.courier_delivery_photo_label')}</label>
        <div className="flex gap-4 items-center">
          <label className={`flex-1 aspect-video rounded-3xl border-2 border-dashed border-neutral-800 flex flex-col items-center justify-center cursor-pointer transition-all ${proofFile ? 'border-bento-accent bg-bento-accent/5' : 'hover:bg-neutral-800'}`}>
            <input 
              type="file" 
              accept="image/*" 
              capture="environment"
              className="hidden" 
              onChange={e => setProofFile(e.target.files?.[0] || null)}
            />
            {proofFile ? (
              <div className="text-center">
                <CheckCircle className="mx-auto text-bento-accent mb-2" />
                <p className="text-[10px] font-black uppercase text-bento-accent">{t('settings.courier_photo_captured')}</p>
              </div>
            ) : (
              <>
                <Camera size={24} className="text-neutral-600 mb-2" />
                <p className="text-[10px] font-black uppercase text-neutral-600">{t('settings.courier_take_photo')}</p>
              </>
            )}
          </label>
        </div>
      </div>

      <button 
        onClick={() => qrContent && onVerify(qrContent, proofFile)}
        disabled={!qrContent || !proofFile || processing || uploadingProof}
        className="w-full bg-white text-black py-5 rounded-[24px] font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-neutral-200 transition-all disabled:opacity-50 mt-4"
      >
        {processing || uploadingProof ? <Loader2 size={20} className="animate-spin" /> : <ShieldCheck size={20} />}
        {uploadingProof ? t('settings.courier_uploading_proof') : processing ? t('settings.courier_scanning') : t('settings.courier_complete_delivery')}
      </button>
      
      {qrContent && (
        <button 
          onClick={() => { setQrContent(null); setProofFile(null); }}
          className="w-full py-4 text-neutral-500 font-bold uppercase tracking-widest text-[10px] hover:text-white transition-colors"
        >
          {t('settings.courier_reset_rescan')}
        </button>
      )}
    </div>
  );
}

function JobDetailsModal({ order, onClose, onUploadProof, isUploading, dir, t }: any) {
  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 md:p-6 bg-black/95 backdrop-blur-xl" dir={dir}>
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-neutral-900 w-full max-w-2xl max-h-[90vh] rounded-[40px] border border-neutral-800 overflow-hidden flex flex-col shadow-2xl"
      >
        <div className={`p-6 md:p-8 border-b border-neutral-800 flex justify-between items-center bg-neutral-900/50 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
          <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
            <h2 className="text-2xl font-black italic tracking-tighter uppercase">{t('settings.courier_order_details')}</h2>
            <p className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest">{t('common.order_id', 'الطلب')} : {order.id}</p>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-neutral-800 rounded-full transition-colors">
            <X size={24} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8">
          {/* Order Header */}
          <div className={`flex gap-6 items-start ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'text-left'}`}>
            <div className="w-24 md:w-32 aspect-square rounded-[24px] overflow-hidden border border-neutral-800 shrink-0">
              <img src={order.productImage || 'https://via.placeholder.com/300'} alt="" className="w-full h-full object-cover" />
            </div>
            <div>
              <h3 className="text-xl md:text-3xl font-black italic tracking-tighter uppercase mb-2">{order.productTitle}</h3>
              <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <span className="text-emerald-500 text-2xl font-black italic">ILS {(order.price * 0.1).toFixed(2)}</span>
                <span className="text-neutral-600 font-bold uppercase tracking-widest text-[10px]">{t('settings.courier_delivery_fee')}</span>
              </div>
            </div>
          </div>

          {/* Delivery Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className={`p-5 bg-black/40 rounded-3xl border border-neutral-800 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                <div className={`flex items-center justify-between mb-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <Building2 size={16} className="text-emerald-500" />
                    <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500">{t('settings.courier_pickup_from')}</p>
                  </div>
                  {order.logistics?.storeLocation && (
                    <a 
                      href={`https://www.google.com/maps/dir/?api=1&destination=${order.logistics.storeLocation.lat},${order.logistics.storeLocation.lng}`} 
                      target="_blank" 
                      rel="noreferrer"
                      className="p-2 bg-emerald-500 text-black rounded-lg hover:bg-emerald-400 transition-colors"
                    >
                      <Navigation size={12} fill="currentColor" />
                    </a>
                  )}
                </div>
                <p className="font-bold text-sm tracking-tight leading-relaxed">
                  {order.logistics?.storeLocation?.address || (dir === 'rtl' ? t('settings.courier_seller_store') : 'Seller Storehouse')}
                </p>
              </div>

              <div className={`p-5 bg-black/40 rounded-3xl border border-neutral-800 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                <div className={`flex items-center justify-between mb-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <MapPin size={16} className="text-emerald-500" />
                    <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500">{t('settings.courier_delivery_to')}</p>
                  </div>
                  {order.logistics?.deliveryLocation && (
                    <a 
                      href={`https://www.google.com/maps/dir/?api=1&destination=${order.logistics.deliveryLocation.lat},${order.logistics.deliveryLocation.lng}`} 
                      target="_blank" 
                      rel="noreferrer"
                      className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-400 transition-colors"
                    >
                      <Navigation size={12} fill="currentColor" />
                    </a>
                  )}
                </div>
                <p className="font-bold text-sm tracking-tight leading-relaxed">
                  {order.logistics?.deliveryLocation?.address || (dir === 'rtl' ? t('settings.courier_buyer_address') : 'Buyer Customer Address')}
                </p>
              </div>
            </div>

            <div className={`p-5 bg-black/40 rounded-3xl border border-neutral-800 flex flex-col justify-between ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
              <div>
                <div className={`flex items-center gap-3 mb-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <Clock size={16} className="text-emerald-500" />
                  <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500">{t('settings.courier_timeline')}</p>
                </div>
                <div className="space-y-3">
                  <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                    <p className="text-[10px] font-bold uppercase tracking-tighter">{t('settings.courier_created')}: {order.createdAt?.toDate?.().toLocaleDateString()}</p>
                  </div>
                  <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className={`w-2 h-2 rounded-full ${order.status === 'ready_for_delivery' ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`}></div>
                    <p className="text-[10px] font-bold uppercase tracking-tighter">{t('settings.courier_status')}: {order.status.replace('_', ' ')}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Proof of Delivery Section */}
          {order.status === 'on_the_way' && (
            <div className={`p-8 bg-neutral-800 rounded-[32px] border border-neutral-700 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
               <div className={`flex items-center justify-between mb-6 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                 <div>
                   <h4 className="text-lg font-black italic tracking-tighter uppercase mb-1">{t('settings.courier_proof_title')}</h4>
                   <p className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest">{t('settings.courier_proof_desc')}</p>
                 </div>
                 <Camera size={24} className="text-neutral-500" />
               </div>

               {order.deliveryProofImage ? (
                 <div className="space-y-4">
                   <div className="aspect-video rounded-2xl overflow-hidden border border-emerald-500/30 relative">
                     <img src={order.deliveryProofImage} alt="Delivery Proof" className="w-full h-full object-cover" />
                     <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <p className="text-[10px] font-black uppercase text-white bg-black/60 px-4 py-2 rounded-full">{t('settings.courier_photo_captured')}</p>
                     </div>
                   </div>
                   <div className="flex items-center gap-2 text-emerald-500 font-black uppercase tracking-widest text-[9px] justify-center h-10 bg-emerald-500/10 rounded-xl">
                     <CheckCircle size={14} /> {t('settings.courier_proof_uploaded_msg')}
                   </div>
                   <label className="block w-full py-4 rounded-xl border border-dashed border-neutral-600 text-center text-neutral-500 cursor-pointer hover:bg-neutral-700 transition-all text-[9px] font-black uppercase tracking-widest">
                     <input 
                       type="file" 
                       accept="image/*" 
                       className="hidden" 
                       onChange={e => e.target.files?.[0] && onUploadProof(e.target.files[0], order.id)}
                       disabled={isUploading}
                     />
                     {isUploading ? t('common.loading') : t('settings.courier_replace_proof')}
                   </label>
                 </div>
               ) : (
                 <label className="flex flex-col items-center justify-center py-12 bg-black/40 rounded-2xl border-2 border-dashed border-neutral-700 hover:border-emerald-500 transition-all group cursor-pointer">
                    <input 
                      type="file" 
                      accept="image/*" 
                      capture="environment"
                      className="hidden" 
                      onChange={e => e.target.files?.[0] && onUploadProof(e.target.files[0], order.id)}
                      disabled={isUploading}
                    />
                    {isUploading ? (
                      <Loader2 className="animate-spin text-emerald-500 mb-3" />
                    ) : (
                      <Upload className="text-neutral-500 group-hover:text-emerald-500 mb-3" />
                    )}
                    <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500 group-hover:text-emerald-500">
                      {isUploading ? t('settings.courier_scanning') : t('settings.courier_upload_proof')}
                    </span>
                 </label>
               )}
            </div>
          )}
        </div>

        <div className="p-8 bg-black/40 border-t border-neutral-800">
           <button 
             onClick={onClose}
             className="w-full bg-white text-black py-5 rounded-[24px] font-black uppercase tracking-widest hover:bg-neutral-200 transition-all"
           >
             {t('settings.courier_close_details')}
           </button>
        </div>
      </motion.div>
    </div>
  );
}
