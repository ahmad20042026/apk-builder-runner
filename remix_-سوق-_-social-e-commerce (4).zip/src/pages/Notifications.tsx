import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, collection, query, where, orderBy, onSnapshot, limit, updateDoc, doc } from '../lib/firebase';
import { Notification } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Bell, 
  Package, 
  MessageSquare, 
  UserPlus, 
  Heart,
  Share2,
  ChevronRight, 
  Search,
  Users,
  ShieldAlert,
  ChevronDown,
  Camera,
  Star,
  ArrowLeft,
  Check
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';

export default function Notifications() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [chats, setChats] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  useEffect(() => {
    if (!user) return;

    // Listen for Notifications
    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc'),
      limit(100)
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      setNotifications(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification)));
      setLoading(false);
    }, (error) => {
      console.warn("Notifications listener error:", error);
      setLoading(false);
    });

    // Listen for Chats
    const chatsQ = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', user.uid),
      orderBy('updatedAt', 'desc'),
      limit(50)
    );

//     const unsubscribeChats = onSnapshot(chatsQ, (snap) => {
//       setChats(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
//     }, (error) => {
//       console.warn("Chats listener error:", error);
//     });

    // Safety timeout for loading state
    const timeout = setTimeout(() => {
      setLoading(false);
    }, 5000);

    return () => {
      unsubscribe();
//       unsubscribeChats();
      clearTimeout(timeout);
    };
  }, [user]);

  const markAsRead = async (id: string) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { read: true });
    } catch (error) {
      console.error("Error marking as read:", error);
    }
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.read);
    if (unread.length === 0) return;
    try {
      const batch = unread.map(n => updateDoc(doc(db, 'notifications', n.id), { read: true }));
      await Promise.all(batch);
    } catch (error) {
      console.error("Error marking all as read:", error);
    }
  };

  const unreadActivity = notifications.filter(n => !n.read && (n.type === 'rating' || n.type === 'comment' || n.type === 'like' || n.type === 'share')).length;
  const unreadOrders = notifications.filter(n => !n.read && (n.type === 'delivery' || n.type === 'sale')).length;
  const unreadFollowers = notifications.filter(n => !n.read && n.type === 'follow').length;
  const unreadSystem = notifications.filter(n => !n.read && n.type === 'system').length;

  const markCategoryAsRead = async (category: string) => {
    let toMark: Notification[] = [];
    switch (category) {
      case 'followers': toMark = notifications.filter(n => !n.read && n.type === 'follow'); break;
      case 'activity': toMark = notifications.filter(n => !n.read && (n.type === 'rating' || n.type === 'comment' || n.type === 'like' || n.type === 'share')); break;
      case 'orders': toMark = notifications.filter(n => !n.read && (n.type === 'delivery' || n.type === 'sale')); break;
      case 'system': toMark = notifications.filter(n => !n.read && n.type === 'system'); break;
    }
    
    if (toMark.length > 0) {
      try {
        const batch = toMark.map(n => updateDoc(doc(db, 'notifications', n.id), { read: true }));
        await Promise.all(batch);
      } catch (error) {
        console.error("Error marking category as read:", error);
      }
    }
  };

  const selectCategory = (category: string) => {
    setActiveCategory(category);
    markCategoryAsRead(category);
  };

  const getFilteredNotifications = () => {
    switch (activeCategory) {
      case 'followers': return notifications.filter(n => n.type === 'follow');
      case 'activity': return notifications.filter(n => n.type === 'rating' || n.type === 'comment' || n.type === 'like' || n.type === 'share');
      case 'orders': return notifications.filter(n => n.type === 'delivery' || n.type === 'sale');
      case 'system': return notifications.filter(n => n.type === 'system');
      default: return [];
    }
  };

  const currentNotifications = getFilteredNotifications();

  const getCategoryTitle = () => {
    switch (activeCategory) {
      case 'followers': return t('notifications_page.followers', 'متابعون جدد');
      case 'activity': return t('notifications_page.activity', 'النشاط');
      case 'orders': return t('nav.orders_tab', 'الطلبات');
      case 'system': return t('nav.system_tab', 'النظام');
      default: return '';
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'delivery': return <Package size={24} className="text-blue-500" />;
      case 'sale': return <Package size={24} className="text-emerald-500" />;
      case 'rating': return <Star size={24} className="text-amber-400" />;
      case 'comment': return <MessageSquare size={24} className="text-indigo-500" />;
      case 'like': return <Heart size={24} className="text-rose-500 fill-rose-500" />;
      case 'share': return <Share2 size={24} className="text-blue-400" />;
      case 'follow': return <UserPlus size={24} className="text-bento-accent" />;
      case 'system': return <ShieldAlert size={24} className="text-red-500" />;
      default: return <Bell size={24} className="text-neutral-500" />;
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-black flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-bento-accent border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className={`min-h-screen bg-black text-white pb-24 md:pb-12 ${dir === 'rtl' ? 'font-arabic' : ''}`}>
      {/* TikTok Style Header */}
      <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-md border-b border-neutral-900 p-4">
        <div className="max-w-xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <button 
              onClick={() => activeCategory ? setActiveCategory(null) : navigate(-1)} 
              className="p-2 hover:bg-neutral-800 rounded-full transition-colors"
            >
              <ArrowLeft size={24} className={dir === 'rtl' ? 'rotate-180' : ''} />
            </button>
            {!activeCategory && (
              <button className="p-2 hover:bg-neutral-800 rounded-full transition-colors">
                <Search size={24} />
              </button>
            )}
          </div>
          
          <button className="flex items-center gap-1 group">
            <span className="text-lg font-black italic tracking-tighter uppercase">
              {activeCategory ? getCategoryTitle() : t('nav.notifications', 'صندوق الوارد')}
            </span>
            {!activeCategory && <ChevronDown size={16} className="group-hover:translate-y-0.5 transition-transform" />}
          </button>

          <div className="flex items-center gap-2">
            {!activeCategory && notifications.some(n => !n.read) && (
              <button 
                onClick={markAllAsRead}
                className="p-2 hover:bg-neutral-800 rounded-full transition-colors text-emerald-500"
                title={t('nav.mark_all_read')}
              >
                <Check size={20} />
              </button>
            )}
            {!activeCategory && (
              <Link to="/orders" className="p-2 hover:bg-neutral-800 rounded-full transition-colors text-bento-accent">
                <Package size={24} />
              </Link>
            )}
            {!activeCategory && (
              <button className="p-2 hover:bg-neutral-800 rounded-full transition-colors">
                <UserPlus size={24} />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-xl mx-auto">
        {!activeCategory ? (
          <>
            {/* Top Categories Row */}
            <div className="flex justify-around py-6 border-b border-neutral-900 overflow-x-auto no-scrollbar gap-2 px-4">
              {/* New Followers */}
              <button 
                onClick={() => selectCategory('followers')}
                className="flex flex-col items-center gap-2 px-1 shrink-0 group"
              >
                <div className="w-16 h-16 rounded-3xl bg-blue-500/10 flex items-center justify-center group-active:scale-95 transition-all relative border border-blue-500/10 group-hover:bg-blue-500/20 group-hover:border-blue-500/30">
                  <Users size={32} className="text-blue-500" />
                  {unreadFollowers > 0 && (
                    <div className="absolute -top-1 -right-1 min-w-[20px] h-5 bg-red-600 rounded-full flex items-center justify-center text-[10px] font-bold border-2 border-black px-1">
                      {unreadFollowers}
                    </div>
                  )}
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500 group-hover:text-white transition-colors text-center w-20 truncate px-1">
                  {t('notifications_page.followers', 'متابعون')}
                </span>
              </button>

              {/* Orders */}
              <button 
                onClick={() => selectCategory('orders')}
                className="flex flex-col items-center gap-2 px-1 shrink-0 group"
              >
                <div className="w-16 h-16 rounded-3xl bg-amber-500/10 flex items-center justify-center group-active:scale-95 transition-all relative border border-amber-500/10 group-hover:bg-amber-500/20 group-hover:border-amber-500/30">
                  <Package size={32} className="text-amber-500" />
                  {unreadOrders > 0 && (
                    <div className="absolute -top-1 -right-1 min-w-[20px] h-5 bg-red-600 rounded-full flex items-center justify-center text-[10px] font-bold border-2 border-black px-1">
                      {unreadOrders}
                    </div>
                  )}
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500 group-hover:text-white transition-colors text-center w-20 truncate px-1">
                  {t('nav.orders_tab', 'الطلبات')}
                </span>
              </button>

              {/* Activity */}
              <button 
                onClick={() => selectCategory('activity')}
                className="flex flex-col items-center gap-2 px-1 shrink-0 group"
              >
                <div className="w-16 h-16 rounded-3xl bg-rose-500/10 flex items-center justify-center group-active:scale-95 transition-all relative border border-rose-500/10 group-hover:bg-rose-500/20 group-hover:border-rose-500/30">
                  <Bell size={32} className="text-rose-500" />
                  {unreadActivity > 0 && (
                    <div className="absolute -top-1 -right-1 min-w-[20px] h-5 bg-red-600 rounded-full flex items-center justify-center text-[10px] font-bold border-2 border-black px-1">
                      {unreadActivity}
                    </div>
                  )}
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500 group-hover:text-white transition-colors text-center w-20 truncate px-1">
                  {t('notifications_page.activity', 'النشاط')}
                </span>
              </button>

              {/* System */}
              <button 
                onClick={() => selectCategory('system')}
                className="flex flex-col items-center gap-2 px-1 shrink-0 group"
              >
                <div className="w-16 h-16 rounded-3xl bg-neutral-800/50 flex items-center justify-center group-active:scale-95 transition-all relative border border-white/5 group-hover:bg-neutral-800 group-hover:border-white/10">
                  <ShieldAlert size={32} className="text-neutral-400" />
                  {unreadSystem > 0 && (
                    <div className="absolute -top-1 -right-1 min-w-[20px] h-5 bg-red-600 rounded-full flex items-center justify-center text-[10px] font-bold border-2 border-black px-1">
                      {unreadSystem}
                    </div>
                  )}
                </div>
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500 group-hover:text-white transition-colors text-center w-20 truncate px-1">
                  {t('nav.system_tab', 'النظام')}
                </span>
              </button>
            </div>

            {/* Recent Notifications Brief (Replacment for Messaging) */}
            <div className="py-2">
              <div className={`px-4 py-3 flex items-center justify-between ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                <h3 className="text-xs font-black text-neutral-500 uppercase tracking-widest">
                  {t('notifications_page.new_activity', 'نشاط جديد')}
                </h3>
                <span className="text-[10px] font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded-full ring-1 ring-amber-500/20">
                  {notifications.filter(n => !n.read).length}
                </span>
              </div>
              
              {notifications.filter(n => !n.read).length === 0 ? (
                <div className="py-20 text-center opacity-20 italic">
                  <Check size={48} className="mx-auto mb-4 text-emerald-500" />
                  <p className="text-sm font-black uppercase tracking-widest">{t('nav.all_caught_up')}</p>
                </div>
              ) : (
                <div className="divide-y divide-neutral-900/50">
                  <AnimatePresence initial={false}>
                    {notifications.filter(n => !n.read).slice(0, 10).map((n, i) => (
                      <motion.div
                        key={n.id}
                        initial={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, x: 20, height: 0, transition: { duration: 0.3 } }}
                        className="overflow-hidden"
                      >
                        <Link 
                          to={n.link || '#'}
                          onClick={() => markAsRead(n.id)}
                          className={`flex items-center gap-4 p-5 hover:bg-neutral-900/60 transition-all active:bg-neutral-900 group ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}
                        >
                          <div className="shrink-0 relative">
                            <div className="w-12 h-12 rounded-2xl bg-neutral-900 border border-neutral-800 flex items-center justify-center group-hover:border-neutral-700 transition-colors shadow-sm">
                              {getIcon(n.type)}
                            </div>
                            <div className="absolute -top-1 -right-1 w-3 h-3 bg-red-600 border-2 border-black rounded-full" />
                          </div>

                          <div className={`flex-1 min-w-0 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                            <h4 className="font-bold text-sm text-white truncate leading-tight mb-1 group-hover:text-bento-accent transition-colors">
                              {n.title}
                            </h4>
                            <p className="text-xs text-neutral-500 font-medium truncate max-w-[280px]">
                              {n.message}
                            </p>
                          </div>

                          <div className={`shrink-0 flex flex-col items-center gap-1 ${dir === 'rtl' ? 'items-start' : 'items-end'}`}>
                            <span className="text-[9px] text-neutral-600 font-black uppercase tracking-tight">
                              {n.createdAt?.seconds ? new Date(n.createdAt.seconds * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                            </span>
                            <ChevronRight size={14} className={`text-neutral-700 group-hover:text-white transition-all transform ${dir === 'rtl' ? 'rotate-180 group-hover:-translate-x-1' : 'group-hover:translate-x-1'}`} />
                          </div>
                        </Link>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                  
                  {notifications.filter(n => !n.read).length > 10 && (
                    <button 
                      onClick={markAllAsRead}
                      className="w-full py-4 text-[10px] font-black uppercase tracking-[0.2em] text-neutral-600 hover:text-white hover:bg-neutral-900/40 transition-all"
                    >
                      {t('nav.mark_all_read')}
                    </button>
                  )}
                </div>
              )}
            </div>
          </>
        ) : (
          /* Category Filtered View */
          <div className="py-2">
            {currentNotifications.length === 0 ? (
              <div className="py-32 text-center opacity-20 italic">
                <Bell size={64} className="mx-auto mb-4" />
                <p className="text-lg font-black uppercase tracking-widest">{t('nav.all_caught_up')}</p>
              </div>
            ) : (
              <div className="divide-y divide-neutral-900">
                <AnimatePresence>
                  {currentNotifications.map((n, index) => (
                    <motion.div
                      key={`${n.id}-${index}`}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <Link 
                        to={n.link || '#'} 
                        onClick={() => markAsRead(n.id)}
                        className={`flex items-start gap-4 p-4 hover:bg-neutral-900/40 transition-colors ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}
                      >
                        <div className="shrink-0 w-12 h-12 bg-neutral-900 rounded-full flex items-center justify-center border border-neutral-800">
                          {getIcon(n.type)}
                        </div>
                        <div className={`flex-1 min-w-0 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                          <div className={`flex justify-between items-start mb-1 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                            <h4 className="font-bold text-white text-sm leading-tight pr-2">{n.title}</h4>
                            {!n.read && <div className="w-2 h-2 bg-red-600 rounded-full shrink-0" />}
                          </div>
                          <p className="text-xs text-neutral-500 font-medium leading-relaxed">{n.message}</p>
                          <span className="text-[10px] text-neutral-600 font-bold mt-2 block uppercase tracking-widest">
                            {n.createdAt?.seconds ? new Date(n.createdAt.seconds * 1000).toLocaleDateString() : ''}
                          </span>
                        </div>
                        <ChevronRight size={16} className={`shrink-0 mt-4 text-neutral-800 ${dir === 'rtl' ? 'rotate-180' : ''}`} />
                      </Link>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
