import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { db, collection, getDocs, query, where, orderBy, doc, setDoc, updateDoc, serverTimestampResilient as serverTimestamp } from '../lib/firebase';
import { SellerType, Region, Zone } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, Store, Briefcase, Camera, Upload, Loader2, ArrowRight, ShieldCheck, MapPin } from 'lucide-react';
import { uploadAndCompressImage } from '../lib/storage';
import PolicyModal from '../components/PolicyModal';
import { POLICIES } from '../constants/policies';
import { CustomSelect } from '../components/CustomSelect';

export default function SetupStore() {
  const { user, profile } = useAuth();
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  React.useEffect(() => {
    if (profile?.sellerProfileExists) {
      navigate('/seller');
    }
  }, [profile, navigate]);
  const [uploading, setUploading] = useState(false);
  const [acceptedPolicy, setAcceptedPolicy] = useState(false);
  const [showPolicyModal, setShowPolicyModal] = useState(false);
  
  const [phoneError, setPhoneError] = useState('');

  const [form, setForm] = useState({
    type: 'seller' as SellerType,
    displayName: profile?.displayName || '',
    description: '',
    category: '',
    phone: '05',
    logo: profile?.photoURL || '',
    coverImage: '',
    regionId: '',
    zoneId: ''
  });

  const validatePhone = (value: string) => {
    if (value.length < 3) return true; // Just "05"
    const digitAfterPrefix = value[2];
    if (digitAfterPrefix && !['6', '9'].includes(digitAfterPrefix)) {
      setPhoneError(dir === 'rtl' ? 'الرقم خاطئ يرجى كتابة الرقم بشكل صحيح (يجب أن يبدأ بـ 6 أو 9)' : 'Invalid number. Must start with 6 or 9 after 05');
      return false;
    }
    setPhoneError('');
    return true;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;
    
    // Ensure only digits are entered
    value = value.replace(/\D/g, '');
    
    // Force prefix 05
    if (!value.startsWith('05')) {
      value = '05' + value.replace(/^0+/, '');
    }
    
    // Limit to 10 digits (05 + 8)
    if (value.length > 10) {
      value = value.slice(0, 10);
    }

    validatePhone(value);
    setForm({ ...form, phone: value });
  };

  const [regions, setRegions] = useState<Region[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [filteredZones, setFilteredZones] = useState<Zone[]>([]);

  React.useEffect(() => {
    const fetchGeo = async () => {
      const rSnap = await (getDocs as any)(query(collection(db, 'regions') as any, where('isActive', '==', true)) as any);
      const rList = rSnap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() } as Region));
      setRegions(rList);

      const zSnap = await (getDocs as any)(query(collection(db, 'zones') as any, where('isActive', '==', true), where('isRestricted', '==', false)) as any);
      const zList = zSnap.docs.map((doc: any) => ({ id: doc.id, ...doc.data() } as Zone));
      setZones(zList);
    };
    fetchGeo();
  }, []);

  React.useEffect(() => {
    if (form.regionId) {
      setFilteredZones(zones.filter(z => z.regionId === form.regionId));
    } else {
      setFilteredZones([]);
    }
  }, [form.regionId, zones]);

  const handleUpload = async (file: File, field: 'logo' | 'coverImage') => {
    setUploading(true);
    try {
      const url = await uploadAndCompressImage(file, {
        maxSizeMB: 1,
        maxWidthOrHeight: 1200,
        path: `sellers/${user?.uid}/${field}`
      });
      setForm(prev => ({ ...prev, [field]: url }));
    } catch (error: any) {
      alert(`Upload failed: ${error.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!acceptedPolicy) {
      alert(t('seller.policy_error'));
      return;
    }
    
    if (phoneError || form.phone.length !== 10) {
      alert(t('seller.phone_invalid') || (dir === 'rtl' ? 'يرجى إدخال رقم هاتف صحيح' : 'Please enter a valid phone number'));
      return;
    }
    
    setLoading(true);
    try {
      const sellerProfileId = user.uid;
      const sellerData = {
        id: sellerProfileId,
        userId: user.uid,
        ...form,
        status: 'active',
        level: 1,
        rating: 0,
        followers: 0,
        following: 0,
        acceptedSellerTerms: true,
        acceptedSellerTermsAt: serverTimestamp(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      await setDoc(doc(db, 'sellerProfiles', sellerProfileId), sellerData);
      await updateDoc(doc(db, 'users', user.uid), {
        role: 'seller',
        sellerProfileExists: true,
        acceptedSellerTerms: true,
        acceptedSellerTermsAt: serverTimestamp()
      });
      
      navigate('/profile');
    } catch (error) {
      console.error("Setup Store Error:", error);
      alert("Failed to setup store. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-bento-bg text-white font-sans overflow-y-auto" dir={dir}>
      <div className="max-w-2xl mx-auto px-6 py-12 flex flex-col gap-8 pb-32">
        <header className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'flex-row text-left'}`}>
            <button onClick={() => navigate(-1)} className="p-3 bg-neutral-900 border border-neutral-800 rounded-2xl hover:bg-neutral-800 transition-colors">
              {dir === 'rtl' ? <ChevronLeft className="rotate-180" size={20} /> : <ChevronLeft size={20} />}
            </button>
           <div className="flex-1">
             <h1 className="text-3xl font-black italic tracking-tighter uppercase">{t('seller.setup_title')}</h1>
             <p className="text-[10px] text-neutral-500 font-black uppercase tracking-widest mt-1">{t('seller.setup_subtitle')}</p>
           </div>
        </header>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Type Selection */}
          <div className="grid grid-cols-2 gap-4">
            <button 
              type="button"
              onClick={() => setForm({...form, type: 'seller'})}
              className={`p-6 rounded-[30px] border-2 transition-all flex flex-col items-center gap-4 ${form.type === 'seller' ? 'border-bento-accent bg-bento-accent/5' : 'border-neutral-800 bg-neutral-900/50'}`}
            >
              <div className={`p-4 rounded-2xl ${form.type === 'seller' ? 'bg-bento-accent text-black' : 'bg-neutral-800 text-neutral-400'}`}>
                <Store size={32} />
              </div>
              <div className="text-center">
                <span className="block font-black text-sm uppercase tracking-tighter">{t('seller.type_regular')}</span>
                <span className="text-[10px] text-neutral-500 font-bold">{t('seller.type_regular_desc')}</span>
              </div>
            </button>

            <button 
              type="button"
              onClick={() => setForm({...form, type: 'brand'})}
              className={`p-6 rounded-[30px] border-2 transition-all flex flex-col items-center gap-4 ${form.type === 'brand' ? 'border-bento-accent bg-bento-accent/5' : 'border-neutral-800 bg-neutral-900/50'}`}
            >
              <div className={`p-4 rounded-2xl ${form.type === 'brand' ? 'bg-bento-accent text-black' : 'bg-neutral-800 text-neutral-400'}`}>
                <Briefcase size={32} />
              </div>
              <div className="text-center">
                <span className="block font-black text-sm uppercase tracking-tighter">{t('seller.type_brand')}</span>
                <span className="text-[10px] text-neutral-500 font-bold">{t('seller.type_brand_desc')}</span>
              </div>
            </button>
          </div>

          <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 md:p-12 shadow-2xl space-y-6">
            {/* Visuals */}
            <div className="space-y-6">
              <div className="flex flex-col items-center">
                 <div className="relative group">
                    <div className="w-24 h-24 rounded-full border-4 border-bento-accent overflow-hidden bg-neutral-800">
                       {form.logo ? (
                         <img src={form.logo} className="w-full h-full object-cover" alt="Logo" />
                       ) : (
                         <div className="w-full h-full flex items-center justify-center text-neutral-600"><Camera size={32} /></div>
                       )}
                    </div>
                    <label className="absolute bottom-0 right-0 p-2 bg-bento-accent text-black rounded-full cursor-pointer hover:scale-110 transition-transform">
                       {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
                       <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*" 
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleUpload(file, 'logo');
                          }}
                          disabled={uploading}
                       />
                    </label>
                 </div>
                 <span className="text-[10px] text-neutral-500 font-black uppercase mt-2">{t('seller.store_logo')}</span>
              </div>

              <div>
                <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller.store_name_label')}</label>
                <input 
                  type="text" 
                  value={form.displayName}
                  onChange={e => setForm({...form, displayName: e.target.value})}
                  className={`w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-colors font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                  placeholder={t('seller.store_name_placeholder')}
                  required
                />
              </div>

              <div>
                <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller.store_desc_label')}</label>
                <textarea 
                  value={form.description}
                  onChange={e => setForm({...form, description: e.target.value})}
                  className={`w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-colors h-32 resize-none text-sm leading-relaxed ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                  placeholder={t('seller.store_desc_placeholder')}
                  required
                />
              </div>

              <div className="space-y-6">
                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller.store_category_label')}</label>
                  <CustomSelect
                    value={form.category}
                    onChange={(val) => setForm({...form, category: val})}
                    options={[
                      { id: 'food', label: t('product_form.categories.food') },
                      { id: 'veg_fruits', label: t('product_form.categories.veg_fruits') },
                      { id: 'supermarket', label: t('product_form.categories.supermarket') },
                      { id: 'electronics', label: t('product_form.categories.electronics') },
                      { id: 'meat', label: t('product_form.categories.meat'), disabled: true },
                      { id: 'home_appliances', label: t('product_form.categories.home_appliances'), disabled: true },
                      { id: 'electrical_tools', label: t('product_form.categories.electrical_tools'), disabled: true },
                      { id: 'sanitary_tools', label: t('product_form.categories.sanitary_tools'), disabled: true },
                      { id: 'drinks', label: t('product_form.categories.drinks'), disabled: true },
                      { id: 'desserts', label: t('product_form.categories.desserts'), disabled: true }
                    ]}
                    placeholder={t('seller.store_category_placeholder')}
                    label={t('seller.store_category_label')}
                    dir={dir}
                  />
                </div>
                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller.store_phone_label')}</label>
                  <input 
                    type="tel" 
                    value={form.phone}
                    onChange={handlePhoneChange}
                    className={`w-full bg-black border ${phoneError ? 'border-red-500' : 'border-neutral-800'} rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-colors font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                    placeholder="05XXXXXXXX"
                    required
                  />
                  {phoneError && (
                    <p className={`text-[10px] text-red-500 font-bold mt-2 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      {phoneError}
                    </p>
                  )}
                </div>
              </div>

              {/* Geographic Selection */}
              <div className="space-y-6">
                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('common.region') || 'المنطقة (النطاق)'}</label>
                  <CustomSelect
                    value={form.regionId}
                    onChange={(val) => setForm({...form, regionId: val, zoneId: ''})}
                    options={regions.map(r => ({ id: r.id, label: dir === 'rtl' ? r.nameAr : r.name }))}
                    placeholder={t('common.select_region') || 'اختر المنطقة'}
                    label={t('common.region') || 'المنطقة'}
                    dir={dir}
                  />
                </div>
                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('common.zone') || 'المحافظة / الحي'}</label>
                  <CustomSelect
                    value={form.zoneId}
                    onChange={(val) => setForm({...form, zoneId: val})}
                    options={filteredZones.map(z => ({ id: z.id, label: dir === 'rtl' ? z.nameAr : z.name }))}
                    placeholder={t('common.select_zone') || 'اختر المحافظة'}
                    label={t('common.zone') || 'المحافظة'}
                    disabled={!form.regionId}
                    dir={dir}
                  />
                </div>
              </div>

              <div className={`flex items-center gap-4 bg-black/40 p-6 rounded-3xl border border-neutral-800 hover:border-bento-accent/30 transition-all cursor-pointer group ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'flex-row text-left'}`} onClick={() => setAcceptedPolicy(!acceptedPolicy)}>
                 <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${acceptedPolicy ? 'bg-bento-accent border-bento-accent' : 'border-neutral-700'}`}>
                    {acceptedPolicy && <ShieldCheck size={14} className="text-black" />}
                 </div>
                 <p className="text-[11px] text-neutral-400 font-bold leading-relaxed flex-1">
                    {POLICIES.CONSENT.SELLER}{' '}
                    <button 
                      type="button"
                      onClick={(e) => { e.stopPropagation(); setShowPolicyModal(true); }} 
                      className="text-bento-accent hover:underline inline"
                    >
                      {t('seller.read_policies')}
                    </button>
                 </p>
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading || uploading || !acceptedPolicy}
              className="w-full bg-white text-black py-5 rounded-[24px] font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-bento-accent transition-all shadow-xl shadow-white/5 disabled:opacity-30 mt-8"
            >
              {loading ? <Loader2 className="animate-spin" /> : (
                <>
                  <span>{t('seller.confirm_setup')}</span>
                  <ArrowRight size={20} className={dir === 'rtl' ? 'rotate-180' : ''} />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
      <PolicyModal isOpen={showPolicyModal} onClose={() => setShowPolicyModal(false)} type="seller" />
    </div>
  );
}
