import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  db, handleFirestoreError, collection, query, where, orderBy, onSnapshot, 
  deleteDoc, doc, updateDoc, incrementResilient as increment, addDoc, 
  serverTimestampResilient as serverTimestamp, getDocs
} from '../lib/firebase';
import { CartItem, Product } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBasket, Trash2, Plus, Minus, ArrowRight, CreditCard, ShoppingBag, Package, MapPin, Truck } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useLanguage } from '../context/LanguageContext';
import { Link, useNavigate } from 'react-router-dom';
import { OrderService } from '../services/OrderService';
import { sendNotification } from '../lib/notifications';

export default function Cart() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [checkingOut, setCheckingOut] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'carts'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      setCartItems(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as CartItem)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, 'list', 'carts');
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const updateQuantity = async (itemId: string, delta: number) => {
    const item = cartItems.find(i => i.id === itemId);
    if (!item) return;

    const newQty = item.quantity + delta;
    if (newQty < 1) return;

    try {
      await updateDoc(doc(db, 'carts', itemId), {
        quantity: newQty
      });
    } catch (error) {
      console.error("Error updating quantity:", error);
    }
  };

  const removeItem = async (itemId: string) => {
    try {
      await deleteDoc(doc(db, 'carts', itemId));
    } catch (error) {
      console.error("Error removing item:", error);
    }
  };

  const calculateTotal = () => {
    return cartItems.reduce((acc, item) => {
      const addonsPrice = item.selectedAddOns?.reduce((sum, a) => sum + (a.price * a.quantity), 0) || 0;
      return acc + ((item.price + addonsPrice) * item.quantity);
    }, 0);
  };

  const canCheckout = calculateTotal() >= 10;

  const handleCheckout = () => {
    if (!user || cartItems.length === 0 || !canCheckout) return;
    navigate('/checkout');
  };

  if (loading) return (
    <div className="h-screen bg-black flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-bento-accent border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-6 text-center">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md"
        >
          <div className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-emerald-500/20">
            <Package size={48} className="text-black" />
          </div>
          <h2 className="text-4xl font-black italic tracking-tighter uppercase text-white mb-4">
            {t('product_details.order_placed_title')}
          </h2>
          <p className="text-neutral-400 mb-12">
            {t('product_details.order_placed_desc')}
          </p>
          <div className="flex flex-col gap-4">
            <Link 
              to="/orders" 
              className="w-full bg-white text-black font-black py-5 rounded-3xl uppercase tracking-widest text-sm hover:scale-105 transition-transform active:scale-95"
            >
              {t('nav.my_orders')}
            </Link>
            <button 
              onClick={() => navigate('/')} 
              className="text-neutral-500 font-bold hover:text-white transition-colors"
            >
              {t('product_details.back_to_store')}
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-black text-white pb-32 ${dir === 'rtl' ? 'font-arabic' : ''}`}>
      {/* Header */}
      <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-md border-b border-neutral-900 p-6">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="w-12 h-12 bg-bento-accent/10 rounded-2xl flex items-center justify-center text-bento-accent border border-bento-accent/20">
               <ShoppingBasket size={24} />
             </div>
             <div>
               <h1 className="text-2xl font-black italic tracking-tighter uppercase">{t('nav.cart')}</h1>
               <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold">
                 {cartItems.length} {t('seller_dashboard.count')}
               </p>
             </div>
          </div>
          <button 
            onClick={() => navigate(-1)}
            className="p-3 hover:bg-neutral-800 rounded-2xl transition-colors"
          >
            <ArrowRight size={24} className={dir === 'rtl' ? '' : 'rotate-180'} />
          </button>
        </div>
      </div>

      <div className="max-w-2xl mx-auto p-6">
        {cartItems.length === 0 ? (
          <div className="py-20 text-center">
            <div className="w-24 h-24 bg-neutral-900 rounded-[40px] flex items-center justify-center mx-auto mb-6 border border-neutral-800">
              <ShoppingBag size={40} className="text-neutral-700" />
            </div>
            <h2 className="text-xl font-bold mb-2">{dir === 'rtl' ? 'السلة فارغة' : 'Your cart is empty'}</h2>
            <p className="text-neutral-500 text-sm mb-8">{dir === 'rtl' ? 'اكتشف المنتجات وأضفها إلى السلة' : 'Discover products and add them to your cart'}</p>
            <Link 
              to="/explore" 
              className="inline-flex items-center gap-2 bg-bento-accent text-black px-8 py-4 rounded-3xl font-black uppercase tracking-widest text-xs hover:scale-105 transition-transform"
            >
              {t('nav.explore')}
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            <AnimatePresence>
              {cartItems.map((item) => (
                <motion.div 
                  key={item.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-neutral-900/50 border border-neutral-800 rounded-[32px] p-4 flex gap-4 items-center group"
                >
                  <img 
                    src={item.imageUrl} 
                    alt={item.title} 
                    className="w-24 h-24 rounded-2xl object-cover ring-1 ring-white/10"
                    referrerPolicy="no-referrer"
                  />
                  <div className={`flex-1 min-w-0 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    <h3 className="font-bold text-white truncate mb-1">{item.title}</h3>
                    
                    {/* Add-ons & Drinks */}
                    {(item.selectedAddOns && item.selectedAddOns.length > 0) || (item.selectedDrinks && item.selectedDrinks.length > 0) ? (
                      <div className="flex flex-wrap gap-1.5 mb-2">
                        {item.selectedAddOns?.map((addon, i) => (
                          <span key={i} className="text-[8px] font-black bg-white/5 border border-white/5 px-2 py-0.5 rounded text-neutral-400 uppercase tracking-widest">
                            +{addon.name}
                          </span>
                        ))}
                        {item.selectedDrinks?.map((drink, i) => (
                          <span key={i} className="text-[8px] font-black bg-bento-accent/10 border border-bento-accent/20 px-2 py-0.5 rounded text-bento-accent uppercase tracking-widest">
                            {drink}
                          </span>
                        ))}
                      </div>
                    ) : null}

                    <p className="text-bento-accent font-black italic uppercase tracking-tighter text-sm mb-3">
                      ${(item.price + (item.selectedAddOns?.reduce((sum, a) => sum + a.price * a.quantity, 0) || 0)).toFixed(2)}
                    </p>
                    
                    <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                      <div className="flex items-center bg-black border border-neutral-800 rounded-xl p-1 shrink-0">
                        <button 
                          onClick={() => updateQuantity(item.id, -1)}
                          className="p-1 hover:text-bento-accent transition-colors"
                        >
                          <Minus size={16} />
                        </button>
                        <span className="w-8 text-center text-xs font-black">{item.quantity}</span>
                        <button 
                          onClick={() => updateQuantity(item.id, 1)}
                          className="p-1 hover:text-bento-accent transition-colors"
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                      <button 
                        onClick={() => removeItem(item.id)}
                        className="text-neutral-600 hover:text-red-500 transition-colors p-2"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {/* Order Summary */}
            <div className="mt-12 bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 shadow-2xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5">
                 <CreditCard size={120} />
              </div>
              
              <h3 className="text-xl font-black italic tracking-tighter uppercase mb-6">{dir === 'rtl' ? 'ملخص الطلب' : 'Order Summary'}</h3>
              
              <div className="space-y-4 mb-8">
                <div className={`flex justify-between items-center text-neutral-400 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <span className="text-sm font-bold uppercase tracking-widest">{dir === 'rtl' ? 'عدد المنتجات' : 'Products'}</span>
                  <span className="font-mono">{cartItems.reduce((acc, i) => acc + i.quantity, 0)}</span>
                </div>
                <div className={`flex justify-between items-center text-neutral-400 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <span className="text-sm font-bold uppercase tracking-widest">{dir === 'rtl' ? 'التوصيل' : 'Shipping'}</span>
                  <span className="text-emerald-500 font-black italic uppercase tracking-tighter text-sm">FREE</span>
                </div>
                <div className="h-px bg-neutral-800" />
                <div className={`flex justify-between items-center ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <span className="text-lg font-black italic tracking-tighter uppercase">{dir === 'rtl' ? 'الإجمالي' : 'Total'}</span>
                  <span className="text-2xl font-black italic tracking-tighter uppercase text-white">${calculateTotal()}</span>
                </div>
              </div>

              {!canCheckout && cartItems.length > 0 && (
                <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex flex-col items-center text-center gap-3">
                  <p className="text-[10px] font-bold text-red-500 uppercase tracking-widest">
                    {t('product_form.min_order_warning')}
                  </p>
                  <button 
                    onClick={() => navigate('/')}
                    className="flex items-center gap-2 text-white bg-white/10 hover:bg-white/20 px-4 py-2 rounded-xl transition-all"
                  >
                    <ShoppingBag size={14} className="text-bento-accent" />
                    <span className="text-[10px] font-black uppercase tracking-widest">{t('product_form.order_more')}</span>
                  </button>
                </div>
              )}

              <button 
                onClick={handleCheckout}
                disabled={checkingOut || !canCheckout}
                className="w-full bg-white text-black h-16 rounded-[24px] font-black uppercase tracking-widest transition-all hover:bg-bento-accent active:scale-95 disabled:opacity-50 disabled:active:scale-100 flex items-center justify-center gap-3 group"
              >
                {checkingOut ? (
                  <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <CreditCard size={20} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    {dir === 'rtl' ? 'إتمام الشراء' : 'Checkout Now'}
                  </>
                )}
              </button>
            </div>
            
            {/* Safety Badges */}
            <div className="grid grid-cols-2 gap-4 mt-8">
               <div className="bg-white/5 border border-white/5 p-4 rounded-3xl flex items-center gap-3">
                 <ShieldCheck size={20} className="text-emerald-500" />
                 <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">{dir === 'rtl' ? 'دفع آمن' : 'Secure Pay'}</span>
               </div>
               <div className="bg-white/5 border border-white/5 p-4 rounded-3xl flex items-center gap-3">
                 <Truck size={20} className="text-blue-500" />
                 <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">{dir === 'rtl' ? 'توصيل سريع' : 'Fast Ship'}</span>
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const ShieldCheck = ({ size, className }: { size: number, className: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
    <path d="m9 12 2 2 4-4" />
  </svg>
);
