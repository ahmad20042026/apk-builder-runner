import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { 
  db, handleFirestoreError, getDocsResilient as getDocs,
  collection, query, doc, updateDoc, deleteDoc, orderBy, limit, where,
  incrementResilient as increment, serverTimestamp, onSnapshot
} from '../lib/firebase';
import { UserProfile, Product, Order, Dispute } from '../types';
import { useAuth } from '../context/AuthContext';
import { 
  Users, 
  ShoppingBag, 
  AlertCircle, 
  Ban, 
  CheckCircle, 
  Trash2, 
  Settings, 
  BadgeCheck, 
  ShieldCheck, 
  Eye, 
  Search, 
  X, 
  FileText, 
  Camera, 
  Briefcase, 
  Loader2, 
  ShieldAlert, 
  Gavel, 
  RefreshCcw, 
  DollarSign, 
  MapPin,
  LayoutDashboard,
  LogOut,
  Bell,
  Menu,
  ChevronRight,
  ChevronLeft,
  Activity,
  UserPlus,
  Package,
  Check,
  MessageSquare,
  Clock
} from 'lucide-react';
import { sendNotification } from '../lib/notifications';
import VerifiedBadge from '../components/VerifiedBadge';
import AdminGeography from '../components/AdminGeography';

export default function AdminPanel() {
  const navigate = useNavigate();
  const { profile, loading } = useAuth();
  const [isDataLoading, setIsDataLoading] = useState(false);

  useEffect(() => {
    if (!loading && profile && profile.role !== 'admin') {
      console.warn("Unauthorized access attempt to AdminPanel");
      navigate('/');
    }
  }, [profile, loading, navigate]);

  const [users, setUsers] = useState<UserProfile[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [stats, setStats] = useState({ totalSales: 0, totalRevenue: 0 });
  const [pendingCount, setPendingCount] = useState(0);
  const [activeTab, setActiveTab] = useState<'performance' | 'users' | 'verification' | 'products' | 'disputes' | 'geography' | 'orders' | 'settings'>('performance');
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth > 768);
  const [allOrders, setAllOrders] = useState<Order[]>([]);
  const [orderSearchTerm, setOrderSearchTerm] = useState('');
  const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);
  const [targetUserId, setTargetUserId] = useState<string | null>(null);
  const [adminMessage, setAdminMessage] = useState('');
  const [isSendingMessage, setIsSendingMessage] = useState(false);
  const [isCategoryMenuOpen, setIsCategoryMenuOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUserForDocs, setSelectedUserForDocs] = useState<UserProfile | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const productCategories = [
    { id: 'all', label: 'الكل' },
    { id: 'food', label: 'طعام جاهز' },
    { id: 'drinks', label: 'مشروبات' },
    { id: 'veg_fruits', label: 'خضار وفواكه' },
    { id: 'meat', label: 'لحوم وطواجن' },
    { id: 'supermarket', label: 'سوبر ماركت' },
    { id: 'desserts', label: 'حلويات وإضافات' },
    { id: 'electronics', label: 'إلكترونيات' },
    { id: 'home_appliances', label: 'أجهزة منزلية' }
  ];

  useEffect(() => {
    // 1. Static fetch for non-user data
    fetchNonUserData();

    // 2. Real-time listener for users
    let q;
    if (activeTab === 'verification') {
      q = query(collection(db, 'users'), where('verificationStatus', 'in', ['pending', 'pending_verification', 'rejected', 'verified']), limit(150));
    } else if (activeTab === 'users') {
      q = query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(100));
    } else {
      q = query(collection(db, 'users'), orderBy('createdAt', 'desc'), limit(20));
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const usersData = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
      
      const pCount = usersData.filter(u => u.verificationStatus === 'pending' || u.verificationStatus === 'pending_verification').length;
      setPendingCount(pCount);

      if (activeTab === 'verification' || activeTab === 'overview') {
        const sorted = usersData
          .sort((a, b) => {
            const isAPending = a.verificationStatus === 'pending' || a.verificationStatus === 'pending_verification';
            const isBPending = b.verificationStatus === 'pending' || b.verificationStatus === 'pending_verification';
            if (isAPending && !isBPending) return -1;
            if (!isAPending && isBPending) return 1;
            
            const dateA = a.updatedAt?.seconds || a.verificationDetails?.submittedAt?.seconds || 0;
            const dateB = b.updatedAt?.seconds || b.verificationDetails?.submittedAt?.seconds || 0;
            return dateB - dateA;
          });
        setUsers(sorted);
      } else {
        setUsers(usersData);
      }
      setIsDataLoading(false);
    }, (error) => {
      console.warn("AdminPanel: Real-time user fetch fail:", error);
      setIsDataLoading(false);
    });

    return () => unsubscribe();
  }, [activeTab]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth <= 768) {
        setIsSidebarOpen(false);
      } else {
        setIsSidebarOpen(true);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const [deletingProductId, setDeletingProductId] = useState<string | null>(null);

  const handleDeleteProduct = async (product: Product) => {
    if (!product || !product.id) return;
    setProductToDelete(product);
  };

  const executeDelete = async () => {
    if (!productToDelete) return;
    const product = productToDelete;
    
    setIsDeleting(true);
    setDeletingProductId(product.id);
    try {
      await deleteDoc(doc(db, 'products', product.id));
      
      if (product.sellerId) {
        await updateDoc(doc(db, 'users', product.sellerId), {
          currentProducts: increment(-1)
        }).catch(err => console.warn("Failed to decrement seller product count:", err));
      }
      
      if (product.sellerId) {
        await sendNotification(
          product.sellerId,
          'system',
          'تنبيه من الإدارة',
          `تم حذف منتجك "${product.title}" من قبل المسؤول.`
        ).catch(err => console.warn("Failed to notify seller about deletion:", err));
      }
      setProductToDelete(null);
      fetchNonUserData();
    } catch (error) {
      console.error("Error deleting product:", error);
      handleFirestoreError(error, 'write', `products/${product.id}`);
    } finally {
      setIsDeleting(false);
      setDeletingProductId(null);
    }
  };

  const fetchNonUserData = async () => {
    try {
      if (activeTab === 'products' || activeTab === 'overview') {
        const snap = await getDocs(query(collection(db, 'products'), orderBy('createdAt', 'desc'), limit(50)));
        setProducts(snap.docs.map((doc: any) => ({ id: doc.id, ...(doc.data() as object) } as Product)));
      }
      if (activeTab === 'disputes' || activeTab === 'overview') {
        const snap = await getDocs(query(collection(db, 'disputes'), orderBy('createdAt', 'desc'), limit(50)));
        setDisputes(snap.docs.map((doc: any) => ({ id: doc.id, ...(doc.data() as object) } as Dispute)));
      }
      
      const orderSnap = await getDocs(query(collection(db, 'orders'), orderBy('createdAt', 'desc')));
      const orders = orderSnap.docs.map((doc: any) => ({ id: doc.id, ...(doc.data() as object) } as Order));
      setAllOrders(orders);
      const totalRevenue = orders.reduce((acc: number, curr: Order) => acc + (curr.price || 0), 0);
      setStats({ totalSales: orders.length, totalRevenue });
    } catch (err) {
      console.warn("Non-user data fetch error:", err);
    }
  };

  const fetchData = async () => {
    // This function is now mostly for manual triggers if needed
    // The useEffect handle real-time sync
    setIsDataLoading(true);
    await fetchNonUserData();
    setIsDataLoading(false);
  };

  const performanceStats = React.useMemo(() => {
    const totalUsers = users.length;
    const activeUsers = users.filter(u => u.lastActiveAt).length; // Simplified
    const buyers = users.filter(u => (u.ordersCount || 0) > 0).length;
    const sellers = users.filter(u => u.role === 'seller').length;
    
    const ordersByRegion: Record<string, number> = {};
    const usersByRegion: Record<string, number> = {};
    
    users.forEach(u => {
      const reg = u.region || 'Unknown';
      usersByRegion[reg] = (usersByRegion[reg] || 0) + 1;
    });

    allOrders.forEach(o => {
      const reg = o.logistics?.deliveryLocation?.address?.split(',').pop()?.trim() || 'Unknown';
      ordersByRegion[reg] = (ordersByRegion[reg] || 0) + 1;
    });

    const storePerformance: Record<string, { name: string; revenue: number; orders: number; products: number }> = {};
    allOrders.forEach(o => {
      if (!storePerformance[o.sellerId]) {
        storePerformance[o.sellerId] = { name: o.sellerName || 'Unknown Store', revenue: 0, orders: 0, products: 0 };
      }
      storePerformance[o.sellerId].revenue += (o.price || 0);
      storePerformance[o.sellerId].orders += 1;
    });

    products.forEach(p => {
      if (storePerformance[p.sellerId]) {
        storePerformance[p.sellerId].products += 1;
      }
    });

    const sortedStores = Object.entries(storePerformance).sort((a, b) => b[1].revenue - a[1].revenue);

    return {
      totalUsers,
      activeUsers,
      buyers,
      sellers,
      usersByRegion,
      ordersByRegion,
      bestStores: sortedStores.slice(0, 5),
      worstStores: sortedStores.slice(-5).reverse(),
      purchaseRatio: totalUsers > 0 ? (buyers / totalUsers) * 100 : 0,
      activeBuyerRatio: activeUsers > 0 ? (buyers / activeUsers) * 100 : 0,
    };
  }, [users, allOrders, products]);

  const toggleUserRole = async (userId: string, currentRole: string) => {
    const newRole = currentRole === 'seller' ? 'buyer' : 'seller';
    await updateDoc(doc(db, 'users', userId), { role: newRole });
    fetchData();
  };

  const updateUserStatus = async (userId: string, updates: Partial<UserProfile>) => {
    try {
      await updateDoc(doc(db, 'users', userId), {
        ...updates,
        updatedAt: serverTimestamp()
      });
      fetchData();
    } catch (err) {
      console.error("Error updating user status:", err);
    }
  };

  const openMessageModal = (userId: string) => {
    setTargetUserId(userId);
    setIsMessageModalOpen(true);
  };

  const sendAdminMessage = async () => {
    if (!targetUserId || !adminMessage.trim()) return;
    setIsSendingMessage(true);
    try {
      await sendNotification(
        targetUserId,
        'system',
        'رسالة من الإدارة',
        adminMessage
      );
      // We can also store this message in a special "announcements" or "messages" collection if we want sticky messages
      alert('تم إرسال الرسالة بنجاح');
      setAdminMessage('');
      setIsMessageModalOpen(false);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSendingMessage(false);
    }
  };

  const menuItems = [
    { id: 'performance', label: 'الأداء والنمو الاستراتيجي', icon: Activity },
    { id: 'users', label: 'قاعدة بيانات المستخدمين', icon: Users },
    { id: 'verification', label: 'مركز توثيق الهوية', icon: ShoppingBag, badge: pendingCount },
    { id: 'orders', label: 'إدارة الطلبات الشاملة', icon: FileText },
    { id: 'products', label: 'إدارة الكاتالوج العالمي', icon: Package },
    { id: 'disputes', label: 'وحدة فض النزاعات', icon: ShieldAlert },
    { id: 'geography', label: 'الذكاء الجغرافي', icon: MapPin },
    { id: 'settings', label: 'إعدادات النظام', icon: Settings },
  ];

  const filteredUsers = useMemo(() => {
    let result = [...users];
    
    if (activeTab === 'verification') {
      // Custom hierarchical sort for verification center: Pending > Verified > Rejected
      result = result.sort((a, b) => {
        const getPriority = (u: UserProfile) => {
          if (u.verificationStatus === 'pending' || u.verificationStatus === 'pending_verification') return 0;
          if (u.isVerified || u.verificationStatus === 'verified') return 1;
          if (u.verificationStatus === 'rejected') return 2;
          return 3;
        };
        const pA = getPriority(a);
        const pB = getPriority(b);
        if (pA !== pB) return pA - pB;
        
        // Secondary sort: most recently updated first within groups
        const dateA = a.updatedAt?.seconds || 0;
        const dateB = b.updatedAt?.seconds || 0;
        return dateB - dateA;
      });
      
      // Filter for verification tab usually shows anyone with a status or details
      result = result.filter(u => 
        u.verificationStatus === 'pending' || 
        u.verificationStatus === 'pending_verification' ||
        !!u.verificationDetails || 
        ['verified', 'rejected'].includes(u.verificationStatus || '')
      );
    }
    
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      result = result.filter(u => 
        u.displayName?.toLowerCase().includes(search) || 
        u.email?.toLowerCase().includes(search) ||
        u.uid.toLowerCase().includes(search)
      );
    }
    
    return result;
  }, [users, searchTerm, activeTab]);

  return (
    <div className="flex h-screen bg-[#080808] text-white font-sans overflow-hidden select-none" dir="rtl">
      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[45] md:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar - Isolated Design */}
      <aside className={`
        ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}
        fixed md:relative right-0 h-full w-80 md:w-auto
        ${isSidebarOpen ? 'md:w-80' : 'md:w-24'} 
        bg-[#111111] border-l border-white/5 flex flex-col transition-all duration-500 ease-in-out z-50 shadow-[20px_0_50px_rgba(0,0,0,0.5)]
      `}>
        <div className="p-8 flex items-center gap-5">
          <div className="w-12 h-12 bg-bento-accent rounded-2xl flex items-center justify-center shrink-0 shadow-[0_0_20px_rgba(var(--bento-accent-rgb),0.3)]">
            <Activity className="text-black" size={28} />
          </div>
            {(isSidebarOpen || window.innerWidth < 768) && (
              <div className="animate-in fade-in slide-in-from-right-8 duration-500">
                <h2 className="font-black italic text-xl tracking-tighter leading-none mb-1 text-white">CORE SYSTEM</h2>
                <p className="text-[10px] text-neutral-500 font-black uppercase tracking-[0.2em] leading-none">v4.5 Administrative</p>
              </div>
            )}
        </div>

        {/* Removed Diagnostic Panel for cleaner UI */}

        <nav className="flex-1 px-5 mt-4 space-y-3">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id as any);
                if (window.innerWidth <= 768) setIsSidebarOpen(false);
              }}
              className={`w-full flex items-center gap-5 p-4 rounded-[24px] transition-all duration-300 group relative ${
                activeTab === item.id 
                ? 'bg-gradient-to-l from-white/[0.08] to-transparent text-bento-accent' 
                : 'text-neutral-500 hover:text-white hover:bg-white/[0.02]'
              }`}
            >
              <item.icon size={22} className={`${activeTab === item.id ? 'stroke-[2.5px]' : 'group-hover:scale-110 transition-transform'}`} />
              {isSidebarOpen && <span className="font-bold text-sm tracking-tight">{item.label}</span>}
              
              {activeTab === item.id && (
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-bento-accent rounded-l-full shadow-[0_0_15px_rgba(var(--bento-accent-rgb),0.8)]" />
              )}
              
              {item.badge > 0 && isSidebarOpen && (
                <span className="mr-auto bg-red-600 text-white text-[10px] px-2.5 py-1 rounded-lg font-black shadow-lg shadow-red-600/20 animate-pulse">
                  {item.badge}
                </span>
              )}

              {!isSidebarOpen && item.badge > 0 && (
                <div className="absolute top-2 right-2 w-3 h-3 bg-red-600 rounded-full border-2 border-[#111111]" />
              )}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5 space-y-4">
          <button 
            onClick={() => navigate('/')}
            className="w-full flex items-center gap-5 p-4 rounded-[24px] text-neutral-500 hover:text-red-500 hover:bg-red-500/5 transition-all group"
          >
            <LogOut size={22} className="group-hover:-translate-x-1 transition-transform" />
            {isSidebarOpen && <span className="font-bold text-sm">مغادرة النظام</span>}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden relative w-full">
        {/* Isolated Header */}
        <header className="h-20 md:h-24 bg-[#0A0A0A]/80 backdrop-blur-3xl border-b border-white/5 px-4 md:px-10 flex items-center justify-between z-40 shrink-0">
          <div className="flex items-center gap-4 md:gap-6">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)} 
              className="p-2 md:p-3 bg-white/5 hover:bg-white/10 rounded-xl md:rounded-2xl text-neutral-400 transition-colors"
            >
              {isSidebarOpen ? <ChevronRight size={22} /> : <Menu size={22} />}
            </button>
            <div className="flex flex-col">
              <span className="hidden md:block text-[10px] font-black text-bento-accent uppercase tracking-[0.3em] mb-1 italic">Authorized Personnel Only</span>
              <h1 className="font-black text-lg md:text-2xl tracking-tighter uppercase italic flex items-center gap-2 md:gap-3 shrink-0">
                <span className="truncate max-w-[150px] md:max-w-none">{menuItems.find(i => i.id === activeTab)?.label}</span>
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shrink-0" />
              </h1>
            </div>
            {activeTab === 'products' && (
              <button 
                onClick={() => setIsCategoryMenuOpen(true)}
                className="md:hidden p-2 bg-white/5 rounded-xl text-bento-accent"
              >
                <ShoppingBag size={20} />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2 md:gap-8 overflow-hidden pl-2">
            <div className="hidden lg:flex items-center gap-3 bg-white/[0.03] border border-white/5 rounded-2xl px-6 py-3 focus-within:border-bento-accent/50 transition-all shrink-0">
              <Search size={18} className="text-neutral-600" />
              <input 
                type="text" 
                placeholder="البحث في سجلات النظام..." 
                className="bg-transparent border-none text-xs font-bold focus:outline-none placeholder:text-neutral-700 w-64"
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex items-center gap-2 md:gap-4 shrink-0">
               <button className="p-2 md:p-4 bg-white/5 rounded-xl md:rounded-2xl text-neutral-400 hover:text-white relative transition-colors">
                  <Bell size={20} className="md:w-[22px] md:h-[22px]" />
                  <div className="absolute top-1.5 right-1.5 md:top-3.5 md:right-3.5 w-2 h-2 md:w-2.5 md:h-2.5 bg-red-600 rounded-full border-2 border-[#121212]" />
               </button>
               <div className="hidden md:block h-10 w-px bg-white/5 mx-2" />
               <div className="flex items-center gap-2 md:gap-4 group cursor-pointer pl-1 pr-1 md:pl-2 md:pr-4 py-1.5 md:py-2 bg-white/5 rounded-xl md:rounded-2xl border border-white/5 hover:bg-white/10 transition-all">
                  <div className="hidden md:flex flex-col text-left items-end">
                    <span className="text-xs font-black text-white italic uppercase">Admin Root</span>
                    <span className="text-[9px] text-neutral-500 font-bold uppercase">System Owner</span>
                  </div>
                  <div className="w-8 h-8 md:w-12 md:h-12 rounded-lg md:rounded-xl overflow-hidden border border-bento-accent shadow-lg shadow-bento-accent/10">
                    <img src="https://api.dicebear.com/7.x/identicon/svg?seed=AdminCore" alt="Admin" className="w-full h-full object-cover" />
                  </div>
                </div>
              </div>
            </div>
          </header>

        {/* Dashboard Scrolling Panel */}
        <div className="flex-1 overflow-y-auto p-4 md:p-10 no-scrollbar space-y-8 md:space-y-10 bg-[radial-gradient(circle_at_50%_0%,rgba(var(--bento-accent-rgb),0.05),transparent_50%)]">
          
          {activeTab === 'performance' && (
            <PerformanceView stats={performanceStats} allUsers={users} allOrders={allOrders} allProducts={products} />
          )}

          {(activeTab === 'users' || activeTab === 'verification') && (
            <div className="animate-in slide-in-from-bottom-10 duration-700">
               <div className="bg-[#121212] rounded-[48px] border border-white/5 overflow-hidden shadow-2xl">
                  <div className="p-6 md:p-10 border-b border-white/5 bg-white/[0.01] flex flex-col md:flex-row gap-6 md:gap-8 items-center justify-between text-center md:text-right">
                    <div>
                      <h3 className="font-black italic text-xl md:text-2xl tracking-tighter uppercase mb-1">
                        {activeTab === 'verification' ? 'مركز توثيق الهوية' : 'مركز التحكم في الكيانات'}
                      </h3>
                      <p className="text-neutral-500 text-[10px] md:text-xs font-bold uppercase tracking-widest">
                        {activeTab === 'verification' ? 'مراجعة وتوثيق الكيانات التجارية والشخصية' : 'إدارة الصلاحيات، الحظر، والتحقق المستندي'}
                      </p>
                    </div>
                    <div className="flex flex-col sm:flex-row items-center gap-4 w-full max-w-lg mt-4 md:mt-0">
                      <div className="w-full flex-1 bg-white/[0.03] border border-white/5 rounded-2xl md:rounded-3xl px-4 md:px-6 py-3 md:py-4 flex items-center gap-3 md:gap-4 focus-within:border-bento-accent transition-all">
                        <Search size={20} className="text-neutral-600 shrink-0" />
                        <input 
                          type="text" 
                          placeholder="ابحث بالاسم، البريد، أو المعرف..." 
                          className="bg-transparent border-none text-xs md:text-sm font-bold focus:outline-none w-full placeholder:text-neutral-700"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                        />
                      </div>
                      <button onClick={fetchData} className="w-full sm:w-auto p-4 md:p-5 bg-white/5 rounded-2xl md:rounded-3xl hover:text-bento-accent transition-colors border border-white/5 flex justify-center shrink-0"><RefreshCcw size={20} /></button>
                    </div>
                  </div>

                  <div className="overflow-x-auto overflow-y-hidden">
                    <table className="w-full text-right border-collapse">
                      <thead>
                        <tr className="bg-black/40 border-b border-white/5">
                          <th className="px-10 py-8 text-[11px] font-black uppercase tracking-[0.2em] text-neutral-600">المستخدم الأساسي</th>
                          <th className="px-10 py-8 text-[11px] font-black uppercase tracking-[0.2em] text-neutral-600">التصنيف النظامي</th>
                          <th className="px-10 py-8 text-[11px] font-black uppercase tracking-[0.2em] text-neutral-600">البيانات المالية</th>
                          <th className="px-10 py-8 text-[11px] font-black uppercase tracking-[0.2em] text-neutral-600">بروتوكول التحقق</th>
                          <th className="px-10 py-8 text-[11px] font-black uppercase tracking-[0.2em] text-neutral-600 text-left">إجراءات المسار السريع</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                         {filteredUsers.map((u, idx) => (
                          <tr key={`${u.uid}-${idx}`} className="hover:bg-white/[0.02] transition-colors group">
                            <td className="px-10 py-8">
                               <div className="flex items-center gap-5">
                                 <div className="w-16 h-16 rounded-2xl bg-neutral-800 border border-white/5 overflow-hidden flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform duration-500">
                                   {u.photoURL ? <img src={u.photoURL} alt="" className="w-full h-full object-cover" /> : <Users size={28} className="text-neutral-600" />}
                                 </div>
                                 <div className="flex flex-col">
                                    <div className="flex items-center gap-2">
                                      <span className="font-black text-lg text-white group-hover:text-bento-accent transition-colors">{u.displayName}</span>
                                      {u.isVerified && <VerifiedBadge size={14} />}
                                    </div>
                                    <span className="text-[11px] font-mono text-neutral-500 uppercase tracking-tighter mt-1">{u.email}</span>
                                 </div>
                               </div>
                            </td>
                            <td className="px-10 py-8">
                               <span className={`px-5 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                                 u.role === 'admin' ? 'bg-red-500/10 text-red-500 border-red-500/20' :
                                 u.role === 'seller' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20 shadow-lg shadow-emerald-500/5' :
                                 'bg-white/5 text-neutral-500 border-white/10'
                               }`}>
                                 {u.role === 'admin' ? 'قائد نظام' : u.role === 'seller' ? 'شريك تجاري' : 'مستهلك'}
                               </span>
                            </td>
                            <td className="px-10 py-8">
                               <div className="flex flex-col">
                                 <span className="text-base font-black text-white italic tracking-tighter">${(u.totalEarnings || 0).toLocaleString()}</span>
                                 <span className="text-[10px] font-bold text-neutral-600 uppercase tracking-widest">{u.salesCount || 0} عملية مكتملة</span>
                               </div>
                            </td>
                            <td className="px-10 py-8">
                               {(u.verificationStatus === 'pending' || u.verificationStatus === 'pending_verification') ? (
                                 <div className="flex items-center gap-3 text-amber-500 bg-amber-500/5 border border-amber-500/10 px-4 py-2 rounded-2xl w-fit animate-pulse">
                                    <Loader2 size={18} className="animate-spin" />
                                    <span className="text-[10px] font-black uppercase italic">قيد الفحص</span>
                                 </div>
                               ) : u.isVerified || u.verificationStatus === 'verified' ? (
                                 <div className="flex items-center gap-3 text-emerald-500 bg-emerald-500/5 border border-emerald-500/10 px-4 py-2 rounded-2xl w-fit">
                                    <BadgeCheck size={18} className="animate-in fade-in zoom-in" />
                                    <span className="text-[10px] font-black uppercase italic">نظام موثق</span>
                                 </div>
                               ) : u.verificationStatus === 'rejected' ? (
                                 <div className="flex items-center gap-3 text-red-500 bg-red-500/5 border border-red-500/10 px-4 py-2 rounded-2xl w-fit">
                                    <ShieldAlert size={18} />
                                    <span className="text-[10px] font-black uppercase italic">مرفوض</span>
                                 </div>
                               ) : (
                                 <div className="flex items-center gap-3 text-neutral-600 border border-white/5 px-4 py-2 rounded-2xl w-fit">
                                    <AlertCircle size={18} />
                                    <span className="text-[10px] font-black uppercase italic">خارج التحقق</span>
                                 </div>
                               )}
                            </td>
                            <td className="px-10 py-8">
                               <div className="flex gap-4 justify-start transition-all duration-300">
                                  {(u.verificationStatus === 'pending' || u.verificationStatus === 'pending_verification' || u.verificationDetails) && (
                                    <button 
                                      onClick={() => setSelectedUserForDocs(u)}
                                      className="p-3 bg-bento-accent text-black rounded-xl hover:scale-110 active:scale-95 transition-all shadow-xl shadow-bento-accent/30"
                                      title="فحص المستندات"
                                    >
                                      <Eye size={20} />
                                    </button>
                                  )}
                                  <button 
                                    onClick={() => toggleUserRole(u.uid, u.role)}
                                    className="p-3 bg-white/5 text-neutral-400 rounded-xl hover:text-bento-accent hover:bg-white/10 transition-all border border-white/5"
                                    title="تغيير صلاحيات الحساب"
                                  >
                                    <RefreshCcw size={20} />
                                  </button>
                                  <button 
                                    onClick={() => openMessageModal(u.uid)}
                                    className="p-3 bg-blue-600/10 text-blue-500 rounded-xl hover:bg-blue-600 hover:text-white transition-all border border-blue-600/10"
                                    title="إرسال رسالة إدارية"
                                  >
                                    <MessageSquare size={20} />
                                  </button>
                                  <button 
                                    onClick={() => updateUserStatus(u.uid, { isFrozen: !u.isFrozen })}
                                    className={`p-3 rounded-xl transition-all border ${u.isFrozen ? 'bg-orange-600 text-white border-orange-600' : 'bg-orange-600/10 text-orange-600 border-orange-600/10 hover:bg-orange-600 hover:text-white'}`}
                                    title={u.isFrozen ? 'إلغاء تجميد الحساب' : 'تجميد الحساب'}
                                  >
                                    <Clock size={20} />
                                  </button>
                                  <button 
                                    onClick={() => updateUserStatus(u.uid, { isBanned: !u.isBanned })}
                                    className={`p-3 rounded-xl transition-all border ${u.isBanned ? 'bg-red-600 text-white border-red-600' : 'bg-red-600/10 text-red-600 border-red-600/10 hover:bg-red-600 hover:text-white'}`}
                                    title={u.isBanned ? 'إلغاء حظر الكيان' : 'حظر الكيان نهائياً'}
                                  >
                                    <Ban size={20} />
                                  </button>
                               </div>
                            </td>
                          </tr>
                        ))}
                        {filteredUsers.length === 0 && !isDataLoading && (
                          <tr>
                            <td colSpan={5} className="py-32 text-center">
                               <div className="flex flex-col items-center gap-4 opacity-20">
                                  {activeTab === 'verification' ? <ShieldCheck size={64} strokeWidth={1} /> : <Users size={64} strokeWidth={1} />}
                                  <span className="font-black italic uppercase tracking-widest text-sm">
                                    {activeTab === 'verification' ? 'لا يوجد طلبات توثيق معلقة' : 'لا يوجد كائنات في هذا النطاق حالياً'}
                                  </span>
                               </div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
               </div>
            </div>
          )}

          {activeTab === 'products' && (
            <div className="animate-in fade-in duration-700 space-y-8">
                <div className="bg-[#121212] p-6 md:p-10 rounded-[32px] md:rounded-[48px] border border-white/5 flex flex-col md:flex-row justify-between items-center text-center md:text-right gap-6 md:gap-8 mb-8">
                   <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6 w-full md:w-auto">
                     <div className="w-12 h-12 md:w-16 md:h-16 bg-bento-accent/10 text-bento-accent rounded-2xl md:rounded-3xl flex items-center justify-center shrink-0">
                       <ShoppingBag size={28} className="md:w-9 md:h-9" />
                     </div>
                     <div className="w-full md:w-auto">
                        <div className="relative">
                          <input 
                            type="text" 
                            className="w-full md:w-64 bg-black border border-white/10 rounded-2xl px-5 py-3 pr-10 focus:border-bento-accent outline-none text-sm font-bold"
                            placeholder="ابحث..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                          />
                          <Search className="absolute right-4 top-3.5 text-neutral-500" size={16} />
                        </div>
                     </div>
                   </div>
                   
                   <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2 w-full md:w-auto justify-center md:justify-end">
                      {productCategories.map(cat => (
                        <button
                          key={cat.id}
                          onClick={() => setSelectedCategory(cat.id === 'all' ? null : cat.id)}
                          className={`px-4 py-2 rounded-xl font-bold text-[10px] uppercase tracking-widest whitespace-nowrap transition-all border ${
                            (selectedCategory === cat.id || (!selectedCategory && cat.id === 'all'))
                            ? 'bg-bento-accent text-black border-bento-accent' 
                            : 'bg-black border-white/5 text-neutral-500 hover:border-white/10'
                          }`}
                        >
                          {cat.label}
                        </button>
                      ))}
                   </div>
                </div>

               <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 md:gap-8">
                  {products.filter(p => {
                    const matchesSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                                          p.sellerName.toLowerCase().includes(searchTerm.toLowerCase());
                    const matchesCategory = !selectedCategory || p.category === selectedCategory;
                    return matchesSearch && matchesCategory;
                  }).map((product, idx) => (
                    <div key={`${product.id}-${idx}`} className="bg-[#121212] rounded-[32px] md:rounded-[40px] border border-white/5 overflow-hidden group hover:border-bento-accent/40 transition-all duration-500 flex flex-col">
                       <div className="aspect-[4/3] relative overflow-hidden bg-black flex items-center justify-center">
                          <img src={product.images[0]} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000 opacity-80 group-hover:opacity-100" />
                          <div className="absolute top-4 md:top-6 right-4 md:right-6 bg-black/80 backdrop-blur-xl border border-white/10 px-3 md:px-4 py-1.5 md:py-2 rounded-xl md:rounded-2xl text-[10px] md:text-xs font-black italic tracking-tighter text-bento-accent shadow-2xl">
                             ${product.price ? product.price.toLocaleString() : '0'}
                          </div>
                          {product.category && (
                            <div className="absolute bottom-4 left-4 bg-bento-accent/10 backdrop-blur-md border border-bento-accent/20 px-3 py-1 rounded-lg text-[8px] font-black uppercase text-bento-accent tracking-widest">
                              {productCategories.find(c => c.id === product.category)?.label || product.category}
                            </div>
                          )}
                       </div>
                       <div className="p-5 md:p-8 flex-1 flex flex-col">
                          <div className="flex justify-between items-start mb-3 md:mb-4">
                             <h3 className="font-black text-sm md:text-xl italic tracking-tighter truncate">{product.title}</h3>
                          </div>
                          <div className="flex items-center gap-2 md:gap-3 mb-4 md:mb-6">
                             <div className="w-5 h-5 md:w-6 md:h-6 rounded-lg bg-neutral-800 border border-white/5 flex items-center justify-center overflow-hidden">
                                <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${product.sellerName}`} alt="" />
                             </div>
                             <span className="text-[8px] md:text-[10px] font-black text-neutral-500 uppercase tracking-widest">{product.sellerName}</span>
                          </div>
                          <div className="mt-auto flex gap-2 md:gap-3 pt-4 md:pt-6 border-t border-white/5">
                             <button className="flex-1 py-2 md:py-3 bg-white/5 hover:bg-white/10 text-white rounded-xl md:rounded-2xl text-[8px] md:text-[10px] font-black uppercase tracking-widest transition-all">مراجعة</button>
                              <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteProduct(product);
                                }}
                                disabled={deletingProductId === product.id}
                                className={`p-2 md:p-3 rounded-xl md:rounded-2xl transition-all border flex items-center justify-center z-50 ${
                                  deletingProductId === product.id
                                  ? 'bg-neutral-800 border-neutral-700 text-neutral-500'
                                  : 'bg-red-600/10 text-red-600 border-red-600/10 hover:bg-red-600 hover:text-white'
                                }`}
                              >
                               {deletingProductId === product.id ? (
                                 <Loader2 size={16} className="animate-spin" />
                               ) : (
                                 <Trash2 size={16} />
                               )}
                             </button>
                          </div>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
          )}

          {activeTab === 'disputes' && (
            <div className="space-y-10 animate-in slide-in-from-bottom-10 duration-700">
               <div className="bg-[#121212] p-6 md:p-10 rounded-[32px] md:rounded-[48px] border border-white/5 flex flex-col md:flex-row justify-between items-center text-center md:text-right gap-6 md:gap-8">
                  <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
                    <div className="w-12 h-12 md:w-16 md:h-16 bg-red-600/10 text-red-600 rounded-2xl md:rounded-3xl flex items-center justify-center shrink-0">
                      <ShieldAlert size={28} className="md:w-9 md:h-9" />
                    </div>
                    <div>
                      <h2 className="text-xl md:text-3xl font-black italic tracking-tighter uppercase leading-tight">مركز النزاعات والعدالة</h2>
                      <p className="text-neutral-500 font-bold uppercase tracking-widest text-[10px] md:text-xs mt-1">وحدة التحكيم بين البائع والمشتري</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 w-full md:w-auto mt-4 md:mt-0">
                    <div className="w-full md:w-auto bg-white/5 border border-white/5 px-6 md:px-8 py-3 md:py-4 rounded-2xl md:rounded-3xl font-black text-lg md:text-xl italic text-red-500 text-center">
                      {disputes.length} نزاعات مفتوحة
                    </div>
                  </div>
               </div>

               <div className="grid grid-cols-1 gap-8">
                  {disputes.length === 0 ? (
                    <div className="bg-[#121212] border border-white/5 border-dashed rounded-[48px] p-24 text-center">
                       <Gavel size={64} className="mx-auto mb-6 text-neutral-800" />
                       <h3 className="text-2xl font-black italic text-neutral-600 uppercase tracking-tighter">السجلات نظيفة حالياً</h3>
                       <p className="text-neutral-500 font-bold uppercase tracking-[0.2em] mt-2 text-xs">لا توجد بلاغات نشطة تتطلب تدخل قضاة النظام</p>
                    </div>
                  ) : (
                    disputes.map((dispute: Dispute) => (
                      <DisputeCard key={dispute.id} dispute={dispute} onRefresh={fetchData} />
                    ))
                  )}
               </div>
            </div>
          )}

          {activeTab === 'geography' && (
             <div className="animate-in fade-in duration-700">
               <div className="bg-[#121212] rounded-[32px] md:rounded-[48px] border border-white/5 p-6 md:p-12">
                  <div className="flex flex-col md:flex-row justify-between items-center text-center md:text-right mb-8 md:mb-12 gap-6 md:gap-8">
                     <div>
                        <h2 className="text-xl md:text-3xl font-black italic tracking-tighter uppercase">خرائط الكثافة السكانية</h2>
                        <p className="text-neutral-500 font-bold uppercase tracking-widest mt-1 md:mt-2 text-[10px] md:text-xs">توزيع الكيانات والأنشطة المالية حسب النطاق الجغرافي</p>
                     </div>
                     <div className="flex gap-4">
                        <div className="bg-white/5 border border-white/5 px-6 py-3 rounded-2xl text-[10px] md:text-xs font-black uppercase tracking-widest">Global Analytics</div>
                     </div>
                  </div>
                  <div className="aspect-video bg-black/40 rounded-[24px] md:rounded-[40px] border border-white/5 overflow-hidden grayscale contrast-125">
                     <AdminGeography />
                  </div>
               </div>
             </div>
          )}

          {activeTab === 'orders' && (
            <OrdersManagementView orders={allOrders} onRefresh={fetchData} />
          )}

          {activeTab === 'settings' && (
             <div className="animate-in fade-in duration-700 max-w-4xl mx-auto space-y-10 py-8 md:py-12">
                <div className="text-center mb-8 md:mb-12">
                   <div className="w-16 h-16 md:w-24 md:h-24 bg-white/5 rounded-[24px] md:rounded-[32px] mx-auto mb-6 md:mb-8 flex items-center justify-center text-neutral-500 border border-white/5">
                      <Settings size={36} className="md:w-12 md:h-12" />
                   </div>
                   <h2 className="text-2xl md:text-4xl font-black italic tracking-tighter uppercase mb-2 md:mb-4">تكوين النواة المركزية</h2>
                   <p className="text-neutral-500 font-bold uppercase tracking-widest text-[10px] md:text-xs px-4">تحذير: التغييرات في هذه المنطقة قد تؤثر على استقرار العمليات العالمية</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
                   {[
                     { label: 'عمولات النظام', val: '10.0%', status: 'نشط', icon: DollarSign },
                     { label: 'وضع الصيانة التجاري', val: 'OFF', status: 'مستقر', icon: Activity },
                     { label: 'تراخيص البائعين الجدد', val: 'OPEN', status: 'مفتوح', icon: UserPlus },
                     { label: 'نظام الكوبونات العالمي', val: 'ENABLE', status: 'نشط', icon: BadgeCheck }
                   ].map((conf, c) => (
                     <div key={`${conf.label}-${c}`} className="bg-[#121212] border border-white/5 p-6 md:p-8 rounded-[32px] md:rounded-[40px] flex items-center justify-between group hover:border-bento-accent transition-colors cursor-pointer">
                        <div className="flex items-center gap-6">
                           <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center text-neutral-400 group-hover:text-white transition-colors">
                              <conf.icon size={28} />
                           </div>
                           <div>
                              <div className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-1">{conf.label}</div>
                              <div className="text-2xl font-black text-white italic tracking-tighter">{conf.val}</div>
                           </div>
                        </div>
                        <div className="text-[9px] font-black text-emerald-500 uppercase tracking-widest px-3 py-1 bg-emerald-500/10 rounded-full">{conf.status}</div>
                     </div>
                   ))}
                </div>
                
                <div className="bg-red-600/10 border border-red-600/20 p-10 rounded-[48px] mt-12 text-center group hover:bg-red-600 transition-all cursor-pointer">
                   <ShieldAlert size={40} className="mx-auto mb-4 text-red-600 group-hover:text-white" />
                   <h3 className="font-black italic text-xl uppercase tracking-tighter group-hover:text-white">بروتوكول التدمير الذاتي / الطوارئ القصوى</h3>
                   <p className="text-red-500/60 font-bold uppercase tracking-[0.2em] mt-2 text-[10px] group-hover:text-white/80">هذا الإجراء سيقوم بتجميد كافة العمليات المالية واغلاق مداخل المنصة فوراً</p>
                </div>
             </div>
          )}
        </div>
      </main>

      {/* Modern Isolation Modal */}
      {selectedUserForDocs && (
        <VerificationReviewModal 
          user={selectedUserForDocs} 
          onClose={() => setSelectedUserForDocs(null)}
          onRefresh={fetchData}
        />
      )}

      <AdminMessageModal 
        isOpen={isMessageModalOpen}
        onClose={() => setIsMessageModalOpen(false)}
        onSend={sendAdminMessage}
        message={adminMessage}
        setMessage={setAdminMessage}
        isLoading={isSendingMessage}
      />
    </div>
  );
}

// Sub-components with Isolated Styling
interface DisputeCardProps {
  dispute: Dispute;
  onRefresh: () => void | Promise<void>;
  key?: React.Key;
}

const DisputeCard: React.FC<DisputeCardProps> = ({ dispute, onRefresh }) => {
  const [order, setOrder] = useState<Order | null>(null);
  const [isDisputeLoading, setIsDisputeLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    const getOrderData = async () => {
       try {
         const oDoc = await getDocs(query(collection(db, 'orders'), where('id', '==', dispute.orderId)));
         if (!oDoc.empty) {
           setOrder({ id: oDoc.docs[0].id, ...(oDoc.docs[0].data() as object) } as Order);
         }
       } catch (error) {
         console.error(error);
       } finally {
         setIsDisputeLoading(false);
       }
    };
    getOrderData();
  }, [dispute.orderId]);

  const resolveDispute = async (decision: 'refund' | 'release' | 'reject') => {
    if (!order) return;
    setActionLoading(true);
    try {
      const disputeRef = doc(db, 'disputes', dispute.id);
      const orderRef = doc(db, 'orders', order.id);
      const sellerRef = doc(db, 'users', order.sellerId);

      if (decision === 'refund') {
        await updateDoc(orderRef, { paymentStatus: 'refunded', status: 'refunded' });
        await updateDoc(disputeRef, { status: 'resolved_buyer', adminNotes: 'System forced refund to buyer' });
        await sendNotification(order.buyerId, 'system', 'تنبيه النزاع', `تم استعادة المبلغ لطلبك ${order.productTitle}`, '/orders');
      } else if (decision === 'release') {
        await updateDoc(sellerRef, {
          totalEarnings: increment(order.price),
          withdrawableBalance: increment(order.netAmount)
        });
        await updateDoc(orderRef, { paymentStatus: 'released', status: 'completed' });
        await updateDoc(disputeRef, { status: 'resolved_seller', adminNotes: 'Funds released to seller by authority' });
        await sendNotification(order.sellerId, 'sale', 'فوز بنزاع', `تم تحرير الأموال لمنتجكم ${order.productTitle}`, '/seller');
      } else {
        await updateDoc(disputeRef, { status: 'rejected' });
      }
      onRefresh();
    } catch (error) {
      console.error(error);
    } finally {
      setActionLoading(false);
    }
  };

  if (isDisputeLoading) return <div className="h-64 bg-[#121212] rounded-[48px] border border-white/5 animate-pulse" />;

  return (
    <div className="bg-[#121212] border border-white/5 rounded-[48px] overflow-hidden group hover:border-red-600/30 transition-all duration-500 shadow-2xl">
      <div className="p-10 flex flex-col xl:flex-row gap-12">
        <div className="flex-1 space-y-6">
          <div className="flex items-center gap-4">
             <div className="px-5 py-2 bg-red-600/10 text-red-600 border border-red-600/20 rounded-full text-[10px] font-black uppercase tracking-widest italic animate-pulse">نزاع مفتوح</div>
             <span className="text-xs font-bold text-neutral-600 uppercase tracking-[0.2em]">ID: {dispute.id.slice(0, 8)}</span>
          </div>
          
          <h3 className="text-4xl font-black italic tracking-tighter uppercase text-white leading-none">
             {dispute.reason.replace(/_/g, ' ')}
          </h3>
          
          <div className="bg-black/40 p-8 rounded-[32px] border border-white/5 relative">
             <div className="text-neutral-500 text-[10px] font-black uppercase tracking-widest mb-4 italic">بيان المشتري (الشاكي)</div>
             <p className="text-lg font-medium text-neutral-300 leading-relaxed">"{dispute.description}"</p>
             <div className="absolute top-6 left-8"><ShieldAlert size={28} className="text-red-900 opacity-20" /></div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
             {dispute.images.map((img, i) => (
               <a key={i} href={img} target="_blank" rel="noreferrer" className="aspect-square rounded-3xl overflow-hidden border border-white/5 hover:border-bento-accent transition-all group/img">
                 <img src={img} alt="Evidence" className="w-full h-full object-cover group-hover/img:scale-110 transition-transform duration-700" />
               </a>
             ))}
          </div>
        </div>

        <div className="w-full xl:w-96 space-y-8 xl:border-r xl:border-white/5 xl:pr-12">
           <div className="bg-black/20 p-8 rounded-[40px] border border-white/5 space-y-4">
              <span className="text-[10px] font-black uppercase tracking-[0.25em] text-neutral-600 block italic">كشف حساب الطلب</span>
              <div className="h-0.5 w-full bg-white/5" />
              <div>
                <div className="text-xs font-black text-neutral-500 uppercase tracking-widest mb-1">المنتج</div>
                <div className="text-lg font-black italic truncate">{order?.productTitle}</div>
              </div>
              <div>
                <div className="text-xs font-black text-neutral-500 uppercase tracking-widest mb-1">القيمة الصافية</div>
                <div className="text-3xl font-black italic text-emerald-400 tracking-tighter">${order?.price.toLocaleString()}</div>
              </div>
           </div>

           <div className="space-y-4">
              <button 
                disabled={actionLoading}
                onClick={() => resolveDispute('refund')}
                className="w-full py-5 bg-red-600 text-white rounded-[24px] font-black uppercase tracking-widest text-xs hover:bg-red-700 transition-all shadow-xl shadow-red-600/20 active:scale-95 disabled:opacity-50"
              >
                إعادة الأموال للمشتري
              </button>
              <button 
                disabled={actionLoading}
                onClick={() => resolveDispute('release')}
                className="w-full py-5 bg-bento-accent text-black rounded-[24px] font-black uppercase tracking-widest text-xs hover:bg-white transition-all shadow-xl shadow-bento-accent/20 active:scale-95 disabled:opacity-50"
              >
                إطلاق الأموال للبائع
              </button>
              <button 
                disabled={actionLoading}
                onClick={() => resolveDispute('reject')}
                className="w-full py-5 bg-white/5 text-neutral-400 rounded-[24px] font-black uppercase tracking-widest text-xs border border-white/5 hover:text-white transition-all active:scale-95 disabled:opacity-50"
              >
                رفض النزاع (إغلاق ملف)
              </button>
           </div>
        </div>
       </div>
    </div>
  );
}
function VerificationReviewModal({ user, onClose, onRefresh }: { user: UserProfile, onClose: () => void, onRefresh: () => void }) {
  const [modalLoading, setModalLoading] = useState(false);

  const handleAction = async (status: 'verified' | 'rejected') => {
    setModalLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        isVerified: status === 'verified',
        verificationStatus: status,
        updatedAt: serverTimestamp()
      });
      alert(status === 'verified' ? 'تم توثيق الحساب بنجاح!' : 'تم رفض الحساب وإغلاق الملف.');
      onRefresh();
      onClose();
    } catch (err: any) {
      console.error(err);
      alert('Error updating user: ' + (err.message || String(err)));
    } finally {
      setModalLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-8 bg-black/95 backdrop-blur-[50px] animate-in fade-in duration-500" dir="rtl">
      <div className="bg-[#121212] border border-white/10 w-full max-w-2xl rounded-[60px] overflow-hidden flex flex-col shadow-[0_0_150px_rgba(0,0,0,0.8)] relative">
        <div className="p-10 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 bg-bento-accent/10 text-bento-accent rounded-3xl flex items-center justify-center border border-bento-accent/20 shadow-[0_0_30px_rgba(var(--bento-accent-rgb),0.1)]">
              <ShieldAlert size={36} />
            </div>
            <div>
              <h2 className="text-3xl font-black italic tracking-tighter uppercase leading-none">مراجعة التحقق اليدوي</h2>
              <p className="text-[11px] text-neutral-500 font-black uppercase tracking-[0.3em] mt-2">Internal ID: {user.uid.slice(0,12).toUpperCase()}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-4 hover:bg-white/5 rounded-3xl transition-all text-neutral-500 hover:text-white border border-white/0 hover:border-white/5"><X size={32} /></button>
        </div>

        <div className="p-12 space-y-10">
          <div className="flex flex-col items-center text-center space-y-6">
             <div className="w-24 h-24 rounded-full bg-neutral-800 border-4 border-bento-accent/20 overflow-hidden shadow-2xl">
                {user.photoURL ? <img src={user.photoURL} alt="" className="w-full h-full object-cover" /> : <Users size={48} className="m-auto mt-6 text-neutral-600" />}
             </div>
             <div>
                <h3 className="text-2xl font-black italic tracking-tighter text-white">{user.displayName}</h3>
                <p className="text-neutral-500 font-bold uppercase text-xs mt-1">{user.email}</p>
             </div>
          </div>

          <div className="bg-white/[0.02] border border-white/5 rounded-[40px] p-10 space-y-6 text-center">
             <div className="w-16 h-16 bg-amber-500/10 text-amber-500 rounded-[28px] mx-auto flex items-center justify-center mb-4">
                <ShieldAlert size={32} />
             </div>
             <div className="space-y-4">
                <h4 className="text-xl font-black italic uppercase tracking-tighter text-amber-500">بروتوكول المراجعة اليدوية (تيليجرام)</h4>
                <p className="text-neutral-400 font-medium leading-relaxed max-w-md mx-auto">
                   يتم إرسال مستندات التحقق لهذا المستخدم عبر تطبيق تيليجرام (@Sooqc2026). يرجى مراجعة الوثائق هناك يدوياً قبل اتخاذ قرار بالموافقة أو الرفض.
                </p>
             </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <button 
              disabled={modalLoading}
              onClick={() => handleAction('rejected')}
              className="py-6 bg-red-600/10 text-red-600 border border-red-600/20 rounded-[28px] font-black uppercase tracking-[0.3em] text-xs hover:bg-red-600 hover:text-white transition-all shadow-xl active:scale-[0.98] disabled:opacity-50"
            >
              رفض الطلب
            </button>
            <button 
              disabled={modalLoading}
              onClick={() => handleAction('verified')}
              className="py-6 bg-bento-accent text-black rounded-[28px] font-black uppercase tracking-[0.3em] text-xs hover:bg-white transition-all shadow-[0_0_50px_rgba(var(--bento-accent-rgb),0.3)] active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-4"
            >
              {modalLoading ? <Loader2 className="animate-spin" /> : <>الموافقة والتفعيل <Check size={24} /></>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- New Administrative Components ---

const AdminMessageModal = ({ isOpen, onClose, onSend, message, setMessage, isLoading }: any) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-8 bg-black/90 backdrop-blur-3xl animate-in fade-in duration-500">
      <div className="bg-[#121212] border border-white/10 w-full max-w-lg rounded-[48px] overflow-hidden p-8 shadow-2xl relative">
        <button onClick={onClose} className="absolute top-8 left-8 text-neutral-500 hover:text-white transition-colors"><X size={24} /></button>
        <div className="text-center mb-8">
           <div className="w-16 h-16 bg-blue-600/10 text-blue-600 rounded-2xl mx-auto mb-4 flex items-center justify-center"><Bell size={32} /></div>
           <h3 className="text-2xl font-black italic tracking-tighter uppercase">إرسال رسالة إدارية</h3>
           <p className="text-neutral-500 text-[10px] font-bold uppercase tracking-widest mt-1">سيتم إرسال تنبيه للمستخدم فوراً</p>
        </div>
        <textarea 
          className="w-full h-40 bg-black border border-white/10 rounded-3xl p-6 text-sm font-medium focus:border-blue-600 outline-none resize-none mb-6"
          placeholder="اكتب رسالتك هنا..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button 
          disabled={isLoading}
          onClick={onSend}
          className="w-full py-5 bg-blue-600 text-white rounded-[24px] font-black uppercase tracking-widest text-xs hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/20 active:scale-95 disabled:opacity-50"
        >
          {isLoading ? <Loader2 className="animate-spin mx-auto" /> : 'تأكيد الإرسال'}
        </button>
      </div>
    </div>
  );
};

const PerformanceView = ({ stats, allUsers, allOrders, allProducts }: any) => {
  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {[
          { label: 'إجمالي الإيرادات', value: `$${stats.totalRevenue?.toLocaleString()}`, icon: DollarSign, color: 'text-emerald-400' },
          { label: 'معدل التحويل', value: `${stats.purchaseRatio?.toFixed(1)}%`, icon: Activity, color: 'text-blue-400' },
          { label: 'المشترين النشطين', value: stats.buyers, icon: Users, color: 'text-purple-400' },
          { label: 'إجمالي المتاجر', value: stats.sellers, icon: Briefcase, color: 'text-amber-400' },
        ].map((kpi, i) => (
          <div key={i} className="bg-[#121212] border border-white/5 p-8 rounded-[40px] group hover:border-bento-accent/40 transition-all shadow-2xl">
            <div className="flex justify-between items-start mb-6">
              <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center group-hover:bg-bento-accent group-hover:text-black transition-all">
                <kpi.icon size={28} />
              </div>
            </div>
            <div className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-1">{kpi.label}</div>
            <div className={`text-4xl font-black italic tracking-tighter ${kpi.color}`}>{kpi.value}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-10">
        {/* Regional Performance */}
        <div className="bg-[#121212] border border-white/5 rounded-[48px] p-10">
          <h3 className="font-black italic text-xl uppercase mb-8">توزيع الطلبات حسب المنطقة</h3>
          <div className="space-y-6">
            {Object.entries(stats.ordersByRegion || {}).sort((a: any, b: any) => b[1] - a[1]).map(([region, count]: any, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 rounded-full bg-bento-accent" />
                  <span className="font-bold">{region}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-black italic">{count} طلب</span>
                  <div className="w-32 h-2 bg-white/5 rounded-full overflow-hidden">
                    <div className="h-full bg-bento-accent" style={{ width: `${(count / (allOrders.length || 1)) * 100}%` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top/Worst Stores */}
        <div className="bg-[#121212] border border-white/5 rounded-[48px] p-10">
          <h3 className="font-black italic text-xl uppercase mb-8">أداء المتاجر (الأكثر بيعاً)</h3>
          <div className="space-y-6">
            {stats.bestStores?.map(([id, data]: any, i: number) => (
              <div key={id} className="flex items-center justify-between p-4 bg-white/[0.02] rounded-2xl border border-white/5">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-neutral-800 rounded-xl flex items-center justify-center font-black">{i + 1}</div>
                  <div>
                    <div className="font-black">{data.name}</div>
                    <div className="text-[10px] text-neutral-500 uppercase font-black">{data.products} منتج</div>
                  </div>
                </div>
                <div className="text-left">
                  <div className="text-emerald-400 font-black italic">${data.revenue.toLocaleString()}</div>
                  <div className="text-[10px] text-neutral-500 font-bold uppercase">{data.orders} طلب</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const OrdersManagementView = ({ orders, onRefresh }: any) => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const groupedOrders = React.useMemo(() => {
    const groups: Record<string, { sellerName: string; orders: Order[] }> = {};
    orders.forEach((o: any) => {
      if (!groups[o.sellerId]) groups[o.sellerId] = { sellerName: o.sellerName || 'Unknown Store', orders: [] };
      groups[o.sellerId].orders.push(o);
    });
    return Object.entries(groups);
  }, [orders]);

  const filteredGroups = groupedOrders.map(([sid, data]) => ({
    ...data,
    sellerId: sid,
    orders: data.orders.filter(o => 
      o.id?.includes(searchTerm) || 
      o.buyerName?.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(g => g.orders.length > 0);

  const transferToSeller = async (orderId: string) => {
    try {
      await updateDoc(doc(db, 'orders', orderId), {
        status: 'pending_to_seller',
        updatedAt: serverTimestamp()
      });
      alert('تم تحويل الطلب للبائع بنجاح');
      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-10 animate-in slide-in-from-bottom-10 duration-700">
      <div className="bg-[#121212] p-10 rounded-[48px] border border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
        <div>
          <h2 className="text-3xl font-black italic tracking-tighter uppercase">إدارة طلبات المنصة</h2>
          <p className="text-neutral-500 font-bold uppercase tracking-widest text-xs mt-1">تتبع وتحويل جميع الطلبات النشطة</p>
        </div>
        <div className="relative w-full max-w-md">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-500" size={20} />
          <input 
            type="text" 
            placeholder="البحث برقم الطلب (10 أرقام)..." 
            className="w-full bg-black border border-white/10 rounded-2xl py-4 pr-12 pl-6 focus:border-bento-accent outline-none font-bold"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-12">
        {filteredGroups.map((group) => (
          <div key={group.sellerId} className="bg-[#121212] border border-white/5 rounded-[48px] overflow-hidden">
            <div className="p-8 bg-white/[0.02] border-b border-white/5 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <Briefcase className="text-bento-accent" size={24} />
                <h3 className="text-xl font-black italic uppercase text-white">{group.sellerName}</h3>
              </div>
              <div className="px-4 py-2 bg-bento-accent/10 border border-bento-accent/20 rounded-xl text-bento-accent text-[10px] font-black uppercase">
                {group.orders.filter(o => o.priority === 'urgent').length} طلبات عاجلة
              </div>
            </div>
            <div className="p-4 space-y-4">
              {group.orders.map((order: any) => (
                <div key={order.id} className="flex flex-col md:flex-row items-center justify-between p-6 bg-black/40 rounded-[32px] border border-white/5 hover:border-bento-accent/30 transition-all gap-6">
                  <div className="flex items-center gap-6">
                    <div className="bg-white/5 p-4 rounded-2xl font-black text-xs text-neutral-400">#{order.id || 'N/A'}</div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-lg">{order.items?.[0]?.title || order.productTitle}</span>
                        {order.items?.length > 1 && (
                          <div className="relative group">
                            <button className="p-1 px-2 bg-bento-accent text-black text-[8px] font-black rounded-md">المزيد (+{order.items.length - 1})</button>
                            <div className="absolute top-full right-0 mt-2 w-48 bg-neutral-900 border border-white/10 rounded-xl p-3 hidden group-hover:block z-20 shadow-2xl">
                               {order.items.slice(1).map((item: any, i: number) => (
                                 <div key={i} className="text-[10px] py-1 border-b border-white/5 last:border-0">{item.title} x{item.quantity}</div>
                               ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="text-[10px] font-bold text-neutral-600 uppercase tracking-widest mt-1">المشتري: {order.buyerName} | {order.status}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-8">
                    <div className="text-left">
                      <div className="text-2xl font-black italic text-white">${order.price?.toLocaleString()}</div>
                      <div className="text-[9px] font-black text-neutral-600 uppercase tracking-widest">إجمالي المبلغ</div>
                    </div>
                    {(order.status === 'pending' || order.status === 'waiting_admin') && (
                      <button 
                        onClick={() => transferToSeller(order.id)}
                        className="p-4 bg-emerald-600 text-white rounded-2xl hover:scale-110 active:scale-95 transition-all shadow-xl shadow-emerald-600/20"
                        title="تحويل للبائع"
                      >
                        <RefreshCcw size={20} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};


