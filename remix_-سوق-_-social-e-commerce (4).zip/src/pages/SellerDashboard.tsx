import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { 
  db, handleFirestoreError,
  collection, addDoc, query, where, getDocs, orderBy, doc, updateDoc, increment, deleteDoc, serverTimestampResilient as serverTimestamp
} from '../lib/firebase';
import { Product, Order, OrderStatus } from '../types';
import { 
  TrendingUp, Package, ShoppingBag, Wallet, Settings, 
  BadgeCheck, Plus, ShieldAlert, AlertTriangle, ChevronRight, 
  ArrowRight, CreditCard, Landmark, LayoutGrid, List,
  Ban, Zap, ArrowUp, ArrowDown, Minus, DollarSign, ShieldCheck, 
  Trash2, Archive, CheckCircle, CheckCircle2, Star, Target, Award, Rocket, Check, Store, Pencil, Pin, X, Building2, Smartphone, Globe, Upload, Loader2, Image as ImageIcon,
  Camera, Info, Truck, Activity
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import IdentityVerification from '../components/IdentityVerification';
import MarketStudio from '../components/MarketStudio';
import { uploadAndCompressImage, deleteImage } from '../lib/storage';
import { SELLER_TIERS, calculateSellerTier, getNextTier } from '../lib/commission';
import { sendNotification } from '../lib/notifications';
import { OrderService } from '../services/OrderService';
import { CustomSelect } from '../components/CustomSelect';

export default function SellerDashboard() {
  const { user, profile } = useAuth();
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const [products, setProducts] = useState<Product[]>([]);
  const [sortBy, setSortBy] = useState<string>('newest');
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'balance' | 'store' | 'market-studio'>((location.state as any)?.activeTab || 'overview');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [productToDelete, setProductToDelete] = useState<Product | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const productCategories = [
    { id: 'all', label: t('product_form.categories.all') || (dir === 'rtl' ? 'الكل' : 'All') },
    { id: 'food', label: t('product_form.categories.food') || (dir === 'rtl' ? 'طعام جاهز' : 'Cooked Food') },
    { id: 'drinks', label: dir === 'rtl' ? 'مشروبات' : 'Drinks' },
    { id: 'veg_fruits', label: t('product_form.categories.veg_fruits') || (dir === 'rtl' ? 'خضار وفواكه' : 'Veg & Fruits') },
    { id: 'meat', label: t('product_form.categories.meat') || (dir === 'rtl' ? 'لحوم وطواجن' : 'Meat') },
    { id: 'supermarket', label: t('product_form.categories.supermarket') || (dir === 'rtl' ? 'سوبر ماركت' : 'Supermarket') },
    { id: 'desserts', label: dir === 'rtl' ? 'حلويات وإضافات' : 'Desserts' },
    { id: 'electronics', label: t('product_form.categories.electronics') },
    { id: 'home_appliances', label: t('product_form.categories.home_appliances') }
  ];

  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [showVerification, setShowVerification] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [proofingOrder, setProofingOrder] = useState<Order | null>(null);
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [uploadingProof, setUploadingProof] = useState(false);
  
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPaymentMethodId, setSelectedPaymentMethodId] = useState<string>('');
  const [paymentMethodForm, setPaymentMethodForm] = useState({
    type: 'wallet' as 'bank' | 'wallet' | 'paypal',
    provider: '',
    accountNumber: '',
    accountHolderName: ''
  });

  useEffect(() => {
    const initializeDashboard = async () => {
      if (user && profile && !profile.sellerProfileExists && profile.role !== 'admin') {
        navigate('/setup-store');
        return;
      }
      if (user) {
        fetchData();
        runMaintenance();
      }
    };
    initializeDashboard();
  }, [user, profile, navigate, sortBy, selectedCategory]);

  const runMaintenance = async () => {
    if (!user || !profile) return;
    const lastRun = localStorage.getItem(`maintenance_${user.uid}`);
    const today = new Date().toDateString();
    if (lastRun === today) return;

    try {
      const q = query(collection(db, 'products'), where('sellerId', '==', user.uid));
      const snap = await getDocs(q);
      const now = new Date();
      const thirtyDays = 30 * 24 * 60 * 60 * 1000;
      const ninetyDays = 90 * 24 * 60 * 60 * 1000;

      const batch: Promise<any>[] = [];
      snap.docs.forEach(d => {
        const data = d.data();
        const createdAt = data.createdAt?.toDate?.() || new Date();
        const lastSoldAt = data.lastSoldAt?.toDate?.() || createdAt;
        const lastActivity = Math.max(createdAt.getTime(), lastSoldAt.getTime());
        const diffraction = now.getTime() - lastActivity;

        if (diffraction > ninetyDays) {
          batch.push(handleDeleteProduct({ id: d.id, ...data } as Product));
        } else if (diffraction > thirtyDays && !data.isArchived) {
          batch.push(updateDoc(doc(db, 'products', d.id), { isArchived: true }));
        }
      });

      if (batch.length > 0) {
        await Promise.all(batch);
        fetchData();
      }
      localStorage.setItem(`maintenance_${user.uid}`, today);
    } catch (error) {
      console.error("Maintenance error:", error);
    }
  };

  const fetchData = async () => {
    if (!user?.uid) return;
    try {
      let qConstraints: any[] = [where('sellerId', '==', user.uid)];

      if (selectedCategory && selectedCategory !== 'all') {
        qConstraints.push(where('category', '==', selectedCategory));
      }

      if (sortBy === 'newest') {
        qConstraints.push(orderBy('isPinned', 'desc'));
        qConstraints.push(orderBy('createdAt', 'desc'));
      } else if (sortBy === 'price_asc') {
        qConstraints.push(orderBy('price', 'asc'));
      } else if (sortBy === 'price_desc') {
        qConstraints.push(orderBy('price', 'desc'));
      } else if (sortBy === 'likes') {
        qConstraints.push(orderBy('likesCount', 'desc'));
      } else if (sortBy === 'last_sold') {
        qConstraints.push(orderBy('lastSoldAt', 'desc'));
      } else if (sortBy === 'pinned') {
        qConstraints.push(orderBy('isPinned', 'desc'));
        qConstraints.push(orderBy('createdAt', 'desc'));
      }

      const productsQ = query(collection(db, 'products'), ...qConstraints);
      const ordersQ = query(collection(db, 'orders'), where('sellerId', '==', user.uid), orderBy('createdAt', 'desc'));
      
      const [pSnap, oSnap] = await Promise.all([getDocs(productsQ), getDocs(ordersQ)]);
      
      setProducts(pSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Product)));
      const fetchedOrders = oSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Order));
      setOrders(fetchedOrders);

      // Auto-Confirm Check for Seller
      fetchedOrders.forEach(async (order) => {
        if (order.status === 'delivered' && order.autoConfirmAt) {
          const autoConfirmDate = order.autoConfirmAt.toDate();
          if (new Date() > autoConfirmDate) {
            try {
              const sellerRef = doc(db, 'users', user.uid);
              await updateDoc(sellerRef, {
                totalEarnings: increment(order.price),
                withdrawableBalance: increment(order.netAmount)
              });
              await updateDoc(doc(db, 'orders', order.id), {
                status: 'completed',
                paymentStatus: 'released',
                updatedAt: serverTimestamp()
              });
            } catch (err) {
              console.error("Auto-confirm release error:", err);
            }
          }
        }
      });
    } catch (error) {
      try {
        handleFirestoreError(error, 'list');
      } catch (e) {
        console.error("Seller Dashboard Data Fetch Fail:", e);
      }
    }
  };

  const [deletingProductId, setDeletingProductId] = useState<string | null>(null);

  const handleDeleteProduct = useCallback(async (productOrId: Product | string, imageUrlOrEvent?: string | React.MouseEvent) => {
    console.log('handleDeleteProduct triggered', { productOrId, imageUrlOrEvent });
    const id = typeof productOrId === 'string' ? productOrId : productOrId.id;
    const img = typeof productOrId === 'string' 
      ? (typeof imageUrlOrEvent === 'string' ? imageUrlOrEvent : undefined)
      : productOrId.imageUrl;

    if (!id) return;
    
    // Instead of window.confirm, we use the state-based modal
    const product = typeof productOrId === 'object' ? productOrId : products.find(p => p.id === id);
    if (product) {
      console.log('Setting product to delete:', product.title);
      setProductToDelete(product);
    } else {
      console.log('Product object not found, using fallback confirm');
      const confirmDelete = window.confirm(dir === 'rtl' ? 'هل أنت متأكد من رغبتك في حذف هذا المنتج نهائياً؟' : 'Are you sure you want to delete this product?');
      if (confirmDelete) executeDelete(id, img);
    }
  }, [products, dir]);

  const executeDelete = useCallback(async (id: string, img?: string) => {
    setIsDeleting(true);
    setDeletingProductId(id);
    try {
      if (img && typeof img === 'string' && img.includes('firebasestorage')) {
        await deleteImage(img).catch(err => console.warn("Image delete fail:", err));
      }
      await deleteDoc(doc(db, 'products', id));
      if (user?.uid) {
        await updateDoc(doc(db, 'users', user.uid), {
          currentProducts: increment(-1)
        });
      }
      fetchData();
      setProductToDelete(null);
    } catch (error) {
      console.error("Error deleting product:", error);
      handleFirestoreError(error, 'write', `products/${id}`);
    } finally {
      setIsDeleting(false);
      setDeletingProductId(null);
    }
  }, [user?.uid, fetchData]);

  const handleUpdateOrderStatus = useCallback(async (orderId: string, buyerId: string, currentStatus: OrderStatus, productTitle: string) => {
    const sequence: OrderStatus[] = ['pending', 'confirmed', 'preparing', 'ready_for_delivery', 'courier_assigned', 'picked_up', 'on_the_way', 'delivered', 'completed'];
    const currentIndex = sequence.indexOf(currentStatus);
    if (currentIndex === -1 || currentIndex >= sequence.length - 1) return;

    // Special handling for preparing (requires proof)
    if (currentStatus === 'confirmed') {
      const order = orders.find(o => o.id === orderId);
      if (order) {
        setProofingOrder(order);
        return;
      }
    }

    const nextStatus = sequence[currentIndex + 1];
    
    // Courier assignments are handled in claimOrder transaction, 
    // so we skip manual status updates for those stages if they require a courier.
    if (nextStatus === 'courier_assigned' || nextStatus === 'picked_up' || nextStatus === 'on_the_way' || nextStatus === 'delivered') {
      return; 
    }

    try {
      await updateDoc(doc(db, 'orders', orderId), { 
        status: nextStatus,
        updatedAt: serverTimestamp()
      });
      
      let title = '';
      let message = '';
      if (nextStatus === 'confirmed') {
        title = t('seller_dashboard.order_notifications.confirmed_title');
        message = t('seller_dashboard.order_notifications.confirmed_msg', { product: productTitle });
      } else if (nextStatus === 'preparing') {
        title = "Preparing Order 📦";
        message = `Seller is preparing your order: ${productTitle}`;
      } else if (nextStatus === 'ready_for_delivery') {
        title = "Order Ready! 🚀";
        message = `Your order ${productTitle} is ready and waiting for a courier.`;
        
        // Use the new service method that triggers dispatch
        const storeLoc = profile?.courierLocation ? { lat: profile.courierLocation.lat, lng: profile.courierLocation.lng } : { lat: 31.9029, lng: 35.2062 };
        await OrderService.markOrderAsReady(orderId, storeLoc);
      }

      await sendNotification(buyerId, 'delivery', title, message, '/orders');
      fetchData();
    } catch (error) {
      console.error("Error updating status:", error);
    }
  }, [fetchData, orders, profile, t]);

  const handleUploadSellerProof = async () => {
    if (!proofingOrder || !proofFile) return;
    setUploadingProof(true);
    try {
      const url = await uploadAndCompressImage(proofFile, {
        maxSizeMB: 1,
        maxWidthOrHeight: 1200,
        path: `proofs/seller/${proofingOrder.id}`
      });
      
      await OrderService.markOrderAsPreparing(proofingOrder.id, url);
      await sendNotification(
        proofingOrder.buyerId, 
        'delivery', 
        'Preparing Order 📦', 
        `Seller uploaded proof and is preparing: ${proofingOrder.productTitle}`, 
        '/orders'
      );
      
      setProofingOrder(null);
      setProofFile(null);
      fetchData();
    } catch (error) {
      console.error("Proof upload error:", error);
    } finally {
      setUploadingProof(false);
    }
  };

  const handleUpdateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !editingProduct) return;

    setUploading(true);
    try {
      let finalImageUrl = editingProduct.imageUrl;
      if (selectedFile) {
        finalImageUrl = await uploadAndCompressImage(selectedFile, {
          maxSizeMB: 2,
          maxWidthOrHeight: 1200,
          path: `products/${user.uid}`
        });
      }
      await updateDoc(doc(db, 'products', editingProduct.id), {
        ...editingProduct,
        imageUrl: finalImageUrl,
        updatedAt: new Date()
      });
      setEditingProduct(null);
      setSelectedFile(null);
      fetchData();
    } catch (error) {
      console.error("Error updating product:", error);
    } finally {
      setUploading(false);
    }
  };

  const handleWithdraw = async () => {
    if (!user || !profile || !withdrawAmount) return;
    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) return;
    if (amount > (profile.withdrawableBalance || 0)) {
      alert(t('common.insufficient_balance') || "Insufficient balance");
      return;
    }
    if (!selectedPaymentMethodId) {
      alert(t('common.select_payment_method') || "Please select a payment method first");
      return;
    }
    const paymentMethod = profile.paymentMethods?.find(m => m.id === selectedPaymentMethodId);
    if (!paymentMethod) {
      alert(t('common.invalid_payment_method') || "Selected payment method is invalid");
      return;
    }
    setIsWithdrawing(true);
    try {
      await addDoc(collection(db, 'withdrawals'), {
        userId: user.uid,
        amount,
        status: 'pending',
        paymentMethod,
        createdAt: new Date()
      });
      await updateDoc(doc(db, 'users', user.uid), {
        withdrawableBalance: increment(-amount)
      });
      setWithdrawAmount('');
      setSelectedPaymentMethodId('');
      alert(t('common.withdrawal_success') || "Withdrawal request submitted successfully");
      fetchData();
    } catch (error) {
      console.error("Withdraw error:", error);
    } finally {
      setIsWithdrawing(false);
    }
  };

  const handleAddPaymentMethod = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;
    try {
      const newMethod = {
        id: `pm_${Date.now().toString(36)}`,
        ...paymentMethodForm,
        isDefault: (profile.paymentMethods || []).length === 0
      };
      await updateDoc(doc(db, 'users', user.uid), {
        paymentMethods: [...(profile.paymentMethods || []), newMethod]
      });
      setShowPaymentModal(false);
      setPaymentMethodForm({ type: 'wallet', provider: '', accountNumber: '', accountHolderName: '' });
    } catch (error) {
      console.error("Error adding payment method:", error);
    }
  };

  const handleRemovePaymentMethod = async (methodId: string) => {
    if (!user || !profile) return;
    try {
      const updatedMethods = (profile.paymentMethods || []).filter(m => m.id !== methodId);
      await updateDoc(doc(db, 'users', user.uid), { paymentMethods: updatedMethods });
    } catch (error) {
      console.error("Error removing payment method:", error);
    }
  };

  const handleTogglePin = async (product: Product) => {
    try {
      await updateDoc(doc(db, 'products', product.id), { isPinned: !product.isPinned });
      fetchData();
    } catch (error) { console.error("Pin error:", error); }
  };

  const handleMoveProduct = async (product: Product, direction: 'up' | 'down') => {
    const currentIndex = products.findIndex(p => p.id === product.id);
    if (direction === 'up' && currentIndex === 0) return;
    if (direction === 'down' && currentIndex === products.length - 1) return;
    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    const targetProduct = products[targetIndex];
    try {
      const currentOrder = product.orderIndex || 0;
      const targetOrder = targetProduct.orderIndex || 0;
      await updateDoc(doc(db, 'products', product.id), { orderIndex: targetOrder });
      await updateDoc(doc(db, 'products', targetProduct.id), { orderIndex: currentOrder });
      fetchData();
    } catch (error) { console.error("Move error:", error); }
  };

  const sellerRating = profile?.sellerProfile?.rating ?? 0;
  const reviewsCount = profile?.reviewsCount || 0;
  
  const currentTier = useMemo(() => 
    calculateSellerTier(profile?.salesCount || 0, profile?.totalEarnings || 0, sellerRating || 5.0),
    [profile?.salesCount, profile?.totalEarnings, sellerRating]
  );
  
  const nextTierInfo = useMemo(() => 
    getNextTier(profile?.salesCount || 0, profile?.totalEarnings || 0, sellerRating || 5.0),
    [profile?.salesCount, profile?.totalEarnings, sellerRating]
  );

  const sortedProducts = useMemo(() => {
    return [...products].sort((a, b) => {
      if (sortBy === 'pinned') {
        if (a.isPinned && !b.isPinned) return -1;
        if (!a.isPinned && b.isPinned) return 1;
        return (b.orderIndex || 0) - (a.orderIndex || 0);
      }
      if (sortBy === 'price_asc') return a.price - b.price;
      if (sortBy === 'price_desc') return b.price - a.price;
      if (sortBy === 'likes') return (b.likes || 0) - (a.likes || 0);
      // Fallback to newest
      const dateA = a.createdAt?.seconds || 0;
      const dateB = b.createdAt?.seconds || 0;
      return dateB - dateA;
    });
  }, [products, sortBy]);

  return (
    <div className="min-h-screen bg-bento-bg text-white p-6 md:p-12 max-w-7xl mx-auto pt-10 md:pt-16 pb-24 md:pb-12" dir={dir}>
      {/* Verification Alert Banner */}
      {!profile?.isVerified && (
        <div className={`mb-8 p-6 bg-amber-500/10 border border-amber-500/20 rounded-[32px] flex flex-col md:flex-row items-center justify-between gap-6 overflow-hidden relative ${dir === 'rtl' ? 'md:flex-row-reverse text-right' : 'md:flex-row text-left'}`}>
           <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 blur-3xl pointer-events-none"></div>
           <div className={`flex items-center gap-6 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className="p-4 bg-amber-500/20 rounded-2xl">
                 <ShieldAlert className="text-amber-500" size={32} />
              </div>
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                 <h3 className="text-xl font-black italic tracking-tighter uppercase">{t('seller.verification_required')}</h3>
                 <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest mt-1 leading-relaxed">
                   {t('seller.verification_needed_desc')}
                 </p>
              </div>
           </div>
           <button 
              onClick={() => navigate('/verification')}
              className="w-full md:w-auto px-10 py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest hover:bg-amber-500 transition-all text-xs shrink-0"
           >
              {t('seller.start_verification')}
           </button>
        </div>
      )}

      {/* Trust Curve Engine (Reputation System) Status */}
      {profile?.sellerProfile?.trustStatus && profile.sellerProfile.trustStatus !== 'ACTIVE' && (
        <div className={`mb-8 p-6 rounded-[32px] border overflow-hidden relative shadow-2xl transition-all duration-700 animate-in slide-in-from-top-4 ${
          profile.sellerProfile.trustStatus === 'SUSPENDED' ? 'bg-red-950/40 border-red-500/50' : 
          profile.sellerProfile.trustStatus === 'RISK' ? 'bg-orange-500/10 border-orange-500/30' :
          'bg-amber-500/10 border-amber-500/20'
        }`}>
          <div className={`absolute top-0 right-0 w-64 h-64 blur-3xl pointer-events-none opacity-20 ${
            profile.sellerProfile.trustStatus === 'SUSPENDED' ? 'bg-red-500' : 
            profile.sellerProfile.trustStatus === 'RISK' ? 'bg-orange-500' :
            'bg-amber-500'
          }`}></div>
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
            <div className="flex items-center gap-6 flex-row-reverse md:flex-row w-full md:w-auto">
              <div className={`p-4 rounded-2xl ${
                profile.sellerProfile.trustStatus === 'SUSPENDED' ? 'bg-red-500/20' : 
                profile.sellerProfile.trustStatus === 'RISK' ? 'bg-orange-500/20' :
                'bg-amber-500/20'
              }`}>
                {profile.sellerProfile.trustStatus === 'SUSPENDED' ? <Ban className="text-red-500" size={32} /> :
                 profile.sellerProfile.trustStatus === 'RISK' ? <Zap className="text-orange-500" size={32} /> :
                 <AlertTriangle className="text-amber-500" size={32} />}
              </div>
              <div className="text-right">
                <div className="flex items-center gap-2 justify-end mb-1">
                  <span className={`text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full ${
                    profile.sellerProfile.trustStatus === 'SUSPENDED' ? 'bg-red-500 text-white' : 
                    profile.sellerProfile.trustStatus === 'RISK' ? 'bg-orange-500 text-white' :
                    'bg-amber-500 text-black'
                  }`}>
                    Status: {profile.sellerProfile.trustStatus}
                  </span>
                  <h3 className="text-xl font-black italic tracking-tighter uppercase">
                    {profile.sellerProfile.trustStatus === 'SUSPENDED' ? t('seller_dashboard.status.suspended') : 
                     profile.sellerProfile.trustStatus === 'RISK' ? t('seller_dashboard.status.risk') :
                     t('seller_dashboard.status.active')}
                  </h3>
                </div>
                <p className="text-xs text-neutral-400 font-bold uppercase tracking-widest leading-relaxed">
                  {profile.sellerProfile.trustStatus === 'SUSPENDED' ? t('seller_dashboard.alert.suspended') :
                   profile.sellerProfile.trustStatus === 'RISK' ? t('seller_dashboard.alert.risk') :
                   t('seller_dashboard.alert.low_rating')}
                </p>
                {profile.sellerProfile.warningsCount && profile.sellerProfile.warningsCount > 0 && (
                  <div className={`mt-3 flex items-center gap-1 ${dir === 'rtl' ? 'justify-end' : 'justify-start'}`}>
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className={`w-3 h-1.5 rounded-full ${i < profile.sellerProfile!.warningsCount! ? 'bg-red-500' : 'bg-neutral-800'}`}></div>
                    ))}
                    <span className={`text-[10px] font-black text-neutral-500 ${dir === 'rtl' ? 'mr-2' : 'ml-2'}`}>{t('seller_dashboard.warnings')}: {profile.sellerProfile.warningsCount}/3</span>
                  </div>
                )}
              </div>
            </div>
            
            {profile.sellerProfile.trustStatus !== 'SUSPENDED' && (
              <div className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5 backdrop-blur-md">
                <div className="text-right">
                  <div className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-1">{t('seller.reputation_trend')}</div>
                  <div className={`flex items-center gap-2 justify-end font-black italic ${
                    profile.sellerProfile.trend === 'UP' ? 'text-emerald-500' : 
                    profile.sellerProfile.trend === 'DOWN' ? 'text-red-500' : 'text-amber-500'
                  }`}>
                    {profile.sellerProfile.trend === 'UP' ? <ArrowUp size={16} /> :
                     profile.sellerProfile.trend === 'DOWN' ? <ArrowDown size={16} /> : <Minus size={16} />}
                    {t(`seller.trend.${profile.sellerProfile.trend}`) || profile.sellerProfile.trend}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Legacy/Standard Alert fallback if trustStatus not yet initialized */}
      {!profile?.sellerProfile?.trustStatus && (sellerRating < 3.5 || (profile?.sellerProfile?.disputeCount || 0) > 5) && (
        <div className="mb-8 p-6 bg-red-500/10 border border-red-500/20 rounded-[32px] flex flex-col md:flex-row items-center justify-between gap-6 overflow-hidden relative">
           <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 blur-3xl pointer-events-none"></div>
           <div className="flex items-center gap-6 text-right md:text-left flex-row-reverse md:flex-row">
              <div className="p-4 bg-red-500/20 rounded-2xl">
                 <AlertTriangle className="text-red-500" size={32} />
              </div>
              <div className="text-right shrink">
                 <h3 className="text-xl font-black italic tracking-tighter uppercase font-ar">{t('seller_dashboard.alert.quality_title')}</h3>
                 <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest mt-1 font-ar leading-relaxed">
                   {sellerRating < 2.5 
                     ? t('seller_dashboard.alert.low_rating_blocked')
                     : t('seller_dashboard.alert.quality_warning')}
                 </p>
              </div>
           </div>
        </div>
      )}

      <header className={`mb-8 flex flex-col md:flex-row md:items-end justify-between gap-6 relative ${dir === 'rtl' ? 'md:flex-row-reverse' : ''}`}>
        <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
          <div className={`flex items-center gap-3 mb-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
            <h1 className="text-4xl md:text-5xl font-black italic tracking-tighter uppercase">{t('seller_dashboard.title')}</h1>
            {profile?.isVerified && <BadgeCheck size={32} className="text-bento-accent" />}
          </div>
          <p className="text-neutral-500 font-medium text-sm">{t('seller_dashboard.subtitle')}</p>
        </div>

        {/* Mobile Menu Toggle (Top Right) */}
        <div className="md:hidden absolute top-0 left-0">
          <button 
            onClick={() => setIsMenuOpen(true)}
            className="p-3 bg-neutral-900 border border-neutral-800 rounded-2xl text-bento-accent shadow-xl active:scale-95 transition-all"
          >
            <List size={24} />
          </button>
        </div>

        <div className={`flex gap-3 mt-4 md:mt-0 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
          <button 
            onClick={() => setActiveTab('market-studio')}
            className={`bg-neutral-900 border border-neutral-800 text-white px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:bg-neutral-800 transition-all shadow-lg ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
          >
            <LayoutGrid size={20} className="text-bento-accent" />
            <span>{t('market_studio.title')}</span>
          </button>
          <button 
            onClick={() => navigate('/add-product')}
            className={`bg-bento-accent text-black px-6 py-3 rounded-2xl font-bold flex items-center gap-2 hover:opacity-90 transition-all shadow-lg ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
          >
            <Plus size={20} />
            <span>{t('seller_dashboard.new_product')}</span>
          </button>
        </div>
      </header>

      {/* Tabs Navigation */}
      <div className={`flex gap-4 mb-8 overflow-x-auto overscroll-contain touch-pan-x no-scrollbar pb-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
        {[
          { id: 'overview', label: t('seller_dashboard.tabs.overview'), icon: TrendingUp }, 
          { id: 'market-studio', label: t('seller_dashboard.tabs.market_studio'), icon: LayoutGrid },
          { id: 'products', label: t('seller_dashboard.tabs.products'), icon: Package }, 
          { id: 'balance', label: t('seller_dashboard.tabs.balance'), icon: Wallet }, 
          { id: 'store', label: t('seller_dashboard.tabs.store'), icon: Store }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold whitespace-nowrap transition-all border ${
              activeTab === tab.id 
                ? 'bg-white text-black border-white shadow-xl' 
                : 'bg-neutral-900 text-neutral-500 border-neutral-800 hover:border-neutral-700'
            }`}
          >
            <tab.icon size={18} />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {activeTab === 'overview' && (
        <div className={`grid grid-cols-1 md:grid-cols-3 gap-6 ${dir === 'rtl' ? 'rtl' : 'ltr'}`}>
          <div className="md:col-span-2 bento-card min-h-[300px] flex flex-col justify-center gap-4 relative overflow-hidden">
            <Award className={`absolute text-bento-accent/5 ${dir === 'rtl' ? '-left-10 -bottom-10' : '-right-10 -bottom-10'}`} size={300} />
            <div className={`relative z-10 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
              <h2 className="text-4xl font-black italic tracking-tighter uppercase mb-4">{profile.sellerProfile?.displayName || t('seller_dashboard.your_store')}</h2>
              <div className={`flex flex-wrap gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                 <div className="px-4 py-2 bg-white/5 rounded-2xl border border-white/5 flex items-center gap-2">
                    <CheckCircle2 size={14} className="text-emerald-500" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">{t('seller_dashboard.verified_seller')}</span>
                 </div>
                 <div className="px-4 py-2 bg-white/5 rounded-2xl border border-white/5 flex items-center gap-2">
                    <Star size={14} className="text-amber-500 fill-amber-500" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">
                      {t('seller.product_rating')}: {reviewsCount > 0 ? sellerRating.toFixed(1) : t('seller.no_ratings')}
                    </span>
                 </div>
              </div>
              <p className={`mt-6 text-neutral-400 max-w-md text-sm font-medium ${dir === 'rtl' ? 'mr-0 ml-auto' : ''}`}>{profile.sellerProfile?.description || t('seller_dashboard.store_desc_placeholder')}</p>
            </div>
          </div>
          <div className="bento-card flex flex-col gap-6">
            <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
              <div className="p-3 bg-emerald-500/10 rounded-2xl text-emerald-500"><DollarSign size={24} /></div>
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                <div className="text-[10px] font-black uppercase tracking-widest text-neutral-500">{t('seller_dashboard.total_earnings_label')}</div>
                <div className="text-2xl font-black">${profile?.totalEarnings?.toFixed(2) || '0.00'}</div>
              </div>
            </div>
            <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
              <div className="p-3 bg-blue-500/10 rounded-2xl text-blue-500"><Package size={24} /></div>
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                <div className="text-[10px] font-black uppercase tracking-widest text-neutral-500">{t('seller_dashboard.sales_count')}</div>
                <div className="text-2xl font-black">{profile?.salesCount || 0}</div>
              </div>
            </div>
          </div>
          <div className="md:col-span-3">
             <h3 className={`text-xl font-black italic mb-6 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller_dashboard.recent_orders')}</h3>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {orders.length === 0 ? (
                  <div className="col-span-full py-12 text-center bg-neutral-900 rounded-[32px] border border-dashed border-neutral-800 text-neutral-600">{t('seller_dashboard.no_orders')}</div>
                ) : (
                  orders.map((order, idx) => (
                    <div key={`${order.id}-${idx}`} className={`bg-neutral-900 p-6 rounded-[30px] border border-neutral-800 flex justify-between items-center group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                       <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                          <h4 className="font-bold text-sm mb-1">{order.productTitle}</h4>
                          <span className={`text-[9px] font-black uppercase tracking-widest ${
                            order.status === 'delivered' || order.status === 'completed' ? 'text-emerald-500' : 
                            order.status === 'cancelled' || order.status === 'refunded' || order.status === 'disputed' ? 'text-red-500' :
                            'text-amber-500'
                          }`}>{t(`seller.${order.status}`) || order.status}</span>
                       </div>
                       {!['delivered', 'completed', 'cancelled', 'refunded', 'disputed'].includes(order.status) && (
                         <button 
                           onClick={() => handleUpdateOrderStatus(order.id, order.buyerId, order.status, order.productTitle)}
                           className="p-2 bg-neutral-800 hover:bg-bento-accent hover:text-black rounded-xl transition-all"
                         >
                           <Rocket size={18} />
                         </button>
                       )}
                    </div>
                  ))
                )}
             </div>
          </div>
        </div>
      )}

      {activeTab === 'products' && (
        <div className={`space-y-6 ${dir === 'rtl' ? 'rtl' : 'ltr'}`}>
          <div className={`flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-neutral-900 border border-neutral-800 p-4 rounded-3xl ${dir === 'rtl' ? 'md:flex-row-reverse' : ''}`}>
             <div className={`flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <List size={20} className="text-bento-accent" />
                <h3 className="font-bold">{t('seller_dashboard.product_list')} ({products.length})</h3>
             </div>
             <div className={`flex items-center gap-3 w-full md:w-auto ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <span className="text-[10px] font-black text-neutral-500 uppercase tracking-widest whitespace-nowrap">{t('seller_dashboard.sort_by')}</span>
                <select 
                   value={sortBy}
                   onChange={(e) => setSortBy(e.target.value)}
                   className={`flex-1 md:flex-none bg-black border border-neutral-800 text-white rounded-xl px-4 py-2 text-xs font-bold focus:border-bento-accent outline-none ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                >
                   <option value="newest">{t('seller_dashboard.sort_options.newest')}</option>
                   <option value="price_asc">{t('seller_dashboard.sort_options.price_asc')}</option>
                   <option value="price_desc">{t('seller_dashboard.sort_options.price_desc')}</option>
                   <option value="likes">{t('seller_dashboard.sort_options.likes')}</option>
                   <option value="last_sold">{t('seller_dashboard.sort_options.last_sold')}</option>
                   <option value="pinned">{t('seller_dashboard.sort_options.pinned')}</option>
                </select>
             </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {sortedProducts.map((product, idx) => (
              <div key={`${product.id}-${idx}`} className="bg-neutral-900 rounded-[32px] overflow-hidden border border-neutral-800 group relative">
                <div className="aspect-square relative">
                  <img src={product.imageUrl} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <div className={`absolute top-3 flex gap-2 z-50 ${dir === 'rtl' ? 'left-3' : 'right-3'}`}>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingProduct(product);
                      }}
                      className="p-2 bg-black/60 backdrop-blur-md rounded-xl text-white hover:bg-bento-accent hover:text-black transition-all shadow-lg"
                    >
                      <Pencil size={16} />
                    </button>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteProduct(product);
                      }}
                      disabled={deletingProductId === product.id}
                      className={`p-2 backdrop-blur-md rounded-xl transition-all shadow-lg ${
                        deletingProductId === product.id
                        ? 'bg-neutral-800 text-neutral-500'
                        : 'bg-black/60 text-red-500 hover:bg-red-500 hover:text-white'
                      }`}
                    >
                      {deletingProductId === product.id ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                    </button>
                  </div>
                </div>
                <div className={`p-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                  <h4 className="font-bold text-sm truncate">{product.title}</h4>
                  <div className={`flex justify-between items-center mt-1 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <span className="text-bento-accent font-black text-sm">${product.price}</span>
                    <span className="text-[9px] font-black uppercase text-neutral-600 tracking-widest">{t(`product_form.categories.${product.category.toLowerCase()}`) || product.category}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'balance' && (
        <div className={`space-y-8 ${dir === 'rtl' ? 'rtl' : 'ltr'}`}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className={`bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] flex justify-between items-center relative overflow-hidden group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
              <div className={`absolute opacity-5 group-hover:scale-110 transition-transform ${dir === 'rtl' ? '-left-4 -bottom-4' : '-right-4 -bottom-4'}`}><TrendingUp size={120} /></div>
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-2">{t('seller_dashboard.total_earnings_label')}</p>
                <h3 className="text-4xl font-black italic tracking-tighter">${profile?.totalEarnings?.toFixed(2) || '0.00'}</h3>
              </div>
              <div className="p-4 bg-emerald-500/10 text-emerald-500 rounded-3xl"><TrendingUp size={24} /></div>
            </div>
            <div className={`bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] flex justify-between items-center relative overflow-hidden group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
              <div className={`absolute opacity-5 group-hover:scale-110 transition-transform ${dir === 'rtl' ? '-left-4 -bottom-4' : '-right-4 -bottom-4'}`}><Smartphone size={120} /></div>
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-2">{t('seller.pending')}</p>
                <h3 className="text-4xl font-black italic tracking-tighter">{orders.filter(o => o.status === 'pending').length}</h3>
              </div>
              <div className="p-4 bg-amber-500/10 text-amber-500 rounded-3xl"><Package size={24} /></div>
            </div>
            <button 
              onClick={() => setShowPaymentModal(true)}
              className={`bg-bento-accent border border-bento-accent p-8 rounded-[40px] flex justify-between items-center relative overflow-hidden group hover:opacity-90 transition-all text-black ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`absolute opacity-10 group-hover:scale-110 transition-transform ${dir === 'rtl' ? '-left-4 -bottom-4' : '-right-4 -bottom-4'}`}><CreditCard size={120} /></div>
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                <p className={`text-[10px] font-black uppercase tracking-widest text-black/60 mb-2 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller_dashboard.link_payment_method')}</p>
                <h3 className={`text-2xl font-black italic tracking-tighter ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller_dashboard.link_payment_method')}</h3>
              </div>
              <div className="p-4 bg-black/10 rounded-3xl"><Plus size={24} /></div>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bento-card p-10 flex flex-col justify-between min-h-[400px]">
                <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                  <span className="text-[10px] font-black uppercase tracking-[0.2em] text-neutral-500">{t('seller_dashboard.withdrawable_balance')}</span>
                  <h2 className="text-6xl font-black italic tracking-tighter mt-2 text-emerald-400">${profile?.withdrawableBalance?.toFixed(2) || '0.00'}</h2>
                </div>
                <div className="space-y-6">
                  <div>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller_dashboard.withdraw_to')}</label>
                    <div className="grid grid-cols-1 gap-2">
                      {profile?.paymentMethods?.length === 0 ? (
                        <button onClick={() => setShowPaymentModal(true)} className="p-4 border border-dashed border-neutral-800 rounded-2xl text-neutral-500 text-xs font-bold hover:border-bento-accent hover:text-bento-accent transition-all flex items-center justify-center gap-2"><Plus size={16} /> {t('seller_dashboard.link_payment_method')}</button>
                      ) : (
                        profile?.paymentMethods?.map((method, i) => (
                          <button key={`${method.id}-${i}`} onClick={() => setSelectedPaymentMethodId(method.id)} className={`p-4 rounded-2xl border transition-all flex items-center justify-between ${selectedPaymentMethodId === method.id ? 'bg-bento-accent/10 border-bento-accent' : 'bg-black border-neutral-800 hover:border-neutral-700'} ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                            <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                              {method.type === 'bank' ? <Building2 size={18} /> : method.type === 'paypal' ? <CreditCard size={18} /> : <Smartphone size={18} />}
                              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                                <div className="text-xs font-bold text-white">{method.provider}</div>
                                <div className="text-[10px] text-neutral-500">{method.accountNumber}</div>
                              </div>
                            </div>
                            {selectedPaymentMethodId === method.id && <CheckCircle size={16} className="text-bento-accent" />}
                          </button>
                        ))
                      )}
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="relative">
                      <span className={`absolute top-1/2 -translate-y-1/2 text-neutral-500 font-bold ${dir === 'rtl' ? 'right-6' : 'left-6'}`}>$</span>
                      <input type="number" value={withdrawAmount} onChange={e => setWithdrawAmount(e.target.value)} className={`w-full bg-black border border-neutral-800 rounded-2xl px-10 py-4 outline-none focus:border-bento-accent transition-all font-black text-xl ${dir === 'rtl' ? 'text-right' : 'text-left'}`} placeholder="0.00" />
                    </div>
                    <button onClick={handleWithdraw} disabled={isWithdrawing || !withdrawAmount || !selectedPaymentMethodId} className="w-full bg-white text-black py-5 rounded-[24px] font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-neutral-100 transition-all disabled:opacity-50">{isWithdrawing ? t('seller_dashboard.processing') : <><Wallet size={20} /> {t('seller_dashboard.withdraw_now')}</>}</button>
                  </div>
                </div>
            </div>
            <div className="space-y-6">
               <div className="bg-neutral-900 p-8 rounded-[40px] border border-neutral-800">
                 <div className={`flex justify-between items-center mb-6 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                   <h3 className="text-xs font-black uppercase tracking-widest text-neutral-500">{t('seller_dashboard.linked_methods')}</h3>
                   <button onClick={() => setShowPaymentModal(true)} className="p-2 bg-bento-accent/10 text-bento-accent rounded-xl hover:bg-bento-accent hover:text-black transition-all"><Plus size={16} /></button>
                 </div>
                 <div className="space-y-3">
                    {profile?.paymentMethods?.length === 0 ? (
                      <div className="py-8 text-center text-neutral-600 text-[10px] font-bold uppercase tracking-widest border border-dashed border-neutral-800 rounded-3xl">{t('seller_dashboard.no_methods')}</div>
                    ) : (
                      profile?.paymentMethods?.map((method, idx) => (
                        <div key={`${method.id}-${idx}`} className={`p-4 bg-black border border-neutral-800 rounded-2xl flex items-center justify-between group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                          <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                            <div className={`p-2.5 bg-neutral-900 rounded-lg ${dir === 'rtl' ? 'ml-3' : 'mr-3'}`}>{method.type === 'bank' ? <Building2 size={16} /> : method.type === 'paypal' ? <CreditCard size={16} /> : <Smartphone size={16} />}</div>
                            <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                              <div className="text-sm font-bold text-white">{method.provider}</div>
                              <div className="text-[10px] text-neutral-500">{method.accountNumber}</div>
                            </div>
                          </div>
                          <button onClick={() => handleRemovePaymentMethod(method.id)} className={`p-2 text-neutral-600 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100 ${dir === 'rtl' ? 'ml-2' : 'mr-2'}`}><Trash2 size={16} /></button>
                        </div>
                      ))
                    )}
                 </div>
               </div>
               <div className="bg-neutral-900 p-8 rounded-[40px] border border-neutral-800">
                 <h3 className={`text-xs font-black uppercase tracking-widest text-neutral-500 mb-6 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller_dashboard.security_guide')}</h3>
                 <div className="space-y-4">
                    <div className="p-6 bg-emerald-500/5 rounded-3xl border border-emerald-500/10">
                        <div className={`flex items-center gap-3 mb-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                          <ShieldCheck className="text-emerald-500" size={20} />
                          <span className="font-bold text-emerald-500 text-sm">{t('seller_dashboard.escrow_system')}</span>
                        </div>
                        <p className={`text-[10px] font-medium text-neutral-400 leading-relaxed ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('seller_dashboard.escrow_desc')}</p>
                    </div>
                 </div>
               </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'store' && (
        <div className={`space-y-8 ${dir === 'rtl' ? 'rtl' : 'ltr'}`}>
           <div className={`bg-neutral-900/50 p-6 rounded-[30px] border border-neutral-800 flex items-center justify-between ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                <h3 className="font-black italic text-xl">{t('seller_dashboard.customize_store')}</h3>
                <p className="text-xs text-neutral-500 font-medium">{t('seller_dashboard.customize_desc')}</p>
              </div>
           </div>
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {products.map((product, idx) => (
                <div key={`${product.id}-${idx}`} className={`bg-neutral-900 p-4 rounded-3xl border border-neutral-800 flex items-center gap-4 group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                   <img src={product.imageUrl} alt="" className="w-16 h-16 rounded-xl object-cover" />
                   <div className={`flex-1 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      <h4 className="font-bold text-sm truncate">{product.title}</h4>
                      <div className={`flex items-center gap-2 mt-1 ${dir === 'rtl' ? 'justify-end' : ''}`}>
                        {product.isPinned && (
                          <span className="bg-bento-accent/20 text-bento-accent text-[8px] font-black px-2 py-0.5 rounded-full flex items-center gap-1">
                            <Pin size={8} /> {t('seller_dashboard.pinned')}
                          </span>
                        )}
                      </div>
                   </div>
                   <div className={`flex gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                       <button onClick={() => handleMoveProduct(product, 'up')} disabled={products.indexOf(product) === 0} className="p-3 bg-black/40 text-neutral-500 hover:text-white rounded-xl transition-all disabled:opacity-20"><ArrowUp size={18} /></button>
                       <button onClick={() => handleMoveProduct(product, 'down')} disabled={products.indexOf(product) === products.length - 1} className="p-3 bg-black/40 text-neutral-500 hover:text-white rounded-xl transition-all disabled:opacity-20"><ArrowDown size={18} /></button>
                       <button onClick={() => handleTogglePin(product)} className={`p-3 rounded-xl transition-all ${product.isPinned ? 'bg-bento-accent text-black' : 'bg-black/40 text-neutral-500 hover:text-white'}`}><Pin size={18} /></button>
                   </div>
                </div>
              ))}
           </div>
        </div>
      )}

      {activeTab === 'market-studio' && (
        <MarketStudio 
          user={user} 
          profile={profile} 
          products={products} 
          orders={orders} 
          onDeleteProduct={handleDeleteProduct}
          onClose={() => setActiveTab('overview')} 
        />
      )}

      {/* Modals */}
      <AnimatePresence>
        {productToDelete && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }} 
              exit={{ scale: 0.9, opacity: 0 }}
              className={`bg-neutral-900 w-full max-w-md rounded-[40px] p-8 md:p-10 border border-neutral-800 shadow-2xl relative ${dir === 'rtl' ? 'rtl' : 'ltr'}`}
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-20 h-20 bg-red-500/10 rounded-[28px] mb-6 flex items-center justify-center text-red-500">
                  <Trash2 size={40} />
                </div>
                <h3 className="text-2xl font-black italic tracking-tighter uppercase mb-2">
                  {dir === 'rtl' ? 'حذف المنتج؟' : 'Delete Product?'}
                </h3>
                <p className="text-sm text-neutral-500 font-bold uppercase tracking-widest leading-relaxed mb-8 px-4">
                  {dir === 'rtl' 
                    ? `هل أنت متأكد من رغبتك في حذف "${productToDelete.title}"؟ لا يمكن التراجع عن هذا الإجراء.` 
                    : `Are you sure you want to delete "${productToDelete.title}"? This action cannot be undone.`}
                </p>
                <div className="flex gap-4 w-full">
                  <button 
                    onClick={() => setProductToDelete(null)}
                    disabled={isDeleting}
                    className="flex-1 py-4 bg-neutral-800 hover:bg-neutral-700 text-white rounded-2xl font-black uppercase tracking-widest text-xs transition-all disabled:opacity-50"
                  >
                    {t('common.cancel')}
                  </button>
                  <button 
                    onClick={() => executeDelete(productToDelete.id, productToDelete.imageUrl)}
                    disabled={isDeleting}
                    className="flex-1 py-4 bg-red-600 hover:bg-red-500 text-white rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-lg shadow-red-600/20 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {isDeleting ? <Loader2 size={16} className="animate-spin" /> : <Trash2 size={16} />}
                    {isDeleting ? t('product_form.uploading') : (dir === 'rtl' ? 'حذف' : 'Delete')}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}

        {proofingOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className={`bg-neutral-900 w-full max-w-lg rounded-[40px] p-8 border border-neutral-800 my-8 shadow-2xl relative ${dir === 'rtl' ? 'rtl' : 'ltr'}`}>
              <button 
                onClick={() => setProofingOrder(null)} 
                className={`absolute top-8 p-2 text-neutral-500 hover:text-white transition-colors ${dir === 'rtl' ? 'left-8' : 'right-8'}`}
              >
                <X size={24} />
              </button>

              <div className={`mb-8 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                <h2 className="text-3xl font-black italic tracking-tighter uppercase">Order Preparation Proof</h2>
                <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest mt-1">Upload a photo of the prepared order</p>
              </div>

              <div className="space-y-6">
                <div className="aspect-video rounded-3xl border-2 border-dashed border-neutral-800 bg-black/40 flex flex-col items-center justify-center relative overflow-hidden group">
                  {proofFile ? (
                    <img src={URL.createObjectURL(proofFile)} alt="Proof" className="w-full h-full object-cover" />
                  ) : (
                    <>
                      <Camera size={32} className="text-neutral-700 mb-2" />
                      <p className="text-[10px] font-black uppercase text-neutral-600 tracking-widest">Take or Select Photo</p>
                    </>
                  )}
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={e => setProofFile(e.target.files?.[0] || null)}
                    className="absolute inset-0 opacity-0 cursor-pointer"
                  />
                </div>

                <div className={`p-4 bg-blue-500/5 border border-blue-500/10 rounded-2xl flex gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <Info size={16} className="text-blue-500 shrink-0 mt-0.5" />
                  <p className={`text-[10px] font-medium text-neutral-400 leading-relaxed uppercase tracking-tight ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    This photo will be shared with the buyer and courier to verify the order integrity before pickup.
                  </p>
                </div>

                <button 
                  onClick={handleUploadSellerProof}
                  disabled={!proofFile || uploadingProof}
                  className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-neutral-100 transition-all disabled:opacity-50"
                >
                  {uploadingProof ? <Loader2 size={18} className="animate-spin" /> : <Upload size={18} />}
                  {uploadingProof ? t('product_form.uploading') : "Upload & Mark as Preparing"}
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {editingProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} 
              animate={{ scale: 1, opacity: 1 }} 
              className={`bg-neutral-900 w-full max-w-4xl rounded-[40px] p-8 md:p-12 border border-neutral-800 my-8 shadow-2xl relative ${dir === 'rtl' ? 'rtl' : 'ltr'}`}
            >
              <button 
                onClick={() => setEditingProduct(null)} 
                className={`absolute top-8 p-2 text-neutral-500 hover:text-white transition-colors ${dir === 'rtl' ? 'left-8' : 'right-8'}`}
              >
                <X size={24} />
              </button>

              <div className={`mb-10 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                <h2 className="text-4xl font-black italic tracking-tighter uppercase">{t('seller_dashboard.edit_product')}</h2>
                <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest mt-1">{t('seller_dashboard.edit_desc') || "Update your product details"}</p>
              </div>

              <form onSubmit={handleUpdateProduct} className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Image Section */}
                <div className="md:col-span-2">
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-4 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_form.image_label')}</label>
                  <div className={`flex flex-wrap gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="relative w-32 h-32 rounded-[24px] overflow-hidden border-2 border-neutral-800 bg-black/40 group">
                      <img src={editingProduct.imageUrl} alt="" className="w-full h-full object-cover" />
                      <label className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                        <Upload size={20} className="text-white" />
                        <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) setSelectedFile(file);
                          }}
                        />
                      </label>
                    </div>
                    {selectedFile && (
                      <div className="w-32 h-32 rounded-[24px] overflow-hidden border-2 border-bento-accent bg-bento-accent/5 flex items-center justify-center relative">
                        <div className="text-[8px] font-black uppercase text-bento-accent tracking-tighter text-center px-2">New Image Selected</div>
                        <button onClick={() => setSelectedFile(null)} className="absolute top-1 right-1 p-1 bg-black/80 rounded-full text-white hover:text-red-500">
                          <X size={12} />
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_form.title_label')}</label>
                  <input 
                    type="text" 
                    value={editingProduct.title}
                    onChange={e => setEditingProduct({...editingProduct, title: e.target.value})}
                    className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                    placeholder={t('product_form.title_placeholder')}
                    required
                  />
                </div>

                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_form.price_label')}</label>
                  <input 
                    type="number" 
                    value={editingProduct.price}
                    onChange={e => setEditingProduct({...editingProduct, price: parseFloat(e.target.value)})}
                    className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                    placeholder="0.00"
                    step="0.01"
                    required
                  />
                </div>

                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_form.stock_label')}</label>
                  <input 
                    type="number" 
                    value={editingProduct.stockQuantity}
                    onChange={e => setEditingProduct({...editingProduct, stockQuantity: parseInt(e.target.value)})}
                    className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                    placeholder="1"
                    required
                  />
                </div>

                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_form.category_label')}</label>
                  <CustomSelect
                    value={editingProduct.category}
                    onChange={(val) => setEditingProduct({...editingProduct, category: val})}
                    options={['veg_fruits', 'meat', 'food', 'supermarket', 'electronics', 'home_appliances', 'electrical_tools', 'sanitary_tools'].map(cat => ({
                      id: cat,
                      label: t(`product_form.categories.${cat.toLowerCase()}`) || cat
                    }))}
                    placeholder={t('seller.store_category_placeholder') || 'اختر الفئة'}
                    label={t('product_form.category_label')}
                    dir={dir}
                  />
                </div>

                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_form.origin_label')}</label>
                  <input 
                    type="text" 
                    value={editingProduct.originCountry}
                    onChange={e => setEditingProduct({...editingProduct, originCountry: e.target.value})}
                    className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                    placeholder={t('product_form.origin_placeholder')}
                    required
                  />
                </div>

                <div className="md:col-span-2">
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_form.delivery_label')}</label>
                  <input 
                    type="text" 
                    value={Array.isArray(editingProduct.availableCountries) ? editingProduct.availableCountries.join(', ') : editingProduct.availableCountries}
                    onChange={e => {
                      const countries = Array.from(new Set(e.target.value.split(',').map(c => c.trim()).filter(c => c !== '')));
                      setEditingProduct({...editingProduct, availableCountries: countries as any});
                    }}
                    className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                    placeholder={t('product_form.delivery_placeholder')}
                    required
                  />
                  <p className={`text-[9px] text-neutral-600 mt-2 font-bold uppercase tracking-widest ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    {dir === 'rtl' ? 'افصل بين الدول بفاصلة (،)' : 'Separate countries with commas (,)'}
                  </p>
                </div>

                <div className="md:col-span-2">
                  <div className="bg-blue-500/5 border border-blue-500/10 rounded-3xl p-6 flex items-center gap-4 relative overflow-hidden">
                     <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 blur-2xl pointer-events-none"></div>
                     <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500 shrink-0">
                        <Truck size={24} />
                     </div>
                     <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                        <h4 className="text-sm font-black italic uppercase mb-1">
                           {dir === 'rtl' ? 'توصيل عبر المناديب المعتمدين' : 'Verified Platform Delivery'}
                        </h4>
                        <p className="text-[10px] text-neutral-500 font-bold uppercase tracking-tight">
                           {dir === 'rtl' 
                             ? 'يتم التوصيل آلياً عبر المندوبين المقبولين من قبل الإدارة.' 
                             : 'Delivery is automatically handled by approved platform couriers.'}
                        </p>
                     </div>
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_form.desc_label')}</label>
                  <textarea 
                    value={editingProduct.description}
                    onChange={e => setEditingProduct({...editingProduct, description: e.target.value})}
                    className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-6 focus:border-bento-accent outline-none transition-all font-bold min-h-[150px] resize-none ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                    placeholder={t('product_form.desc_placeholder')}
                    required
                  />
                </div>

                <div className={`md:col-span-2 flex gap-4 pt-6 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <button 
                    type="button" 
                    onClick={() => setEditingProduct(null)} 
                    className="flex-1 px-8 py-5 border border-neutral-800 rounded-[25px] font-black uppercase tracking-widest text-xs hover:bg-neutral-800 transition-all"
                  >
                    {t('common.cancel')}
                  </button>
                  <button 
                    type="submit" 
                    disabled={uploading}
                    className="flex-[2] px-8 py-5 bg-white text-black rounded-[25px] font-black uppercase tracking-widest text-xs hover:bg-neutral-100 transition-all flex items-center justify-center gap-2"
                  >
                    {uploading ? (
                      <Loader2 className="animate-spin" size={20} />
                    ) : (
                      <Check size={20} />
                    )}
                    {uploading ? t('product_form.uploading') : t('common.save')}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}

        {showPaymentModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className={`bg-neutral-900 w-full max-w-lg rounded-[40px] p-8 border border-neutral-800 my-8 shadow-2xl relative ${dir === 'rtl' ? 'rtl' : 'ltr'}`}>
              <button 
                onClick={() => setShowPaymentModal(false)} 
                className={`absolute top-6 p-2 text-neutral-500 hover:text-white ${dir === 'rtl' ? 'left-6' : 'right-6'}`}
              >
                <X size={24} />
              </button>
              <h2 className={`text-3xl font-black mb-8 italic tracking-tighter uppercase ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                {t('seller_dashboard.link_payment_method')}
              </h2>
              <form onSubmit={handleAddPaymentMethod} className="space-y-6">
                <div>
                   <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                     {t('settings.payment_method_type') || 'Payment Method Type'}
                   </label>
                   <div className="grid grid-cols-3 gap-4">
                     {[
                       { id: 'wallet', label: t('settings.payment_methods.wallet') || 'Wallet', icon: Smartphone }, 
                       { id: 'bank', label: t('settings.payment_methods.bank') || 'Bank', icon: Building2 }, 
                       { id: 'paypal', label: 'PayPal', icon: CreditCard }
                     ].map(type => (
                       <button 
                         key={type.id} 
                         type="button" 
                         onClick={() => setPaymentMethodForm({...paymentMethodForm, type: type.id as any})} 
                         className={`flex flex-col items-center gap-2 p-4 rounded-2xl border transition-all ${paymentMethodForm.type === type.id ? 'bg-bento-accent/10 border-bento-accent text-bento-accent' : 'bg-black border-neutral-800 text-neutral-500 hover:border-neutral-700'}`}
                       >
                         <type.icon size={20} />
                         <span className="text-[10px] font-bold uppercase">{type.label}</span>
                       </button>
                     ))}
                   </div>
                </div>
                <input 
                  type="text" 
                  value={paymentMethodForm.provider} 
                  onChange={e => setPaymentMethodForm({...paymentMethodForm, provider: e.target.value})} 
                  className={`w-full bg-black border border-neutral-800 rounded-2xl px-5 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`} 
                  placeholder={t('settings.bank_name_placeholder') || 'Bank or Wallet Name'} 
                  required 
                />
                <input 
                  type="text" 
                  value={paymentMethodForm.accountNumber} 
                  onChange={e => setPaymentMethodForm({...paymentMethodForm, accountNumber: e.target.value})} 
                  className={`w-full bg-black border border-neutral-800 rounded-2xl px-5 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`} 
                  placeholder={t('settings.account_number_placeholder') || 'Account Number'} 
                  required 
                />
                <input 
                  type="text" 
                  value={paymentMethodForm.accountHolderName} 
                  onChange={e => setPaymentMethodForm({...paymentMethodForm, accountHolderName: e.target.value})} 
                  className={`w-full bg-black border border-neutral-800 rounded-2xl px-5 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`} 
                  placeholder={t('settings.full_name_placeholder') || 'Full Name'} 
                  required 
                />
                <div className={`flex gap-4 pt-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <button type="button" onClick={() => setShowPaymentModal(false)} className="flex-1 px-8 py-5 border border-neutral-800 rounded-[25px] font-bold hover:bg-neutral-800 transition-all uppercase tracking-widest text-xs">{t('common.cancel')}</button>
                  <button type="submit" className="flex-[2] px-8 py-5 bg-white text-black rounded-[25px] font-black hover:bg-neutral-100 transition-all uppercase tracking-widest text-xs">{t('common.save')}</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <IdentityVerification isOpen={showVerification} onClose={() => setShowVerification(false)} />
      {/* Mobile Category Menu Drawer */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: dir === 'rtl' ? 300 : -300 }}
              animate={{ x: 0 }}
              exit={{ x: dir === 'rtl' ? 300 : -300 }}
              className={`fixed top-0 bottom-0 w-72 bg-neutral-950 border-neutral-800 z-[70] shadow-2xl p-8 flex flex-col ${dir === 'rtl' ? 'right-0 border-l' : 'left-0 border-r'}`}
            >
              <div className={`flex items-center justify-between mb-10 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <h3 className="text-xl font-black italic tracking-tighter uppercase">{dir === 'rtl' ? 'التصنيفات' : 'Categories'}</h3>
                <button onClick={() => setIsMenuOpen(false)} className="p-2 bg-white/5 rounded-xl text-neutral-500 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-2 flex-1 overflow-y-auto no-scrollbar">
                {productCategories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => {
                      setSelectedCategory(cat.id === 'all' ? null : cat.id);
                      setIsMenuOpen(false);
                      setActiveTab('products');
                    }}
                    className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all border ${
                      (selectedCategory === cat.id || (cat.id === 'all' && !selectedCategory))
                        ? 'bg-bento-accent/10 border-bento-accent text-bento-accent' 
                        : 'bg-white/5 border-transparent text-neutral-400 hover:bg-white/10'
                    } ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'text-left'}`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                      (selectedCategory === cat.id || (cat.id === 'all' && !selectedCategory))
                        ? 'bg-bento-accent text-black' 
                        : 'bg-white/10 text-neutral-500'
                    }`}>
                      {cat.id === 'all' ? 'Σ' : cat.label.charAt(0)}
                    </div>
                    <span className="font-bold text-sm">{cat.label}</span>
                  </button>
                ))}
              </div>

              <div className="pt-6 border-t border-white/5 mt-auto">
                <div className={`flex items-center gap-3 p-4 rounded-2xl bg-white/5 ${dir === 'rtl' ? 'flex-row-reverse text-right' : ''}`}>
                  <Activity size={18} className="text-bento-accent" />
                  <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">{dir === 'rtl' ? 'تصفح التصنيفات النشطة' : 'Browsing Active Categories'}</div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
