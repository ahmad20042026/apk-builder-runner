import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LogIn, UserPlus, Mail, Phone, Lock, ChevronRight, ShieldCheck } from 'lucide-react';
import PolicyModal from '../components/PolicyModal';
import { POLICIES } from '../constants/policies';
import { AuthService } from '../services/AuthService';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [showPolicyModal, setShowPolicyModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const [isCompletingGoogleProfile, setIsCompletingGoogleProfile] = useState(false);
  const [googleUser, setGoogleUser] = useState<any>(null);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegistering || isCompletingGoogleProfile) {
      if (!acceptedTerms) {
        setError('يجب الموافقة على سياسات الاستخدام والخصوصية للمتابعة');
        return;
      }
      if (isRegistering && password !== confirmPassword) {
        setError('كلمات المرور غير متطابقة');
        return;
      }
      if (!firstName || !lastName || !phone) {
        setError('يرجى ملء جميع الحقول المطلوبة');
        return;
      }
      // Phone format validation 05********
      if (!/^05[0-9]{8}$/.test(phone)) {
        setError('رقم الهاتف يجب أن يبدأ بـ 05 ويتكون من 10 أرقام');
        return;
      }
    }
    if (isSubmitting) return; 
    setIsSubmitting(true);
    setError('');
    try {
      if (isCompletingGoogleProfile && googleUser) {
        // Complete Google Profile
        await AuthService.syncProfile(googleUser, true, { firstName, lastName, phone });
        // Set password for the account
        try {
          const { updatePassword } = await import('../lib/firebase');
          await updatePassword(googleUser, password);
        } catch (pwErr) {
          console.warn("Could not set password for Google account:", pwErr);
        }
        navigate('/');
      } else if (isRegistering) {
        await AuthService.registerWithEmail(email, password, true, { firstName, lastName, phone });
        navigate('/');
      } else {
        await AuthService.loginWithEmail(email, password);
        navigate('/');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const signInWithGoogle = async () => {
    if (!acceptedTerms) {
      setError('يجب الموافقة على شروط الاستخدام للمتابعة');
      return;
    }
    if (isSubmitting) return;
    setIsSubmitting(true);
    setError('');
    try {
      const { signInWithPopup, GoogleAuthProvider, auth, db, doc, getDoc } = await import('../lib/firebase');
      const provider = new GoogleAuthProvider();
      const cred = await signInWithPopup(auth, provider);
      
      // Check if user already has a profile
      const userRef = doc(db, 'users', cred.user.uid);
      const userSnap = await getDoc(userRef);
      
      if (userSnap.exists()) {
        navigate('/');
      } else {
        // New user from Google, show completion form
        setGoogleUser(cred.user);
        setIsCompletingGoogleProfile(true);
        // Pre-fill some data if available
        if (cred.user.displayName) {
          const names = cred.user.displayName.split(' ');
          setFirstName(names[0] || '');
          setLastName(names.slice(1).join(' ') || '');
        }
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isCompletingGoogleProfile) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black px-4">
        <div className="w-full max-w-md bg-neutral-900 rounded-3xl p-8 border border-neutral-800 shadow-2xl">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-black text-white italic tracking-tighter">إكمال الملف الشخصي</h1>
            <p className="text-neutral-400 mt-2">يرجى إدخال معلوماتك للمتابعة</p>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-sm rounded-lg">
              {error}
            </div>
          )}

          <form onSubmit={handleAuth} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="relative">
                <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                <input 
                  type="text" 
                  placeholder="الاسم الأول"
                  className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  required
                />
              </div>
              <div className="relative">
                <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                <input 
                  type="text" 
                  placeholder="الاسم الأخير"
                  className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  required
                />
              </div>
            </div>
            
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
              <input 
                type="tel" 
                placeholder="رقم الهاتف (05********)"
                className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                required
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
              <input 
                type="password" 
                placeholder="كلمة مرور الحساب"
                className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <button 
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isSubmitting ? (
                <span className="flex items-center gap-2"><div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" /> جاري الحفظ...</span>
              ) : (
                <><ChevronRight size={18} /> إتمام التسجيل</>
              )}
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-black px-4">
      <div className="w-full max-w-md bg-neutral-900 rounded-3xl p-8 border border-neutral-800 shadow-2xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-black text-white italic tracking-tighter">سوق</h1>
          <p className="text-neutral-400 mt-2">The social way to shop</p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-sm rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleAuth} className="space-y-4">
          {isRegistering && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div className="relative">
                  <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                  <input 
                    type="text" 
                    placeholder="الاسم الأول (كما في الهوية)"
                    className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    required
                  />
                </div>
                <div className="relative">
                  <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                  <input 
                    type="text" 
                    placeholder="الاسم الأخير (كما في الهوية)"
                    className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    required
                  />
                </div>
              </div>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
                <input 
                  type="tel" 
                  placeholder="رقم الهاتف"
                  className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  required
                />
              </div>
            </>
          )}

          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
            <input 
              type="email" 
              placeholder="البريد الإلكتروني"
              className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
            <input 
              type="password" 
              placeholder="كلمة المرور"
              className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          {isRegistering && (
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" size={18} />
              <input 
                type="password" 
                placeholder="تأكيد كلمة المرور"
                className="w-full bg-neutral-800 border-none rounded-xl py-3 pl-10 pr-4 text-white focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
              />
            </div>
          )}

          <div className="flex items-center gap-3 bg-neutral-800/50 p-4 rounded-xl border border-neutral-800 hover:border-emerald-500/30 transition-colors group cursor-pointer" onClick={() => setAcceptedTerms(!acceptedTerms)}>
             <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${acceptedTerms ? 'bg-emerald-500 border-emerald-500' : 'border-neutral-700'}`}>
               {acceptedTerms && <ShieldCheck size={12} className="text-black" />}
             </div>
             <p className="text-[10px] text-neutral-400 font-bold leading-relaxed text-right flex-1">
               لقد قرأت سياسات الاستخدام والخصوصية واوافق عليها{' '}
               <button 
                type="button"
                onClick={(e) => { e.stopPropagation(); setShowPolicyModal(true); }} 
                className="text-emerald-400 hover:underline inline"
              >
                (اقرأ السياسات)
              </button>
             </p>
          </div>

          <button 
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isSubmitting ? (
              <span className="flex items-center gap-2"><div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin" /> جاري المعالجة...</span>
            ) : isRegistering ? (
              <><UserPlus size={18} /> إنشاء حساب</>
            ) : (
              <><LogIn size={18} /> تسجيل الدخول</>
            )}
          </button>
        </form>

        <div className="my-8 flex items-center gap-4 text-neutral-600">
          <div className="h-[1px] flex-1 bg-neutral-800" />
          <span className="text-xs font-bold uppercase tracking-widest">أو المتابعة بواسطة</span>
          <div className="h-[1px] flex-1 bg-neutral-800" />
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <button 
            type="button"
            onClick={signInWithGoogle}
            disabled={isSubmitting}
            className="flex items-center justify-center gap-2 bg-neutral-800 hover:bg-neutral-700 text-white py-3 rounded-xl transition-all border border-neutral-700/50 disabled:opacity-50"
          >
            <img src="https://www.google.com/favicon.ico" alt="google" className="w-4 h-4" />
            <span className="text-sm font-medium">جوجل</span>
          </button>
          <button 
            className="flex items-center justify-center gap-2 bg-neutral-800 hover:bg-neutral-700 text-white py-3 rounded-xl transition-all border border-neutral-700/50 opacity-50 cursor-not-allowed"
            title="قريباً"
          >
            <Phone size={16} />
            <span className="text-sm font-medium">الهاتف</span>
          </button>
        </div>

        <p className="text-center text-neutral-500 text-sm">
          {isRegistering ? 'لديك حساب بالفعل؟' : "ليس لديك حساب؟"}
          <button 
            onClick={() => setIsRegistering(!isRegistering)}
            className="ml-1 text-emerald-400 font-bold hover:underline"
          >
            {isRegistering ? 'تسجيل الدخول' : 'إنشاء حساب'}
          </button>
        </p>
      </div>
      <PolicyModal isOpen={showPolicyModal} onClose={() => setShowPolicyModal(false)} type="buyer" />
    </div>
  );
}
