import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  db, collection, query, where, getDocs, 
  doc, updateDoc, incrementResilient as increment, 
  serverTimestampResilient as serverTimestamp, runTransaction, getDoc, addDoc 
} from '../lib/firebase';
import { CartItem, UserProfile, Product } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calculator, Phone, Wallet, CreditCard, ShieldCheck, 
  ArrowRight, CheckCircle2, ChevronLeft, Truck, Package, 
  ShoppingBag, Building, AlertTriangle, BadgeCheck, Loader2, Download, Printer, Zap
} from 'lucide-react';
import { useNavigate, useSearchParams, useLocation } from 'react-router-dom';
import { sendNotification } from '../lib/notifications';
import { OrderService } from '../services/OrderService';

export default function Checkout() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const productId = searchParams.get('productId');
  const directBuyState = location.state as { selectedAddOns?: any[], selectedDrinks?: string[] } | null;
  
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [paying, setPaying] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'invoice' | 'payment_method' | 'processing' | 'success'>('invoice');
  const [paymentMethod, setPaymentMethod] = useState<'wallet' | 'jawwal_pay'>('wallet');
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isJawwalPaySimulating, setIsJawwalPaySimulating] = useState(false);

  useEffect(() => {
    if (!user) return;
    
    const fetchData = async () => {
      try {
        if (productId) {
          const productSnap = await getDoc(doc(db, 'products', productId));
          if (productSnap.exists()) {
            const prod = productSnap.data() as Product;
            setCartItems([{
              id: 'temp',
              userId: user.uid,
              productId: productId,
              sellerId: prod.sellerId,
              sellerName: prod.sellerName,
              title: prod.title,
              price: prod.price,
              imageUrl: prod.imageUrl,
              quantity: 1,
              selectedAddOns: directBuyState?.selectedAddOns || [],
              selectedDrinks: directBuyState?.selectedDrinks || [],
              createdAt: new Date()
            } as CartItem]);
          }
        } else {
          // Fetch from cart collection
          const cartSnap = await getDocs(query(collection(db, 'carts'), where('userId', '==', user.uid)));
          const items = cartSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as CartItem));
          setCartItems(items);
        }
        
        const userSnap = await getDoc(doc(db, 'users', user.uid));
        if (userSnap.exists()) {
          setUserProfile({ uid: userSnap.id, ...userSnap.data() } as UserProfile);
        }
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, [user, productId]);

  const calculateSubtotal = () => cartItems.reduce((acc, item) => {
    const addonsTotal = item.selectedAddOns?.reduce((sum, a) => sum + (a.price * a.quantity), 0) || 0;
    return acc + ((item.price + addonsTotal) * item.quantity);
  }, 0);
  const deliveryFee = 15; 
  const totalAmount = calculateSubtotal() + deliveryFee;

  const handleWalletPayment = async () => {
    if (!user || !userProfile) return;
    
    if (paymentMethod === 'wallet' && (userProfile.walletBalance || 0) < totalAmount) {
      alert('رصيدك في المحفظة غير كافٍ. يرجى الشحن أولاً أو استخدام وسيلة دفع أخرى.');
      return;
    }

    setPaying(true);
    setPaymentStep('processing');
    
    try {
      const userRef = doc(db, 'users', user.uid);
      
      if (paymentMethod === 'wallet') {
        await runTransaction(db, async (transaction) => {
          const userDoc = await transaction.get(userRef);
          const currentBalance = userDoc.data()?.walletBalance || 0;
          
          if (currentBalance < totalAmount) {
            throw new Error("Insufficient balance");
          }

          transaction.update(userRef, {
            walletBalance: currentBalance - totalAmount,
            totalSpent: increment(totalAmount),
            updatedAt: serverTimestamp()
          });
        });
      }

      // Group items by seller
      const itemsBySeller: Record<string, CartItem[]> = {};
      cartItems.forEach(item => {
        if (!itemsBySeller[item.sellerId]) itemsBySeller[item.sellerId] = [];
        itemsBySeller[item.sellerId].push(item);
      });

      const orderPromises = Object.entries(itemsBySeller).map(async ([sellerId, items]) => {
        const sellerName = items[0].sellerName || 'متجر سوق';
        const subtotal = items.reduce((acc, i) => acc + (i.price * i.quantity), 0);
        const orderId = Math.floor(1000000000 + Math.random() * 9000000000).toString();
        
        await addDoc(collection(db, 'orders'), {
          id: orderId,
          buyerId: user.uid,
          buyerName: userProfile.displayName,
          sellerId,
          sellerName,
          items: items.map(i => ({
            productId: i.productId,
            title: i.title,
            price: i.price,
            quantity: i.quantity,
            imageUrl: i.imageUrl,
            selectedAddOns: i.selectedAddOns || [],
            selectedDrinks: i.selectedDrinks || []
          })),
          price: subtotal + (deliveryFee / Object.keys(itemsBySeller).length),
          status: 'pending',
          paymentStatus: 'paid',
          paymentMethod: paymentMethod,
          deliveryFee: deliveryFee / Object.keys(itemsBySeller).length,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });

        await sendNotification(
          sellerId,
          'sale',
          'طلب جديد!',
          `لديك طلب جديد بقيمة $${subtotal}`,
          '/seller'
        );
      });

      await Promise.all(orderPromises);
      
      if (!productId) {
        // Clear Cart
        const cartDocs = await getDocs(query(collection(db, 'carts'), where('userId', '==', user.uid)));
        for (const d of cartDocs.docs) {
          await updateDoc(doc(db, 'carts', d.id), { status: 'ordered' });
        }
      }

      setPaymentStep('success');
    } catch (error) {
      console.error(error);
      alert('فشلت عملية الدفع. يرجى المحاولة مرة أخرى.');
      setPaymentStep('invoice');
    } finally {
      setPaying(false);
      setIsJawwalPaySimulating(false);
    }
  };

  const handleJawwalPay = () => {
    setIsJawwalPaySimulating(true);
    setPaymentStep('processing');
    
    // Simulate Jawwal Pay integration delay
    setTimeout(() => {
      handleWalletPayment(); 
    }, 3000);
  };

  const downloadInvoice = () => {
    window.print();
  };

  if (loading) return <div className="min-h-screen bg-black flex items-center justify-center"><Loader2 className="w-10 h-10 text-bento-accent animate-spin" /></div>;

  if (paymentStep === 'success') {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-8 text-center" dir="rtl">
        <motion.div initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="w-32 h-32 bg-emerald-500 rounded-full flex items-center justify-center mb-10 shadow-[0_0_80px_rgba(16,185,129,0.3)]">
          <CheckCircle2 size={64} className="text-black" />
        </motion.div>
        <h2 className="text-4xl font-black italic tracking-tighter uppercase mb-4 text-white">تم تأكيد الدفع بنجاح!</h2>
        <p className="text-neutral-500 max-w-sm mb-12 font-bold uppercase tracking-widest text-[10px]">شكراً لك على ثقتك بـ "سوق". طلبك الآن قيد المراجعة وسيتم تحويله للبائع فوراً.</p>
        
        <div className="bg-[#121212] border border-white/5 p-8 rounded-[40px] w-full max-w-sm mb-12">
            <div className="flex justify-between items-center mb-6">
                <span className="text-neutral-500 text-[10px] font-black uppercase">رقم العملية</span>
                <span className="font-mono text-white text-xs">#PX-{Math.random().toString(36).substr(2, 9).toUpperCase()}</span>
            </div>
            <div className="flex justify-between items-center mb-6">
                <span className="text-neutral-500 text-[10px] font-black uppercase">المبلغ المدفوع</span>
                <span className="text-xl font-black text-emerald-400">${totalAmount}</span>
            </div>
            <button onClick={downloadInvoice} className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center gap-3 text-neutral-400 hover:text-white transition-colors">
               <Download size={18} />
               <span className="text-[10px] font-black uppercase tracking-widest">تحميل الفاتورة (PDF)</span>
            </button>
        </div>

        <div className="flex flex-col gap-4 w-full max-w-xs">
           <button onClick={() => navigate('/orders')} className="py-5 bg-white text-black rounded-3xl font-black uppercase tracking-widest text-sm hover:scale-105 transition-transform">تتبع طلباتي</button>
           <button onClick={() => navigate('/')} className="py-5 bg-white/5 text-neutral-400 rounded-3xl font-bold border border-white/5 hover:text-white transition-colors">العودة للرئيسية</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6 pb-32" dir="rtl">
      {paymentStep === 'processing' && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-3xl flex flex-col items-center justify-center text-center p-12">
           <div className="relative w-32 h-32 mb-10">
              <div className="absolute inset-0 border-4 border-bento-accent/20 rounded-full" />
              <div className="absolute inset-0 border-4 border-bento-accent border-r-transparent rounded-full animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                 <Zap className="text-bento-accent animate-pulse" size={40} />
              </div>
           </div>
           <h2 className="text-3xl font-black italic tracking-tighter uppercase mb-4">جاري تأكيد العملية...</h2>
           <p className="text-neutral-500 text-[10px] font-black uppercase tracking-widest leading-relaxed max-w-xs">
             {isJawwalPaySimulating ? 'نقوم بالاتصال بخوادم Jawwal Pay للتحقق من السداد' : 'جاري سحب الرصيد وتأكيد الطلب مع النظام السحابي'}
           </p>
        </div>
      )}

      <header className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-3 bg-white/5 rounded-2xl hover:bg-white/10 transition-colors"><ArrowRight size={20} /></button>
          <div>
            <h1 className="text-2xl font-black italic tracking-tighter uppercase">ملخص السداد الآمن</h1>
            <p className="text-[10px] text-neutral-500 font-bold uppercase tracking-widest">تأكيد الفاتورة وبيانات الاستلام</p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-emerald-500/10 rounded-full border border-emerald-500/20">
           <ShieldCheck size={16} className="text-emerald-500" />
           <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest italic">Protected</span>
        </div>
      </header>

      <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 space-y-8">
          {/* Invoice Section */}
          <div className="bg-[#0A0A0A] border border-white/5 rounded-[48px] overflow-hidden shadow-2xl">
            <div className="p-8 border-b border-white/5 flex justify-between items-center bg-white/[0.01]">
              <h3 className="font-black italic text-xl uppercase tracking-tighter flex items-center gap-3">
                <Calculator size={20} className="text-bento-accent" />
                بيان الفاتورة التفصيلي
              </h3>
            </div>
            <div className="p-10 space-y-8">
              <div className="space-y-6">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex justify-between items-center group">
                    <div className="flex items-center gap-6">
                      <div className="w-16 h-16 bg-neutral-900 rounded-2xl overflow-hidden border border-white/5 group-hover:border-bento-accent transition-colors">
                        <img src={item.imageUrl} alt="" className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <div className="font-bold text-lg">{item.title}</div>
                        {((item.selectedAddOns && item.selectedAddOns.length > 0) || (item.selectedDrinks && item.selectedDrinks.length > 0)) && (
                          <div className="flex flex-wrap gap-1 mt-1 mb-1">
                            {item.selectedAddOns?.map((a, i) => (
                              <span key={i} className="text-[7px] font-black bg-white/5 px-1.5 py-0.5 rounded border border-white/5 uppercase">+{a.name}</span>
                            ))}
                            {item.selectedDrinks?.map((d, i) => (
                              <span key={i} className="text-[7px] font-black bg-bento-accent/10 text-bento-accent px-1.5 py-0.5 rounded border border-bento-accent/20 uppercase">{d}</span>
                            ))}
                          </div>
                        )}
                        <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-widest">الكمية: {item.quantity} × ${item.price + (item.selectedAddOns?.reduce((s, a) => s + a.price * a.quantity, 0) || 0)}</div>
                        <div className="text-[9px] text-emerald-500/60 font-black uppercase tracking-tighter mt-1">البائع: {item.sellerName}</div>
                      </div>
                    </div>
                    <div className="text-xl font-black italic tracking-tighter">${item.price * item.quantity}</div>
                  </div>
                ))}
              </div>

              <div className="h-px bg-white/5" />

              <div className="space-y-4">
                <div className="flex justify-between items-center text-neutral-500 text-sm font-bold uppercase tracking-widest">
                  <span>المجموع الفرعي</span>
                  <span>${calculateSubtotal()}</span>
                </div>
                <div className="flex justify-between items-center text-neutral-500 text-sm font-bold uppercase tracking-widest">
                  <span>رسوم التوصيل والخدمة</span>
                  <div className="flex items-center gap-2">
                    <Truck size={14} className="text-neutral-600" />
                    <span>${deliveryFee}</span>
                  </div>
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-dashed border-white/10">
                  <span className="text-2xl font-black italic tracking-tighter uppercase">الإجمالي النهائي</span>
                  <span className="text-4xl font-black italic tracking-tighter text-bento-accent">${totalAmount}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-[#0A0A0A] border border-white/5 rounded-[48px] p-10 flex items-center justify-between group cursor-pointer hover:border-white/10 transition-colors">
             <div className="flex items-center gap-8">
                <div className="w-16 h-16 bg-blue-500/10 text-blue-500 rounded-3xl flex items-center justify-center"><Package size={32} /></div>
                <div>
                   <h4 className="text-xl font-black italic uppercase tracking-tighter">عنوان التوصيل</h4>
                   <p className="text-neutral-500 text-sm font-medium mt-1">{userProfile?.region || 'غزة'} - {userProfile?.zone || 'الشارع الرئيسي'}</p>
                   <div className="text-[9px] text-blue-500 font-black uppercase tracking-widest mt-2">{userProfile?.phone || 'لا يوجد رقم هاتف'}</div>
                </div>
             </div>
             <button onClick={() => navigate('/profile')} className="p-4 bg-white/5 rounded-2xl text-neutral-500 hover:text-white transition-colors"><ChevronLeft size={24} /></button>
          </div>
        </div>

        <div className="space-y-8">
           <div className="bg-[#0A0A0A] border border-white/5 rounded-[48px] overflow-hidden">
             <div className="p-8 border-b border-white/5 bg-white/[0.01]">
               <h3 className="font-black italic text-lg uppercase tracking-tighter">اختر وسيلة الدفع</h3>
             </div>
             <div className="p-8 space-y-4">
                <button 
                  onClick={() => setPaymentMethod('wallet')}
                  className={`w-full p-6 rounded-3xl border transition-all flex items-center justify-between group ${paymentMethod === 'wallet' ? 'bg-white text-black border-white' : 'bg-white/5 border-white/5 text-neutral-500 hover:border-white/20'}`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-2xl ${paymentMethod === 'wallet' ? 'bg-black/10' : 'bg-white/5'}`}>
                      <Wallet size={20} />
                    </div>
                    <div className="text-right">
                       <div className="font-black italic uppercase tracking-tighter text-sm">رصيد المحفظة</div>
                       <div className={`text-[10px] font-black uppercase ${paymentMethod === 'wallet' ? 'text-black/60' : 'text-neutral-600'}`}>${userProfile?.walletBalance?.toLocaleString() || 0}</div>
                    </div>
                  </div>
                  {paymentMethod === 'wallet' && <CheckCircle2 size={24} className="text-black" />}
                </button>

                <button 
                  onClick={() => setPaymentMethod('jawwal_pay')}
                  className={`w-full p-6 rounded-3xl border transition-all flex items-center justify-between group ${paymentMethod === 'jawwal_pay' ? 'bg-[#FF0000] border-[#FF0000] text-white shadow-xl shadow-red-600/20' : 'bg-white/5 border-white/5 text-neutral-500 hover:border-red-600/30'}`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-2xl ${paymentMethod === 'jawwal_pay' ? 'bg-white/20' : 'bg-white/5'}`}>
                      <CreditCard size={20} />
                    </div>
                    <div className="text-right">
                       <div className="font-black italic uppercase tracking-tighter text-sm">Jawwal Pay</div>
                       <div className={`text-[10px] font-black uppercase ${paymentMethod === 'jawwal_pay' ? 'text-white/60' : 'text-neutral-600'}`}>دفع آمن بالهاتف</div>
                    </div>
                  </div>
                  {paymentMethod === 'jawwal_pay' && <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center"><CheckCircle2 size={18} className="text-red-600" /></div>}
                </button>
             </div>
           </div>

           <button 
             disabled={paying || cartItems.length === 0}
             onClick={paymentMethod === 'wallet' ? handleWalletPayment : handleJawwalPay}
             className="w-full py-7 bg-bento-accent text-black rounded-[32px] font-black uppercase tracking-[0.2em] text-sm hover:scale-102 transition-all shadow-[0_20px_50px_rgba(var(--bento-accent-rgb),0.3)] active:scale-98 disabled:opacity-50 flex items-center justify-center gap-4"
           >
             {paying ? <Loader2 className="animate-spin" /> : <>تأكيد السداد الآن <ArrowRight size={22} className="rotate-180" /></>}
           </button>

           <div className="p-8 bg-[#0A0A0A] border border-white/5 rounded-[40px] text-center">
              <ShieldCheck size={32} className="mx-auto mb-4 text-emerald-500 opacity-30" />
              <p className="text-[9px] font-black text-neutral-600 uppercase leading-relaxed px-4 tracking-widest">
                بضغطك على تأكيد السداد، أنت توافق على شروط الخدمة وسياسة الخصوصية الخاصة بمنصة "سوق". يتم حفظ الأموال في خزانة آمنة لحين تأكيد الاستلام.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
}
