import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { auth, db, signOut, updateDoc, doc, collection, query, where, getDocs, writeBatch, deleteDoc, serverTimestampResilient as serverTimestamp, EmailAuthProvider, reauthenticateWithCredential } from '../lib/firebase';
import { ChevronLeft, User, Lock, Globe, Bell, Shield, Eye, LogOut, ChevronRight, Check, Camera, ShieldAlert, Smartphone, Truck, ArrowRight, ArrowLeft, Trash2, Snowflake, Pause, Download, Fingerprint, Key, MessageCircle, Send, RefreshCw, ShieldCheck, Store } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import CourierApplicationPortal from '../components/CourierApplicationPortal';
import IdentityVerification from '../components/IdentityVerification';
import { uploadAndCompressImage } from '../lib/storage';
import { logAction } from '../lib/audit';
import { ActivationService } from '../services/ActivationService';
import { CourierActivationCode } from '../types';
import VerifiedBadge from '../components/VerifiedBadge';

type SettingsTab = 'main' | 'account' | 'password' | 'language' | 'notifications' | 'privacy' | 'security' | 'privacy_store' | 'order_confirmation' | 'identity' | 'admin';

export default function Settings() {
  const { user, profile } = useAuth();
  const isGoogleUser = user?.providerData.some(p => p.providerId === 'google.com');
  const { changeLanguage, language: currentLang, dir } = useLanguage();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<SettingsTab>('main');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState<string | null>(null);

  // Form States
  const [accountForm, setAccountForm] = useState({
    displayName: profile?.displayName || '',
    bio: profile?.bio || ''
  });

  const [passwordForm, setPasswordForm] = useState({
    current: '',
    new: '',
    confirm: ''
  });

  const [selectedLang, setSelectedLang] = useState(currentLang);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [notificationSettings, setNotificationSettings] = useState({
    sales: true,
    messages: true,
    promotions: true
  });

  const [privacySettings, setPrivacySettings] = useState({
    profileVisibility: profile?.isPrivate ? 'private' : 'public',
    showLikes: true
  });

  const [securityModal, setSecurityModal] = useState<string | null>(null);
  const [showCourierModal, setShowCourierModal] = useState(false);
  const [showVerifyModal, setShowVerifyModal] = useState(false);
  const [deleteStep, setDeleteStep] = useState<'none' | 'warning' | 'auth'>('none');
  const [deleteActionType, setDeleteActionType] = useState<'delete_store' | 'delete_data'>('delete_store');
  const [authVerify, setAuthVerify] = useState({ password: '', otp: '' });
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [simpleConfirm, setSimpleConfirm] = useState<{title: string, desc: string, action: () => void} | null>(null);
  const [activationCodes, setActivationCodes] = useState<CourierActivationCode[]>([]);
  const [sendingOTP, setSendingOTP] = useState(false);

  React.useEffect(() => {
    if (activeTab === 'admin' && profile?.role === 'admin') {
      fetchActivationCodes();
    }
  }, [activeTab]);

  const fetchActivationCodes = async () => {
    try {
      const codes = await ActivationService.getCodes();
      setActivationCodes(codes.sort((a, b) => b.createdAt?.seconds - a.createdAt?.seconds));
    } catch (error) {
      console.error("Error fetching codes:", error);
    }
  };

  const handleGenerateCode = async () => {
    setLoading(true);
    try {
      await ActivationService.generateCode();
      await fetchActivationCodes();
      setSuccess("Code Generated Successfully");
      setTimeout(() => setSuccess(null), 3000);
    } catch (error) {
      console.error("Error generating code:", error);
      setDeleteError("Error generating code");
      setTimeout(() => setDeleteError(null), 3000);
    } finally {
      setLoading(false);
    }
  };

  const handleActionWithAudit = async (action: string, metadata?: any) => {
    await logAction(action, metadata);
  };

  const [orderConfirmMode, setOrderConfirmMode] = useState(profile?.orderConfirmationMode || 'password');
  const [securityPasswordForm, setSecurityPasswordForm] = useState({
    old: '',
    new: '',
    confirm: ''
  });
  const [showSecurityPasswordSetup, setShowSecurityPasswordSetup] = useState(!profile?.securityPassword);
  const [securityPasswordError, setSecurityPasswordError] = useState<string | null>(null);

  const handleUpdateSecurityPassword = async () => {
    if (!user) return;
    setLoading(true);
    setSecurityPasswordError(null);
    try {
      if (profile?.securityPassword) {
        // Change flow
        if (securityPasswordForm.old !== profile.securityPassword) {
          setSecurityPasswordError(dir === 'rtl' ? 'كلمة المرور القديمة غير صحيحة' : 'Incorrect current security password');
          setLoading(false);
          return;
        }
      }
      
      if (securityPasswordForm.new !== securityPasswordForm.confirm) {
        setSecurityPasswordError(dir === 'rtl' ? 'كلمات المرور غير متطابقة' : 'Passwords do not match');
        setLoading(false);
        return;
      }

      if (securityPasswordForm.new.length < 4) {
        setSecurityPasswordError(dir === 'rtl' ? 'يجب أن تكون كلمة المرور 4 أحرف على الأقل' : 'Password must be at least 4 characters');
        setLoading(false);
        return;
      }

      await updateDoc(doc(db, 'users', user.uid), {
        securityPassword: securityPasswordForm.new,
        orderConfirmationMode: 'password',
        updatedAt: serverTimestamp()
      });

      setSuccess(t('settings.success_security_password', 'تم حفظ كلمة مرور التأكيد بنجاح'));
      setSecurityPasswordForm({ old: '', new: '', confirm: '' });
      setShowSecurityPasswordSetup(false);
      setTimeout(() => setSuccess(null), 3000);
    } catch (err: any) {
      console.error(err);
      setSecurityPasswordError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      setLoading(true);
      await signOut();
      // Redirection is handled by App.tsx PrivateRoute
    } catch (error) {
      console.error("Logout error:", error);
      setDeleteError(t('common.error_occurred', 'حدث خطأ ما'));
      setTimeout(() => setDeleteError(null), 3000);
    } finally {
      setLoading(false);
    }
  };

  const handleBecomeCourier = async () => {
    if (!user) return;
    setShowCourierModal(true);
  };

  const handleUpdateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        ...accountForm,
        updatedAt: serverTimestamp()
      });
      setSuccess(t('settings.success_update'));
      setTimeout(() => setSuccess(null), 3000);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveLanguage = async () => {
    setLoading(true);
    try {
      await changeLanguage(selectedLang);
      setSuccess(t('settings.success_language'));
      setTimeout(() => setSuccess(null), 3000);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handlePhotoUpload = async (file: File) => {
    if (!user) return;
    setUploadingPhoto(true);
    try {
      const photoURL = await uploadAndCompressImage(file, {
        maxSizeMB: 1,
        maxWidthOrHeight: 500,
        path: `profiles/${user.uid}`
      });

      await updateDoc(doc(db, 'users', user.uid), {
        photoURL,
        updatedAt: serverTimestamp()
      });

      setSuccess('Photo updated');
      setTimeout(() => setSuccess(null), 3000);
    } catch (error) {
      console.error(error);
      setDeleteError('Error uploading photo');
      setTimeout(() => setDeleteError(null), 3000);
    } finally {
      setUploadingPhoto(false);
    }
  };

  const menuItems = [
    { id: 'account', icon: User, label: t('settings.edit_account'), color: 'text-blue-400' },
    { id: 'language', icon: Globe, label: t('settings.change_language'), color: 'text-emerald-400' },
    { id: 'password', icon: Lock, label: t('settings.password'), color: 'text-purple-400' },
    { id: 'privacy', icon: Shield, label: t('settings.privacy'), color: 'text-amber-400' },
    { id: 'notifications', icon: Bell, label: t('settings.notifications'), color: 'text-pink-400' },
    { id: 'security', icon: Fingerprint, label: t('settings.security_settings'), color: 'text-cyan-400' },
    /* { 
      id: 'identity', 
      icon: ShieldCheck, 
      label: t('settings.identity_verification', 'التحقق من الهوية'), 
      color: 'text-emerald-500',
      status: profile?.isVerified ? 'verified' : ((profile?.verificationStatus === 'pending' || profile?.verificationStatus === 'pending_verification') ? 'pending' : 'not_verified')
    }, */
    { id: 'order_confirmation', icon: Check, label: t('settings.order_confirmation', 'تأكيد الطلبات'), color: 'text-emerald-400' },
    ...(profile?.role === 'admin' ? [{ id: 'admin', icon: ShieldAlert, label: 'Admin Panel', color: 'text-red-400' }] : [])
  ];

  const renderMain = () => (
    <div className="space-y-2">
      {menuItems.map((item) => (
        <button
          key={item.id}
          onClick={() => setActiveTab(item.id as SettingsTab)}
          className="w-full flex items-center justify-between p-5 bg-neutral-900/50 border border-neutral-800 rounded-3xl hover:bg-neutral-800 transition-all group mt-2"
        >
          <div className="flex items-center gap-4">
            <div className={`p-3 rounded-2xl bg-neutral-800 group-hover:scale-110 transition-transform ${item.color}`}>
              <item.icon size={20} />
            </div>
            <div className="flex flex-col items-start gap-1">
              <span className="font-bold text-neutral-200">{item.label}</span>
              {'status' in item && (
                <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded-full border ${
                  item.status === 'verified' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' :
                  item.status === 'pending' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                  'bg-red-500/10 text-neutral-500 border-neutral-800'
                }`}>
                  {item.status === 'verified' ? t('common.verified', 'موثق') : 
                   item.status === 'pending' ? t('common.pending', 'قيد المراجعة') : 
                   t('common.not_verified', 'غير موثق')}
                </span>
              )}
            </div>
          </div>
          {dir === 'rtl' ? <ChevronLeft size={18} className="text-neutral-600" /> : <ChevronRight size={18} className="text-neutral-600" />}
        </button>
      ))}

      <button
        onClick={() => {
          setSimpleConfirm({
            title: t('common.logout', 'تسجيل الخروج'),
            desc: t('settings.logout_confirm_desc', 'هل أنت متأكد أنك تريد تسجيل الخروج من الحساب؟'),
            action: handleLogout
          });
        }}
        className="w-full flex items-center justify-between p-5 bg-red-500/10 border border-red-500/20 rounded-3xl hover:bg-red-500/20 transition-all group mt-2"
      >
        <div className="flex items-center gap-4">
          <div className="p-3 rounded-2xl bg-red-500/20 text-red-500 group-hover:scale-110 transition-transform">
            <LogOut size={20} />
          </div>
          <span className="font-bold text-red-500">{t('common.logout')}</span>
        </div>
        {dir === 'rtl' ? <ChevronLeft size={18} className="text-red-500/50" /> : <ChevronRight size={18} className="text-red-500/50" />}
      </button>

      {(!profile?.role || profile?.role === 'buyer') && (
        <motion.button
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleBecomeCourier}
          className={`w-full mt-4 group relative overflow-hidden rounded-[32px] p-[1px] bg-gradient-to-br from-neutral-800 via-neutral-900 to-neutral-800 ${profile?.role === 'courier' ? 'opacity-60' : ''}`}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-bento-accent/0 via-bento-accent/10 to-bento-accent/0 opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-xl"></div>
          
          <div className="relative bg-neutral-900/90 backdrop-blur-xl rounded-[31px] p-6 flex items-center justify-between">
            <div className={`flex items-center gap-5 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className="w-16 h-16 rounded-2xl bg-black flex items-center justify-center border border-neutral-800 group-hover:border-bento-accent/30 transition-colors shadow-2xl relative">
                <Truck className="text-emerald-500 group-hover:scale-110 transition-transform" size={28} />
                <motion.div 
                  animate={{ scale: [1, 1.2, 1] }} 
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-neutral-900"
                ></motion.div>
              </div>
              
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                <h3 className="font-black italic tracking-tighter text-base uppercase mb-1 leading-tight group-hover:text-emerald-500 transition-colors">
                  {t('settings.become_courier_title')} {profile?.role === 'courier' ? '(تجربة الواجهة)' : ''}
                </h3>
                <p className="text-[9px] text-neutral-500 font-bold uppercase tracking-widest max-w-[180px] leading-relaxed">
                  {t('settings.become_courier_desc')}
                </p>
              </div>
            </div>

            <div className={`p-4 rounded-2xl bg-neutral-800/50 group-hover:bg-neutral-800 transition-colors ${dir === 'rtl' ? 'rotate-180' : ''}`}>
               <ArrowRight size={20} className="text-neutral-500 group-hover:text-white transition-all transform group-hover:translate-x-1" />
            </div>
          </div>
        </motion.button>
      )}

      {profile?.role === 'courier' && (
        <motion.button
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.98 }}
          onClick={() => navigate('/courier')}
          className="w-full mt-8 group relative overflow-hidden rounded-[32px] p-[1px] bg-bento-accent"
        >
          <div className="relative bg-bento-accent rounded-[31px] p-6 flex items-center justify-between font-sans">
            <div className={`flex items-center gap-5 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className="w-16 h-16 rounded-2xl bg-black/10 flex items-center justify-center relative shadow-inner">
                <Smartphone className="text-black" size={28} />
              </div>
              
              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                <h3 className="font-black italic tracking-tighter text-2xl uppercase mb-1 leading-tight text-black">
                  {t('settings.courier_dashboard')}
                </h3>
                <p className="text-[10px] text-black/60 font-black uppercase tracking-widest leading-relaxed">
                  {t('settings.manage_deliveries')}
                </p>
              </div>
            </div>

            <div className={`p-4 rounded-2xl bg-black/10 group-hover:bg-black/20 transition-colors ${dir === 'rtl' ? 'rotate-180' : ''}`}>
               <ArrowRight size={20} className="text-black transition-all transform group-hover:translate-x-1" />
            </div>
          </div>
        </motion.button>
      )}
      
      <div className="pt-4 px-2">
        <p className="text-[10px] text-neutral-600 font-black uppercase tracking-[3px] mb-4 text-center">Version 2.0.4 - Pre-release</p>
      </div>
    </div>
  );

  const renderBackBtn = () => (
    <button 
      onClick={() => setActiveTab('main')} 
      className="flex items-center gap-2 text-neutral-500 font-bold hover:text-white transition-colors mb-8"
    >
      {dir === 'rtl' ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
      <span>{t('settings.back')}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-black text-white pb-32 pt-28" dir={dir}>
      <div className="max-w-lg mx-auto px-4">
        <header className="mb-10 relative">
          <button 
            onClick={() => navigate('/profile')} 
            className={`absolute ${dir === 'rtl' ? 'right-0' : 'left-0'} top-1/2 -translate-y-1/2 p-3 bg-neutral-900 border border-neutral-800 rounded-2xl hover:bg-neutral-800 transition-colors`}
          >
            {dir === 'rtl' ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
          </button>
          <div className="text-center">
            <div className={`flex items-center justify-center gap-2 mb-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
              <h1 className="text-3xl md:text-4xl font-black italic tracking-tighter uppercase">{t('settings.title')}</h1>
              {profile?.isVerified && <VerifiedBadge size={28} />}
            </div>
            <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest">{t('settings.subtitle')}</p>
          </div>
        </header>

        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, x: dir === 'rtl' ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: dir === 'rtl' ? 20 : -20 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'main' && renderMain()}

            {activeTab === 'account' && (
              <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 md:p-10 shadow-2xl relative overflow-hidden">
                {renderBackBtn()}
                <h2 className={`text-2xl font-black italic tracking-tighter mb-8 uppercase ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('settings.edit_account')}</h2>
                
                <div className="flex flex-col items-center mb-10">
                   <div className="relative group">
                      <div className="w-24 h-24 rounded-[32px] overflow-hidden border-4 border-neutral-800 bg-neutral-800">
                         {profile?.photoURL ? (
                           <img src={profile.photoURL} alt="" className="w-full h-full object-cover" />
                         ) : (
                           <div className="w-full h-full flex items-center justify-center bg-neutral-900 text-neutral-600">
                             <User size={40} />
                           </div>
                         )}
                      </div>
                      <button 
                        disabled={uploadingPhoto}
                        onClick={() => document.getElementById('avatar-upload')?.click()}
                        className="absolute -bottom-2 -left-2 p-2 bg-bento-accent text-black rounded-xl shadow-lg hover:scale-110 transition-transform disabled:opacity-50"
                      >
                         <Camera size={16} />
                      </button>
                      <input 
                        id="avatar-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handlePhotoUpload(file);
                        }}
                      />
                   </div>
                </div>

                <form onSubmit={handleUpdateAccount} className="space-y-6">
                  <div>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('settings.display_name')}</label>
                    <input 
                      type="text"
                      dir={dir}
                      value={accountForm.displayName}
                      onChange={e => setAccountForm({...accountForm, displayName: e.target.value})}
                      className="w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none font-bold"
                    />
                  </div>
                  <div>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('settings.phone', 'رقم الهاتف (للتلجرام)')}</label>
                    <input 
                      type="tel"
                      dir="ltr"
                      value={profile?.phone || ''}
                      onChange={async (e) => {
                        if (!user) return;
                        await updateDoc(doc(db, 'users', user.uid), { phone: e.target.value });
                      }}
                      placeholder="+9665xxxxxxxx"
                      className="w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none font-bold"
                    />
                    <p className="mt-2 text-[10px] text-neutral-500 italic">
                      {dir === 'rtl' ? 'يرجى إدخال الرقم مع رمز الدولة (مثال: +966...) لاستقبال الرمز عبر تلجرام' : 'Please enter the number with country code (e.g. +966...) to receive the code via Telegram'}
                    </p>
                  </div>
                  <div>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('settings.bio')}</label>
                    <textarea 
                      dir={dir}
                      value={accountForm.bio}
                      onChange={e => setAccountForm({...accountForm, bio: e.target.value})}
                      className="w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none font-bold h-32 resize-none"
                    />
                  </div>
                  <button className="w-full bg-white text-black py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-bento-accent transition-all shadow-xl">
                    {t('settings.save_changes')}
                  </button>
                </form>
              </div>
            )}

            {activeTab === 'language' && (
              <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 shadow-2xl">
                {renderBackBtn()}
                <h2 className={`text-2xl font-black italic tracking-tighter mb-8 uppercase ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('settings.change_language')}</h2>
                <div className="space-y-3">
                  {[
                    { label: 'العربية', code: 'ar' },
                    { label: 'English', code: 'en' },
                    { label: 'Français', code: 'fr' },
                    { label: 'Español', code: 'es' }
                  ].map((lang) => {
                    const isSelected = selectedLang === lang.code;
                    return (
                      <button 
                        key={lang.code}
                        onClick={() => setSelectedLang(lang.code as any)}
                        className={`w-full flex items-center justify-between p-6 rounded-3xl border transition-all ${
                          isSelected
                          ? 'border-bento-accent bg-bento-accent/5' 
                          : 'border-neutral-800 bg-black/20 hover:border-neutral-700'
                        }`}
                      >
                        <div className="w-6 h-6 rounded-full border-2 border-neutral-800 flex items-center justify-center">
                          {isSelected && <Check size={14} className="text-bento-accent" />}
                        </div>
                        <span className="font-bold">{lang.label}</span>
                      </button>
                    )
                  })}
                </div>
                
                <button 
                  onClick={handleSaveLanguage}
                  disabled={loading}
                  className="w-full mt-8 bg-bento-accent text-black font-black uppercase tracking-widest py-5 rounded-2xl flex items-center justify-center gap-3 hover:bg-emerald-400 transition-all shadow-xl disabled:opacity-50"
                >
                  <Globe size={20} />
                  <span>{loading ? t('common.loading') : t('settings.apply_language')}</span>
                </button>
              </div>
            )}

            {activeTab === 'password' && (
              <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 shadow-2xl">
                {renderBackBtn()}
                <h2 className={`text-2xl font-black italic tracking-tighter mb-8 uppercase ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('settings.password')}</h2>
                <div className="space-y-6">
                  <div>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('settings.current_password')}</label>
                    <input type="password" className="w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none font-bold" />
                  </div>
                  <div>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('settings.new_password')}</label>
                    <input type="password" className="w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none font-bold" />
                  </div>
                  <button className="w-full bg-white text-black py-5 rounded-2xl font-black uppercase tracking-widest hover:bg-bento-accent transition-all shadow-xl">
                    {t('settings.save_changes')}
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'order_confirmation' && (
              <div className={`bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 shadow-2xl ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                {renderBackBtn()}
                <h2 className="text-2xl font-black italic tracking-tighter mb-8 uppercase">{t('settings.order_confirmation', 'تأكيد الطلبات')}</h2>
                
                {!profile?.securityPassword || showSecurityPasswordSetup ? (
                  <div className="space-y-6">
                    <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest mb-6">
                      {profile?.securityPassword 
                        ? (dir === 'rtl' ? 'تغيير كلمة مرور التأكيد' : 'Change Security Password')
                        : (dir === 'rtl' ? 'قم بإعداد كلمة مرور لتأكيد الطلبات والعمليات الحساسة' : 'Setup a password for order confirmation and sensitive actions')}
                    </p>
                    
                    {securityPasswordError && (
                      <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-500 text-xs rounded-xl font-bold">
                        {securityPasswordError}
                      </div>
                    )}

                    <div className="space-y-4">
                      {profile?.securityPassword && (
                        <div>
                          <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block">{t('settings.current_password', 'كلمة المرور الحالية')}</label>
                          <input 
                            type="password"
                            className="w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none font-bold"
                            value={securityPasswordForm.old}
                            onChange={e => setSecurityPasswordForm({...securityPasswordForm, old: e.target.value})}
                          />
                        </div>
                      )}
                      <div>
                        <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block">{t('settings.new_password', 'كلمة مرور جديدة')}</label>
                        <input 
                          type="password"
                          className="w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none font-bold"
                          value={securityPasswordForm.new}
                          onChange={e => setSecurityPasswordForm({...securityPasswordForm, new: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block">{t('settings.confirm_new_password', 'تأكيد كلمة المرور')}</label>
                        <input 
                          type="password"
                          className="w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none font-bold"
                          value={securityPasswordForm.confirm}
                          onChange={e => setSecurityPasswordForm({...securityPasswordForm, confirm: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="flex gap-4">
                       <button 
                         onClick={handleUpdateSecurityPassword}
                         disabled={loading}
                         className="flex-1 bg-white text-black font-black py-4 rounded-2xl uppercase tracking-widest text-xs hover:bg-bento-accent transition-colors disabled:opacity-30"
                       >
                         {loading ? <RefreshCw size={18} className="animate-spin" /> : (profile?.securityPassword ? t('common.update', 'تحديث') : t('common.save', 'حفظ'))}
                       </button>
                       {profile?.securityPassword && (
                         <button 
                           onClick={() => {
                             setShowSecurityPasswordSetup(false);
                             setSecurityPasswordError(null);
                             setSecurityPasswordForm({ old: '', new: '', confirm: '' });
                           }}
                           className="px-6 bg-neutral-800 text-neutral-400 font-black rounded-2xl uppercase tracking-widest text-xs"
                         >
                           {t('common.cancel', 'إلغاء')}
                         </button>
                       )}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-3xl flex items-center justify-between">
                       <div className="flex items-center gap-4">
                          <div className="p-3 bg-emerald-500/20 text-emerald-500 rounded-2xl">
                             <Key size={24} />
                          </div>
                          <div>
                             <span className="block font-bold text-emerald-400">{t('settings.order_confirmation_active', 'تأكيد الطلبات مفعل')}</span>
                             <span className="text-[10px] text-neutral-500 font-bold uppercase tracking-widest">{t('settings.via_password', 'باستخدام كلمة المرور')}</span>
                          </div>
                       </div>
                       <Check className="text-emerald-500" />
                    </div>

                    <button 
                      onClick={() => setShowSecurityPasswordSetup(true)}
                      className="w-full p-6 bg-neutral-800/50 rounded-3xl border border-neutral-800 hover:border-neutral-700 transition-all flex items-center justify-between group"
                    >
                       <div className="flex items-center gap-4">
                          <Lock size={20} className="text-neutral-500 group-hover:text-white" />
                          <span className="font-bold">{t('settings.change_security_password', 'تغيير كلمة مرور التأكيد')}</span>
                       </div>
                       {dir === 'rtl' ? <ChevronLeft size={18} className="text-neutral-600" /> : <ChevronRight size={18} className="text-neutral-600" />}
                    </button>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'privacy' && (
              <div className={`bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 shadow-2xl ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                {renderBackBtn()}
                <div className={`flex items-center gap-4 mb-8 ${dir === 'rtl' ? 'flex-row-reverse text-right' : ''}`}>
                   <div className="p-3 bg-amber-500/10 text-amber-500 rounded-2xl">
                      <Shield size={24} />
                   </div>
                   <h2 className="text-2xl font-black italic tracking-tighter uppercase">{t('settings.privacy')}</h2>
                </div>
                <div className="space-y-4">
                   <div className={`p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-3xl flex items-start gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                      <div className="p-2 bg-emerald-500/20 rounded-xl text-emerald-500">
                         <Shield size={20} />
                      </div>
                      <div className="flex-1">
                         <p className="text-sm font-bold text-emerald-400 mb-1">{t('settings.account_protected', 'تتم حماية حسابك بالكامل')}</p>
                         <p className="text-[10px] text-neutral-500 font-medium leading-relaxed">{t('settings.account_protected_desc', 'نحن لا نشارك معلوماتك الشخصية مع أي طرف ثالث. يمكنك التحكم في من يرى إعجاباتك ومنشوراتك من هنا.')}</p>
                      </div>
                   </div>
                   <button 
                    onClick={() => {
                      const newVal = privacySettings.profileVisibility === 'public' ? 'private' : 'public';
                      setPrivacySettings({...privacySettings, profileVisibility: newVal});
                      setSuccess(dir === 'rtl' ? `تم تعيين الحساب إلى ${newVal === 'public' ? 'عام' : 'خاص'}` : `Account set to ${newVal}`);
                      setTimeout(() => setSuccess(null), 3000);
                    }}
                    className="w-full flex items-center justify-between p-6 bg-black/20 rounded-3xl border border-neutral-800 hover:border-neutral-700 transition-all group"
                   >
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-black uppercase px-2 py-1 rounded-lg ${privacySettings.profileVisibility === 'public' ? 'bg-emerald-500/20 text-emerald-500' : 'bg-amber-500/20 text-amber-500'}`}>
                          {privacySettings.profileVisibility === 'public' ? (t('common.public', 'عام')) : (t('common.private', 'خاص'))}
                        </span>
                        {dir === 'rtl' ? <ChevronRight size={18} className="text-neutral-600 group-hover:translate-x-1 transition-transform" /> : <ChevronLeft size={18} className="text-neutral-600 group-hover:-translate-x-1 transition-transform" />}
                      </div>
                      <span className="font-bold">{t('settings.profile_visibility', 'رؤية الملف الشخصي')}</span>
                   </button>
                </div>

                <div className="mt-12 pt-8 border-t border-neutral-800 space-y-3">
                  <h3 className="text-sm font-black text-neutral-500 uppercase tracking-widest mb-4">{t('settings.data_management', 'إدارة البيانات والمتجر')}</h3>
                  <button 
                    onClick={() => {
                      setSimpleConfirm({
                        title: t('settings.download_data', 'تنزيل بياناتي'),
                        desc: t('settings.download_data_confirm', 'هل تريد طلب تنزيل جميع بياناتك؟ سيتم إرسال رابط التنزيل إلى بريدك الإلكتروني.'),
                        action: () => {
                          handleActionWithAudit('download_data_request');
                          setSuccess(t('settings.data_req_success', 'تم استلام طلب بياناتك. ستتلقى رسالة بالبريد الإلكتروني قريباً.'));
                          setTimeout(() => setSuccess(null), 3000);
                        }
                      });
                    }}
                    className="w-full flex items-center gap-4 p-6 bg-neutral-800/50 rounded-3xl border border-neutral-700 hover:bg-neutral-700 transition-all"
                  >
                    <Download className="text-blue-400" size={20} />
                    <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                      <span className="block font-bold">{t('settings.download_data', 'تنزيل بياناتي')}</span>
                    </div>
                  </button>

                  <button 
                    onClick={async () => {
                      if (!profile?.sellerProfile) return;
                      const isFrozen = profile.sellerProfile.status === 'frozen';
                      setSimpleConfirm({
                        title: isFrozen ? t('settings.unfreeze_store', 'إلغاء تجميد المتجر') : t('settings.freeze_store', 'تجميد المتجر'),
                        desc: isFrozen 
                          ? t('settings.unfreeze_store_confirm', 'هل أنت متأكد أنك تريد إلغاء تجميد متجرك؟ سيعود للظهور للعملاء.') 
                          : t('settings.freeze_store_confirm', 'هل أنت متأكد أنك تريد تجميد متجرك؟ لن يظهر للعملاء حتى تلغي التجميد.'),
                        action: async () => {
                          if (!user) return;
                          const newStatus = isFrozen ? 'active' : 'frozen';
                          await updateDoc(doc(db, 'sellerProfiles', user.uid), {
                            status: newStatus,
                            updatedAt: serverTimestamp()
                          });
                          handleActionWithAudit('toggle_store_freeze', { status: newStatus });
                          setSuccess(newStatus === 'frozen' ? 'Store Frozen' : 'Store Active');
                          setTimeout(() => setSuccess(null), 3000);
                        }
                      });
                    }}
                    className="w-full flex items-center gap-4 p-6 bg-neutral-800/50 rounded-3xl border border-neutral-700 hover:bg-neutral-700 transition-all"
                  >
                    <Snowflake className="text-amber-400" size={20} />
                    <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                      <span className="block font-bold">{profile?.sellerProfile?.status === 'frozen' ? t('settings.unfreeze_store', 'إلغاء تجميد المتجر') : t('settings.freeze_store', 'تجميد المتجر')}</span>
                    </div>
                  </button>

                  <button 
                    onClick={() => {
                      setDeleteError(null);
                      setDeleteActionType('delete_store');
                      setDeleteStep('warning');
                    }}
                    className="w-full flex items-center gap-4 p-6 bg-red-500/10 rounded-3xl border border-red-500/20 hover:bg-red-500/20 transition-all font-bold group"
                  >
                    <div className="p-3 bg-red-500/20 rounded-2xl text-red-500 group-hover:scale-110 transition-transform">
                      <Trash2 size={20} />
                    </div>
                    <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                      <span className="block text-red-500">{t('settings.delete_store')}</span>
                    </div>
                  </button>

                  <button 
                    onClick={() => {
                      setDeleteError(null);
                      setDeleteActionType('delete_data');
                      setDeleteStep('warning');
                    }}
                    className="w-full flex items-center gap-4 p-6 bg-red-500/10 rounded-3xl border border-red-500/20 hover:bg-red-500/20 transition-all font-bold group"
                  >
                    <div className="p-3 bg-red-500/20 rounded-2xl text-red-500 group-hover:scale-110 transition-transform">
                      <ShieldAlert size={20} />
                    </div>
                    <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                      <span className="block text-red-500">{t('settings.delete_my_data')}</span>
                    </div>
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className={`bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 shadow-2xl ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                {renderBackBtn()}
                <h2 className="text-2xl font-black italic tracking-tighter mb-8 uppercase">{t('settings.security_settings')}</h2>
                <div className="space-y-6">
                  <div className={`flex ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'} items-center justify-between p-6 bg-neutral-800/50 rounded-3xl`}>
                    <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                       <span className="font-black text-xs uppercase tracking-widest text-neutral-300 block mb-1">Two-Step Verification</span>
                       <span className="text-[10px] text-neutral-500 font-bold uppercase tracking-widest">Active via email</span>
                    </div>
                    <Shield className="text-bento-accent" size={24} />
                  </div>
                  <button 
                    onClick={() => setSecurityModal('devices')}
                    className="w-full bg-neutral-800 text-white py-4 rounded-xl font-bold border border-neutral-700 hover:bg-neutral-700 transition-all"
                  >
                    {t('settings.view_logged_devices', 'عرض الأجهزة المتصلة')}
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'admin' && profile?.role === 'admin' && (
              <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 shadow-2xl">
                {renderBackBtn()}
                <h2 className={`text-2xl font-black italic tracking-tighter mb-8 uppercase ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                  {dir === 'rtl' ? 'لوحة تحكم الإدارة' : 'Admin Control Panel'}
                </h2>
                
                <div className="space-y-6">
                  <div className="bg-black/40 p-6 rounded-3xl border border-neutral-800">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-sm font-black uppercase tracking-widest text-neutral-400">
                        {dir === 'rtl' ? 'أكواد تفعيل المناديب' : 'Courier Activation Codes'}
                      </h3>
                      <button onClick={fetchActivationCodes} className="p-2 hover:bg-neutral-800 rounded-lg text-neutral-500 hover:text-white transition-colors">
                        <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
                      </button>
                    </div>

                    <button 
                      onClick={handleGenerateCode}
                      disabled={loading}
                      className="w-full bg-bento-accent text-black font-black py-5 rounded-2xl mb-6 hover:bg-emerald-400 transition-all shadow-lg flex items-center justify-center gap-2 uppercase tracking-tighter italic"
                    >
                      {loading ? <RefreshCw size={20} className="animate-spin" /> : <Key size={20} />}
                      <span>{dir === 'rtl' ? 'توليد كود 6 أرقام جديد' : 'Generate New 6-Digit Code'}</span>
                    </button>
                    
                    <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                      {activationCodes.length === 0 && !loading && (
                        <p className="text-center py-8 text-neutral-600 font-bold uppercase text-[10px] tracking-widest">No codes generated yet</p>
                      )}
                      {activationCodes.map(code => (
                        <div key={code.id} className="flex items-center justify-between p-4 bg-neutral-900/50 rounded-2xl border border-neutral-800 hover:border-neutral-700 transition-colors">
                          <div className="flex flex-col">
                            <span className="font-mono text-xl font-black tracking-[0.3em] text-white select-all">{code.code}</span>
                            <span className="text-[8px] text-neutral-600 font-bold mt-1">
                              {new Date(code.createdAt?.seconds * 1000).toLocaleString()}
                            </span>
                          </div>
                          <div className="flex flex-col items-end gap-1">
                            <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-full ${code.isUsed ? 'bg-red-500/20 text-red-500' : 'bg-emerald-500/20 text-emerald-500'}`}>
                              {code.isUsed ? (dir === 'rtl' ? 'مستخدم' : 'Used') : (dir === 'rtl' ? 'متاح' : 'Available')}
                            </span>
                            {code.usedBy && (
                              <span className="text-[8px] text-neutral-500 font-mono">UID: ...{code.usedBy.slice(-6)}</span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-6 bg-red-500/5 border border-red-500/10 rounded-3xl">
                    <p className="text-[10px] text-neutral-500 font-bold uppercase tracking-widest leading-relaxed">
                      {dir === 'rtl' ? 'أعطِ هذه الأكواد للمتقدمين الجدد بعد مراجعة بياناتهم وتفعيلهم يدوياً.' : 'Give these codes to new applicants after manually reviewing and approving their details.'}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
          <IdentityVerification 
            isOpen={activeTab === 'identity' || showVerifyModal}
            onClose={() => {
              setShowVerifyModal(false);
              if (activeTab === 'identity') setActiveTab('main');
            }}
          />
        </AnimatePresence>
      </div>

      <AnimatePresence>
        {deleteStep !== 'none' && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[400] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-neutral-900 border border-red-500/20 p-8 rounded-[40px] max-w-sm w-full text-center shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-red-500"></div>
              
              {deleteStep === 'warning' && (
                <motion.div 
                  key="delete-warning"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <div className="inline-flex p-5 rounded-[24px] bg-red-500/10 text-red-500 mb-6 font-bold shadow-sm ring-1 ring-red-500/20">
                    {deleteActionType === 'delete_store' ? <Store size={40} /> : <ShieldAlert size={40} />}
                  </div>
                  <h3 className="text-2xl font-black italic tracking-tighter mb-4 uppercase text-red-500">
                    {deleteActionType === 'delete_store' ? t('settings.final_warning_store') : t('settings.final_warning_data')}
                  </h3>
                  <p className="text-neutral-400 font-bold mb-8 text-sm leading-relaxed">
                    {deleteActionType === 'delete_store' 
                      ? t('settings.delete_store_warning')
                      : t('settings.delete_data_warning')}
                  </p>
                  
                  <div className="space-y-3">
                    <button 
                      onClick={() => {
                        setDeleteError(null);
                        setDeleteStep('auth');
                      }}
                      className="w-full bg-red-600 text-white font-black py-5 rounded-2xl flex items-center justify-center gap-2 hover:bg-red-700 transition-colors uppercase tracking-widest text-xs shadow-lg shadow-red-600/20"
                    >
                      <span>{t('settings.proceed_anyway', 'الاستمرار على أي حال')}</span>
                    </button>
                    <button 
                      onClick={() => setDeleteStep('none')}
                      className="w-full bg-neutral-800 text-neutral-400 font-black py-5 rounded-2xl flex items-center justify-center gap-2 hover:bg-neutral-700 transition-colors uppercase tracking-widest text-xs"
                    >
                      <span>{t('common.cancel', 'إلغاء')}</span>
                    </button>
                  </div>
                </motion.div>
              )}

              {deleteStep === 'auth' && (
                <motion.div
                  key="delete-auth"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                >
                  <div className="inline-flex p-5 rounded-[24px] bg-white/5 text-white mb-6 font-bold shadow-sm ring-1 ring-white/10 flex justify-center mx-auto">
                    {deleteActionType === 'delete_store' ? <Store size={40} /> : <ShieldAlert size={40} />}
                  </div>
                   <h3 className="text-2xl font-black italic tracking-tighter mb-4 uppercase text-white">
                    {t('settings.confirm_identity')}
                  </h3>
                  <p className="text-neutral-400 font-bold mb-8 text-xs uppercase tracking-widest leading-relaxed">
                    {profile?.orderConfirmationMode === 'password' 
                      ? t('settings.enter_password_confirm', 'يرجى إدخال كلمة المرور للمتابعة')
                      : t('settings.auth_required_desc', 'يرجى إكمال عملية التحقق للمتابعة')}
                  </p>

                  {deleteError && (
                    <motion.div 
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl text-red-500 text-[10px] font-black uppercase tracking-widest"
                    >
                      {deleteError}
                    </motion.div>
                  )}

                  <div className="space-y-4 mb-8">
                    {(profile?.orderConfirmationMode === 'password' || !profile?.orderConfirmationMode || (!isGoogleUser && profile?.orderConfirmationMode === 'biometric')) && (
                      <input 
                        type="password"
                        autoFocus
                        placeholder={profile?.securityPassword ? t('settings.security_password', 'كلمة مرور التأكيد') : t('common.password', 'كلمة المرور')}
                        className="w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 focus:border-red-500 outline-none text-center font-bold"
                        value={authVerify.password}
                        onChange={e => setAuthVerify({...authVerify, password: e.target.value})}
                      />
                    )}

                    {(profile?.orderConfirmationMode === 'email_otp' || profile?.orderConfirmationMode === 'phone_otp') && (
                      <div className="flex gap-2">
                        <input 
                          type="text"
                          placeholder="OTP Code"
                          className="flex-1 bg-black border border-neutral-800 rounded-2xl px-6 py-4 focus:border-red-500 outline-none text-center font-bold"
                          value={authVerify.otp}
                          onChange={e => setAuthVerify({...authVerify, otp: e.target.value})}
                        />
                        <button 
                          disabled={sendingOTP || (!user?.email && !profile?.phone)}
                          onClick={async () => {
                            setSendingOTP(true);
                            setDeleteError(null);
                            try {
                              const res = await fetch('/api/send-otp', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ 
                                  email: user?.email, 
                                  phone: profile?.phone,
                                  type: 'delete',
                                  method: profile?.orderConfirmationMode === 'phone_otp' ? 'telegram' : 'email' 
                                })
                              });
                              const data = await res.json();
                              if (res.ok) {
                                setSuccess(t('settings.otp_sent', 'تم إرسال الرمز بنجاح'));
                                setTimeout(() => setSuccess(null), 4000);
                              } else {
                                setDeleteError(data.error || 'Failed to send OTP');
                              }
                            } catch (e) {
                              console.error(e);
                              setDeleteError('Connection error');
                            } finally {
                              setSendingOTP(false);
                            }
                          }}
                          className="px-4 bg-neutral-800 rounded-2xl hover:bg-neutral-700 text-[10px] font-black uppercase disabled:opacity-50"
                        >
                          {sendingOTP ? <RefreshCw size={14} className="animate-spin" /> : t('settings.send_otp', 'أرسل الرمز')}
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="space-y-3">
                    <button 
                      disabled={loading || (profile?.orderConfirmationMode === 'password' && !authVerify.password) || ((profile?.orderConfirmationMode === 'email_otp' || profile?.orderConfirmationMode === 'phone_otp') && authVerify.otp.length < 4)}
                      onClick={async () => {
                        setLoading(true);
                        setDeleteError(null);
                        try {
                          let isVerified = false;

                          if (profile?.orderConfirmationMode === 'password' || !profile?.orderConfirmationMode) {
                            if (profile?.securityPassword) {
                              // Verify against Security Password (ensure both are handled as strings)
                              isVerified = String(authVerify.password) === String(profile.securityPassword);
                              if (!isVerified) {
                                setDeleteError(dir === 'rtl' ? 'كلمة مرور التأكيد خاطئة' : 'Incorrect security password');
                              }
                            } else {
                              // Fallback or handle as before (account password)
                              try {
                                if (!user?.email) throw new Error('Email is required');
                                const credential = EmailAuthProvider.credential(user.email, authVerify.password);
                                await reauthenticateWithCredential(user, credential);
                                isVerified = true;
                              } catch (err: any) {
                                console.error("Password verification failed:", err);
                                if (err?.code === 'auth/operation-not-allowed') {
                                  setDeleteError(dir === 'rtl' 
                                    ? 'خيار تسجيل الدخول بكلمة المرور غير مفعّل. يرجى استخدام كلمة مرور الأمان من الإعدادات.' 
                                    : 'Password sign-in is disabled. Please set and use a Security Password.');
                                } else {
                                  setDeleteError(dir === 'rtl' ? 'كلمة المرور غير صحيحة' : 'Invalid Password');
                                }
                                isVerified = false;
                              }
                            }
                          } else {
                            const res = await fetch('/api/verify-otp', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ 
                                email: user?.email, 
                                phone: profile?.phone,
                                otp: authVerify.otp 
                              })
                            });
                            isVerified = res.ok;
                            if (!isVerified) {
                              const data = await res.json();
                              setDeleteError(data.error || 'Invalid Code');
                            }
                          }

                          if (isVerified) {
                            if (deleteActionType === 'delete_store') {
                               const sellerRef = doc(db, 'sellerProfiles', user!.uid);
                               const productsRef = collection(db, 'products');
                               const q = query(productsRef, where('sellerId', '==', user!.uid));
                               const querySnapshot = await getDocs(q);
                               
                               const batch = writeBatch(db);
                               querySnapshot.forEach((doc) => {
                                 batch.delete(doc.ref);
                               });
                               await batch.commit();

                               await deleteDoc(sellerRef);

                               const profileRef = doc(db, 'users', user!.uid);
                               await updateDoc(profileRef, {
                                 sellerProfileExists: false,
                                 updatedAt: serverTimestamp()
                               });

                               handleActionWithAudit('store_permanently_deleted', { sellerId: user!.uid });
                               setSuccess(t('settings.store_deleted_success', 'تم حذف المتجر بنجاح'));
                            } else {
                              handleActionWithAudit('final_account_deletion_request', { type: deleteActionType });
                              setSuccess(t('settings.delete_request_sent', 'تم تسجيل طلبك.'));
                            }
                            
                            setDeleteStep('none');
                            setAuthVerify({ password: '', otp: '' });
                            setTimeout(() => setSuccess(null), 5000);
                          }
                        } catch (e) {
                          console.error(e);
                          setDeleteError('Connection error');
                        } finally {
                          setLoading(false);
                        }
                      }}
                      className="w-full bg-white text-black font-black py-5 rounded-2xl flex items-center justify-center gap-2 hover:bg-neutral-200 transition-all uppercase tracking-widest text-xs disabled:opacity-30 shadow-xl"
                    >
                      {loading ? <RefreshCw size={16} className="animate-spin" /> : <span>{t('settings.verify_and_delete', 'تأكيد العملية')}</span>}
                    </button>
                    <button 
                      onClick={() => setDeleteStep('none')}
                      className="w-full bg-neutral-800 text-neutral-400 font-black py-5 rounded-2xl flex items-center justify-center gap-2 hover:bg-neutral-700 transition-colors uppercase tracking-widest text-xs"
                    >
                      <span>{t('common.cancel', 'إلغاء')}</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </motion.div>
          </motion.div>
        )}

        {securityModal && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] max-w-sm w-full text-center shadow-2xl relative"
            >
              <h3 className="text-2xl font-black italic tracking-tighter mb-4 uppercase">
                {securityModal === 'devices' ? t('settings.devices', 'الأجهزة') : t('common.info', 'معلومات')}
              </h3>
              <p className="text-neutral-400 font-medium mb-8 text-sm leading-relaxed">
                {securityModal === 'devices' ? t('settings.only_device', 'هاتفك الحالي هو الجهاز النشط الوحيد.') : ''}
              </p>
              
              <button 
                onClick={() => setSecurityModal(null)}
                className="w-full bg-white text-black font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-neutral-200 transition-colors uppercase tracking-widest text-xs"
              >
                <span>{t('common.close')}</span>
              </button>
            </motion.div>
          </motion.div>
        )}

        {simpleConfirm && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[400] flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] max-w-sm w-full text-center shadow-2xl relative"
            >
              <h3 className="text-xl font-black italic tracking-tighter mb-4 uppercase">
                {simpleConfirm.title}
              </h3>
              <p className="text-neutral-400 font-bold mb-8 text-sm leading-relaxed">
                {simpleConfirm.desc}
              </p>
              
              <div className="space-y-3">
                <button 
                  onClick={async () => {
                    const action = simpleConfirm.action;
                    setSimpleConfirm(null);
                    if (action) {
                      try {
                        await action();
                      } catch (e) {
                        console.error("Simple confirm action failed", e);
                      }
                    }
                  }}
                  className="w-full bg-white text-black font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-neutral-200 transition-colors uppercase tracking-widest text-xs"
                >
                  <span>{t('common.confirm', 'تأكيد')}</span>
                </button>
                <button 
                  onClick={() => setSimpleConfirm(null)}
                  className="w-full bg-neutral-800 text-neutral-400 font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-neutral-700 transition-colors uppercase tracking-widest text-xs"
                >
                  <span>{t('common.cancel', 'إلغاء')}</span>
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}

        <CourierApplicationPortal 
          isOpen={showCourierModal} 
          onClose={() => setShowCourierModal(false)}
          onSuccess={(msg) => {
            setSuccess(msg);
            setTimeout(() => setSuccess(null), 3000);
          }}
        />
      </AnimatePresence>

      {loading && (
        <div className="fixed inset-0 z-[1000] bg-black/60 backdrop-blur-md flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
             <div className="w-12 h-12 border-4 border-bento-accent border-t-transparent rounded-full animate-spin" />
             <span className="text-xs font-black uppercase tracking-widest text-white/60 animate-pulse">{t('common.processing', 'جاري المعالجة...')}</span>
          </div>
        </div>
      )}

      {success && (
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed bottom-10 left-1/2 -translate-x-1/2 bg-white text-black px-8 py-4 rounded-2xl font-black shadow-2xl z-[200]"
        >
          {success}
        </motion.div>
      )}
    </div>
  );
}
