import React, { useEffect, useState } from 'react';
import { seedProducts } from '../lib/seed';
import { 
  db, handleFirestoreError, getDocsResilient, isMockMode,
  collection, query, orderBy, limit, where, startAfter, doc, deleteDoc, addDoc, updateDoc, incrementResilient as increment, serverTimestampResilient as serverTimestamp
} from '../lib/firebase';
import type { QueryDocumentSnapshot, DocumentData, QueryConstraint } from 'firebase/firestore';
import { Product, Review } from '../types';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Heart, MessageCircle, Share2, Info, ChevronDown, Zap, UserPlus, Loader2, Eye, LayoutGrid, X, Utensils, Coffee, Leaf, Beef, ShoppingBag, Smartphone, Home as HomeIcon, Star, MessageSquare, ShoppingBasket, Check } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import QuickViewModal from '../components/QuickViewModal';
import ShareModal from '../components/ShareModal';
import VerifiedBadge from '../components/VerifiedBadge';

export default function Home() {
  const { user } = useAuth();
  const { dir } = useLanguage();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [lastVisible, setLastVisible] = useState<QueryDocumentSnapshot<DocumentData> | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [feedType, setFeedType] = useState<'forYou' | 'following'>('forYou');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isCategoryMenuOpen, setIsCategoryMenuOpen] = useState(false);
  const [wishlistItems, setWishlistItems] = useState<Set<string>>(new Set());
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [shareProduct, setShareProduct] = useState<Product | null>(null);
  const [reviewsProduct, setReviewsProduct] = useState<Product | null>(null);
  const [addingToCart, setAddingToCart] = useState<string | null>(null);
  const [productReviews, setProductReviews] = useState<Review[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(false);
  const [successItems, setSuccessItems] = useState<Set<string>>(new Set());

  const PAGE_SIZE = 10;

  const productCategories = React.useMemo(() => [
    { id: 'all', label: t('product_form.categories.all'), icon: LayoutGrid },
    { id: 'food', label: t('product_form.categories.food'), icon: Utensils },
    { id: 'drinks', label: t('product_form.categories.drinks'), icon: Coffee },
    { id: 'veg_fruits', label: t('product_form.categories.veg_fruits'), icon: Leaf },
    { id: 'meat', label: t('product_form.categories.meat'), icon: Beef },
    { id: 'supermarket', label: t('product_form.categories.supermarket'), icon: ShoppingBag },
    { id: 'desserts', label: t('product_form.categories.desserts'), icon: Star },
    { id: 'electronics', label: t('product_form.categories.electronics'), icon: Smartphone },
    { id: 'home_appliances', label: t('product_form.categories.home_appliances'), icon: HomeIcon }
  ], [t]);

  useEffect(() => {
    if (user) {
      fetchWishlist();
    } else {
      setWishlistItems(new Set());
    }
    setLastVisible(null);
    setHasMore(true);
    fetchProducts(true);
  }, [feedType, user, selectedCategory]);

  const fetchWishlist = async () => {
    if (!user) return;
    try {
      const q = query(collection(db, 'wishlists'), where('userId', '==', user.uid));
      const snap = await getDocsResilient(q);
      setWishlistItems(new Set(snap.docs.map(doc => (doc.data() as any).productId)));
    } catch (e) {
      console.warn("Could not fetch wishlist resiliently:", e);
    }
  };

  const handleAddToCart = async (product: Product) => {
    if (!user) {
      navigate('/login');
      return;
    }

    setAddingToCart(product.id);
    try {
      const q = query(
        collection(db, 'carts'),
        where('userId', '==', user.uid),
        where('productId', '==', product.id)
      );
      const snap = await getDocsResilient(q);

      if (!snap.empty) {
        const cartDocId = snap.docs[0].id;
        await updateDoc(doc(db, 'carts', cartDocId), {
          quantity: increment(1)
        });
      } else {
        await addDoc(collection(db, 'carts'), {
          userId: user.uid,
          productId: product.id,
          sellerId: product.sellerId,
          title: product.title,
          price: product.price,
          imageUrl: product.imageUrl,
          quantity: 1,
          createdAt: serverTimestamp()
        });
      }
      
      // Success feedback
      setSuccessItems(prev => new Set(prev).add(product.id));
      setTimeout(() => {
        setSuccessItems(prev => {
          const next = new Set(prev);
          next.delete(product.id);
          return next;
        });
      }, 2000);

      // Removed navigate('/cart') to stay on home page as requested
    } catch (error) {
      console.error("Error adding to cart:", error);
    } finally {
      setAddingToCart(null);
    }
  };

  const fetchProductReviews = async (productId: string) => {
    setLoadingReviews(true);
    try {
      const q = query(
        collection(db, 'reviews'), 
        where('productId', '==', productId), 
        orderBy('createdAt', 'desc'),
        limit(20)
      );
      const snap = await getDocsResilient(q);
      setProductReviews(snap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Review)));
    } catch (e) {
      console.error("Error fetching reviews:", e);
    } finally {
      setLoadingReviews(false);
    }
  };

  const handleLikeToggle = async (product: Product) => {
    if (!user) {
      navigate('/login');
      return;
    }

    const isLiked = wishlistItems.has(product.id);
    const productRef = doc(db, 'products', product.id);

    try {
      if (isLiked) {
        // Find the wishlist doc id
        const q = query(collection(db, 'wishlists'), where('userId', '==', user.uid), where('productId', '==', product.id));
        const snap = await getDocsResilient(q);
        if (!snap.empty) {
          await deleteDoc(doc(db, 'wishlists', snap.docs[0].id));
          await updateDoc(productRef, { likesCount: increment(-1) });
          
          // Update user counts
          await updateDoc(doc(db, 'users', user.uid), { likesCount: increment(-1) });
          await updateDoc(doc(db, 'users', product.sellerId), { receivedLikesCount: increment(-1) });
          
          setWishlistItems(prev => {
            const next = new Set(prev);
            next.delete(product.id);
            return next;
          });
          setProducts(prev => prev.map(p => p.id === product.id ? { ...p, likesCount: Math.max(0, (p.likesCount || 0) - 1) } : p));
        }
      } else {
        await addDoc(collection(db, 'wishlists'), {
          userId: user.uid,
          productId: product.id,
          productTitle: product.title,
          productImage: product.imageUrl,
          productImageUrls: product.imageUrls || [],
          productPrice: product.price,
          sellerId: product.sellerId,
          createdAt: serverTimestamp()
        });
        await updateDoc(productRef, { likesCount: increment(1) });
        
        // Update user counts
        await updateDoc(doc(db, 'users', user.uid), { likesCount: increment(1) });
        await updateDoc(doc(db, 'users', product.sellerId), { receivedLikesCount: increment(1) });
        
        // Notify seller about like
        if (product.sellerId !== user.uid) {
          await addDoc(collection(db, 'notifications'), {
            userId: product.sellerId,
            type: 'like',
            title: dir === 'rtl' ? 'إعجاب جديد' : 'New Like',
            message: dir === 'rtl' 
              ? `قام ${user.displayName || 'مستخدم'} بالإعجاب بمنتجك "${product.title}"`
              : `${user.displayName || 'A user'} liked your product "${product.title}"`,
            link: `/product/${product.id}`,
            read: false,
            createdAt: serverTimestamp()
          });
        }

        setWishlistItems(prev => {
          const next = new Set(prev);
          next.add(product.id);
          return next;
        });
        setProducts(prev => prev.map(p => p.id === product.id ? { ...p, likesCount: (p.likesCount || 0) + 1 } : p));
      }
    } catch (error) {
      console.error("Home Like Toggle Error:", error);
    }
  };

  const fetchProducts = async (isInitial: boolean = false) => {
    if (isInitial) setLoading(true);
    else setLoadingMore(true);

    try {
      const constraints: any[] = [
        where('isArchived', '==', false)
      ];

      if (selectedCategory && selectedCategory !== 'all') {
        constraints.push(where('category', '==', selectedCategory));
      }

      constraints.push(orderBy('createdAt', 'desc'));
      constraints.push(limit(PAGE_SIZE));

      if (!isInitial && lastVisible) {
        constraints.push(startAfter(lastVisible));
      }

      let q;
      if (feedType === 'following' && user) {
        const followQ = query(collection(db, 'follows'), where('followerId', '==', user.uid), limit(25)) as any;
        const followSnap = await getDocsResilient(followQ);
        const followingIds = followSnap.docs.map((d: any) => d.data().followingId);

        if (followingIds.length > 0) {
          q = query(
            collection(db, 'products'), 
            where('sellerId', 'in', followingIds),
            ...constraints
          ) as any;
        } else {
          setProducts([]);
          setHasMore(false);
          return;
        }
      } else {
        q = query(collection(db, 'products'), ...constraints) as any;
      }

      let querySnapshot;
      try {
        querySnapshot = await getDocsResilient(q);
      } catch (e) {
        console.warn("Ordered Home feed failed, falling back to unordered:", e);
        // Remove orderBy for fallback
        const fallbackConstraints = constraints.filter(c => !c.toString().includes('orderBy'));
        const fallbackQ = query(collection(db, 'products'), ...fallbackConstraints) as any;
        querySnapshot = await getDocsResilient(fallbackQ);
      }
      
      let fetchedProducts = querySnapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Product));
      
      // Client side sort if fallback was used
      fetchedProducts.sort((a, b) => {
        const dateA = a.createdAt?.seconds || 0;
        const dateB = b.createdAt?.seconds || 0;
        return dateB - dateA;
      });
      
      if (isInitial && fetchedProducts.length === 0 && isMockMode) {
        await seedProducts();
        // Re-fetch after seeding
        return fetchProducts(true);
      }

      if (isInitial) {
        setProducts(fetchedProducts);
      } else {
        setProducts(prev => {
          const newProducts = [...prev];
          fetchedProducts.forEach(newProd => {
            if (!newProducts.find(p => p.id === newProd.id)) {
              newProducts.push(newProd);
            }
          });
          return newProducts;
        });
      }

      setLastVisible(querySnapshot.docs[querySnapshot.docs.length - 1] || null);
      setHasMore(querySnapshot.docs.length === PAGE_SIZE);

    } catch (error) {
       console.error("Home Feed Error:", error);
       if (isInitial) setProducts([]);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  if (loading) return (
    <div className="h-screen flex items-center justify-center bg-bento-bg text-white">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-bento-accent"></div>
    </div>
  );

  return (
    <div className="h-screen overflow-y-scroll snap-y snap-mandatory no-scrollbar bg-black" dir={dir}>
      {/* Floating Header */}
      <div className={`fixed top-0 left-0 right-0 z-50 pointer-events-none p-6 pt-8 bg-gradient-to-b from-black/80 to-transparent flex justify-center gap-6 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
         <button 
          onClick={() => setFeedType('following')}
          className={`pointer-events-auto cursor-pointer font-black tracking-widest text-[10px] uppercase transition-all ${
            feedType === 'following' ? 'text-white border-b-2 border-bento-accent pb-1' : 'text-white/60 hover:text-white'
          }`}
         >
           {t('home.following')}
         </button>
         <button 
          onClick={() => setFeedType('forYou')}
          className={`pointer-events-auto cursor-pointer font-black tracking-widest text-[10px] uppercase transition-all ${
            feedType === 'forYou' ? 'text-white border-b-2 border-bento-accent pb-1' : 'text-white/60 hover:text-white'
          }`}
         >
           {t('home.for_you')}
         </button>

         {/* Category Button - Top Right Corner */}
         <button 
          onClick={() => setIsCategoryMenuOpen(true)}
          className="fixed top-4 right-4 pointer-events-auto w-12 h-12 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center text-white border border-white/20 hover:bg-white/30 transition-all shadow-2xl z-[60]"
         >
            <LayoutGrid size={24} />
         </button>
      </div>

      <AnimatePresence>
        {isCategoryMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCategoryMenuOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-md z-[100] pointer-events-auto"
            />
            <motion.div 
              initial={{ x: dir === 'rtl' ? 300 : -300 }}
              animate={{ x: 0 }}
              exit={{ x: dir === 'rtl' ? 300 : -300 }}
              className={`fixed top-0 bottom-0 w-80 bg-neutral-950 border-neutral-800 z-[110] shadow-2xl p-8 flex flex-col pointer-events-auto ${dir === 'rtl' ? 'right-0 border-l' : 'left-0 border-r'}`}
            >
              <div className={`flex items-center justify-between mb-10 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-bento-accent rounded-xl flex items-center justify-center text-black">
                      <LayoutGrid size={20} />
                   </div>
                   <h3 className="text-xl font-black italic tracking-tighter uppercase">{t('common.categories')}</h3>
                </div>
                <button onClick={() => setIsCategoryMenuOpen(false)} className="p-2 bg-white/5 rounded-xl text-neutral-500 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-3 flex-1 overflow-y-auto no-scrollbar pb-10">
                {productCategories.map((cat) => {
                  const Icon = cat.icon;
                  return (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setSelectedCategory(cat.id);
                        setIsCategoryMenuOpen(false);
                      }}
                      className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all border ${
                        selectedCategory === cat.id
                          ? 'bg-bento-accent/10 border-bento-accent text-bento-accent' 
                          : 'bg-white/5 border-white/5 text-neutral-400 hover:bg-white/10'
                      } ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'text-left'}`}
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                        selectedCategory === cat.id
                          ? 'bg-bento-accent text-black' 
                          : 'bg-neutral-800 text-neutral-500'
                      }`}>
                        <Icon size={18} />
                      </div>
                      <div className="flex flex-col">
                        <span className="font-black text-xs uppercase tracking-widest">{cat.label}</span>
                        <span className="text-[8px] text-neutral-600 font-bold uppercase tracking-tight">
                           {selectedCategory === cat.id ? 'Active Filter' : 'Explore Items'}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="pt-6 border-t border-white/5">
                 <button 
                   onClick={() => {
                     setSelectedCategory('all');
                     setIsCategoryMenuOpen(false);
                   }}
                   className="w-full py-4 bg-white/5 text-neutral-500 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all"
                 >
                   Clear Filters
                 </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {products.length === 0 ? (
        <div className="h-screen w-full flex flex-col items-center justify-center text-white p-6 gap-4">
           <UserPlus size={64} className="text-neutral-700 mb-2" />
           <h3 className="text-2xl font-black italic tracking-tighter text-center uppercase">{t('home.no_content')}</h3>
           <p className="text-neutral-500 text-sm text-center max-w-xs">
              {feedType === 'following' 
                ? t('home.follow_prompt')
                : t('home.empty_feed')}
           </p>
           {feedType === 'following' && (
             <button 
              onClick={() => setFeedType('forYou')}
              className="bg-bento-accent text-black px-8 py-3 rounded-2xl font-black uppercase tracking-widest text-xs"
             >
               {t('home.explore_for_you')}
             </button>
           )}
        </div>
      ) : (
        products.map((product, idx) => (
          <section key={`${product.id}-${idx}`} className="h-screen w-full snap-start relative bg-neutral-900 flex items-center justify-center overflow-hidden group/home">
            {/* Background Image / Video Placeholder */}
            <div className="absolute inset-0 z-0">
              {product.imageUrl ? (
                <img 
                  src={product.imageUrl} 
                  alt="" 
                  className="w-full h-full object-cover opacity-80"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              ) : (
                <div className="w-full h-full bg-gradient-to-br from-neutral-800 to-neutral-950 flex items-center justify-center">
                   <ShoppingCart size={100} className="text-white/5" />
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/40" />

              {/* Hover Overlay with Quick View */}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/home:opacity-100 transition-opacity duration-300 hidden md:flex items-center justify-center pointer-events-none z-20">
                 <button 
                   onClick={(e) => {
                     e.preventDefault();
                     setQuickViewProduct(product);
                   }}
                   className="bg-white/90 backdrop-blur-sm hover:bg-white text-black text-sm font-black uppercase tracking-widest px-6 py-3 rounded-xl flex items-center gap-2 transform translate-y-4 group-hover/home:translate-y-0 transition-all duration-300 pointer-events-auto shadow-2xl"
                 >
                   <Eye size={18} />
                   {t('common.quick_view')}
                 </button>
              </div>
            </div>

            {/* Core Product Info (Bottom Left) */}
            <div className={`absolute bottom-24 ${dir === 'rtl' ? 'right-4 left-16' : 'left-4 right-16'} z-10 space-y-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
               <div className={`flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <Link to={`/profile/${product.sellerId}`} className="w-9 h-9 rounded-full border-2 border-bento-accent overflow-hidden">
                     <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${product.sellerId}`} alt="" />
                  </Link>
                  <div className={`flex flex-col ${dir === 'rtl' ? 'items-end' : 'items-start'}`}>
                     <div className={`flex items-center gap-1 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                        <span className="font-black text-sm tracking-tighter">@{product.sellerName}</span>
                        {product.sellerIsVerified && <VerifiedBadge size={14} />}
                     </div>
                     <span className="text-[9px] text-bento-accent font-black uppercase tracking-widest">
                        {product.sellerIsVerified ? t('home.verified_seller') : t('home.pro_seller')}
                     </span>
                  </div>
               </div>

               <div>
                  <h3 className="font-bold text-lg text-white mb-1 line-clamp-1">{product.title}</h3>
                  <p className="text-sm text-neutral-300 line-clamp-2 max-w-sm leading-snug">{product.description}</p>
               </div>

               <div className={`flex items-center gap-2 ${dir === 'rtl' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                     <Zap size={14} className="text-yellow-400" />
                     <span className="text-xs font-black uppercase tracking-tighter italic">{t('home.featured')}</span>
                  </div>
               </div>
            </div>

            {/* Social Actions (Right Side) */}
            <div className={`absolute ${dir === 'rtl' ? 'left-2' : 'right-2'} bottom-24 z-10 flex flex-col items-center gap-4`}>
               <button 
                onClick={() => handleLikeToggle(product)}
                className="flex flex-col items-center gap-0.5 group"
               >
                  <div className={`w-10 h-10 backdrop-blur-md rounded-full flex items-center justify-center border transition-all ${
                    wishlistItems.has(product.id)
                    ? 'bg-red-500/20 border-red-500/50 text-red-500'
                    : 'bg-white/10 border-white/10 text-white group-hover:bg-red-500/20 group-hover:border-red-500/30'
                  }`}>
                     <Heart size={20} fill={wishlistItems.has(product.id) ? "currentColor" : "none"} />
                  </div>
                  <span className={`text-[9px] font-black uppercase tracking-tighter drop-shadow-md ${wishlistItems.has(product.id) ? 'text-red-500' : 'text-white'}`}>
                    {product.likesCount || 0}
                  </span>
               </button>

               <button 
                 onClick={() => {
                   setReviewsProduct(product);
                   fetchProductReviews(product.id);
                 }}
                 className="flex flex-col items-center gap-0.5 group"
               >
                  <div className="w-10 h-10 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center border border-white/10 group-hover:bg-bento-accent/20 group-hover:border-bento-accent/30 transition-all text-white">
                     <MessageCircle size={20} />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-tighter text-white drop-shadow-md">
                    {product.reviewsCount || 0}
                  </span>
               </button>

               <button 
                 onClick={async () => {
                   setShareProduct(product);
                   // Notify seller about share
                   if (user && product.sellerId !== user.uid) {
                     try {
                        await addDoc(collection(db, 'notifications'), {
                          userId: product.sellerId,
                          type: 'share',
                          title: dir === 'rtl' ? 'مشاركة جديدة' : 'New Share',
                          message: dir === 'rtl' 
                            ? `قام ${user.displayName || 'مستخدم'} بمشاركة منتجك "${product.title}"`
                            : `${user.displayName || 'A user'} shared your product "${product.title}"`,
                          link: `/product/${product.id}`,
                          read: false,
                          createdAt: serverTimestamp()
                        });
                     } catch (e) {
                       console.warn("Share notification error:", e);
                     }
                   }
                 }}
                 className="flex flex-col items-center gap-0.5 group"
               >
                  <div className="w-10 h-10 bg-white/10 backdrop-blur-md rounded-full flex items-center justify-center border border-white/10 group-hover:bg-white/20 transition-all text-white">
                     <Share2 size={20} />
                  </div>
                  <span className="text-[9px] font-black uppercase tracking-tighter text-white drop-shadow-md">{t('common.share')}</span>
               </button>
            </div>

            {/* Red Buy Now Button Above Navigation */}
            <div className={`absolute bottom-[92px] ${dir === 'rtl' ? 'right-4' : 'left-4'} z-20`}>
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleAddToCart(product)}
                className={`bg-red-600 text-white px-8 py-3 rounded-2xl flex items-center gap-3 shadow-2xl shadow-red-600/30 font-black uppercase tracking-widest text-[10px] border border-red-500/50 hover:bg-red-500 transition-all ${
                  addingToCart === product.id ? 'opacity-70 pointer-events-none' : ''
                }`}
              >
                {addingToCart === product.id ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : successItems.has(product.id) ? (
                  <Check size={16} strokeWidth={3} />
                ) : (
                  <ShoppingBasket size={16} />
                )}
                <span>{successItems.has(product.id) ? (dir === 'rtl' ? 'تمت الإضافة' : 'Added!') : (dir === 'rtl' ? 'شراء الآن' : 'Buy Now')}</span>
              </motion.button>
            </div>

            {/* Hint for next */}
            {idx === 0 && (
              <motion.div 
                animate={{ y: [0, 10, 0] }}
                transition={{ repeat: Infinity, duration: 2 }}
                className="absolute bottom-6 left-1/2 -translate-x-1/2 opacity-30"
              >
                 <ChevronDown size={24} />
              </motion.div>
            )}

            {/* Load More Trigger */}
            {idx === products.length - 1 && hasMore && (
              <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20">
                 <button 
                  onClick={() => fetchProducts(false)}
                  disabled={loadingMore}
                  className="bg-white/10 backdrop-blur-md px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10 hover:bg-white/20 transition-all flex items-center gap-2 whitespace-nowrap pointer-events-auto"
                 >
                   {loadingMore ? <Loader2 size={12} className="animate-spin" /> : t('common.load_more')}
                 </button>
              </div>
            )}
          </section>
        ))
      )}

      <QuickViewModal 
        product={quickViewProduct} 
        isOpen={!!quickViewProduct} 
        onClose={() => setQuickViewProduct(null)}
        onLike={handleLikeToggle}
        isLiked={quickViewProduct ? wishlistItems.has(quickViewProduct.id) : false}
      />

      <ShareModal 
        product={shareProduct}
        isOpen={!!shareProduct}
        onClose={() => setShareProduct(null)}
      />

      {/* Reviews Drawer */}
      <AnimatePresence>
        {reviewsProduct && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setReviewsProduct(null)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[150] pointer-events-auto"
            />
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 h-[70vh] bg-neutral-900 rounded-t-[40px] z-[160] shadow-2xl p-6 flex flex-col pointer-events-auto"
            >
               <div className="w-12 h-1.5 bg-neutral-800 rounded-full mx-auto mb-6" />
               <div className={`flex items-center justify-between mb-6 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="w-10 h-10 bg-bento-accent/10 rounded-xl flex items-center justify-center text-bento-accent">
                      <MessageCircle size={20} />
                    </div>
                    <h3 className="text-xl font-black italic tracking-tighter uppercase">
                      {reviewsProduct.reviewsCount || productReviews.length} {t('product_details.customer_feedback')}
                    </h3>
                  </div>
                  <button onClick={() => setReviewsProduct(null)} className="p-2 bg-white/5 rounded-xl text-neutral-500 hover:text-white transition-colors">
                    <X size={20} />
                  </button>
               </div>

               <div className="flex-1 overflow-y-auto no-scrollbar space-y-4 pb-10">
                 {loadingReviews ? (
                    <div className="h-full flex items-center justify-center">
                      <Loader2 className="animate-spin text-bento-accent" size={32} />
                    </div>
                 ) : productReviews.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-neutral-600 italic gap-3">
                      <MessageSquare size={32} className="opacity-20" />
                      <p>{t('product_details.be_first_reviewer')}</p>
                    </div>
                 ) : (
                    productReviews.map((review, idx) => (
                      <div key={`${review.id}-${idx}`} className="bg-white/5 p-5 rounded-3xl border border-white/5">
                         <div className={`flex justify-between items-start mb-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                            <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse text-right' : ''}`}>
                               <img 
                                 src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${review.userId}`} 
                                 alt="" 
                                 className="w-8 h-8 rounded-full bg-neutral-800"
                               />
                               <div>
                                  <div className="text-xs font-black">{review.userName}</div>
                                  <div className="text-[8px] text-neutral-500 font-bold uppercase tracking-tighter">Verified Buyer</div>
                               </div>
                            </div>
                            <div className="flex gap-0.5">
                               {[1, 2, 3, 4, 5].map((s) => (
                                 <Star key={s} size={10} fill={s <= review.rating ? "#FCD34D" : "none"} className={s <= review.rating ? "text-amber-400" : "text-neutral-800"} />
                               ))}
                            </div>
                         </div>
                         <p className={`text-neutral-300 text-xs leading-relaxed italic ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                            "{review.comment}"
                         </p>
                      </div>
                    ))
                 )}
               </div>

               <div className="pt-4 border-t border-white/5">
                  <Link 
                    to={`/product/${reviewsProduct.id}`}
                    className="w-full py-4 bg-white text-black rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-bento-accent transition-all flex items-center justify-center gap-2"
                  >
                    {t('common.view_product_details')}
                  </Link>
               </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
