import React, { useEffect, useState } from 'react';
import { db, collection, query, where, orderBy, limit, getDocs } from '../lib/firebase';
import { Product } from '../types';
import { Search, Filter, TrendingUp, Sparkles, Zap, BadgeCheck, X, ChevronDown, Star, Globe, Truck, Heart, Eye } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import QuickViewModal from '../components/QuickViewModal';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';

export default function Explore() {
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  
  const categories = ['All', 'food', 'veg_fruits', 'supermarket', 'electronics', 'meat', 'home_appliances', 'drinks', 'desserts'];
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Advanced Filter States
  const [priceRange, setPriceRange] = useState({ min: 0, max: 10000 });
  const [minRating, setMinRating] = useState(0);
  const [selectedArea, setSelectedArea] = useState('');
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isCategoryDrawerOpen, setIsCategoryDrawerOpen] = useState(false);

  const areas = ['All', 'north_gaza', 'gaza', 'both'];

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      let snap;
      try {
        const q = query(collection(db, 'products'), where('isArchived', '==', false), orderBy('createdAt', 'desc'), limit(100));
        snap = await getDocs(q);
      } catch (e) {
        console.warn("Ordered Explore fetch failed, falling back to unordered:", e);
        const qSimple = query(collection(db, 'products'), where('isArchived', '==', false), limit(100));
        snap = await getDocs(qSimple);
      }
      
      const fetchedProducts = snap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Product));
      
      // Client side sort if needed
      fetchedProducts.sort((a, b) => {
        const dateA = a.createdAt?.seconds || 0;
        const dateB = b.createdAt?.seconds || 0;
        return dateB - dateA;
      });
      
      setProducts(fetchedProducts);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const filteredProducts = React.useMemo(() => {
    return products.filter(p => {
      const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
      const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           p.sellerName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPrice = p.price >= priceRange.min && p.price <= priceRange.max;
      const matchesArea = !selectedArea || selectedArea === 'All' || 
                         p.deliveryArea === selectedArea || 
                         p.deliveryArea === 'both' ||
                         (selectedArea !== 'both' && p.deliveryArea === 'both');
      
      return matchesCategory && matchesSearch && matchesPrice && matchesArea;
    });
  }, [products, activeCategory, searchQuery, priceRange, selectedArea]);

  return (
    <div className="min-h-screen bg-bento-bg text-white pb-20 pt-12 md:pt-20 px-4 md:px-8" dir={dir}>
      <div className="max-w-7xl mx-auto">
        <header className="mb-12">
          <div className={`flex flex-col lg:flex-row lg:items-end justify-between gap-6 ${dir === 'rtl' ? 'lg:flex-row-reverse' : ''}`}>
            <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
              <h1 className="text-4xl md:text-6xl font-black italic tracking-tighter uppercase mb-4">{t('explore.title')}</h1>
              <p className="text-neutral-500 font-medium max-w-md">{t('explore.subtitle')}</p>
            </div>
            
              <div className={`flex flex-col sm:flex-row gap-4 w-full lg:w-auto ${dir === 'rtl' ? 'sm:flex-row-reverse' : ''}`}>
                <button 
                  onClick={() => setIsCategoryDrawerOpen(true)}
                  className="md:hidden flex items-center justify-center p-4 bg-bento-item border border-bento-border rounded-3xl text-bento-accent"
                >
                  <TrendingUp size={20} />
                </button>
                <div className="relative flex-1 lg:w-96">
                <Search className={`absolute top-1/2 -translate-y-1/2 text-neutral-500 ${dir === 'rtl' ? 'right-4' : 'left-4'}`} size={20} />
                <input 
                  type="text" 
                  placeholder={t('explore.search_placeholder')}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className={`w-full bg-bento-item border border-bento-border rounded-3xl py-4 focus:border-bento-accent outline-none transition-all font-bold text-sm ${dir === 'rtl' ? 'pr-12 pl-4 text-right' : 'pl-12 pr-4 text-left'}`}
                />
              </div>
              
              <button 
                onClick={() => setShowFilters(!showFilters)}
                className={`flex items-center justify-center gap-2 px-6 py-4 rounded-3xl font-black uppercase tracking-widest text-xs transition-all border ${
                  showFilters 
                  ? 'bg-white text-black border-white shadow-xl shadow-white/10' 
                  : 'bg-bento-item border-bento-border text-white hover:border-white/20'
                }`}
              >
                <Filter size={18} />
                <span>{t('explore.filters')}</span>
                { (priceRange.min > 0 || priceRange.max < 10000 || selectedArea) && (
                  <div className="w-2 h-2 rounded-full bg-bento-accent animate-pulse" />
                )}
              </button>
            </div>
          </div>
        </header>

        {/* Advanced Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden mb-12"
            >
              <div className="bg-bento-item border border-bento-border rounded-[40px] p-8 space-y-8">
                <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 ${dir === 'rtl' ? 'rtl' : 'ltr'}`}>
                  {/* Price Range */}
                  <div className={`space-y-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black flex items-center gap-2 ${dir === 'rtl' ? 'justify-end' : 'justify-start'}`}>
                       {dir === 'rtl' ? <>{t('explore.price_range')} <Zap size={12} className="text-bento-accent" /></> : <><Zap size={12} className="text-bento-accent" /> {t('explore.price_range')}</>}
                    </label>
                    <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                      <input 
                        type="number" 
                        placeholder="Min"
                        value={priceRange.min === 0 ? '' : priceRange.min}
                        onChange={e => setPriceRange({...priceRange, min: Number(e.target.value) || 0})}
                        className={`w-full bg-black/40 border border-neutral-800 rounded-xl px-4 py-3 text-xs font-bold outline-none focus:border-bento-accent ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                      />
                      <span className="text-neutral-600">{t('explore.to')}</span>
                      <input 
                        type="number" 
                        placeholder="Max"
                        value={priceRange.max === 10000 ? '' : priceRange.max}
                        onChange={e => setPriceRange({...priceRange, max: Number(e.target.value) || 10000})}
                        className={`w-full bg-black/40 border border-neutral-800 rounded-xl px-4 py-3 text-xs font-bold outline-none focus:border-bento-accent ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                      />
                    </div>
                  </div>

                  {/* Seller Rating */}
                  <div className={`space-y-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black flex items-center gap-2 ${dir === 'rtl' ? 'justify-end' : 'justify-start'}`}>
                       {dir === 'rtl' ? <>{t('explore.seller_rating')} <Star size={12} className="text-bento-accent" /></> : <><Star size={12} className="text-bento-accent" /> {t('explore.seller_rating')}</>}
                    </label>
                    <div className={`flex gap-2 ${dir === 'rtl' ? 'justify-end flex-row-reverse' : 'justify-start'}`}>
                      {[1, 2, 3, 4].map(r => (
                        <button 
                          key={r}
                          onClick={() => setMinRating(minRating === r ? 0 : r)}
                          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all border ${
                            minRating === r ? 'bg-bento-accent border-bento-accent text-black shadow-lg shadow-bento-accent/20' : 'bg-black/40 border-neutral-800 text-neutral-400'
                          }`}
                        >
                          <span className="text-xs font-black">{r}+</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Delivery Area */}
                  <div className={`space-y-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black flex items-center gap-2 ${dir === 'rtl' ? 'justify-end' : 'justify-start'}`}>
                       {dir === 'rtl' ? <>{t('product_form.delivery_area')} <Globe size={12} className="text-bento-accent" /></> : <><Globe size={12} className="text-bento-accent" /> {t('product_form.delivery_area')}</>}
                    </label>
                    <select 
                      value={selectedArea}
                      onChange={e => setSelectedArea(e.target.value)}
                      className={`w-full bg-black/40 border border-neutral-800 rounded-xl px-4 py-3 text-xs font-bold outline-none focus:border-bento-accent appearance-none ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                    >
                      {areas.map((a, index) => (
                        <option key={`${a}-${index}`} value={a}>
                          {a === 'All' ? t('explore.all_countries') : t(`product_form.area_${a}`)}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className={`flex justify-between items-center pt-6 border-t border-white/5 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <button 
                    onClick={() => {
                      setPriceRange({ min: 0, max: 10000 });
                      setMinRating(0);
                      setSelectedArea('');
                      setActiveCategory('All');
                      setSearchQuery('');
                    }}
                    className="text-[10px] text-neutral-500 hover:text-white font-black uppercase tracking-widest underline underline-offset-4"
                  >
                    {t('explore.reset_filters')}
                  </button>
                  <button 
                    onClick={() => setShowFilters(false)}
                    className="bg-white text-black px-8 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-bento-accent transition-all"
                  >
                    {t('explore.apply_filters')}
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Categories Bar */}
        <div className={`flex gap-3 mb-12 overflow-x-auto overscroll-contain touch-pan-x pb-4 no-scrollbar ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
          {categories.map(cat => (
            <button 
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-8 py-3 rounded-xl font-bold text-xs uppercase tracking-widest whitespace-nowrap transition-all ${
                activeCategory === cat 
                ? 'bg-bento-accent text-black shadow-lg shadow-bento-accent/20' 
                : 'bg-bento-item border border-bento-border text-neutral-400 hover:text-white'
              }`}
            >
              {cat === 'All' ? t('common.all') : t(`product_form.categories.${cat.toLowerCase()}`) || cat}
            </button>
          ))}
        </div>

        {/* Results Info */}
        {!loading && (
          <div className="mb-6 flex items-center justify-between">
            <div className={`text-[10px] text-neutral-500 font-black uppercase tracking-widest ${dir === 'rtl' ? 'text-right w-full' : ''}`}>
              {t('explore.results_count', { count: filteredProducts.length })}
            </div>
          </div>
        )}

        {/* Explore Bento Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {loading ? (
            Array(12).fill(0).map((_, i) => (
              <div key={i} className="aspect-[3/4] bg-bento-item rounded-3xl animate-pulse" />
            ))
          ) : filteredProducts.length > 0 ? (
            filteredProducts.map((product, idx) => (
              <motion.div
                key={`${product.id}-${idx}`}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: idx * 0.02 }}
                className={`group relative bento-card border-none overflow-hidden h-full flex flex-col ${
                  idx % 7 === 0 ? 'md:col-span-2 md:row-span-2' : ''
                }`}
              >
                <Link to={`/product/${product.id}`} className="flex-1 flex flex-col">
                  <div className="relative aspect-square md:aspect-auto flex-1 overflow-hidden rounded-2xl mb-3 group/image">
                    <img src={product.imageUrl} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                    
                    {/* Hover Overlay with Quick View */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/image:opacity-100 transition-opacity duration-300 flex items-center justify-center pointer-events-none">
                       <button 
                         onClick={(e) => {
                           e.preventDefault();
                           setQuickViewProduct(product);
                         }}
                         className="bg-white/90 backdrop-blur-sm hover:bg-white text-black text-xs font-black uppercase tracking-widest px-4 py-2 rounded-xl flex items-center gap-2 transform translate-y-4 group-hover/image:translate-y-0 transition-all duration-300 pointer-events-auto"
                       >
                         <Eye size={14} />
                         {t('explore.quick_view')}
                       </button>
                    </div>

                    <div className={`absolute top-2 flex flex-col gap-1 items-end z-10 pointer-events-none ${dir === 'rtl' ? 'left-2' : 'right-2'}`}>
                      <div className="bg-bento-accent text-black text-[10px] font-black px-2 py-1 rounded-lg">
                        ${product.price}
                      </div>
                      <div className="bg-black/60 backdrop-blur-md text-white text-[9px] font-black px-2 py-1 rounded-lg flex items-center gap-1 border border-white/10">
                        <Heart size={10} className="text-red-500 fill-red-500" />
                        <span>{product.likesCount || 0}</span>
                      </div>
                    </div>
                  </div>
                  <div className={`flex flex-col gap-1 px-1 pb-2 ${dir === 'rtl' ? 'text-right' : ''}`}>
                    <h3 className="font-bold text-xs truncate uppercase tracking-tighter">{product.title}</h3>
                    <div className={`flex items-center gap-1 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                      <span className="text-[9px] text-neutral-500 font-black uppercase tracking-widest">@{product.sellerName}</span>
                      {product.sellerIsVerified && <BadgeCheck size={10} className="text-bento-accent" />}
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))
          ) : (
            <div className="col-span-full py-20 text-center">
              <div className="w-20 h-20 bg-neutral-900 rounded-full flex items-center justify-center mx-auto mb-6 border border-neutral-800">
                <Search size={32} className="text-neutral-700" />
              </div>
              <h3 className="text-xl font-bold mb-2 uppercase tracking-tighter italic">{t('explore.no_results')}</h3>
              <p className="text-neutral-500 text-sm">{t('explore.no_results_desc')}</p>
            </div>
          )}
        </div>
      </div>
      <AnimatePresence>
        {isCategoryDrawerOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCategoryDrawerOpen(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              initial={{ x: dir === 'rtl' ? 300 : -300 }}
              animate={{ x: 0 }}
              exit={{ x: dir === 'rtl' ? 300 : -300 }}
              className={`fixed top-0 bottom-0 w-72 bg-neutral-950 border-neutral-800 z-[70] shadow-2xl p-8 flex flex-col ${dir === 'rtl' ? 'right-0 border-l' : 'left-0 border-r'}`}
            >
              <div className={`flex items-center justify-between mb-10 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <h3 className="text-xl font-black italic tracking-tighter uppercase">{t('common.categories')}</h3>
                <button onClick={() => setIsCategoryDrawerOpen(false)} className="p-2 bg-white/5 rounded-xl text-neutral-500 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-2 flex-1 overflow-y-auto no-scrollbar">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setActiveCategory(cat);
                      setIsCategoryDrawerOpen(false);
                    }}
                    className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all border ${
                      activeCategory === cat
                        ? 'bg-bento-accent/10 border-bento-accent text-bento-accent' 
                        : 'bg-white/5 border-transparent text-neutral-400 hover:bg-white/10'
                    } ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'text-left'}`}
                  >
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                      activeCategory === cat
                        ? 'bg-bento-accent text-black' 
                        : 'bg-white/10 text-neutral-500'
                    }`}>
                      {cat === 'All' ? 'Σ' : cat.charAt(0).toUpperCase()}
                    </div>
                    <span className="font-bold text-sm">{cat === 'All' ? t('common.all') : t(`product_form.categories.${cat.toLowerCase()}`) || cat}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <QuickViewModal 
        product={quickViewProduct} 
        isOpen={!!quickViewProduct} 
        onClose={() => setQuickViewProduct(null)} 
      />
    </div>
  );
}
