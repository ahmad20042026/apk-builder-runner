import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { db } from '../lib/firebase';
import { doc, updateDoc, setDoc, serverTimestampResilient as serverTimestamp, handleFirestoreError } from '../lib/firebase';
import { ShieldCheck, Upload, CreditCard, ChevronLeft, CheckCircle, Info, Camera, ArrowRight, X, ShieldAlert, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { uploadAndCompressImage } from '../lib/storage';

export default function Verification() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [activeStep, setActiveStep] = useState(1);
  
  const [files, setFiles] = useState<{
    idCard: File | null;
    selfie: File | null;
  }>({
    idCard: null,
    selfie: null
  });

  const handleUpload = async () => {
    if (!user || !files.idCard || !files.selfie) return;
    
    setLoading(true);
    try {
      console.log("DEBUG: Verification Page - Starting upload for UID:", user.uid);
      const idCardUrl = await uploadAndCompressImage(files.idCard, {
        maxSizeMB: 2,
        path: `verification/${user.uid}/id`
      });
      const selfieUrl = await uploadAndCompressImage(files.selfie, {
        maxSizeMB: 2,
        path: `verification/${user.uid}/selfie`
      });

      console.log("DEBUG: Verification Page - Documents uploaded, saving to Firestore...");

      const updateData = {
        verificationStatus: 'pending',
        verificationDetails: {
          documentType: 'id_card',
          documentFrontUrl: idCardUrl,
          documentBackUrl: null,
          facePhotoUrl: selfieUrl,
          profilePhotoUrl: selfieUrl,
          legalDocumentUrl: null,
          isBrandVerification: false,
          submittedAt: serverTimestamp()
        },
        updatedAt: serverTimestamp()
      };

      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, updateData, { merge: true });
      console.log("DEBUG: Verification Page - WRITE SUCCESSFUL for UID:", user.uid);

      setSuccess(true);
    } catch (error: any) {
      console.error('DEBUG: Verification Page ERROR:', error);
      alert('حدث خطأ أثناء التوثيق: ' + (error.message || 'يرجى المحاولة لاحقاً'));
    } finally {
      setLoading(false);
    }
  };

  if (profile?.isVerified) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="bg-neutral-900 border border-neutral-800 p-10 rounded-[40px] max-w-md w-full text-center shadow-2xl">
          <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShieldCheck className="text-emerald-500" size={40} />
          </div>
          <h1 className="text-3xl font-black italic tracking-tighter uppercase mb-2">حساب موثق</h1>
          <p className="text-neutral-500 font-bold mb-8">حسابك مفعل وموثق بالكامل. يمكنك الآن البيع بلا قيود.</p>
          <button 
            onClick={() => navigate('/profile')}
            className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-emerald-500 transition-all"
          >
            العودة للملف الشخصي
          </button>
        </div>
      </div>
    );
  }

  if (success || profile?.verificationStatus === 'pending' || profile?.verificationStatus === 'pending_verification' || !!profile?.verificationDetails) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4" dir="rtl">
        <div className="bg-[#121212] border border-white/10 p-12 rounded-[50px] max-w-md w-full text-center shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 blur-[80px] rounded-full" />
          <div className="w-24 h-24 bg-amber-500/10 rounded-[32px] flex items-center justify-center mx-auto mb-8 border border-amber-500/20 shadow-[0_0_40px_rgba(245,158,11,0.1)]">
             <motion.div
               animate={{ rotate: [0, 10, -10, 0] }}
               transition={{ duration: 4, repeat: Infinity }}
             >
                <ShieldAlert className="text-amber-500" size={48} />
             </motion.div>
          </div>
          <h1 className="text-4xl font-black italic tracking-tighter uppercase mb-4 text-white">قيد المراجعة اليدوية</h1>
          <p className="text-neutral-500 font-bold mb-10 leading-relaxed">بمجرد تواصلك معنا عبر تيليجرام وإرسال الوثائق، سيقوم فريق الدعم بمراجعة طلبك وتفعيل حسابك يدوياً. عادة ما يستغرق الأمر أقل من 12 ساعة.</p>
          <button 
            onClick={() => window.open('https://t.me/Sooqc2026', '_blank')}
            className="w-full bg-white text-black py-5 rounded-[28px] font-black uppercase tracking-widest hover:bg-bento-accent transition-all shadow-xl active:scale-95 mb-4"
          >
            تواصل مع الإدارة الآن
          </button>
          <button 
            onClick={() => navigate('/profile')}
            className="w-full text-neutral-500 font-black uppercase tracking-[0.2em] text-[10px] hover:text-white transition-colors"
          >
            العودة للملف الشخصي
          </button>
        </div>
      </div>
    );
  }

  const handleManualVerificationInit = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        verificationStatus: 'pending_verification',
        updatedAt: serverTimestamp()
      });
      window.open('https://t.me/Sooqc2026', '_blank');
      setSuccess(true);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-black text-white selection:bg-bento-accent/30 flex items-center justify-center" dir="rtl">
      <div className="max-w-2xl mx-auto px-10 py-16 bg-[#121212] border border-white/10 rounded-[60px] shadow-2xl text-center space-y-10 relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-64 h-64 bg-bento-accent/5 blur-[120px] rounded-full -mr-32 -mt-32" />
        
        <div className="w-28 h-28 bg-bento-accent/10 rounded-[40px] flex items-center justify-center mx-auto border border-bento-accent/20 shadow-[0_0_60px_rgba(var(--bento-accent-rgb),0.1)] group-hover:scale-110 transition-transform duration-700">
          <ShieldCheck size={56} className="text-bento-accent" strokeWidth={1.5} />
        </div>

        <div className="space-y-4">
          <h1 className="text-5xl font-black italic tracking-tighter uppercase leading-none text-white">نظام التحقق المطور</h1>
          <p className="text-neutral-500 font-bold uppercase tracking-[0.2em] text-xs">Clearance Protocol: Identity Authentication v3.0</p>
        </div>

        <div className="bg-white/[0.02] border border-white/5 p-10 rounded-[48px] space-y-6">
          <p className="text-lg font-medium text-neutral-300 leading-relaxed">
            للحصول على شارة التوثيق وتفعيل البيع، يرجى التواصل مع الإدارة مباشرة عبر تيليجرام لإرسال وثائق الهوية يدوياً.
          </p>
          <div className="h-px w-20 bg-bento-accent/30 mx-auto" />
          <div className="space-y-3">
             <div className="flex items-center justify-center gap-3 text-bento-accent font-black tracking-widest text-xs italic uppercase">
                <CheckCircle size={16} /> سرعة في المراجعة
             </div>
             <div className="flex items-center justify-center gap-3 text-bento-accent font-black tracking-widest text-xs italic uppercase">
                <CheckCircle size={16} /> معالجة يدوية آمنة
             </div>
          </div>
        </div>

        <div className="flex flex-col gap-6">
           <button 
             disabled={loading}
             onClick={handleManualVerificationInit}
             className="w-full bg-bento-accent text-black py-7 rounded-[32px] font-black uppercase tracking-[0.25em] text-sm hover:bg-white hover:scale-[1.02] active:scale-95 transition-all shadow-[0_0_50px_rgba(var(--bento-accent-rgb),0.3)] flex items-center justify-center gap-4"
           >
             {loading ? <Loader2 size={24} className="animate-spin" /> : <>فتح تيليجرام للتوثيق <ArrowRight size={24} /></>}
           </button>
           
           <p className="text-[10px] text-neutral-600 font-bold uppercase tracking-[0.3em]">
             ACCOUNT ID: {user?.uid.toUpperCase()}
           </p>
        </div>
      </div>
    </div>
  );
}
