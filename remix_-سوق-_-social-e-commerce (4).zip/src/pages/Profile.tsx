import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { 
  auth, db, handleFirestoreError, getDocResilient, getDocsResilient, getCountFromServer,
  collection, query, where, orderBy, doc, updateDoc, addDoc, deleteDoc, incrementResilient as increment, serverTimestampResilient as serverTimestamp,
  signOut, getDoc, getDocs
} from '../lib/firebase';
import { Product, UserProfile, WishlistItem, Review, SellerProfile, Order, Withdrawal } from '../types';
import { Settings, Edit2, Share2, Grid, Key, Package, Heart, ChevronLeft, UserPlus, UserMinus, Upload, Loader2, Star, MessageSquare, MessageCircle, LayoutDashboard, QrCode, LogOut, X, Store, PlusCircle, DollarSign, CheckCircle2, ShieldAlert, ArrowRight, ShoppingBag, ShieldCheck, Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { uploadAndCompressImage } from '../lib/storage';
import IdentityVerification from '../components/IdentityVerification';
import VerifiedBadge from '../components/VerifiedBadge';

export default function Profile() {
  const { uid: watchedUid } = useParams();
  const { user, profile: myProfile } = useAuth();
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const navigate = useNavigate();
  
  const [targetProfile, setTargetProfile] = useState<UserProfile | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [purchases, setPurchases] = useState<Order[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [activeTab, setActiveTab] = useState<'products' | 'liked' | 'reviews' | 'history'>('products');
  const [isEditing, setIsEditing] = useState(false);
  const [isFollowing, setIsFollowing] = useState(false);
  const [followId, setFollowId] = useState<string | null>(null);
  const [hasChat, setHasChat] = useState(false);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);
  const [showQrModal, setShowQrModal] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showVerify, setShowVerify] = useState(false);
  const [isMessaging, setIsMessaging] = useState(false);

  const [editForm, setEditForm] = useState({
    displayName: '',
    bio: '',
    photoURL: ''
  });

  const isMe = !watchedUid || watchedUid === user?.uid;
  const currentUid = watchedUid || user?.uid;

  useEffect(() => {
    const fetchProfileData = async () => {
      if (!currentUid) {
        setLoading(false);
        return;
      }
      
      setLoading(true);
      try {
        // Fetch User Profile
        if (isMe && myProfile) {
          setTargetProfile(myProfile);
          setEditForm({
            displayName: myProfile.displayName || '',
            bio: myProfile.bio || '',
            photoURL: myProfile.photoURL || ''
          });
        } else {
          try {
            const userSnap = await getDocResilient(doc(db, 'users', currentUid));
            if (userSnap.exists()) {
              const userData = { uid: userSnap.id, ...(userSnap.data() as object) } as UserProfile;
              if (userData.sellerProfileExists) {
                const sellerSnap = await getDocResilient(doc(db, 'sellerProfiles', currentUid)).catch(() => null);
                if (sellerSnap?.exists()) {
                  userData.sellerProfile = sellerSnap.data() as SellerProfile;
                }
              }

              // Self-healing synchronization for counts
              try {
                const updates: any = {};
                
                // If counts are missing or zero, try to recover from collections
                if (userData.followersCount === undefined || userData.followersCount === 0) {
                  const snap = await getCountFromServer(query(collection(db, 'follows'), where('followingId', '==', currentUid)));
                  if (snap.data().count > 0) {
                    userData.followersCount = snap.data().count;
                    updates.followersCount = userData.followersCount;
                  }
                }
                
                if (userData.followingCount === undefined || userData.followingCount === 0) {
                  const snap = await getCountFromServer(query(collection(db, 'follows'), where('followerId', '==', currentUid)));
                  if (snap.data().count > 0) {
                    userData.followingCount = snap.data().count;
                    updates.followingCount = userData.followingCount;
                  }
                }
                
                if (userData.likesCount === undefined || userData.likesCount === 0) {
                  const snap = await getCountFromServer(query(collection(db, 'wishlists'), where('userId', '==', currentUid)));
                  if (snap.data().count > 0) {
                    userData.likesCount = snap.data().count;
                    updates.likesCount = userData.likesCount;
                  }
                }

                if (userData.reviewsCount === undefined || userData.reviewsCount === 0) {
                  const snap = await getCountFromServer(query(collection(db, 'reviews'), where('sellerId', '==', currentUid)));
                  if (snap.data().count > 0) {
                    userData.reviewsCount = snap.data().count;
                    updates.reviewsCount = userData.reviewsCount;
                  }
                }

                if (Object.keys(updates).length > 0) {
                  updateDoc(doc(db, 'users', currentUid), updates).catch(() => {});
                }
              } catch (e) {
                console.warn("Count sync error:", e);
              }

              setTargetProfile(userData);
            }
          } catch (e) {
            console.warn("Resilient fetch failed for target profile:", e);
          }
        }

        // Fetch Products - More resilient query
        let productsArray: Product[] = [];
        try {
          // Try with orderBy first
          const prodQ = query(collection(db, 'products') as any, where('sellerId', '==', currentUid), orderBy('createdAt', 'desc')) as any;
          const prodSnap = await getDocsResilient(prodQ);
          productsArray = prodSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Product));
        } catch (e) {
          console.warn("Ordered product fetch failed, falling back to unordered:", e);
          const prodQSimple = query(collection(db, 'products') as any, where('sellerId', '==', currentUid)) as any;
          const prodSnapSimple = await getDocsResilient(prodQSimple);
          productsArray = prodSnapSimple.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Product))
            .sort((a, b) => {
              const dateA = a.createdAt?.seconds || 0;
              const dateB = b.createdAt?.seconds || 0;
              return dateB - dateA;
            });
        }
        setProducts(productsArray);

        // Fetch Seller Reviews
        // Fetch Reviews (Public)
        const revQ = query(collection(db, 'reviews') as any, where('sellerId', '==', currentUid), orderBy('createdAt', 'desc')) as any;
        const revSnap = await getDocsResilient(revQ);
        setReviews(revSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Review)));

        // Update rating avg if missing
        if (targetProfile && (targetProfile.rating === undefined || targetProfile.rating === 0)) {
          if (revSnap.docs.length > 0) {
            const totalRating = revSnap.docs.reduce((acc, d) => acc + ((d.data() as any).rating || 0), 0);
            const avgRating = totalRating / revSnap.docs.length;
            setTargetProfile(prev => prev ? { ...prev, rating: avgRating } : null);
            updateDoc(doc(db, 'users', currentUid), { rating: avgRating }).catch(() => {});
          }
        }

        // Fetch Wishlist Items (Publicly visible liked products)
        const wishQ = query(collection(db, 'wishlists') as any, where('userId', '==', currentUid), orderBy('createdAt', 'desc')) as any;
        const wishSnap = await getDocsResilient(wishQ);
        setWishlistItems(wishSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as WishlistItem)));

        // Fetch Private Data (Only if Me)
        if (isMe) {
          const buyQ = query(collection(db, 'orders') as any, where('buyerId', '==', currentUid), orderBy('createdAt', 'desc')) as any;
          const withdrawQ = query(collection(db, 'withdrawals') as any, where('userId', '==', currentUid), orderBy('createdAt', 'desc')) as any;
          
          const [buySnap, withdrawSnap] = await Promise.all([
            getDocsResilient(buyQ),
            getDocsResilient(withdrawQ)
          ]);

          setPurchases(buySnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Order)));
          setWithdrawals(withdrawSnap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Withdrawal)));
        }

        // Check Follow Relationship
        if (user && !isMe) {
          const followQ = query(collection(db, 'follows') as any, where('followerId', '==', user.uid), where('followingId', '==', watchedUid)) as any;
          const followSnap = await getDocsResilient(followQ);
          if (!followSnap.empty) {
             setIsFollowing(true);
             setFollowId(followSnap.docs[0].id);
          } else {
             setIsFollowing(false);
             setFollowId(null);
          }

          // Check if chat exists
          try {
            const combinedId = user.uid > watchedUid ? `${user.uid}_${watchedUid}` : `${watchedUid}_${user.uid}`;
            const chatRef = doc(db, 'chats', combinedId);
            const chatSnap = await getDoc(chatRef);
            setHasChat(chatSnap.exists());
          } catch (e) {
            console.error("Error checking chat:", e);
          }
        }
      } catch (error) {
        console.error("Profile Fetch Error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProfileData();
  }, [currentUid, user?.uid]);

  const handleFollowToggle = async () => {
    if (!user || !targetProfile || isMe || !myProfile) return;
    setActionLoading(true);
    const targetUid = targetProfile.uid;

    try {
      const { writeBatch, incrementResilient: increment, serverTimestampResilient: serverTimestamp } = await import('../lib/firebase');
      const batch = writeBatch(db);
      const myRef = doc(db, 'users', user.uid);
      const targetUserRef = doc(db, 'users', targetUid);
      const targetSellerRef = doc(db, 'sellerProfiles', targetUid);

      if (isFollowing && followId) {
        // Optimistic update
        setIsFollowing(false);
        setFollowId(null);
        setTargetProfile(prev => {
          if (!prev) return null;
          const newCount = Math.max(0, (prev.followersCount || 0) - 1);
          const newProfile = { ...prev, followersCount: newCount };
          if (newProfile.sellerProfile) {
            newProfile.sellerProfile = {
              ...newProfile.sellerProfile,
              followers: Math.max(0, (newProfile.sellerProfile.followers || 0) - 1)
            };
          }
          return newProfile;
        });

        // Unfollow
        batch.delete(doc(db, 'follows', followId));
        batch.update(myRef, { followingCount: increment(-1) });
        batch.update(targetUserRef, { followersCount: increment(-1) });
        if (targetProfile.sellerProfile) {
          batch.update(targetSellerRef, { followers: increment(-1) });
        }
        
        await batch.commit();
      } else {
        // Optimistic update
        const followRef = doc(collection(db, 'follows'));
        const newFollowId = followRef.id;
        setIsFollowing(true);
        setFollowId(newFollowId);
        setTargetProfile(prev => {
          if (!prev) return null;
          const newCount = (prev.followersCount || 0) + 1;
          const newProfile = { ...prev, followersCount: newCount };
          if (newProfile.sellerProfile) {
            newProfile.sellerProfile = {
              ...newProfile.sellerProfile,
              followers: (newProfile.sellerProfile.followers || 0) + 1
            };
          }
          return newProfile;
        });

        // Follow
        batch.set(followRef, {
          followerId: user.uid,
          followingId: targetUid,
          createdAt: serverTimestamp()
        });
        batch.update(myRef, { followingCount: increment(1) });
        batch.update(targetUserRef, { followersCount: increment(1) });
        if (targetProfile.sellerProfile) {
          batch.update(targetSellerRef, { followers: increment(1) });
        }

        // Add Notification
        const notifRef = doc(collection(db, 'notifications'));
        batch.set(notifRef, {
          userId: targetUid,
          type: 'follow',
          title: dir === 'rtl' ? 'متابع جديد' : 'New Follower',
          message: dir === 'rtl' 
            ? `@${myProfile.displayName || 'مستخدم'} بدأ في متابعتك`
            : `@${myProfile.displayName || 'User'} started following you`,
          link: `/profile/${user.uid}`,
          read: false,
          createdAt: serverTimestamp()
        });

        await batch.commit();
      }
    } catch (error) {
      console.error("Follow error:", error);
      // Revert on error? 
      // Fetching again would be the safest way to revert
      const userSnap = await getDocResilient(doc(db, 'users', targetUid));
      if (userSnap.exists()) {
        const userData = { uid: userSnap.id, ...(userSnap.data() as object) } as UserProfile;
        if (userData.sellerProfileExists) {
          const sellerSnap = await getDocResilient(doc(db, 'sellerProfiles', targetUid)).catch(() => null);
          if (sellerSnap?.exists()) {
            userData.sellerProfile = sellerSnap.data() as SellerProfile;
          }
        }
        setTargetProfile(userData);
      }
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setActionLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        ...editForm,
        updatedAt: new Date()
      });
      setIsEditing(false);
    } catch (error) {
      handleFirestoreError(error, 'update', `users/${user.uid}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleProfilePhotoUpload = async (file: File) => {
    if (!user) return;
    setUploading(true);
    try {
      const photoURL = await uploadAndCompressImage(file, {
        maxSizeMB: 1,
        maxWidthOrHeight: 800,
        path: `profiles/${user.uid}`
      });
      setEditForm(prev => ({ ...prev, photoURL }));
    } catch (error: any) {
      alert(`Upload failed: ${error.message}`);
    } finally {
      setUploading(false);
    }
  };

  if (loading) return (
    <div className="h-screen bg-bento-bg flex items-center justify-center">
       <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-bento-accent"></div>
    </div>
  );

  if (!targetProfile) return (
    <div className="h-screen bg-bento-bg flex flex-col items-center justify-center text-white p-6">
       <h1 className="text-4xl font-black italic tracking-tighter mb-4">PROFILE NOT FOUND</h1>
       <button onClick={() => navigate('/')} className="bg-bento-accent text-black px-6 py-2 rounded-xl font-bold">Return Home</button>
    </div>
  );

  return (
    <div className="min-h-screen bg-bento-bg text-white pb-20" dir={dir}>
      {/* Mobile Top Bar */}
      <div className={`md:hidden flex items-center justify-between px-4 py-3 sticky top-0 bg-bento-bg/80 backdrop-blur-xl z-20 border-b border-bento-border ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
         <button onClick={() => navigate(-1)} className={`p-2 ${dir === 'rtl' ? 'rotate-180' : ''}`}><ChevronLeft /></button>
         <div className={`flex items-center gap-1.5 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
           <span className="font-bold">@{targetProfile.sellerProfileExists ? targetProfile.sellerProfile?.displayName.toLowerCase().replace(/\s/g, '') : targetProfile.displayName?.toLowerCase().replace(/\s/g, '')}</span>
           {targetProfile.isVerified && <VerifiedBadge size={14} />}
         </div>
         {isMe && (
           <div className={`flex items-center gap-1 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
             {myProfile?.role === 'admin' && (
               <button 
                 onClick={() => navigate('/system/hq')} 
                 className="p-2 text-red-500 hover:bg-red-500/10 rounded-xl transition-colors"
                 title="Admin Panel"
               >
                 <ShieldAlert size={20} />
               </button>
             )}
             <button onClick={() => navigate('/seller')} className="p-2 text-bento-accent hover:bg-bento-accent/10 rounded-xl transition-colors">
               <LayoutDashboard size={20} />
             </button>
             <button onClick={() => setShowSettingsMenu(true)} className="p-2 text-white hover:bg-white/10 rounded-xl transition-colors">
               <Settings size={20} />
             </button>
           </div>
         )}
      </div>

      <div className="max-w-4xl mx-auto px-4">
        {/* Identity Verification Prompt (If not verified or pending) */}
        {isMe && myProfile && !myProfile.isVerified && myProfile.verificationStatus !== 'pending' && (
          <motion.div 
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className={`mt-6 bg-emerald-500/10 border border-emerald-500/20 backdrop-blur-md p-4 rounded-3xl flex items-center justify-between gap-4 shadow-2xl ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'text-left'}`}
          >
            <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-500 shrink-0">
                <ShieldCheck size={20} />
              </div>
              <div>
                <p className="text-xs font-black uppercase tracking-widest text-emerald-500">Identity Verification Recommended</p>
                <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-tighter">Get your verified seller badge and build trust</p>
              </div>
            </div>
            <button 
              onClick={() => setShowVerify(true)}
              className={`px-6 py-2 bg-emerald-500 text-neutral-900 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-400 transition-all flex items-center gap-2 group shrink-0 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
            >
              <span>Verify ID</span>
              <ArrowRight size={14} className={dir === 'rtl' ? 'group-hover:-translate-x-1 transition-transform rotate-180' : 'group-hover:translate-x-1 transition-transform'} />
            </button>
          </motion.div>
        )}

        {/* Profile Header */}
        <section className="flex flex-col items-center pt-8 pb-4">
          {/* Avatar Section */}
          <div className="relative mb-6">
            <div className="w-28 h-28 md:w-32 md:h-32 rounded-full border-[6px] border-bento-bg ring-4 ring-bento-accent/30 overflow-hidden shadow-2xl relative">
              {targetProfile.sellerProfileExists && targetProfile.sellerProfile?.logo ? (
                <img src={targetProfile.sellerProfile.logo} alt="" className="w-full h-full object-cover" />
              ) : targetProfile.photoURL ? (
                <img src={targetProfile.photoURL} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-neutral-900 flex items-center justify-center text-5xl font-black italic text-bento-accent">
                  {targetProfile.displayName?.charAt(0)}
                </div>
              )}
            </div>
            
            {isMe && (
              <button 
                onClick={() => setIsEditing(true)}
                className="absolute -bottom-1 -right-1 p-2.5 bg-bento-accent text-black rounded-full shadow-xl hover:scale-110 transition-all hover:rotate-12 group"
              >
                <Edit2 size={18} className="group-hover:scale-90 transition-transform" />
              </button>
            )}
          </div>

          {/* Identity Section */}
          <div className="text-center w-full max-w-lg">
            <div className="flex flex-col items-center gap-1 mb-4">
              <div className="flex items-center justify-center gap-2">
                <h1 className="text-2xl md:text-3xl font-black tracking-tighter italic uppercase text-white">
                  {targetProfile.sellerProfileExists ? targetProfile.sellerProfile?.displayName : targetProfile.displayName}
                </h1>
                <div className="flex items-center gap-1.5">
                  {targetProfile.isVerified && (
                    <VerifiedBadge size={16} iconOnly={true} />
                  )}
                  {targetProfile.sellerProfileExists && (
                    <div className="flex items-center gap-1 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-full" title={`${t('profile.level')} ${targetProfile.sellerProfile?.level}`}>
                      <Trophy size={12} className="text-amber-500" />
                      <span className="text-[10px] font-black text-amber-500">{targetProfile.sellerProfile?.level || 1}</span>
                    </div>
                  )}
                </div>
              </div>
              <p className="text-neutral-500 font-bold uppercase tracking-widest text-[9px]">
                @{targetProfile.displayName?.toLowerCase().replace(/\s/g, '')}
              </p>
            </div>

            {/* Stats Section - Moved up and made more compact */}
            <div className="flex justify-center gap-x-6 gap-y-2 mb-6">
              <div className="flex items-center gap-1.5">
                <span className="font-black text-lg tracking-tighter italic text-white">
                  {targetProfile.rating && targetProfile.rating > 0 
                    ? targetProfile.rating.toFixed(1) 
                    : t('seller.no_ratings')}
                </span>
                <span className="text-[9px] uppercase tracking-widest text-neutral-500 font-bold">{t('profile.rating')}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-lg tracking-tighter italic text-white">{Math.max(0, targetProfile.likesCount || 0)}</span>
                <span className="text-[9px] uppercase tracking-widest text-neutral-500 font-bold">{t('profile.likes')}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-lg tracking-tighter italic text-white">{Math.max(0, targetProfile.followersCount || 0)}</span>
                <span className="text-[9px] uppercase tracking-widest text-neutral-500 font-bold">{t('profile.followers')}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-lg tracking-tighter italic text-white">{Math.max(0, targetProfile.followingCount || 0)}</span>
                <span className="text-[9px] uppercase tracking-widest text-neutral-500 font-bold">{t('profile.following')}</span>
              </div>
            </div>

            <p className="text-neutral-400 text-sm max-w-xs mx-auto mb-8 leading-relaxed font-medium">
              {targetProfile.sellerProfileExists ? targetProfile.sellerProfile?.description : (targetProfile.bio || "No bio yet.")}
            </p>

            {/* Actions Section */}
            <div className="flex flex-wrap justify-center gap-3">
              {isMe ? (
                <>
                  <button 
                    onClick={() => navigate(targetProfile.sellerProfileExists ? '/seller' : '/setup-store')}
                    className="flex-1 min-w-[120px] bg-bento-accent text-black h-11 rounded-xl font-black uppercase tracking-widest text-[10px] hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 shadow-xl shadow-bento-accent/20"
                  >
                    {targetProfile.sellerProfileExists ? (
                      <><LayoutDashboard size={16} /> {t('profile.seller_dashboard')}</>
                    ) : (
                      <><Store size={16} /> {t('profile.start_selling')}</>
                    )}
                  </button>
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="flex-1 min-w-[120px] bg-neutral-900 border border-neutral-800 h-11 rounded-xl font-black uppercase tracking-widest text-[10px] hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2"
                  >
                    <Edit2 size={16} /> {t('profile.edit_profile')}
                  </button>
                  <button 
                    onClick={() => setShowQrModal(true)}
                    className="w-11 h-11 bg-neutral-900 border border-neutral-800 rounded-xl flex items-center justify-center hover:bg-neutral-800 transition-colors"
                  >
                    <QrCode size={18} />
                  </button>
                </>
              ) : (
                <div className="flex items-center gap-2 w-full max-w-sm">
                  <button 
                    onClick={handleFollowToggle}
                    disabled={actionLoading}
                    className={`flex-1 h-11 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all flex items-center justify-center gap-2 shadow-xl ${
                      isFollowing 
                      ? 'bg-neutral-800 text-neutral-500 border border-neutral-700' 
                      : 'bg-red-600 text-white shadow-red-600/20'
                    }`}
                  >
                    {isFollowing ? <><UserMinus size={16} /> {t('profile.unfollow')}</> : <><UserPlus size={16} /> {t('profile.follow')}</>}
                  </button>
                </div>
              )}
            </div>
          </div>
        </section>
 
        {isMe && targetProfile.sellerProfileExists && (
          <section className="mt-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
             <div className="bg-neutral-900/50 border border-neutral-800 rounded-[32px] p-6 md:p-8">
                <div className={`flex items-center justify-between mb-6 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                   <h3 className={`text-[10px] font-black uppercase tracking-widest text-neutral-500 flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                      <LayoutDashboard size={14} className="text-bento-accent" /> {t('profile.seller_tools')}
                   </h3>
                   <div className={`flex gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                      <span className="text-[10px] font-black text-bento-accent bg-bento-accent/10 px-2 py-0.5 rounded uppercase tracking-tighter border border-bento-accent/20">
                         {t('profile.level')} {targetProfile.sellerProfile?.level}
                      </span>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded uppercase tracking-tighter border ${targetProfile.sellerProfile?.type === 'brand' ? 'bg-purple-500/10 text-purple-400 border-purple-500/20' : 'bg-blue-500/10 text-blue-400 border-blue-500/20'}`}>
                         {targetProfile.sellerProfile?.type === 'brand' ? t('profile.brand') : t('profile.seller')}
                      </span>
                   </div>
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                   <button onClick={() => navigate('/seller', { state: { activeTab: 'products' } })} className="p-5 bg-black/40 border border-neutral-800 rounded-2xl flex flex-col items-center gap-3 hover:bg-bento-accent/5 hover:border-bento-accent/30 transition-all group">
                      <div className="p-3 bg-neutral-800 rounded-xl group-hover:bg-bento-accent group-hover:text-black transition-colors">
                        <Package size={20} />
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400 group-hover:text-white">{t('profile.manage_products')}</span>
                   </button>
                   <button onClick={() => navigate('/add-product')} className="p-5 bg-black/40 border border-neutral-800 rounded-2xl flex flex-col items-center gap-3 hover:bg-bento-accent/5 hover:border-bento-accent/30 transition-all group">
                      <div className="p-3 bg-neutral-800 rounded-xl group-hover:bg-bento-accent group-hover:text-black transition-colors">
                        <PlusCircle size={20} />
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400 group-hover:text-white">{t('profile.upload_new')}</span>
                   </button>
                   <button onClick={() => navigate('/seller', { state: { activeTab: 'balance' } })} className="p-5 bg-black/40 border border-neutral-800 rounded-2xl flex flex-col items-center gap-3 hover:bg-bento-accent/5 hover:border-bento-accent/30 transition-all group">
                      <div className="p-3 bg-neutral-800 rounded-xl group-hover:bg-bento-accent group-hover:text-black transition-colors">
                        <DollarSign size={20} />
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400 group-hover:text-white">{t('profile.earnings')}</span>
                   </button>
                   <button onClick={() => navigate('/seller', { state: { activeTab: 'store' } })} className="p-5 bg-black/40 border border-neutral-800 rounded-2xl flex flex-col items-center gap-3 hover:bg-bento-accent/5 hover:border-bento-accent/30 transition-all group">
                      <div className="p-3 bg-neutral-800 rounded-xl group-hover:bg-bento-accent group-hover:text-black transition-colors">
                        <Settings size={20} />
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400 group-hover:text-white">{t('profile.store_settings')}</span>
                   </button>
                </div>
             </div>
          </section>
        )}

        {/* Tabs */}
        <div className="border-t border-bento-border mt-8">
           <div className={`flex max-w-full overflow-x-auto overscroll-contain touch-pan-x no-scrollbar justify-start sm:justify-center gap-8 sm:gap-12 px-4 sm:px-0 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
              <button 
                onClick={() => setActiveTab('products')}
                className={`py-4 border-t-2 shrink-0 flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-all ${
                  activeTab === 'products' ? 'border-white text-white' : 'border-transparent text-neutral-500'
                }`}
              >
                <Grid size={18} /> {t('profile.tabs.products')}
              </button>
              <button 
                onClick={() => setActiveTab('liked')}
                className={`py-4 border-t-2 shrink-0 flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-all ${
                  activeTab === 'liked' ? 'border-white text-white' : 'border-transparent text-neutral-500'
                }`}
              >
                <Heart size={18} /> {t('profile.tabs.liked')}
              </button>
              <button 
                onClick={() => setActiveTab('reviews')}
                className={`py-4 border-t-2 shrink-0 flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-all ${
                  activeTab === 'reviews' ? 'border-white text-white' : 'border-transparent text-neutral-500'
                }`}
              >
                <MessageSquare size={18} /> {t('profile.tabs.reviews')}
              </button>
              {isMe && (
                <button 
                  onClick={() => setActiveTab('history')}
                  className={`py-4 border-t-2 shrink-0 flex items-center gap-2 text-sm font-bold uppercase tracking-widest transition-all ${
                    activeTab === 'history' ? 'border-white text-white' : 'border-transparent text-neutral-500'
                  }`}
                >
                  <DollarSign size={18} /> {t('profile.tabs.history')}
                </button>
              )}
           </div>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-3 md:grid-cols-3 lg:grid-cols-4 gap-0.5 md:gap-4 mt-6">
           {activeTab === 'products' ? (
             products.length === 0 ? (
               <div className="col-span-full py-20 text-center">
                  <Package size={48} className="mx-auto text-neutral-700 mb-4" />
                  <p className="text-neutral-500 italic">{t('profile.no_products')}</p>
               </div>
             ) : (
               products.map((product, idx) => (
                 <Link 
                  to={`/product/${product.id}`} 
                  key={`${product.id}-${idx}`} 
                  className="aspect-[3/4] bg-bento-item rounded-xl overflow-hidden relative group"
                 >
                   <img src={product.imageUrl} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                   <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                      <span className={`font-bold text-sm truncate ${dir === 'rtl' ? 'text-right' : ''}`}>{product.title}</span>
                   </div>
                   <div className={`absolute top-2 flex flex-col gap-1 items-end ${dir === 'rtl' ? 'left-2' : 'right-2'}`}>
                     <div className="bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-lg text-[10px] font-black border border-white/10 uppercase">
                        ${product.price}
                     </div>
                     <div className="bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-lg text-[9px] font-black border border-white/10 flex items-center gap-1">
                        <Heart size={10} className="text-red-500 fill-red-500" />
                        <span>{product.likesCount || 0}</span>
                     </div>
                   </div>
                 </Link>
               ))
             )
           ) : activeTab === 'liked' ? (
             wishlistItems.length === 0 ? (
               <div className="col-span-full py-20 text-center">
                  <Heart size={48} className="mx-auto text-neutral-700 mb-4" />
                  <p className="text-neutral-500 italic">{t('profile.wishlist_empty')}</p>
                  <Link to="/" className={`text-bento-accent font-bold mt-2 inline-block ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    {dir === 'rtl' ? '← استكشف المنتجات' : 'Explore products →'}
                  </Link>
               </div>
             ) : (
               wishlistItems.map(item => (
                 <div key={item.id} className="relative group">
                   <Link 
                    to={`/product/${item.productId}`} 
                    className="aspect-[3/4] bg-bento-item rounded-xl overflow-hidden block relative"
                   >
                     <img src={item.productImage} alt="" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                     <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                        <span className={`font-bold text-sm truncate ${dir === 'rtl' ? 'text-right' : ''}`}>{item.productTitle}</span>
                     </div>
                     <div className={`absolute top-2 bg-black/60 backdrop-blur-md px-2 py-0.5 rounded-lg text-[10px] font-black border border-white/10 uppercase ${dir === 'rtl' ? 'right-2' : 'left-2'}`}>
                        ${item.productPrice}
                     </div>
                   </Link>
                   {isMe && (
                     <button 
                       onClick={async (e) => {
                         e.preventDefault();
                         e.stopPropagation();
                         try {
                           await deleteDoc(doc(db, 'wishlists', item.id));
                           setWishlistItems(prev => prev.filter(i => i.id !== item.id));
                         } catch (error) {
                           console.error("Remove from wishlist error:", error);
                         }
                       }}
                       className={`absolute top-2 p-2 bg-red-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover:scale-110 ${dir === 'rtl' ? 'left-2' : 'right-2'}`}
                     >
                       <Heart size={14} fill="currentColor" />
                     </button>
                   )}
                 </div>
               ))
             )
           ) : activeTab === 'reviews' ? (
             reviews.length === 0 ? (
               <div className="col-span-full py-20 text-center">
                  <MessageSquare size={48} className="mx-auto text-neutral-700 mb-4" />
                  <p className="text-neutral-500 italic">{t('profile.no_reviews')}</p>
               </div>
             ) : (
               <div className={`col-span-full space-y-4 max-w-2xl mx-auto w-full px-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                 {reviews.map((review, idx) => (
                   <motion.div 
                     initial={{ opacity: 0, y: 10 }}
                     animate={{ opacity: 1, y: 0 }}
                     key={`${review.id}-${idx}`} 
                     className="bg-bento-item p-6 rounded-[30px] border border-stone-800 shadow-xl hover:border-bento-accent/30 transition-all"
                   >
                     <div className={`flex justify-between items-start mb-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                       <div className="flex gap-0.5">
                         {[1, 2, 3, 4, 5].map((s) => (
                           <Star key={s} size={12} fill={s <= review.rating ? "#FCD34D" : "none"} className={s <= review.rating ? "text-amber-400" : "text-stone-800"} />
                         ))}
                       </div>
                       <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                         <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                           <div className="text-sm font-bold text-white">{review.userName}</div>
                           <div className="text-[10px] text-stone-500 font-bold uppercase tracking-tighter">Verified Purchase • <span className="text-stone-400">{review.productTitle}</span></div>
                         </div>
                         <div className="w-10 h-10 rounded-full bg-neutral-800 overflow-hidden border border-neutral-700">
                           <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${review.userId}`} alt="user" />
                         </div>
                       </div>
                     </div>
                     <p className="text-stone-300 text-sm leading-relaxed italic">"{review.comment}"</p>
                   </motion.div>
                 ))}
               </div>
             )
           ) : (
             <div className={`col-span-full space-y-8 max-w-3xl mx-auto w-full px-4 mb-20 ${dir === 'rtl' ? 'text-right' : 'text-left'}`} dir={dir}>
                <div>
                   <h3 className={`text-xs font-black uppercase tracking-widest text-neutral-500 mb-4 flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                     {t('profile.purchases')} <Package size={14} className="text-bento-accent" />
                   </h3>
                   {purchases.length === 0 ? (
                     <div className="bg-neutral-900/30 border border-dashed border-neutral-800 rounded-3xl p-10 text-center">
                       <p className="text-neutral-500 text-sm italic">{t('profile.history_empty')}</p>
                     </div>
                   ) : (
                     <div className="space-y-3">
                       {purchases.map((order, idx) => (
                         <div key={`${order.id}-${idx}`} className={`bg-neutral-900 border border-neutral-800 p-4 rounded-2xl flex items-center justify-between group hover:border-bento-accent/30 transition-all ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                           <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'text-left'}`}>
                             <div className="w-12 h-12 bg-neutral-800 rounded-xl overflow-hidden shrink-0">
                               <img src={order.productImage} className="w-full h-full object-cover" alt="" />
                             </div>
                             <div>
                               <div className="font-bold text-sm">{order.productTitle}</div>
                               <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-tighter">
                                 {new Date(order.createdAt?.seconds * 1000).toLocaleDateString()} • {order.status === 'completed' ? t('profile.completed') : t('profile.processing')}
                               </div>
                             </div>
                           </div>
                           <div className={dir === 'rtl' ? 'text-left' : 'text-right'}>
                             <div className="font-black text-white">${order.price.toFixed(2)}</div>
                             <div className={`text-[9px] font-black uppercase tracking-widest ${order.paymentStatus === 'released' ? 'text-emerald-500' : 'text-amber-500'}`}>
                               {order.paymentStatus}
                             </div>
                           </div>
                         </div>
                       ))}
                     </div>
                   )}
                </div>

                <div>
                  <h3 className={`text-xs font-black uppercase tracking-widest text-neutral-500 mb-4 flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    {t('profile.withdrawals')} <DollarSign size={14} className="text-emerald-500" />
                  </h3>
                  {withdrawals.length === 0 ? (
                    <div className="bg-neutral-900/30 border border-dashed border-neutral-800 rounded-3xl p-10 text-center">
                      <p className="text-neutral-500 text-sm italic">{t('profile.no_withdrawals') || "No withdrawals yet."}</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {withdrawals.map((w, idx) => (
                        <div key={`${w.id}-${idx}`} className={`bg-neutral-900 border border-neutral-800 p-4 rounded-2xl flex items-center justify-between group hover:border-emerald-500/30 transition-all ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                          <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'text-left'}`}>
                            <div className="w-10 h-10 bg-neutral-800 rounded-xl flex items-center justify-center shrink-0">
                               <DollarSign size={20} className={w.status === 'completed' ? 'text-emerald-500' : 'text-amber-500'} />
                            </div>
                            <div>
                              <div className="font-bold text-sm">{t('profile.withdrawal_to')} {w.paymentMethod.provider}</div>
                              <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-tighter">
                                {new Date(w.createdAt?.seconds * 1000).toLocaleDateString()} • {w.status === 'completed' ? t('profile.success') : t('profile.processing')}
                              </div>
                            </div>
                          </div>
                          <div className={dir === 'rtl' ? 'text-left' : 'text-right'}>
                            <div className="font-black text-white">-${w.amount.toFixed(2)}</div>
                            <div className="text-[10px] text-neutral-500 font-bold">{w.paymentMethod.accountNumber}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
             </div>
           )}
        </div>
      </div>

      {/* Edit Modal */}
      <AnimatePresence>
        {isEditing && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-bento-item w-full max-w-lg rounded-3xl p-8 border border-bento-border relative shadow-2xl"
              dir={dir}
            >
              <h2 className={`text-2xl font-black mb-8 uppercase italic tracking-tighter ${dir === 'rtl' ? 'text-right' : ''}`}>{t('profile.edit_profile')}</h2>
              <form onSubmit={handleUpdateProfile} className="space-y-6">
                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : ''}`}>{t('settings.display_name')}</label>
                  <input 
                    type="text" 
                    value={editForm.displayName}
                    onChange={e => setEditForm({...editForm, displayName: e.target.value})}
                    className={`w-full bg-bento-bg border border-bento-border text-white rounded-xl px-4 py-3 focus:border-bento-accent outline-none transition-colors font-bold ${dir === 'rtl' ? 'text-right' : ''}`}
                    maxLength={30}
                    required
                  />
                </div>
                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : ''}`}>{t('settings.bio')}</label>
                  <textarea 
                    value={editForm.bio}
                    onChange={e => setEditForm({...editForm, bio: e.target.value})}
                    className={`w-full bg-bento-bg border border-bento-border text-white rounded-xl px-4 py-3 focus:border-bento-accent outline-none transition-colors h-24 resize-none text-sm ${dir === 'rtl' ? 'text-right' : ''}`}
                    maxLength={150}
                    placeholder="Tell the world who you are..."
                  />
                </div>
                <div>
                  <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : ''}`}>{t('common.profile_picture') || "Profile Picture"}</label>
                  <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-bento-accent bg-neutral-900 flex-shrink-0">
                      <img 
                        src={editForm.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.uid}`} 
                        className="w-full h-full object-cover" 
                        alt="Preview" 
                      />
                    </div>
                    <div className="flex-1">
                      <input 
                        type="file" 
                        accept="image/*"
                        className="hidden"
                        id="profile-photo-input"
                        onChange={e => e.target.files?.[0] && handleProfilePhotoUpload(e.target.files[0])}
                      />
                      <label 
                        htmlFor="profile-photo-input"
                        className="bg-bento-bg border border-bento-border rounded-xl px-4 py-2.5 text-xs font-bold hover:border-bento-accent cursor-pointer transition-all inline-flex items-center gap-2"
                      >
                        {uploading ? <Loader2 size={14} className="animate-spin" /> : <Upload size={14} />}
                        {uploading ? 'Compressing...' : (t('common.change_photo') || 'Change Photo')}
                      </label>
                      <p className={`text-[9px] text-neutral-600 mt-1 uppercase font-bold tracking-tight ${dir === 'rtl' ? 'text-right' : ''}`}>Max size 1MB • Auto-compressed</p>
                    </div>
                  </div>
                </div>
                <div className={`flex gap-4 pt-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <button 
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="flex-1 px-6 py-4 border border-bento-border rounded-2xl font-bold hover:bg-neutral-800 transition-colors uppercase tracking-widest text-xs"
                  >
                    {t('common.discard') || "Discard"}
                  </button>
                  <button 
                    type="submit"
                    className="flex-1 px-6 py-4 bg-bento-accent text-black rounded-2xl font-black hover:opacity-90 transition-all shadow-xl shadow-bento-accent/20 uppercase tracking-widest text-xs"
                  >
                    {t('settings.save_changes')}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Settings Bottom Menu (TikTok Style) */}
      <AnimatePresence>
        {showSettingsMenu && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettingsMenu(false)}
              className="fixed inset-0 z-[110] bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed bottom-0 left-0 right-0 z-[120] bg-neutral-900 border-t border-neutral-800 rounded-t-[32px] overflow-hidden"
            >
              <div className="w-12 h-1 bg-neutral-800 rounded-full mx-auto mt-3 mb-2" />
              <div className="p-4 space-y-1">
                {myProfile?.role === 'admin' && (
                  <button 
                    onClick={() => {
                      setShowSettingsMenu(false);
                      navigate('/system/hq');
                    }}
                    className={`w-full flex items-center justify-between p-4 hover:bg-red-500/5 rounded-2xl transition-colors group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
                  >
                    <div className={`flex items-center gap-4 text-red-500 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                      <div className="p-2.5 bg-red-500/10 rounded-xl group-hover:bg-red-500 group-hover:text-black transition-colors">
                        <ShieldAlert size={20} />
                      </div>
                      <span className="font-black uppercase tracking-widest text-xs">{t('nav.admin') || "System Admin"}</span>
                    </div>
                    <ArrowRight size={16} className={dir === 'rtl' ? 'rotate-180' : ''} />
                  </button>
                )}
                <button 
                  onClick={() => {
                    setShowSettingsMenu(false);
                    setShowQrModal(true);
                  }}
                  className={`w-full flex items-center justify-between p-4 hover:bg-neutral-800 rounded-2xl transition-colors group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`flex items-center gap-4 text-white ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="p-2.5 bg-neutral-800 rounded-xl group-hover:bg-bento-accent group-hover:text-black transition-colors">
                      <QrCode size={20} />
                    </div>
                    <span className="font-bold">{t('profile.qr_share')}</span>
                  </div>
                </button>

                <button 
                  onClick={() => {
                    setShowSettingsMenu(false);
                    setShowVerify(true);
                  }}
                  className={`w-full flex items-center justify-between p-4 hover:bg-neutral-800 rounded-2xl transition-colors group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`flex items-center gap-4 text-white ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="p-2.5 bg-neutral-800 rounded-xl group-hover:bg-emerald-500 group-hover:text-black transition-colors">
                      <ShieldCheck size={20} />
                    </div>
                    <span className="font-bold">{t('profile.identity_verification', 'التحقق من الهوية')}</span>
                  </div>
                </button>

                <button 
                  onClick={() => {
                    setShowSettingsMenu(false);
                    navigate('/settings');
                  }}
                  className={`w-full flex items-center justify-between p-4 hover:bg-neutral-800 rounded-2xl transition-colors group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`flex items-center gap-4 text-white ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="p-2.5 bg-neutral-800 rounded-xl group-hover:bg-bento-accent group-hover:text-black transition-colors">
                      <Settings size={20} />
                    </div>
                    <span className="font-bold">{t('settings.title')}</span>
                  </div>
                </button>

                <div className="h-px bg-neutral-800 mx-4 my-2" />

                <button 
                  onClick={() => {
                    setShowSettingsMenu(false);
                    setShowLogoutConfirm(true);
                  }}
                  className={`w-full flex items-center justify-between p-4 hover:bg-red-500/10 rounded-2xl transition-colors group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}
                >
                  <div className={`flex items-center gap-4 text-red-500 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="p-2.5 bg-red-500/10 rounded-xl group-hover:bg-red-500 group-hover:text-white transition-colors">
                      <LogOut size={20} />
                    </div>
                    <span className="font-bold">{t('common.logout')}</span>
                  </div>
                </button>
              </div>
              <div className="h-10 invisible" /> {/* Safe area placeholder */}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Logout Confirmation Modal */}
      <AnimatePresence>
        {showLogoutConfirm && (
          <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-neutral-900 w-full max-w-sm rounded-[32px] p-8 border border-neutral-800 shadow-2xl text-center"
              dir={dir}
            >
              <div className="w-16 h-16 bg-red-500/10 text-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <LogOut size={32} />
              </div>
              <h3 className="text-xl font-black mb-2">{t('profile.logout_confirm_title')}</h3>
              <p className="text-neutral-500 font-bold mb-8 text-sm">{t('profile.logout_confirm_desc')}</p>
              
              <div className={`flex gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <button 
                  onClick={() => setShowLogoutConfirm(false)}
                  className="flex-1 py-4 bg-neutral-800 text-white rounded-2xl font-bold hover:bg-neutral-700 transition-colors flex items-center justify-center gap-2"
                >
                  <X size={18} />
                  <span>{t('profile.cancel')}</span>
                </button>
                <button 
                  onClick={async () => {
                    await signOut();
                  }}
                  className="flex-1 py-4 bg-red-500 text-white rounded-2xl font-black hover:bg-red-600 transition-colors shadow-lg shadow-red-500/20 flex items-center justify-center gap-2"
                >
                  <LogOut size={18} />
                  <span>{t('profile.confirm')}</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* QR Code Modal */}
      <AnimatePresence>
        {showQrModal && (
          <div className="fixed inset-0 z-[130] flex items-center justify-center p-6 bg-black/90 backdrop-blur-xl">
             <motion.div 
               initial={{ scale: 0.9, opacity: 0 }}
               animate={{ scale: 1, opacity: 1 }}
               exit={{ scale: 0.9, opacity: 0 }}
               className="bg-white w-full max-w-sm rounded-[40px] p-8 text-black flex flex-col items-center relative shadow-2xl"
             >
                <button 
                  onClick={() => setShowQrModal(false)}
                  className={`absolute top-4 p-2 hover:bg-neutral-100 rounded-full transition-colors ${dir === 'rtl' ? 'left-4' : 'right-4'}`}
                >
                  <X />
                </button>

                <div className="w-16 h-16 rounded-2xl bg-bento-accent mb-6 flex items-center justify-center">
                   <div className="w-10 h-10 bg-black rounded-lg"></div>
                </div>

                <h3 className="text-xl font-black tracking-tighter mb-1 uppercase">{t('profile.qr_share')}</h3>
                <p className="text-neutral-500 font-bold mb-8 text-sm">@{targetProfile.displayName?.toLowerCase().replace(/\s/g, '')}</p>

                <div className="w-64 h-64 bg-neutral-100 rounded-[30px] p-6 mb-8 border-4 border-neutral-50 flex items-center justify-center">
                   <QrCode size={160} strokeWidth={1.5} className="text-black" />
                </div>

                <button 
                  onClick={() => setShowQrModal(false)}
                  className="w-full bg-black text-white font-black py-4 rounded-[20px] uppercase tracking-widest text-xs shadow-xl shadow-black/20"
                >
                  {t('profile.save_qr')}
                </button>
             </motion.div>
          </div>
        )}
      </AnimatePresence>

      {isMe && <IdentityVerification isOpen={showVerify} onClose={() => setShowVerify(false)} />}
    </div>
  );
}
