import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { db, collection, query, where, orderBy, onSnapshot, addDoc, serverTimestamp, doc, getDoc, setDoc, updateDoc, handleFirestoreError } from '../lib/firebase';
import { ChevronLeft, Send, User } from 'lucide-react';
import { motion } from 'motion/react';

export default function Chat() {
  const { uid } = useParams(); // Target user ID
  const { user, profile } = useAuth();
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const navigate = useNavigate();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [targetUser, setTargetUser] = useState<any>(null);
  const [chatId, setChatId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user || !uid) return;

    const setupChat = async () => {
      try {
        // Fetch target user details
        const userDoc = await getDoc(doc(db, 'users', uid));
        if (userDoc.exists()) {
          setTargetUser({ id: userDoc.id, ...userDoc.data() });
        }

        // Determine chat ID (sorted combination of both UIDs)
        const combinedId = user.uid > uid ? `${user.uid}_${uid}` : `${uid}_${user.uid}`;
        console.log("Setting up chat:", { combinedId, myUid: user.uid, targetUid: uid });
        setChatId(combinedId);

        // Ensure chat document exists
        const chatRef = doc(db, 'chats', combinedId);
        console.log("Checking for chat document at:", chatRef.path);
        const chatDoc = await getDoc(chatRef);
        console.log("Chat document exists?", chatDoc.exists());
        if (!chatDoc.exists()) {
          console.log("Creating new chat document...");
          await setDoc(chatRef, {
            participants: [user.uid, uid],
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
            recentMessage: ''
          });
          console.log("Chat document created successfully");
        }

        // Listen to messages
        const q = query(
          collection(db, 'chats', combinedId, 'messages'),
          orderBy('createdAt', 'asc')
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
          const msgs = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          }));
          setMessages(msgs);
          setLoading(false);
          setTimeout(() => scrollToBottom(), 100);
        }, (error) => {
          console.error("Chat sync error:", error);
          setLoading(false);
        });

        return unsubscribe;
      } catch (error) {
        console.error("Setup chat error:", error);
        setLoading(false);
      }
    };

    let unsub: any;
    setupChat().then(u => { unsub = u; });

    return () => {
      if (unsub && typeof unsub === 'function') unsub();
    };
  }, [user, uid]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || !chatId) return;

    const messageText = newMessage.trim();
    setNewMessage(''); // Clear immediately for better UX

    try {
      await addDoc(collection(db, 'chats', chatId, 'messages'), {
        text: messageText,
        senderId: user.uid,
        createdAt: serverTimestamp()
      });
      await updateDoc(doc(db, 'chats', chatId), {
        recentMessage: messageText,
        updatedAt: serverTimestamp()
      });
    } catch (error: any) {
      console.error("Error sending message:", error);
      alert(t('chat.error_sending', 'حدث خطأ أثناء إرسال الرسالة: ') + error.message);
      // Restore message on failure
      setNewMessage(messageText);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{t('common.please_login', 'يرجى تسجيل الدخول أولاً')}</p>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-neutral-950 z-50 flex flex-col pt-[max(env(safe-area-inset-top),16px)]">
      {/* Header */}
      <header className="flex items-center p-4 border-b border-neutral-800 bg-neutral-900 shrink-0">
        <button 
          onClick={() => navigate(-1)}
          className="p-2 hover:bg-neutral-800 rounded-full transition-colors me-2"
        >
          <ChevronLeft size={24} className={dir === 'rtl' ? 'rotate-180' : ''} />
        </button>
        
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-neutral-800 overflow-hidden flex items-center justify-center shrink-0">
            {targetUser?.photoURL ? (
              <img src={targetUser.photoURL} alt={targetUser.displayName} className="w-full h-full object-cover" />
            ) : (
              <User size={20} className="text-neutral-400" />
            )}
          </div>
          <div>
            <h2 className="font-bold text-white line-clamp-1">{targetUser?.displayName || '...'}</h2>
            {targetUser?.sellerProfileExists && (
              <span className="text-xs text-red-500 font-medium">
                {t('common.seller', 'بائع')}
              </span>
            )}
          </div>
        </div>
      </header>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-neutral-950 flex flex-col max-h-[calc(100vh-140px)]">
        {loading ? (
          <div className="flex-1 flex items-center justify-center opacity-50">...</div>
        ) : messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-neutral-500">
            <p>{t('chat.no_messages', 'لا توجد رسائل بعد')}</p>
            <p className="text-sm mt-1">{t('chat.start_conversation', 'ابدأ المحادثة الآن')}</p>
          </div>
        ) : (
          messages.map((msg, index) => {
            const isMe = msg.senderId === user.uid;
            return (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                key={msg.id || `msg-${index}`} 
                className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
              >
                <div 
                  className={`max-w-[80%] rounded-2xl p-3 px-4 ${
                    isMe 
                    ? 'bg-red-600 text-white rounded-br-sm' 
                    : 'bg-neutral-800 text-neutral-100 rounded-bl-sm'
                  }`}
                >
                  <p className="whitespace-pre-wrap word-break-words text-[15px]">{msg.text}</p>
                </div>
              </motion.div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 bg-neutral-900 border-t border-neutral-800 shrink-0 pb-[max(env(safe-area-inset-bottom),16px)]">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder={t('chat.type_message', 'اكتب رسالة...')}
            className="flex-1 bg-neutral-800 text-white rounded-full px-5 py-3 focus:outline-none focus:ring-2 focus:ring-red-500"
            dir={dir}
          />
          <button 
            type="submit"
            disabled={!newMessage.trim()}
            className="w-12 h-12 bg-red-600 hover:bg-red-700 disabled:opacity-50 disabled:hover:bg-red-600 rounded-full flex flex-shrink-0 items-center justify-center text-white transition-colors"
          >
            <Send size={20} className={dir === 'rtl' ? 'rotate-180 transform -translate-x-[2px]' : 'transform translate-x-[2px]'} />
          </button>
        </form>
      </div>
    </div>
  );
}
