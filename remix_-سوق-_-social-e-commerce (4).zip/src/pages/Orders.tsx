import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { db, handleFirestoreError, collection, query, where, orderBy, onSnapshot, updateDoc, doc, incrementResilient as increment, addDoc, serverTimestampResilient as serverTimestamp, getDoc, runTransaction, limit } from '../lib/firebase';
import { Order, Dispute, OrderStatus } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Package, ShieldCheck, AlertCircle, CheckCircle, ChevronRight, MessageSquare, Star, Clock, ShieldAlert, X, Upload, Loader2, Camera, Info, Trash2, Truck, DollarSign } from 'lucide-react';
import { sendNotification } from '../lib/notifications';
import { uploadAndCompressImage } from '../lib/storage';
import { OrderService } from '../services/OrderService';
import QRCode from 'react-qr-code';
import { useTranslation } from 'react-i18next';
import { Link } from 'react-router-dom';

const Countdown = ({ date, onComplete }: { date: Date, onComplete: () => void }) => {
  const [timeLeft, setTimeLeft] = useState<number>(0);

  useEffect(() => {
    const timer = setInterval(() => {
      const remaining = date.getTime() - new Date().getTime();
      if (remaining <= 0) {
        clearInterval(timer);
        onComplete();
        setTimeLeft(0);
      } else {
        setTimeLeft(remaining);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [date]);

  const minutes = Math.floor(timeLeft / 60000);
  const seconds = Math.floor((timeLeft % 60000) / 1000);

  if (timeLeft <= 0) return <span className="text-emerald-500 font-black">جاري التأكيد...</span>;

  return (
    <div className="flex items-center gap-1 font-mono font-black text-emerald-500 text-xs">
      <span>{minutes.toString().padStart(2, '0')}</span>
      <span className="animate-pulse">:</span>
      <span>{seconds.toString().padStart(2, '0')}</span>
    </div>
  );
};

export default function Orders() {
  const { user, profile } = useAuth();
  const { t } = useTranslation();
  const [activeTab, setActiveTab] = useState<'purchases' | 'sales' | 'available' | 'deliveries'>('purchases');
  const [purchaseOrders, setPurchaseOrders] = useState<Order[]>([]);
  const [salesOrders, setSalesOrders] = useState<Order[]>([]);
  const [availableOrders, setAvailableOrders] = useState<Order[]>([]);
  const [myDeliveries, setMyDeliveries] = useState<Order[]>([]);
  
  const [loading, setLoading] = useState(true);
  const [showDisputeModal, setShowDisputeModal] = useState<Order | null>(null);
  const [cancellingOrder, setCancellingOrder] = useState<string | null>(null);
  const [claimingOrder, setClaimingOrder] = useState<string | null>(null);
  
  const [disputeForm, setDisputeForm] = useState({
    reason: '',
    description: '',
    images: [] as string[]
  });
  const [submittingDispute, setSubmittingDispute] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    if (!user || !profile) return;

    let unsubscribers: (() => void)[] = [];

    // 1. My Purchases (All roles)
    const qPurchases = query(
      collection(db, 'orders'),
      where('buyerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubPurchases = onSnapshot(qPurchases, (snap) => {
      const p = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
      setPurchaseOrders(p);
      setLoading(false);
    }, (error) => handleFirestoreError(error, 'list', 'orders/purchases'));
    unsubscribers.push(unsubPurchases);

    // 2. My Sales (Sellers only)
    if (profile.role === 'seller' || profile.role === 'admin') {
      const qSales = query(
        collection(db, 'orders'),
        where('sellerId', '==', user.uid),
        orderBy('createdAt', 'desc')
      );
      const unsubSales = onSnapshot(qSales, (snap) => {
        const s = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
        setSalesOrders(s);
      }, (error) => handleFirestoreError(error, 'list', 'orders/sales'));
      unsubscribers.push(unsubSales);
    }

    // 3. Deliveries (Couriers only)
    if (profile.role === 'courier' || profile.role === 'admin') {
      // Available orders to deliver (Ready for pickup)
      const qAvail = query(
        collection(db, 'orders'),
        where('status', '==', 'ready_for_delivery'),
        limit(20)
      );
      const unsubAvail = onSnapshot(qAvail, (snap) => {
        const a = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
        setAvailableOrders(a);
      }, (error) => handleFirestoreError(error, 'list', 'orders/available'));
      unsubscribers.push(unsubAvail);

      // Orders assigned to me
      const qMyDeliveries = query(
        collection(db, 'orders'),
        where('courierId', '==', user.uid),
        orderBy('updatedAt', 'desc')
      );
      const unsubMyDeliveries = onSnapshot(qMyDeliveries, (snap) => {
        const d = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Order));
        setMyDeliveries(d);
      }, (error) => handleFirestoreError(error, 'list', 'orders/my_deliveries'));
      unsubscribers.push(unsubMyDeliveries);
    }

    return () => unsubscribers.forEach(unsub => unsub());
  }, [user, profile]);

  const handleClaimOrder = async (orderId: string) => {
    if (!user) return;
    setClaimingOrder(orderId);
    try {
      await OrderService.claimOrder(orderId, user.uid);
      setActiveTab('deliveries');
    } catch (error: any) {
      alert(error.message);
    } finally {
      setClaimingOrder(null);
    }
  };

  const getActiveOrders = () => {
    switch (activeTab) {
      case 'purchases': return purchaseOrders;
      case 'sales': return salesOrders;
      case 'available': return availableOrders;
      case 'deliveries': return myDeliveries;
      default: return [];
    }
  };

  const orders = getActiveOrders();

  const confirmReceipt = async (order: Order) => {
    if (!window.confirm('هل أنت متأكد من استلام المنتج؟ سيتم تحويل المبلغ للبائع مباشرة.')) return;

    try {
      await OrderService.confirmReceipt(order.id, order.sellerId, order.price, order.netAmount);

      // 3. Notify Seller asynchronously
      sendNotification(
        order.sellerId,
        'sale',
        'Funds Released! 💰',
        `Buyer confirmed receipt of ${order.productTitle}. $${order.netAmount.toFixed(2)} credited to your balance.`,
        '/seller'
      ).catch(console.error);

    } catch (error: any) {
      console.error("Confirm Receipt Error:", error);
      alert(error.message);
    }
  };

  const handleCancelOrder = async (order: Order) => {
    if (!window.confirm('هل أنت متأكد من إلغاء الطلب؟')) return;

    setCancellingOrder(order.id);
    try {
      await OrderService.cancelOrder(order.id, order.sellerId, order.productId);
      alert("تم إلغاء الطلب بنجاح وتم إرجاع المنتج للمخزون.");
    } catch (error: any) {
      console.error("Cancel Order Error:", error);
      alert(error.message || "Failed to cancel order");
    } finally {
      setCancellingOrder(null);
    }
  };

  const handleImageUpload = async (file: File) => {
    if (!user) return;
    setUploadingImage(true);
    try {
      const url = await uploadAndCompressImage(file, {
        maxSizeMB: 1,
        maxWidthOrHeight: 1000,
        path: `disputes/${user.uid}`
      });
      setDisputeForm(prev => ({ ...prev, images: [...prev.images, url] }));
    } catch (error) {
      console.error("Upload error:", error);
    } finally {
      setUploadingImage(false);
    }
  };

  const submitDispute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !showDisputeModal) return;

    setSubmittingDispute(true);
    try {
      // 1. Create Dispute Doc
      const disputeData: Partial<Dispute> = {
        orderId: showDisputeModal.id,
        buyerId: user.uid,
        sellerId: showDisputeModal.sellerId,
        reason: disputeForm.reason,
        description: disputeForm.description,
        images: disputeForm.images,
        status: 'open',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      const disputeRef = await addDoc(collection(db, 'disputes'), disputeData);

      // 2. Update Order
      await updateDoc(doc(db, 'orders', showDisputeModal.id), {
        status: 'disputed',
        disputeId: disputeRef.id,
        updatedAt: serverTimestamp()
      });

      // 3. Update User/Seller Dispute Counts
      const buyerRef = doc(db, 'users', user.uid);
      const sellerRef = doc(db, 'users', showDisputeModal.sellerId);
      
      await updateDoc(buyerRef, {
        disputeCount: increment(1),
        monthlyDisputeCount: increment(1)
      });

      // 4. Notify Seller
      await sendNotification(
        showDisputeModal.sellerId,
        'system',
        'Dispute Opened! ⚠️',
        `Buyer opened a dispute for ${showDisputeModal.productTitle}. Funds are held until resolution.`,
        '/seller'
      );

      setShowDisputeModal(null);
      setDisputeForm({ reason: '', description: '', images: [] });
    } catch (error) {
      console.error("Dispute error:", error);
    } finally {
      setSubmittingDispute(false);
    }
  };

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'completed': return 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20';
      case 'on_the_way': return 'text-blue-500 bg-blue-500/10 border-blue-500/20';
      case 'delivered': return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20';
      case 'disputed': return 'text-red-500 bg-red-500/10 border-red-500/20';
      case 'cancelled': return 'text-neutral-400 bg-neutral-400/10 border-neutral-400/20';
      case 'confirmed': return 'text-indigo-500 bg-indigo-500/10 border-indigo-500/20';
      default: return 'text-neutral-500 bg-neutral-500/10 border-neutral-500/20';
    }
  };

  const canDispute = (order: Order) => {
    if (order.status !== 'delivered') return false;
    if (!order.autoConfirmAt) return true;
    
    const autoConfirmDate = order.autoConfirmAt.toDate();
    return new Date() < autoConfirmDate;
  };

  if (loading) return <div className="min-h-screen bg-black flex items-center justify-center text-white italic font-black uppercase tracking-widest">Loading...</div>;

  return (
    <div className="min-h-screen bg-black text-white p-6 md:p-12 max-w-5xl mx-auto pt-10 md:pt-16 pb-24 md:pb-12">
      <header className="mb-12">
        <h1 className="text-4xl md:text-6xl font-black italic tracking-tighter uppercase mb-4">
          {activeTab === 'purchases' ? t('nav.my_orders') : 
           activeTab === 'sales' ? t('seller.customer_orders') : 
           activeTab === 'available' ? t('settings.courier_available_jobs') : t('settings.courier_my_jobs')}
        </h1>
        <div className="flex items-center gap-2 text-neutral-500 font-bold uppercase tracking-widest text-[10px] bg-neutral-900 w-fit px-4 py-2 rounded-full border border-neutral-800">
          <ShieldCheck size={14} className="text-emerald-500" />
          Order Protection V1 Active
        </div>
      </header>

      {/* Tabs */}
      <div className="flex gap-2 mb-8 overflow-x-auto no-scrollbar pb-2 items-center">
        <button 
          onClick={() => setActiveTab('purchases')}
          className={`px-6 py-3 rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'purchases' ? 'bg-white text-black' : 'bg-neutral-900 text-neutral-500 border border-neutral-800'}`}
        >
          <Package size={14} /> {t('nav.my_orders')}
        </button>

        {(profile?.role === 'seller' || profile?.role === 'admin') && (
          <button 
            onClick={() => setActiveTab('sales')}
            className={`px-6 py-3 rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'sales' ? 'bg-emerald-500 text-black' : 'bg-neutral-900 text-neutral-500 border border-neutral-800'}`}
          >
            <DollarSign size={14} /> {t('seller.customer_orders')}
          </button>
        )}

        {(profile?.role === 'courier' || profile?.role === 'admin') && (
          <>
            <button 
              onClick={() => setActiveTab('available')}
              className={`px-6 py-3 rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'available' ? 'bg-blue-500 text-white' : 'bg-neutral-900 text-neutral-500 border border-neutral-800'}`}
            >
              <Truck size={14} /> {t('settings.courier_available_jobs')}
            </button>
            <button 
              onClick={() => setActiveTab('deliveries')}
              className={`px-6 py-3 rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center gap-2 transition-all whitespace-nowrap ${activeTab === 'deliveries' ? 'bg-indigo-500 text-white' : 'bg-neutral-900 text-neutral-500 border border-neutral-800'}`}
            >
              <CheckCircle size={14} /> {t('settings.courier_my_jobs')}
            </button>
          </>
        )}
      </div>

      <div className="space-y-6">
        {orders.length === 0 ? (
          <div className="py-32 bg-neutral-900/30 rounded-[40px] border border-neutral-900 border-dashed text-center">
            <Package size={48} className="mx-auto text-neutral-800 mb-6" />
            <p className="text-neutral-500 font-black italic text-xl uppercase">{t('nav.inbox_clear')}</p>
          </div>
        ) : (
          orders.map((order, idx) => (
            <div key={`${order.id}-${idx}`} className="bg-neutral-900/50 backdrop-blur-xl border border-neutral-800 rounded-[40px] p-6 md:p-10 transition-all hover:bg-neutral-900 group">
              <div className="flex flex-col md:flex-row gap-8 items-start">
                {/* Product Image */}
                <div className="w-full md:w-48 aspect-square rounded-[32px] overflow-hidden border border-neutral-800 shrink-0 relative">
                  <img src={order.productImage || 'https://via.placeholder.com/300'} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  <div className={`absolute top-4 left-4 px-3 py-1.5 rounded-xl border text-[9px] font-black uppercase tracking-widest backdrop-blur-md ${getStatusColor(order.status)}`}>
                    {order.status}
                  </div>
                </div>

                {/* Details */}
                <div className="flex-1 w-full text-left">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                    <div className="text-left">
                      <h3 className="text-2xl font-black italic tracking-tighter mb-1 uppercase">{order.productTitle}</h3>
                      <p className="text-[10px] font-black uppercase tracking-widest text-neutral-600 font-mono">
                        Order #{order.id.slice(0, 8).toUpperCase()} • {order.createdAt?.toDate?.().toLocaleDateString() || 'N/A'}
                      </p>
                    </div>
                    <div className="text-3xl font-black italic text-right">${order.price.toFixed(2)}</div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                    <div className="p-4 bg-black/40 rounded-2xl border border-neutral-800">
                      <p className="text-[8px] font-black uppercase tracking-widest text-neutral-500 mb-1">Status</p>
                      <p className="text-xs font-bold uppercase">{order.status}</p>
                    </div>
                    <div className="p-4 bg-black/40 rounded-2xl border border-neutral-800">
                      <p className="text-[8px] font-black uppercase tracking-widest text-neutral-500 mb-1">Payment</p>
                      <div className="flex items-center gap-1.5">
                        <div className={`w-1.5 h-1.5 rounded-full ${order.paymentStatus === 'held' ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`}></div>
                        <p className="text-xs font-bold uppercase">{order.paymentStatus}</p>
                      </div>
                    </div>
                    <div className="p-4 bg-black/40 rounded-2xl border border-neutral-800">
                      <p className="text-[8px] font-black uppercase tracking-widest text-neutral-500 mb-1">Shipping</p>
                      <p className="text-xs font-bold uppercase truncate">{order.shippingMethod?.replace('_', ' ')}</p>
                    </div>
                    {order.trackingCode && (
                      <div className="p-4 bg-black/40 rounded-2xl border border-neutral-800">
                        <p className="text-[8px] font-black uppercase tracking-widest text-neutral-500 mb-1">Tracking Code</p>
                        <p className="text-xs font-black font-mono">{order.trackingCode}</p>
                      </div>
                    )}
                  </div>

                  {/* Security Proofs Section */}
                  {(order.pickupProofImage || order.deliveryProofImage) && (
                    <div className="mb-8 space-y-4">
                      <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500">Security & Tracking Proofs</p>
                      <div className="flex gap-4">
                        {order.pickupProofImage && (
                          <div className="flex-1 p-4 bg-neutral-900 border border-neutral-800 rounded-2xl">
                             <img src={order.pickupProofImage} alt="Pickup Proof" className="w-full aspect-video object-cover rounded-xl mb-2" />
                             <p className="text-[8px] font-black uppercase tracking-widest text-neutral-600 text-center">Seller Preparation Proof</p>
                          </div>
                        )}
                        {order.deliveryProofImage && (
                          <div className="flex-1 p-4 bg-neutral-900 border border-neutral-800 rounded-2xl">
                             <img src={order.deliveryProofImage} alt="Delivery Proof" className="w-full aspect-video object-cover rounded-xl mb-2" />
                             <p className="text-[8px] font-black uppercase tracking-widest text-neutral-600 text-center">Courier Delivery Proof</p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* QR Logic (Only for Purchases) */}
                  {activeTab === 'purchases' && (order.status === 'on_the_way' || order.status === 'delivered') && (
                    <div className="mb-8 p-8 bg-white text-black rounded-[32px] flex flex-col md:flex-row items-center gap-8 justify-between">
                      <div className="text-center md:text-left">
                        <h4 className="text-2xl font-black italic tracking-tighter uppercase mb-2">Delivery Verification</h4>
                        <p className="text-xs font-bold uppercase tracking-widest leading-relaxed text-black/60 max-w-xs">
                          Show this QR code to the courier upon arrival to confirm delivery.
                        </p>
                      </div>
                      <div className="p-4 bg-white rounded-2xl shadow-xl">
                        <QRCode value={order.deliveryQrCode} size={150} fgColor="#000000" />
                        <div className="mt-4 text-center font-mono font-black tracking-widest text-xs">{order.deliveryQrCode}</div>
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex items-center flex-wrap gap-4">
                    {activeTab === 'purchases' && ['pending', 'confirmed', 'preparing', 'ready_for_delivery'].includes(order.status) && (
                      <button 
                        onClick={() => handleCancelOrder(order)}
                        disabled={cancellingOrder === order.id}
                        className="bg-red-500 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-red-400 transition-all shadow-lg shadow-red-500/20 flex items-center gap-2 disabled:opacity-50"
                      >
                        {cancellingOrder === order.id ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />} 
                        إلغاء الطلب
                      </button>
                    )}

                    {activeTab === 'purchases' && order.status === 'delivered' && (
                      <button 
                        onClick={() => confirmReceipt(order)}
                        className="bg-emerald-500 text-black px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/20 flex items-center gap-2"
                      >
                        <CheckCircle size={14} /> تأكيد الاستلام
                      </button>
                    )}

                    {activeTab === 'available' && (
                      <button 
                        onClick={() => handleClaimOrder(order.id)}
                        disabled={claimingOrder === order.id || order.buyerId === user.uid}
                        className="bg-blue-500 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-blue-400 transition-all shadow-lg shadow-blue-500/20 flex items-center gap-2 disabled:opacity-50"
                      >
                        {claimingOrder === order.id ? <Loader2 size={14} className="animate-spin" /> : <Truck size={14} />} 
                        {order.buyerId === user.uid ? "طلبك الشخصي" : t('settings.courier_claim_job')}
                      </button>
                    )}

                    {activeTab === 'deliveries' && order.status === 'courier_assigned' && (
                      <Link 
                        to="/courier/dashboard"
                        className="bg-indigo-500 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-indigo-400 transition-all shadow-lg shadow-indigo-500/20 flex items-center gap-2"
                      >
                        إدارة التوصيل
                      </Link>
                    )}

                    {activeTab === 'purchases' && canDispute(order) && (
                      <button 
                        onClick={() => setShowDisputeModal(order)}
                        className="bg-neutral-800 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-red-500/10 hover:text-red-500 border border-transparent hover:border-red-500 transition-all flex items-center gap-2"
                      >
                        <AlertCircle size={14} /> فتح نزاع
                      </button>
                    )}

                    {activeTab === 'purchases' && order.status === 'disputed' && (
                      <div className="flex items-center gap-2 text-red-500 font-black uppercase tracking-widest text-[10px] bg-red-500/10 px-6 py-4 rounded-2xl border border-red-500/20">
                        <ShieldAlert size={14} /> حالة نزاع مفتوح
                      </div>
                    )}

                    {order.status === 'completed' && (
                      <div className="flex items-center gap-2 text-emerald-500 font-black uppercase tracking-widest text-[10px] bg-emerald-500/10 px-6 py-4 rounded-2xl border border-emerald-500/20">
                        <ShieldCheck size={14} /> تم اكتمال الطلب بنجاح
                      </div>
                    )}

                    {order.status === 'cancelled' && (
                      <div className="flex items-center gap-2 text-neutral-500 font-black uppercase tracking-widest text-[10px] bg-neutral-500/10 px-6 py-4 rounded-2xl border border-neutral-500/20">
                        <X size={14} /> تم إلغاء الطلب
                      </div>
                    )}
                  </div>

                  {order.autoConfirmAt && order.status === 'delivered' && (
                    <div className="mt-4 p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl flex items-center justify-between">
                      <p className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest flex items-center gap-2">
                        <Clock size={12} className="text-emerald-500" /> 
                        سيتم التأكيد التلقائي والإفراج عن الأموال قريباً
                      </p>
                      <Countdown date={order.autoConfirmAt.toDate()} onComplete={() => confirmReceipt(order)} />
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Dispute Modal */}
      <AnimatePresence>
        {showDisputeModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-neutral-900 w-full max-w-xl rounded-[40px] border border-neutral-800 overflow-hidden shadow-2xl"
            >
              <div className="p-8 border-b border-neutral-800 flex justify-between items-center bg-neutral-900/50 backdrop-blur-md">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-red-500/10 text-red-500 rounded-2xl">
                    <ShieldAlert size={24} />
                  </div>
                  <div>
                    <h2 className="text-2xl font-black italic tracking-tighter uppercase">Submit Dispute</h2>
                    <p className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest">Order protection active</p>
                  </div>
                </div>
                <button onClick={() => setShowDisputeModal(null)} className="p-2 hover:bg-neutral-800 rounded-full">
                  <X />
                </button>
              </div>

              <form onSubmit={submitDispute} className="p-8 space-y-6">
                <div>
                  <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block">Reason for Dispute</label>
                  <select 
                    required
                    value={disputeForm.reason}
                    onChange={e => setDisputeForm({...disputeForm, reason: e.target.value})}
                    className="w-full bg-black border border-neutral-800 rounded-2xl px-4 py-4 outline-none focus:border-red-500 transition-all font-bold appearance-none text-sm"
                  >
                    <option value="">Select a reason...</option>
                    <option value="item_not_as_described">Item not as described</option>
                    <option value="item_never_received">Item never received</option>
                    <option value="counterfeit">Counterfeit / Fake item</option>
                    <option value="defective">Defective / Broken</option>
                    <option value="other">Other reason</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-2 block">Tell us what happened</label>
                  <textarea 
                    required
                    value={disputeForm.description}
                    onChange={e => setDisputeForm({...disputeForm, description: e.target.value})}
                    placeholder="Provide detailed information about your issue..."
                    className="w-full bg-black border border-neutral-800 rounded-[24px] px-4 py-4 outline-none focus:border-red-500 transition-all h-32 resize-none text-sm font-medium"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block">Upload Evidence (Photos)</label>
                  <div className="grid grid-cols-4 gap-3">
                    {disputeForm.images.map((img, i) => (
                      <div key={`dispute-upload-${i}-${img.slice(-10)}`} className="aspect-square rounded-2xl overflow-hidden border border-neutral-800 relative group">
                        <img src={img} alt="" className="w-full h-full object-cover" />
                        <button 
                          type="button"
                          onClick={() => setDisputeForm(prev => ({ ...prev, images: prev.images.filter((_, idx) => idx !== i) }))}
                          className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X size={12} />
                        </button>
                      </div>
                    ))}
                    {disputeForm.images.length < 4 && (
                      <label className="aspect-square rounded-2xl border-2 border-dashed border-neutral-800 flex flex-col items-center justify-center cursor-pointer hover:border-red-500/50 hover:bg-neutral-800 transition-all">
                        <input 
                          type="file" 
                          accept="image/*" 
                          className="hidden" 
                          onChange={e => e.target.files?.[0] && handleImageUpload(e.target.files[0])}
                        />
                        {uploadingImage ? <Loader2 size={20} className="animate-spin text-neutral-600" /> : <Camera size={20} className="text-neutral-600" />}
                      </label>
                    )}
                  </div>
                </div>

                <div className="bg-amber-500/5 border border-amber-500/10 p-4 rounded-2xl flex gap-3">
                  <Info size={16} className="text-amber-500 shrink-0 mt-0.5" />
                  <p className="text-[9px] font-medium text-neutral-400 leading-relaxed uppercase tracking-tight">
                    Our team will review your dispute within 24-48 hours. Funds will remain securely held until a decision is made.
                  </p>
                </div>

                <button 
                  type="submit"
                  disabled={submittingDispute || !disputeForm.reason || !disputeForm.description}
                  className="w-full bg-red-500 text-white py-5 rounded-[24px] font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-red-600 transition-all shadow-lg shadow-red-500/20 disabled:opacity-50"
                >
                  {submittingDispute ? <Loader2 size={20} className="animate-spin" /> : <ShieldAlert size={20} />}
                  Submit Dispute
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
