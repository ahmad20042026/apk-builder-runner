import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  db, getDocResilient, getDocsResilient,
  doc, getDoc, addDoc, collection, updateDoc, increment, query, where, getDocs, deleteDoc, serverTimestampResilient as serverTimestamp, orderBy, runTransaction
} from '../lib/firebase';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { processReputationUpdate } from '../lib/trustEngine';
import OrderVerificationModal from '../components/OrderVerificationModal';
import { Product, Review, UserProfile } from '../types';
import { OrderService } from '../services/OrderService';
import { sendNotification } from '../lib/notifications';
import { ChevronLeft, ShoppingCart, ShieldCheck, Truck, RotateCcw, Heart, UserPlus, UserMinus, CheckCircle, ArrowRight, Star, MessageSquare, Share2, Copy, Send, Twitter as TwitterIcon, Facebook, Globe, MapPin, ArrowUp, ArrowDown, Minus, Plus, Zap, Ban, Navigation, Clock as ClockIcon, Loader2, ShoppingBasket } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LogisticsService } from '../services/LogisticsService';
import VerifiedBadge from '../components/VerifiedBadge';

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, profile } = useAuth();
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [buying, setBuying] = useState(false);
  const [addingToCart, setAddingToCart] = useState(false);
  const [showVerifyModal, setShowVerifyModal] = useState(false);
  const [wishlisting, setWishlisting] = useState(false);
  const [isInWishlist, setIsInWishlist] = useState(false);
  const [wishlistId, setWishlistId] = useState<string | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showShare, setShowShare] = useState(false);
  const [copying, setCopying] = useState(false);

  // Add-ons State
  const [selectedAddOns, setSelectedAddOns] = useState<Record<string, number>>({});
  const [selectedDrinks, setSelectedDrinks] = useState<string[]>([]);

  // New Logistics State
  const [calculatingLogistics, setCalculatingLogistics] = useState(false);
  const [logisticsResult, setLogisticsResult] = useState<any>(null);
  const [buyerLocation, setBuyerLocation] = useState<{lat: number, lng: number} | null>(null);

  const [isFollowing, setIsFollowing] = useState(false);
  const [followId, setFollowId] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [sellerReputation, setSellerReputation] = useState<any>(null);

  const [reviews, setReviews] = useState<Review[]>([]);
  const [hasOrdered, setHasOrdered] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    const fetchProduct = async () => {
      if (!id) return;
      try {
        const snap = await getDocResilient(doc(db, 'products', id));
        if (snap.exists()) {
          const prodData = { id: snap.id, ...(snap.data() as object) } as Product;
          setProduct(prodData);
          
          // Fetch Seller Reputation
          try {
            const sellerSnap = await getDocResilient(doc(db, 'users', prodData.sellerId));
            if (sellerSnap.exists()) {
              setSellerReputation((sellerSnap.data() as any).sellerProfile || null);
            }
          } catch (e) {
            console.warn("Could not fetch seller rep resiliently:", e);
          }

          if (user) {
            // Wishlist Check
            const q = query(collection(db, 'wishlists'), where('userId', '==', user.uid), where('productId', '==', snap.id));
            const wSnap = await getDocsResilient(q);
            if (!wSnap.empty) {
              setIsInWishlist(true);
              setWishlistId(wSnap.docs[0].id);
            }

            // Follow Check
            const fQ = query(collection(db, 'follows'), where('followerId', '==', user.uid), where('followingId', '==', prodData.sellerId));
            const fSnap = await getDocsResilient(fQ);
            if (!fSnap.empty) {
              setIsFollowing(true);
              setFollowId(fSnap.docs[0].id);
            }

            // Order Check (Buyer permission to review)
            const oQ = query(collection(db, 'orders'), where('buyerId', '==', user.uid), where('productId', '==', snap.id));
            const oSnap = await getDocsResilient(oQ);
            setHasOrdered(!oSnap.empty);

            // Already reviewed check
            const rQ = query(collection(db, 'reviews'), where('userId', '==', user.uid), where('productId', '==', snap.id));
            const rSnap = await getDocsResilient(rQ);
            setHasReviewed(!rSnap.empty);
          }
        }
      } catch (error) {
        console.error("Product Detail Fetch Error:", error);
      } finally {
        setLoading(false);
      }
    };

    const fetchReviews = async () => {
      if (!id) return;
      try {
        const q = query(collection(db, 'reviews'), where('productId', '==', id), orderBy('createdAt', 'desc'));
        const snap = await getDocsResilient(q);
        setReviews(snap.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Review)));
      } catch (e) {
        console.warn("Could not fetch reviews resiliently:", e);
      }
    };

    fetchProduct();
    fetchReviews();
  }, [id, user]);

  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser");
      return;
    }
    setCalculatingLogistics(true);
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      setBuyerLocation(loc);
      await calculateDelivery(loc);
    }, (err) => {
      console.error(err);
      setCalculatingLogistics(false);
      alert("Please allow location access to calculate delivery fees.");
    });
  };

  const handleFollowToggle = async () => {
    if (!user || !product || user.uid === product.sellerId) return;
    setActionLoading(true);
    try {
      const myRef = doc(db, 'users', user.uid);
      const targetRef = doc(db, 'users', product.sellerId);

      if (isFollowing && followId) {
        await deleteDoc(doc(db, 'follows', followId));
        await updateDoc(myRef, { followingCount: increment(-1) });
        await updateDoc(targetRef, { followersCount: increment(-1) });
        setIsFollowing(false);
        setFollowId(null);
      } else {
        const newFollow = await addDoc(collection(db, 'follows'), {
          followerId: user.uid,
          followingId: product.sellerId,
          createdAt: serverTimestamp()
        });
        await updateDoc(myRef, { followingCount: increment(1) });
        await updateDoc(targetRef, { followersCount: increment(1) });
        setIsFollowing(true);
        setFollowId(newFollow.id);

        // Notify seller
        await sendNotification(
          product.sellerId,
          'follow',
          'New Follower!',
          `@${profile?.displayName || 'Someone'} started following you.`,
          `/profile/${user.uid}`
        );
      }
    } catch (error) {
      console.error("Follow error:", error);
    } finally {
      setActionLoading(false);
    }
  };

  const handleAddToWishlist = async () => {
    if (!user || !product) {
      navigate('/login');
      return;
    }

    setWishlisting(true);
    try {
      const productRef = doc(db, 'products', product.id);
      if (isInWishlist && wishlistId) {
        await deleteDoc(doc(db, 'wishlists', wishlistId));
        await updateDoc(productRef, { likesCount: increment(-1) });
        setProduct(prev => prev ? { ...prev, likesCount: Math.max(0, (prev.likesCount || 0) - 1) } : null);
        setIsInWishlist(false);
        setWishlistId(null);
      } else {
        const docRef = await addDoc(collection(db, 'wishlists'), {
          userId: user.uid,
          productId: product.id,
          productTitle: product.title,
          productImage: product.imageUrl,
          productPrice: product.price,
          createdAt: serverTimestamp()
        });
        await updateDoc(productRef, { likesCount: increment(1) });
        setProduct(prev => prev ? { ...prev, likesCount: (prev.likesCount || 0) + 1 } : null);
        setIsInWishlist(true);
        setWishlistId(docRef.id);
      }
    } catch (error) {
      console.error("Wishlist error:", error);
    } finally {
      setWishlisting(false);
    }
  };

  const calculateDelivery = async (loc: {lat: number, lng: number}) => {
    if (!product) return;
    setCalculatingLogistics(true);
    try {
      // Mock store location (Ramallah center) if not available
      const storeLoc = { lat: 31.9029, lng: 35.2062 }; 
      const result = await LogisticsService.calculateLogistics(storeLoc, loc, product.category);
      setLogisticsResult(result);
    } catch (error) {
      console.error("Logistics calculation failed:", error);
    } finally {
      setCalculatingLogistics(false);
    }
  };

  const handleBuy = async () => {
    if (!user || !product || !id) {
      navigate('/login');
      return;
    }

    // Direct Purchase System
    navigate(`/checkout?productId=${id}`, { 
      state: { 
        selectedAddOns: Object.entries(selectedAddOns)
          .filter(([_, qty]) => Number(qty) > 0)
          .map(([addonId, qty]) => {
            const addon = product.addOns?.find(a => a.id === addonId);
            return { id: addonId, name: addon?.name || '', price: addon?.price || 0, quantity: Number(qty) };
          }),
        selectedDrinks 
      } 
    });
  };

  const handleAddToCart = async () => {
    if (!user || !product || !id) {
      navigate('/login');
      return;
    }

    setAddingToCart(true);
    try {
      // Check if already in cart
      const q = query(
        collection(db, 'carts'),
        where('userId', '==', user.uid),
        where('productId', '==', id)
      );
      const snap = await getDocs(q);

      if (!snap.empty) {
        // Increment quantity
        const cartDocId = snap.docs[0].id;
        await updateDoc(doc(db, 'carts', cartDocId), {
          quantity: increment(1),
          selectedAddOns: Object.entries(selectedAddOns)
            .filter(([_, qty]) => Number(qty) > 0)
            .map(([id, qty]) => {
              const addon = product.addOns?.find(a => a.id === id);
              return { id, name: addon?.name || '', price: addon?.price || 0, quantity: Number(qty) };
            }),
          selectedDrinks
        });
      } else {
        // Add new item
        await addDoc(collection(db, 'carts'), {
          userId: user.uid,
          productId: id,
          sellerId: product.sellerId,
          sellerName: product.sellerName,
          title: product.title,
          price: product.price,
          imageUrl: product.imageUrl,
          quantity: 1,
          selectedAddOns: Object.entries(selectedAddOns)
            .filter(([_, qty]) => Number(qty) > 0)
            .map(([id, qty]) => {
              const addon = product.addOns?.find(a => a.id === id);
              return { id, name: addon?.name || '', price: addon?.price || 0, quantity: Number(qty) };
            }),
          selectedDrinks,
          createdAt: serverTimestamp()
        });
      }
      
      // Success feedback (maybe a toast or just quick navigation)
      navigate('/cart');
    } catch (error) {
      console.error("Error adding to cart:", error);
    } finally {
      setAddingToCart(false);
    }
  };

  const executePurchase = async () => {
    if (!user || !product || !id || !logisticsResult) return;
    if (buying) return;
    setBuying(true);
    setShowVerifyModal(false);
    const selectedAddOnsList = Object.entries(selectedAddOns)
      .filter(([_, qty]) => Number(qty) > 0)
      .map(([id, qty]) => {
        const addon = product.addOns?.find(a => a.id === id);
        return {
          id,
          name: addon?.name || '',
          price: addon?.price || 0,
          quantity: Number(qty)
        };
      });

    try {
      const idempotencyKey = `${user.uid}_${product.id}_${Date.now()}`;
      
      const orderId = await (OrderService as any).purchaseProduct(
        user.uid,
        product,
        product.sellerId,
        idempotencyKey,
        logisticsResult,
        selectedAddOnsList,
        selectedDrinks
      );
      
      // Auto-dispatch after purchase (in a real app this would be triggered by status change to ready_for_delivery)
      // For this intelligent system, we can dispatch as soon as it's created or wait for seller prep.
      // We will follow the flow: Seller prepares -> Ready -> Dispatch.

      // Local state update
      setProduct(prev => prev ? { ...prev, stockQuantity: (prev.stockQuantity || 0) - 1 } : null);

      // Async Notification
      sendNotification(
        product.sellerId,
        'sale',
        'New Sale!',
        `You just sold ${product.title}. Distance: ${logisticsResult.distanceKm.toFixed(1)}km.`,
        `/seller`
      ).catch(console.error);

      setShowSuccess(true);
    } catch (error: any) {
      console.error("Purchase error:", error);
      if (error.message === "OUT_OF_STOCK" || error.message.includes("OUT_OF_STOCK")) {
        alert(t('product_details.out_of_stock_alert'));
        setProduct(prev => prev ? { ...prev, stockQuantity: 0 } : null);
      } else if (error.message === "SELLER_NOT_VERIFIED") {
        alert(t('product_details.seller_not_verified_alert'));
      } else if (error.message === "BUYER_NOT_VERIFIED") {
        alert("يرجى تفعيل حسابك أولاً بالتحقق من الإيميل والجوال");
      } else {
        alert("Failed to place order: " + error.message);
      }
    } finally {
      setBuying(false);
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: product?.title || 'Check out this product',
      text: product?.description || 'I found this amazing deal on the marketplace!',
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          setShowShare(true);
        }
      }
    } else {
      setShowShare(true);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopying(true);
      setTimeout(() => setCopying(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const shareLinks = {
    whatsapp: `https://wa.me/?text=${encodeURIComponent(`${product?.title} - ${window.location.href}`)}`,
    twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(`Check out this ${product?.title}`)}&url=${encodeURIComponent(window.location.href)}`,
    telegram: `https://t.me/share/url?url=${encodeURIComponent(window.location.href)}&text=${encodeURIComponent(`Check out this ${product?.title}`)}`,
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !product || !id) return;
    setSubmittingReview(true);
    try {
      const reviewData = {
        productId: id,
        productTitle: product.title,
        sellerId: product.sellerId,
        userId: user.uid,
        userName: profile?.displayName || 'Anonymous User',
        rating: newReview.rating,
        comment: newReview.comment,
        createdAt: serverTimestamp()
      };
      const docRef = await addDoc(collection(db, 'reviews'), reviewData);
      
      // Update product reviews count
      await updateDoc(doc(db, 'products', id), {
        reviewsCount: increment(1)
      });

      // Update seller reviews count
      await updateDoc(doc(db, 'users', product.sellerId), {
        reviewsCount: increment(1)
      });
      if (product.sellerProfileExists) {
        await updateDoc(doc(db, 'sellerProfiles', product.sellerId), {
          reviewsCount: increment(1)
        });
      }

      // Notify seller about new review
      if (product.sellerId !== user.uid) {
        await addDoc(collection(db, 'notifications'), {
          userId: product.sellerId,
          type: 'comment',
          title: dir === 'rtl' ? 'تعليق جديد' : 'New Comment',
          message: dir === 'rtl' 
            ? `قام ${user.displayName || 'مستخدم'} بالتعليق على منتجك "${product.title}"`
            : `${user.displayName || 'A user'} commented on your product "${product.title}"`,
          link: `/product/${id}`,
          read: false,
          createdAt: serverTimestamp()
        });
      }

      setReviews([{ id: docRef.id, ...reviewData, createdAt: new Date() } as Review, ...reviews]);
      setProduct(prev => prev ? { ...prev, reviewsCount: (prev.reviewsCount || 0) + 1 } : null);
      setHasReviewed(true);
      setNewReview({ rating: 5, comment: '' });

      // Notify Seller
      await sendNotification(
        product.sellerId,
        'rating',
        'New Product Review!',
        `@${profile?.displayName || 'Someone'} left a ${newReview.rating}-star review for ${product.title}`,
        `/profile/${product.sellerId}?tab=reviews`
      );

      // Trigger Trust Curve Engine Update
      processReputationUpdate(product.sellerId);
    } catch (error) {
      console.error("Error submitting review:", error);
    } finally {
      setSubmittingReview(false);
    }
  };

  const sumRatings = Array.isArray(reviews) ? reviews.reduce((acc, r: any) => acc + (r.rating || 0), 0) : 0;
  const averageRating = reviews.length > 0 
    ? (sumRatings / reviews.length).toFixed(1)
    : null;

  const isFood = product.category === 'food';
  const isVegFruits = product.category === 'veg_fruits';
  const isElectronics = product.category === 'electronics';
  const isSupermarket = product.category === 'supermarket';

  if (loading) return <div className="h-screen bg-black flex items-center justify-center text-white font-black italic uppercase tracking-tighter">Scanning...</div>;
  if (!product) return <div className="h-screen bg-black flex items-center justify-center text-white">Product not found</div>;

  return (
    <div className="min-h-screen bg-black text-white pb-24 md:pb-24">
      {/* Mobile Header */}
      <div className="sticky top-0 z-20 bg-black/80 backdrop-blur-md p-4 flex items-center gap-4 border-b border-neutral-900">
        <button onClick={() => navigate(-1)} className="p-2 hover:bg-neutral-800 rounded-full transition-colors">
          <ChevronLeft size={24} />
        </button>
        <h1 className="font-bold truncate flex-1">{product.title}</h1>
        <button onClick={handleShare} className="p-2 hover:bg-neutral-800 rounded-full transition-colors">
          <Share2 size={20} />
        </button>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          {/* Visuals */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="rounded-[40px] overflow-hidden aspect-square md:aspect-auto md:h-[600px] border border-neutral-800 bg-neutral-900 flex items-center justify-center relative group"
          >
            {product.imageUrl ? (
              <img src={product.imageUrl} alt={product.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" referrerPolicy="no-referrer" />
            ) : (
              <ShoppingCart className="text-neutral-700" size={120} />
            )}
            
            {averageRating && (
              <div className="absolute top-6 left-6 bg-black/60 backdrop-blur-xl border border-white/10 px-4 py-2 rounded-2xl flex items-center gap-2 shadow-2xl">
                <Star size={16} fill="#FCD34D" className="text-amber-400" />
                <span className="font-black text-white">{averageRating}</span>
                <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">{reviews.length} Reviews</span>
              </div>
            )}
          </motion.div>

          {/* Content */}
          <div className="flex flex-col">
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <span className="bg-bento-accent/20 text-bento-accent px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase">
                  {t(`product_form.categories.${product.category}`)}
                </span>
                {(product.mealType || product.itemSubtype) && (
                  <span className="bg-white/5 text-neutral-400 px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase border border-white/5">
                    {product.itemSubtype 
                      ? (isVegFruits 
                          ? t(`product_form.type_${product.itemSubtype}`) 
                          : isSupermarket 
                            ? t(`product_form.type_${product.itemSubtype}`)
                            : t(`product_form.type_${product.itemSubtype}`)) 
                      : t(`product_form.meal_type_${product.mealType}`)}
                  </span>
                )}
                {isElectronics && product.deviceCondition && (
                  <span className="bg-emerald-500/10 text-emerald-500 px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase border border-emerald-500/20">
                    {t(`product_form.condition_${product.deviceCondition}`)}
                  </span>
                )}
                <span className={`px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase ${product.stockQuantity > 0 ? 'bg-neutral-800 text-neutral-400' : 'bg-red-500/20 text-red-500'}`}>
                  {product.stockQuantity > 0 
                    ? (isVegFruits 
                        ? `${product.stockQuantity} KG` 
                        : (isElectronics || isSupermarket)
                          ? `${t('product_form.available_stock')}: ${product.stockQuantity}`
                          : t('product_details.in_stock', { count: product.stockQuantity })) 
                    : t('product_details.out_of_stock')}
                </span>
                <span className="text-neutral-500 text-[10px] font-black uppercase tracking-widest">• {t('product_details.genuine')}</span>
              </div>
              <h2 className="text-5xl font-black italic tracking-tighter mb-4 leading-tight uppercase">{product.title}</h2>
              <div className="text-6xl font-black text-white mb-8 tracking-tighter">
                ${(product.price + Object.entries(selectedAddOns).reduce((sum, [id, qty]) => {
                  const addon = product.addOns?.find(a => a.id === id);
                  return sum + (addon?.price || 0) * Number(qty);
                }, 0)).toFixed(2)}
                {isVegFruits && <span className="text-2xl text-neutral-500 italic ml-2">/KG</span>}
              </div>

              {isFood && product.drinks && (
                <div className="mb-10 space-y-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-neutral-500 mb-4">{t('product_form.meal_drinks')}</h3>
                  <div className="grid grid-cols-1 gap-3">
                    {Array.isArray(product.drinks) ? (
                      product.drinks.map((drink, idx) => (
                        <label 
                          key={idx}
                          className={`p-4 rounded-3xl border transition-all flex items-center justify-between cursor-pointer ${
                            selectedDrinks.includes(drink) ? 'bg-bento-accent/10 border-bento-accent' : 'bg-neutral-900/50 border-neutral-800'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Zap size={18} className={selectedDrinks.includes(drink) ? 'text-bento-accent' : 'text-neutral-600'} />
                            <span className="font-black italic text-sm">{drink}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all ${
                              selectedDrinks.includes(drink) ? 'bg-bento-accent border-bento-accent' : 'bg-black/40 border-neutral-800'
                            }`}>
                              <input 
                                type="checkbox"
                                checked={selectedDrinks.includes(drink)}
                                onChange={() => {
                                  if (selectedDrinks.includes(drink)) {
                                    setSelectedDrinks(prev => prev.filter(d => d !== drink));
                                  } else {
                                    setSelectedDrinks(prev => [...prev, drink]);
                                  }
                                }}
                                className="hidden"
                              />
                              {selectedDrinks.includes(drink) && <Plus size={14} className="text-black" />}
                            </div>
                          </div>
                        </label>
                      ))
                    ) : (
                      /* Backward compatibility for string drinks */
                      product.drinks.split(',').map((drinkName, idx) => {
                        const drink = drinkName.trim();
                        if (!drink) return null;
                        return (
                          <label 
                            key={idx}
                            className={`p-4 rounded-3xl border transition-all flex items-center justify-between cursor-pointer ${
                              selectedDrinks.includes(drink) ? 'bg-bento-accent/10 border-bento-accent' : 'bg-neutral-900/50 border-neutral-800'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <Zap size={18} className={selectedDrinks.includes(drink) ? 'text-bento-accent' : 'text-neutral-600'} />
                              <span className="font-black italic text-sm">{drink}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <div className={`w-6 h-6 rounded-lg border flex items-center justify-center transition-all ${
                                selectedDrinks.includes(drink) ? 'bg-bento-accent border-bento-accent' : 'bg-black/40 border-neutral-800'
                              }`}>
                                <input 
                                  type="checkbox"
                                  checked={selectedDrinks.includes(drink)}
                                  onChange={() => {
                                    if (selectedDrinks.includes(drink)) {
                                      setSelectedDrinks(prev => prev.filter(d => d !== drink));
                                    } else {
                                      setSelectedDrinks(prev => [...prev, drink]);
                                    }
                                  }}
                                  className="hidden"
                                />
                                {selectedDrinks.includes(drink) && <Plus size={14} className="text-black" />}
                              </div>
                            </div>
                          </label>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* Add-ons Section - Only for Food category */}
              {product.category === 'food' && product.addOns && product.addOns.length > 0 && (
                <div className="mb-10 space-y-4">
                  <h3 className="text-xs font-black uppercase tracking-widest text-neutral-500 mb-4">{dir === 'rtl' ? 'إضافات الطعام' : 'Food Add-ons'}</h3>
                  <div className="grid grid-cols-1 gap-3">
                    {product.addOns.map((addon, index) => {
                      const qty = selectedAddOns[addon.id] || 0;
                      return (
                        <div 
                          key={`${addon.id}-${index}`} 
                          className={`p-4 rounded-3xl border transition-all flex items-center justify-between ${
                            qty > 0 ? 'bg-bento-accent/10 border-bento-accent' : 'bg-neutral-900/50 border-neutral-800'
                          }`}
                        >
                          <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                            <div className="font-black italic text-sm">{addon.name}</div>
                            <div className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">
                              {addon.price > 0 ? `+$${addon.price}` : (dir === 'rtl' ? 'مجاني' : 'Free')}
                              {addon.isMandatory && ` • ${dir === 'rtl' ? 'إجباري' : 'Mandatory'}`}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-3 bg-black/40 p-1.5 rounded-2xl border border-white/5">
                            <button 
                              onClick={() => setSelectedAddOns(prev => ({ ...prev, [addon.id]: Math.max(0, (prev[addon.id] || 0) - 1) }))}
                              className="w-8 h-8 flex items-center justify-center rounded-xl bg-neutral-800 text-white hover:bg-neutral-700 transition-colors"
                            >
                              <Minus size={14} />
                            </button>
                            <span className="text-xs font-black w-4 text-center">{qty}</span>
                            <button 
                              onClick={() => setSelectedAddOns(prev => ({ ...prev, [addon.id]: (prev[addon.id] || 0) + 1 }))}
                              className="w-8 h-8 flex items-center justify-center rounded-xl bg-white text-black hover:bg-bento-accent transition-colors"
                            >
                              <Plus size={14} />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
              
              <div className="flex items-center gap-3 p-4 bg-neutral-900/50 backdrop-blur-sm rounded-3xl border border-neutral-800 mb-8 hover:border-bento-accent/30 transition-all group">
                <Link to={`/profile/${product.sellerId}`} className="w-12 h-12 rounded-full bg-neutral-800 overflow-hidden border-2 border-transparent group-hover:border-bento-accent/50 transition-all">
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${product.sellerId}`} alt="seller" />
                </Link>
                <div className="flex-1">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <div className="text-[10px] font-black text-neutral-500 uppercase tracking-widest">
                      {product.sellerIsVerified ? t('product_details.verified_seller') : t('product_details.master_seller')}
                    </div>
                    {product.sellerIsVerified && <VerifiedBadge size={14} />}
                  </div>
                  {sellerReputation && (
                    <div className="flex items-center gap-2 mb-1">
                      <div className="flex items-center gap-1 bg-white/5 px-2 py-0.5 rounded-full border border-white/5">
                        <Star size={10} className="text-amber-500 fill-amber-500" />
                        <span className="text-[10px] font-black text-white">
                          {sellerReputation.rating && sellerReputation.rating > 0 
                            ? sellerReputation.rating.toFixed(1) 
                            : t('seller.no_ratings')}
                        </span>
                      </div>
                      {sellerReputation.trend && (
                        <div className={`flex items-center gap-1 px-2 py-0.5 rounded-full border ${
                          sellerReputation.trend === 'UP' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' :
                          sellerReputation.trend === 'DOWN' ? 'bg-red-500/10 border-red-500/20 text-red-500' :
                          'bg-amber-500/10 border-amber-500/20 text-amber-500'
                        }`}>
                          {sellerReputation.trend === 'UP' ? <ArrowUp size={8} /> :
                           sellerReputation.trend === 'DOWN' ? <ArrowDown size={8} /> : <Minus size={8} />}
                          <span className="text-[8px] font-black uppercase tracking-widest">{sellerReputation.trend}</span>
                        </div>
                      )}
                      {sellerReputation.trustStatus === 'RISK' && (
                        <div className="bg-orange-500/10 border border-orange-500/20 text-orange-500 px-2 py-0.5 rounded-full flex items-center gap-1">
                          <Zap size={8} />
                          <span className="text-[8px] font-black uppercase tracking-widest">{t('product_details.risk')}</span>
                        </div>
                      )}
                    </div>
                  )}
                  <Link to={`/profile/${product.sellerId}`} className="font-extrabold text-white text-lg hover:text-bento-accent transition-colors tracking-tight">@{product.sellerName}</Link>
                </div>
                {user?.uid !== product.sellerId && (
                  <button 
                    onClick={handleFollowToggle}
                    disabled={actionLoading}
                    className={`text-[10px] font-black px-5 py-2.5 rounded-2xl transition-all shadow-xl flex items-center gap-1.5 ${
                      isFollowing 
                      ? 'bg-neutral-800 text-white border border-neutral-700 hover:bg-red-500/10 hover:border-red-500' 
                      : 'bg-white text-black hover:bg-bento-accent'
                    }`}
                  >
                    {isFollowing ? (
                      <><UserMinus size={14} /> {t('product_details.following')}</>
                    ) : (
                      <><UserPlus size={14} /> {t('product_details.follow')}</>
                    )}
                  </button>
                )}
              </div>
              <p className="text-neutral-400 leading-relaxed text-lg font-medium mb-8">{product.description}</p>
              
              <div className="grid grid-cols-1 gap-4 mb-10">
                <div className="p-5 bg-neutral-900/50 rounded-3xl border border-neutral-800 flex items-start gap-4">
                  <div className="p-3 bg-bento-accent/10 rounded-2xl">
                    <MapPin size={20} className="text-bento-accent" />
                  </div>
                  <div>
                    <div className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-1">{t('product_form.delivery_area')}</div>
                    <div className="flex flex-wrap gap-1.5 mt-1">
                      {product.deliveryArea ? (
                        <span className="text-[9px] bg-white text-black px-3 py-1 rounded border border-white font-black uppercase tracking-widest">
                          {t(`product_form.area_${product.deliveryArea}`)}
                        </span>
                      ) : (
                        product.availableCountries?.map((c, i) => (
                          <span key={`${c}-${i}`} className="text-[9px] bg-white/5 text-neutral-400 px-2 py-0.5 rounded border border-white/5 font-bold uppercase">
                            {c}
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-auto space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-neutral-900/30 p-3 rounded-2xl border border-neutral-900 flex items-center justify-center gap-2">
                  <Truck size={14} className="text-bento-accent" />
                  <span className="text-[10px] font-black uppercase text-neutral-500">
                    {dir === 'rtl' ? 'مناديب معتمدين' : 'Verified Courier'}
                  </span>
                </div>
                <div className="bg-neutral-900/30 p-3 rounded-2xl border border-neutral-900 flex items-center justify-center gap-2">
                  <ShieldCheck size={14} className="text-bento-accent" />
                  <span className="text-[10px] font-black uppercase text-neutral-500">{t('product_details.secure_vault')}</span>
                </div>
                <div className="bg-neutral-900/30 p-3 rounded-2xl border border-neutral-900 flex items-center justify-center gap-2">
                  <RotateCcw size={14} className="text-bento-accent" />
                  <span className="text-[10px] font-black uppercase text-neutral-500">{t('product_details.return_policy')}</span>
                </div>
              </div>
              
              {/* Logistics Calculation Section */}
              <div className="p-6 bg-neutral-900 ring-1 ring-white/10 rounded-[32px] overflow-hidden">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Truck size={18} className="text-bento-accent" />
                    <h4 className="font-black italic uppercase tracking-tighter text-sm">{dir === 'rtl' ? 'حساب رسوم التوصيل' : 'Delivery Estimator'}</h4>
                  </div>
                  {logisticsResult && (
                    <div className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[9px] font-black uppercase text-emerald-500">
                      {dir === 'rtl' ? 'تم الحساب' : 'Calculated'}
                    </div>
                  )}
                </div>

                {!logisticsResult ? (
                  <button 
                    onClick={handleGetLocation}
                    disabled={calculatingLogistics}
                    className="w-full py-4 bg-white/5 border border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center gap-2 hover:bg-white/10 transition-all group"
                  >
                    {calculatingLogistics ? (
                      <Loader2 className="animate-spin text-bento-accent" />
                    ) : (
                      <>
                        <Navigation size={20} className="text-neutral-500 group-hover:text-white transition-colors" />
                        <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500 group-hover:text-white">
                          {dir === 'rtl' ? 'حدد موقعك لحساب الأجرة' : 'Pin location to see delivery fee'}
                        </span>
                      </>
                    )}
                  </button>
                ) : (
                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 bg-black/40 rounded-2xl border border-white/5 text-center">
                       <p className="text-[8px] font-black uppercase text-neutral-500 mb-1">{dir === 'rtl' ? 'المسافة' : 'Distance'}</p>
                       <p className="font-black italic text-sm">{logisticsResult.distanceKm.toFixed(1)} km</p>
                    </div>
                    <div className="p-3 bg-black/40 rounded-2xl border border-white/5 text-center">
                       <p className="text-[8px] font-black uppercase text-neutral-500 mb-1">{dir === 'rtl' ? 'الوقت' : 'Time'}</p>
                       <p className="font-black italic text-sm">{logisticsResult.estimatedTime} min</p>
                    </div>
                    <div className="p-3 bg-bento-accent/10 rounded-2xl border border-bento-accent/20 text-center">
                       <p className="text-[8px] font-black uppercase text-bento-accent mb-1">{dir === 'rtl' ? 'الأجرة' : 'Fee'}</p>
                       <p className="font-black italic text-sm text-bento-accent">ILS {logisticsResult.deliveryFee.toFixed(1)}</p>
                    </div>
                  </div>
                )}

                {logisticsResult && (
                  <button 
                    onClick={handleGetLocation}
                    className="w-full mt-4 py-2 text-[9px] font-black uppercase tracking-widest text-neutral-600 hover:text-white transition-colors"
                  >
                    {dir === 'rtl' ? 'إعادة تحديد الموقع' : 'Change Location'}
                  </button>
                )}
              </div>

              <div className="flex flex-col gap-4">
                <div className="flex gap-4">
                  <button 
                    onClick={handleAddToCart}
                    disabled={addingToCart || product.stockQuantity <= 0}
                    className="flex-1 bg-neutral-900 border border-neutral-800 text-white hover:bg-neutral-800 font-black text-lg py-5 rounded-[24px] transition-all flex items-center justify-center gap-3 disabled:opacity-50 uppercase tracking-tighter"
                  >
                    {addingToCart ? (
                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <ShoppingBasket size={24} className="text-bento-accent" />
                        {dir === 'rtl' ? 'إضافة للسلة' : 'Add to Cart'}
                      </>
                    )}
                  </button>

                  <button 
                    onClick={handleBuy}
                    disabled={buying || product.stockQuantity <= 0}
                    className="flex-1 bg-white text-black hover:bg-bento-accent font-black text-lg py-5 rounded-[24px] transition-all shadow-xl flex items-center justify-center gap-3 disabled:opacity-50 uppercase tracking-tighter"
                  >
                    {buying ? (
                        <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <>
                        <ShoppingCart size={24} />
                        {dir === 'rtl' ? 'شراء الآن' : 'Buy Now'}
                      </>
                    )}
                  </button>
                </div>
                
                <button 
                  onClick={handleAddToWishlist}
                  disabled={wishlisting}
                  className={`w-full border-2 py-4 rounded-[24px] transition-all flex items-center justify-center gap-3 font-black ${
                    isInWishlist 
                    ? 'bg-red-500/10 border-red-500 text-red-500 hover:bg-red-500 hover:text-white' 
                    : 'bg-transparent border-neutral-800 text-white hover:border-white'
                  }`}
                >
                  <Heart size={20} fill={isInWishlist ? "currentColor" : "none"} />
                  <span className="uppercase tracking-widest text-xs font-black">{isInWishlist ? t('product_details.saved') : t('product_details.wishlist')}</span>
                  <span className="text-neutral-400 font-bold text-xs ml-auto pr-4">{product.likesCount || 0}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="border-t border-neutral-900 pt-16">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <h2 className="text-4xl font-black italic tracking-tighter uppercase mb-2">{t('product_details.customer_feedback')}</h2>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star key={s} size={16} fill={s <= Math.round(Number(averageRating || 0)) ? "#FCD34D" : "none"} className={s <= Math.round(Number(averageRating || 0)) ? "text-amber-400" : "text-neutral-800"} />
                  ))}
                </div>
                <span className="text-neutral-500 font-bold text-sm uppercase tracking-widest">{t('product_details.verified_reviews', { count: reviews.length })}</span>
              </div>
            </div>
            
            {(hasOrdered && !hasReviewed) && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 px-6 py-3 rounded-2xl flex items-center gap-3">
                <CheckCircle size={18} className="text-emerald-500" />
                <span className="text-xs font-black text-emerald-400 uppercase tracking-widest">{t('product_details.verified_buyer_badge')}</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Review Form */}
            <div className="lg:col-span-1">
              {hasOrdered ? (
                hasReviewed ? (
                  <div className="bg-neutral-900 p-8 rounded-[30px] border border-neutral-800 text-center">
                    <MessageSquare size={40} className="text-neutral-700 mx-auto mb-4" />
                    <h4 className="text-xl font-black uppercase mb-2">{t('product_details.review_submitted')}</h4>
                    <p className="text-neutral-500 text-sm">{t('product_details.review_thank_you')}</p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmitReview} className="bg-neutral-900 p-8 rounded-[30px] border border-neutral-800">
                    <h4 className="text-xl font-black uppercase mb-6 tracking-tight">{t('product_details.write_review')}</h4>
                    <div className="space-y-6">
                      <div>
                        <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-3 block">{t('product_details.your_rating')}</label>
                        <div className="flex gap-2">
                          {[1, 2, 3, 4, 5].map((r) => (
                            <button
                              key={r}
                              type="button"
                              onClick={() => setNewReview({ ...newReview, rating: r })}
                              className="focus:outline-none transition-transform hover:scale-110"
                            >
                              <Star size={28} fill={r <= newReview.rating ? "#FCD34D" : "none"} className={r <= newReview.rating ? "text-amber-400" : "text-neutral-700"} />
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-3 block">{t('product_details.your_experience')}</label>
                        <textarea
                          required
                          value={newReview.comment}
                          onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                          className="w-full bg-black border border-neutral-800 rounded-2xl px-5 py-4 text-sm focus:border-bento-accent outline-none transition-all h-32 resize-none"
                          placeholder={t('product_details.experience_placeholder')}
                        />
                      </div>
                      <button
                        type="submit"
                        disabled={submittingReview}
                        className="w-full bg-bento-accent text-black font-black py-4 rounded-2xl hover:opacity-90 transition-all flex items-center justify-center gap-2 disabled:opacity-50 uppercase tracking-widest text-xs"
                      >
                        {submittingReview ? t('product_details.sending') : t('product_details.post_review')}
                      </button>
                    </div>
                  </form>
                )
              ) : (
                <div className="bg-neutral-900 p-8 rounded-[30px] border border-neutral-800">
                  <ShieldCheck size={32} className="text-neutral-700 mb-4" />
                  <h4 className="text-lg font-black uppercase mb-2 tracking-tight">{t('product_details.verified_reviews_only_title')}</h4>
                  <p className="text-neutral-500 text-sm leading-relaxed">{t('product_details.verified_reviews_only_desc')}</p>
                </div>
              )}
            </div>

            {/* Review List */}
            <div className="lg:col-span-2 space-y-6">
              {reviews.length === 0 ? (
                <div className="h-64 border border-dashed border-neutral-800 rounded-[30px] flex flex-col items-center justify-center text-neutral-600 italic">
                  <MessageSquare size={32} className="mb-3 opacity-20" />
                  <p>{t('product_details.be_first_reviewer')}</p>
                </div>
              ) : (
                reviews.map((review, idx) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    key={`${review.id}-${idx}`} 
                    className="bg-neutral-900/30 p-6 rounded-[30px] border border-neutral-900"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-neutral-800 overflow-hidden border border-neutral-700">
                          <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${review.userId}`} alt="user" />
                        </div>
                        <div>
                          <div className="text-sm font-bold">{review.userName}</div>
                          <div className="text-[10px] text-neutral-500 font-bold uppercase tracking-tighter">{t('product_details.verified_purchase')}</div>
                        </div>
                      </div>
                      <div className="flex gap-0.5">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star key={s} size={12} fill={s <= review.rating ? "#FCD34D" : "none"} className={s <= review.rating ? "text-amber-400" : "text-neutral-800"} />
                        ))}
                      </div>
                    </div>
                    <p className="text-neutral-300 text-sm leading-relaxed italic">"{review.comment}"</p>
                  </motion.div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {showVerifyModal && profile?.orderConfirmationMode && (
          <OrderVerificationModal 
            isOpen={showVerifyModal}
            onClose={() => setShowVerifyModal(false)}
            onVerified={executePurchase}
            mode={profile.orderConfirmationMode}
          />
        )}

        {showShare && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          >
            <motion.div 
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="bg-neutral-900 border border-neutral-800 p-8 rounded-t-[40px] sm:rounded-[40px] max-w-sm w-full text-center shadow-2xl relative"
            >
              <button 
                onClick={() => setShowShare(false)}
                className="absolute top-6 right-6 text-neutral-500 hover:text-white"
              >
                <ArrowRight className="rotate-45" size={24} />
              </button>

              <h3 className={`text-3xl font-black italic tracking-tighter mb-8 uppercase ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{t('product_details.share_product')}</h3>
              
              <div className="grid grid-cols-4 gap-4 mb-8">
                <a href={shareLinks.whatsapp} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Send className="text-emerald-500" size={24} />
                  </div>
                  <span className="text-[10px] font-black uppercase text-neutral-500 tracking-widest">WhatsApp</span>
                </a>
                <a href={shareLinks.twitter} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <TwitterIcon className="text-blue-500" size={24} />
                  </div>
                  <span className="text-[10px] font-black uppercase text-neutral-500 tracking-widest">Twitter</span>
                </a>
                <a href={shareLinks.telegram} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-2 group">
                  <div className="w-12 h-12 bg-sky-500/20 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Send className="text-sky-500" size={24} />
                  </div>
                  <span className="text-[10px] font-black uppercase text-neutral-500 tracking-widest">Telegram</span>
                </a>
                <button onClick={copyToClipboard} className="flex flex-col items-center gap-2 group">
                  <div className={`w-12 h-12 ${copying ? 'bg-emerald-500' : 'bg-neutral-800'} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-all`}>
                    <Copy className={copying ? 'text-black' : 'text-white'} size={24} />
                  </div>
                  <span className="text-[10px] font-black uppercase text-neutral-500 tracking-widest leading-tight">{copying ? t('product_details.copied') : t('product_details.copy_link')}</span>
                </button>
              </div>

              <div className="bg-black/50 p-4 rounded-2xl border border-neutral-800 flex items-center gap-3 overflow-hidden">
                <div className={`text-[10px] font-mono text-neutral-500 truncate flex-1 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{window.location.href}</div>
                <button 
                  onClick={copyToClipboard}
                  className="text-bento-accent font-black text-[10px] uppercase tracking-widest hover:underline shrink-0"
                >
                  {copying ? t('product_details.success') : t('product_details.copy')}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}

        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] max-w-sm w-full text-center shadow-2xl"
            >
              <div className="w-20 h-20 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle size={40} className="text-emerald-500" />
              </div>
              <h3 className="text-3xl font-black italic tracking-tighter mb-2 uppercase">{t('product_details.order_placed_title')}</h3>
              <p className="text-neutral-500 font-medium mb-8">{t('product_details.order_placed_desc')}</p>
              
              <button 
                onClick={() => navigate('/')}
                className="w-full bg-white text-black font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-neutral-200 transition-colors"
              >
                <span>{t('product_details.back_to_store')}</span>
                <ArrowRight size={20} />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
