import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Product, ProductAddOn } from '../types';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { useUpload } from '../context/UploadContext';
import { db, handleFirestoreError, collection, addDoc, doc, updateDoc, incrementResilient as increment, serverTimestampResilient as serverTimestamp } from '../lib/firebase';
import { Package, Upload, Plus, Target, Rocket, ShieldCheck, ChevronLeft, ArrowRight, Star, TrendingUp, Info, Ban, Globe, ShoppingBag, CheckCircle2, AlertCircle, Building2, Smartphone, Truck, Trash2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { uploadAndCompressImage } from '../lib/storage';
import { SELLER_TIERS, calculateSellerTier, getNextTier, canSellerUpload } from '../lib/commission';
import { CustomSelect } from '../components/CustomSelect';

export default function AddProduct() {
  const { user, profile } = useAuth();
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const navigate = useNavigate();
  const { startUpload, updateProgress, completeUpload, failUpload } = useUpload();
  
  const [uploading, setUploading] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const [newProduct, setNewProduct] = useState({
    title: '',
    description: '',
    price: '',
    stockQuantity: '1',
    category: '',
    originCountry: '-', // Placeholder since we are removing the field from UI
    availableCountries: '',
    shippingMethod: 'delivery_agent' as const,
    mealType: 'regular',
    itemSubtype: 'vegetables', // Default for veg_fruits
    drinks: [] as string[],
    deliveryArea: 'gaza' as const,
    deviceCondition: 'new' as const,
    addOns: [] as ProductAddOn[]
  });

  // Auto-categorize based on seller store category
  useEffect(() => {
    if (profile?.sellerProfile?.category) {
      setNewProduct(prev => ({ 
        ...prev, 
        category: profile.sellerProfile.category,
        deliveryArea: 'gaza' as const // Ensure default delivery area
      }));
    }
  }, [profile]);

  const isFood = newProduct.category === 'food';
  const isVegFruits = newProduct.category === 'veg_fruits';
  const isElectronics = newProduct.category === 'electronics';
  const isSupermarket = newProduct.category === 'supermarket';

  // Reset category-specific fields if category changes
  useEffect(() => {
    if (newProduct.category !== 'food') {
      setNewProduct(prev => ({ 
        ...prev, 
        addOns: [], 
        drinks: [], 
        mealType: 'regular' 
      }));
    }
    if (newProduct.category !== 'veg_fruits' && newProduct.category !== 'electronics' && newProduct.category !== 'supermarket') {
      setNewProduct(prev => ({ 
        ...prev, 
        itemSubtype: 'vegetables' 
      }));
    }
    if (newProduct.category === 'electronics') {
      setNewProduct(prev => ({ 
        ...prev, 
        itemSubtype: prev.itemSubtype || 'phone'
      }));
    }
    if (newProduct.category === 'supermarket') {
      setNewProduct(prev => ({ 
        ...prev, 
        itemSubtype: prev.itemSubtype || 'groceries'
      }));
    }
    if (newProduct.category !== 'electronics') {
      setNewProduct(prev => ({ 
        ...prev, 
        deviceCondition: 'new' as const
      }));
    }
  }, [newProduct.category]);

  const [currentAddOn, setCurrentAddOn] = useState({
    name: '',
    price: '',
    isMandatory: false
  });

  const [showAddOnEmptyError, setShowAddOnEmptyError] = useState(false);

  const addAddOn = () => {
    if (!currentAddOn.name) {
      setShowAddOnEmptyError(true);
      setTimeout(() => setShowAddOnEmptyError(false), 2000);
      return;
    }
    const addOn: ProductAddOn = {
      id: Date.now() + Math.random().toString(36).substr(2, 9),
      name: currentAddOn.name,
      price: parseFloat(currentAddOn.price) || 0,
      isMandatory: currentAddOn.isMandatory
    };
    setNewProduct(prev => ({
      ...prev,
      addOns: [...prev.addOns, addOn]
    }));
    setCurrentAddOn({ name: '', price: '', isMandatory: false });
    setShowAddOnEmptyError(false);
  };

  const removeAddOn = (id: string) => {
    setNewProduct(prev => ({
      ...prev,
      addOns: prev.addOns.filter(a => a.id !== id)
    }));
  };

  const sellerRating = profile?.sellerProfile?.rating ?? 0;
  const reviewsCount = profile?.reviewsCount || 0;
  const currentTier = calculateSellerTier(profile?.salesCount || 0, profile?.totalEarnings || 0, sellerRating || 5.0);
  const nextTierData = getNextTier(profile?.salesCount || 0, profile?.totalEarnings || 0, sellerRating || 5.0);

  const { canUpload: ratingAllowsUpload, reason: restrictionReason } = canSellerUpload(sellerRating || 5.0);
  const canUpload = profile?.sellerProfileExists && profile?.isVerified && (profile.currentProducts < currentTier.maxProducts) && ratingAllowsUpload;

  const [drinkInput, setDrinkInput] = useState('');

  const addDrink = () => {
    if (drinkInput.trim()) {
      setNewProduct(prev => ({
        ...prev,
        drinks: [...prev.drinks, drinkInput.trim()]
      }));
      setDrinkInput('');
    }
  };

  const removeDrink = (index: number) => {
    setNewProduct(prev => ({
      ...prev,
      drinks: prev.drinks.filter((_, i) => i !== index)
    }));
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;

    if (!profile.sellerProfileExists) {
      alert(t('seller.create_store_first'));
      navigate('/setup-store');
      return;
    }

    if (!profile.isVerified) {
      alert(t('seller.verification_needed_desc'));
      navigate('/verification');
      return;
    }

    if (!ratingAllowsUpload) {
      alert(t(restrictionReason || 'seller.rating_too_low', { rating: sellerRating.toFixed(1) }));
      return;
    }

    if (profile.currentProducts >= (currentTier.maxProducts)) {
      alert(t('seller.max_products_error', { count: currentTier.maxProducts }));
      return;
    }

    if (selectedFiles.length === 0) {
      alert(t('product_form.image_required'));
      return;
    }

    // Start background process
    const uploadId = `upload_${Date.now()}`;
    const filesToUpload = [...selectedFiles]; // Capture the files
    const productInfo = { ...newProduct }; // Capture product details
    
    startUpload(uploadId);
    
    // Navigate home immediately
    navigate('/');

    // Move logic to background execution
    (async () => {
      try {
        console.log('Starting background images upload...');
        
        const imageUrls: string[] = [];
        for (let i = 0; i < filesToUpload.length; i++) {
          const file = filesToUpload[i];
          
          const url = await uploadAndCompressImage(file, {
            maxSizeMB: 2,
            path: `products/${user.uid}`,
            onProgress: (p) => {
              const totalProgress = ((i * 100) + p) / filesToUpload.length;
              updateProgress(uploadId, totalProgress);
            }
          });
          imageUrls.push(url);
        }
        
        const imageUrl = imageUrls[0];

        const productData = {
          ...productInfo,
          price: parseFloat(productInfo.price),
          stockQuantity: parseFloat(productInfo.stockQuantity),
          addOns: productInfo.addOns,
          deliveryArea: productInfo.deliveryArea,
          imageUrl,
          imageUrls,
          sellerId: user.uid,
          sellerName: profile.sellerProfileExists ? (profile.sellerProfile?.displayName || profile.displayName) : profile.displayName,
          sellerIsVerified: profile.isVerified,
          sellerType: profile.sellerProfile?.type || 'seller',
          sellerProfileId: profile.sellerProfileExists ? user.uid : null,
          isArchived: false,
          isPinned: false,
          orderIndex: Date.now(),
          createdAt: serverTimestamp()
        };

        console.log('Background Saving to Firestore...');
        await addDoc(collection(db, 'products'), productData);

        console.log('Background Updating product count...');
        await updateDoc(doc(db, 'users', user.uid), {
          currentProducts: increment(1)
        });

        console.log('Background Product added successfully!');
        completeUpload(uploadId);
      } catch (error: any) {
        console.error('Background AddProduct error:', error);
        failUpload(uploadId, error.message || (dir === 'rtl' ? 'فشل النشر' : 'Publish failed'));
      }
    })();
  };

  return (
    <div className="min-h-screen bg-bento-bg text-white pb-32 pt-20 md:pt-28" dir={dir}>
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className={`flex items-center gap-4 mb-10 ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'flex-row text-left'}`}>
          <button onClick={() => navigate(-1)} className="p-3 bg-neutral-900 border border-neutral-800 rounded-2xl hover:bg-neutral-800 transition-colors">
            {dir === 'rtl' ? <ArrowRight className="rotate-180" size={20} /> : <ChevronLeft size={20} />}
          </button>
          <div>
            <h1 className="text-3xl font-black italic tracking-tighter uppercase">{t('seller.add_new')}</h1>
            <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest mt-1">{t('seller.be_seller_desc')}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Eligibility Info Header */}
          <div className="lg:col-span-3">
             <div className="bg-neutral-900 border border-neutral-800 rounded-[32px] p-6 flex flex-wrap items-center justify-between gap-6 relative overflow-hidden shadow-xl">
                <div className="absolute top-0 right-0 w-32 h-32 bg-bento-accent/5 blur-3xl"></div>
                <div className={`flex items-center gap-6 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                   <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${canUpload ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'}`}>
                      {canUpload ? <Rocket size={32} /> : <Ban size={32} />}
                   </div>
                   <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                      <div className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-1">{t('seller.eligibility')}</div>
                      <h2 className="text-xl font-black italic tracking-tighter uppercase">
                        {profile?.sellerProfileExists 
                          ? (canUpload ? t('seller.eligible') : t('seller.not_eligible'))
                          : t('seller.create_store_first')}
                      </h2>
                   </div>
                </div>

                <div className={`flex gap-8 flex-wrap ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                   <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                      <div className="text-[10px] font-black text-neutral-500 uppercase tracking-widest mb-1">{t('seller_dashboard.count')}</div>
                      <div className="text-lg font-black italic tracking-tighter">{profile?.currentProducts || 0} / {currentTier.maxProducts} {t('seller.stock')}</div>
                   </div>
                </div>
                
                {!profile?.sellerProfileExists && (
                  <button 
                    onClick={() => navigate('/setup-store')}
                    className="bg-bento-accent text-black px-8 py-3 rounded-xl font-black uppercase tracking-widest text-[10px] hover:scale-105 transition-all shadow-lg shadow-bento-accent/20"
                  >
                    {t('seller.create_store_now')}
                  </button>
                )}
             </div>
          </div>

          {/* Main Form */}
          <div className="lg:col-span-2 space-y-10">
            <form onSubmit={handleAddProduct} className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 md:p-12 shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 right-0 w-64 h-64 bg-bento-accent/5 blur-[100px] pointer-events-none"></div>
               
               <div className="grid grid-cols-1 md:grid-cols-2 gap-8 relative z-10">
                  <div className="md:col-span-2">
                    <div className={`flex items-center justify-between mb-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                      <label className="text-[10px] text-neutral-500 uppercase tracking-widest font-black block">{t('product_form.image_label')}</label>
                      <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">{t('product_form.single_image_limit')}</span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {selectedFiles.length > 0 ? (
                        <div className="aspect-square rounded-3xl border border-neutral-800 bg-black/40 relative overflow-hidden group">
                          <img src={URL.createObjectURL(selectedFiles[0])} alt="" className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                          <button 
                            type="button"
                            onClick={() => setSelectedFiles([])}
                            className="absolute top-4 right-4 p-2 bg-red-600 rounded-full text-white shadow-xl hover:scale-110 transition-transform"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      ) : (
                        <button 
                          type="button"
                          onClick={() => document.getElementById('product-image-upload')?.click()}
                          className="aspect-square rounded-[40px] border-2 border-dashed border-neutral-800 hover:border-bento-accent bg-black/20 flex flex-col items-center justify-center gap-4 transition-all group overflow-hidden"
                        >
                          <div className="w-16 h-16 rounded-2xl bg-neutral-900 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <Upload className="text-neutral-500 group-hover:text-bento-accent" size={28} />
                          </div>
                          <div className="text-center px-6">
                            <span className="text-xs font-black uppercase tracking-widest text-neutral-400 block mb-1">{t('product_form.image_placeholder')}</span>
                            <span className="text-[9px] font-bold text-neutral-600 uppercase tracking-tighter block">{t('product_form.image_size_warning')}</span>
                          </div>
                        </button>
                      )}
                    </div>
                    <input 
                      id="product-image-upload"
                      type="file" 
                      accept="image/*"
                      className="hidden"
                      onChange={e => {
                        const files = Array.from(e.target.files || []) as File[];
                        if (files.length > 0) {
                          const file = files[0];
                          const maxSize = 2 * 1024 * 1024; // 2MB
                          if (file.size > maxSize) {
                            const errorMsg = dir === 'rtl' 
                              ? 'حجم الصورة كبير جداً (أكبر من 2 ميجابايت). يرجى اختيار صورة أصغر.' 
                              : 'Image size is too large (exceeds 2MB). Please select a smaller image.';
                            alert(errorMsg);
                            setErrorMessage(errorMsg);
                            e.target.value = ''; // Reset input
                            setSelectedFiles([]);
                            return;
                          }
                          setErrorMessage(null);
                          setSelectedFiles([file]);
                        }
                      }}
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      {isFood ? t('product_form.meal_name') : isVegFruits ? t('product_form.item_name') : isElectronics ? t('product_form.device_name') : isSupermarket ? t('product_form.supermarket_item_name') : t('product_form.title_label')}
                    </label>
                    <input 
                      type="text"
                      required
                      placeholder={isFood ? t('product_form.meal_name') : isVegFruits ? t('product_form.item_name') : isElectronics ? t('product_form.device_name') : isSupermarket ? t('product_form.supermarket_item_name') : t('product_form.title_placeholder')}
                      value={newProduct.title}
                      onChange={e => setNewProduct({...newProduct, title: e.target.value})}
                      className="w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 text-sm focus:border-bento-accent outline-none transition-all"
                    />
                  </div>

                  {isFood && (
                    <div className="md:col-span-2">
                      <CustomSelect 
                        value={newProduct.mealType || 'regular'}
                        onChange={(val) => setNewProduct({...newProduct, mealType: val})}
                        options={[
                          { id: 'sandwich', label: t('product_form.meal_type_sandwich') },
                          { id: 'regular', label: t('product_form.meal_type_regular') }
                        ]}
                        placeholder={t('product_form.meal_type')}
                        label={t('product_form.meal_type')}
                      />
                    </div>
                  )}

                  {isVegFruits && (
                    <div className="md:col-span-2">
                      <CustomSelect 
                        value={newProduct.itemSubtype || 'vegetables'}
                        onChange={(val) => setNewProduct({...newProduct, itemSubtype: val})}
                        options={[
                          { id: 'vegetables', label: t('product_form.type_vegetables') },
                          { id: 'fruits', label: t('product_form.type_fruits') }
                        ]}
                        placeholder={t('product_form.item_type')}
                        label={t('product_form.item_type')}
                      />
                    </div>
                  )}

                  {isElectronics && (
                    <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <CustomSelect 
                        value={newProduct.itemSubtype || 'phone'}
                        onChange={(val) => setNewProduct({...newProduct, itemSubtype: val})}
                        options={[
                          { id: 'pc', label: t('product_form.type_pc') },
                          { id: 'laptop', label: t('product_form.type_laptop') },
                          { id: 'phone', label: t('product_form.type_phone') },
                          { id: 'accessories', label: t('product_form.type_accessories') }
                        ]}
                        placeholder={t('product_form.device_type')}
                        label={t('product_form.device_type')}
                      />
                      <CustomSelect 
                        value={newProduct.deviceCondition || 'new'}
                        onChange={(val) => setNewProduct({...newProduct, deviceCondition: val as any})}
                        options={[
                          { id: 'new', label: t('product_form.condition_new') },
                          { id: 'used', label: t('product_form.condition_used') }
                        ]}
                        placeholder={t('product_form.device_condition')}
                        label={t('product_form.device_condition')}
                      />
                    </div>
                  )}

                  {isSupermarket && (
                    <div className="md:col-span-2">
                      <CustomSelect 
                        value={newProduct.itemSubtype || 'groceries'}
                        onChange={(val) => setNewProduct({...newProduct, itemSubtype: val})}
                        options={[
                          { id: 'groceries', label: t('product_form.type_groceries') },
                          { id: 'snacks', label: t('product_form.type_snacks') }
                        ]}
                        placeholder={t('product_form.supermarket_item_type')}
                        label={t('product_form.supermarket_item_type')}
                      />
                    </div>
                  )}

                  {/* Hidden category display to inform user */}
                  <div className="md:col-span-2">
                     <div className="p-4 bg-white/5 rounded-2xl border border-white/5 flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase text-neutral-500">{t('product_form.category_label')}</span>
                        <span className="text-xs font-bold text-bento-accent uppercase tracking-widest italic">{newProduct.category ? t(`product_form.categories.${newProduct.category}`) : t('common.loading')}</span>
                     </div>
                  </div>

                  <div>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      {isVegFruits ? t('product_form.price_per_kg') : t('product_form.price_label')}
                    </label>
                    <div className="relative">
                      <input 
                        type="number" 
                        step="0.01"
                        value={newProduct.price}
                        onChange={e => setNewProduct({...newProduct, price: e.target.value})}
                        className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                        placeholder="0.00"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      {isFood ? t('product_form.meal_count') : isVegFruits ? t('product_form.stock_kg') : (isElectronics || isSupermarket) ? t('product_form.available_stock') : t('product_form.stock_label')}
                    </label>
                    <input 
                      type="number" 
                      step={isVegFruits ? "0.1" : "1"}
                      value={newProduct.stockQuantity}
                      onChange={e => setNewProduct({...newProduct, stockQuantity: e.target.value})}
                      className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                      placeholder="1"
                      min="1"
                      required
                    />
                  </div>

                  <div className="md:col-span-2">
                    <CustomSelect 
                      value={newProduct.deliveryArea || 'gaza'}
                      onChange={(val) => setNewProduct({...newProduct, deliveryArea: val as any})}
                      options={[
                        { id: 'north_gaza', label: t('product_form.area_north_gaza') },
                        { id: 'gaza', label: t('product_form.area_gaza') },
                        { id: 'both', label: t('product_form.area_both') }
                      ]}
                      placeholder={t('product_form.delivery_area')}
                      label={t('product_form.delivery_area')}
                    />
                  </div>

                  <div className="md:col-span-2">
                    <div className="bg-blue-500/5 border border-blue-500/10 rounded-[30px] p-8 flex flex-col md:flex-row items-center gap-6 relative overflow-hidden">
                       <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 blur-3xl pointer-events-none"></div>
                       <div className="w-16 h-16 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500 shrink-0">
                          <Truck size={32} />
                       </div>
                       <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                          <h3 className="text-xl font-black italic tracking-tighter uppercase mb-1">
                             {dir === 'rtl' ? 'توصيل عبر مناديب المنصة' : 'Delivery via Platform Couriers'}
                          </h3>
                          <p className="text-xs text-neutral-500 font-bold uppercase tracking-widest leading-relaxed">
                             {dir === 'rtl' 
                               ? 'سيتم توصيل هذا المنتج حصراً عبر مناديب التوصيل المعتمدين والمقبولين في منصتنا لضمان الأمان والسرعة.' 
                               : 'This product will be delivered exclusively via verified and approved platform couriers to ensure safety and speed.'}
                          </p>
                       </div>
                    </div>
                  </div>

                  {/* Food Add-ons Section - Only visible for Food category sellers */}
                  {(profile?.sellerProfile?.category === 'food' || newProduct.category === 'food') && (
                    <div className="md:col-span-2 border-t border-white/5 pt-8 mt-4">
                      <div className={`flex items-center justify-between mb-6 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                        <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                          <h3 className="text-xl font-black italic tracking-tighter uppercase">
                            {isFood ? t('product_form.meal_additions') : (dir === 'rtl' ? 'إضافات المنتج' : 'Product Add-ons')}
                          </h3>
                          <p className="text-[10px] text-neutral-500 font-bold uppercase tracking-widest">
                            {isFood ? t('product_form.meal_additions_desc', 'أضف خيارات إضافية للوجبة') : (dir === 'rtl' ? 'أضف خيارات إضافية للمشتري لمنتجك' : 'Add extra options for buyers for your product')}
                          </p>
                        </div>
                        <button 
                          type="button"
                          onClick={() => {
                            if (currentAddOn.name) {
                              addAddOn();
                            } else {
                              setShowAddOnEmptyError(true);
                              setTimeout(() => setShowAddOnEmptyError(false), 2000);
                            }
                          }}
                          className={`p-3 rounded-2xl border transition-all active:scale-95 ${showAddOnEmptyError ? 'bg-red-500/20 text-red-500 border-red-500/30' : 'bg-white/5 text-bento-accent border-white/5 hover:bg-white/10'}`}
                        >
                          <Plus size={20} />
                        </button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div className="md:col-span-1">
                          <label className={`text-[9px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{dir === 'rtl' ? 'اسم الإضافة' : 'Add-on Name'}</label>
                          <input 
                            type="text" 
                            value={currentAddOn.name}
                            onChange={e => {
                                setCurrentAddOn({...currentAddOn, name: e.target.value});
                                if (showAddOnEmptyError) setShowAddOnEmptyError(false);
                            }}
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                addAddOn();
                              }
                            }}
                            className={`w-full bg-black/40 border rounded-xl px-4 py-3 focus:border-bento-accent outline-none text-xs font-bold transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'} ${showAddOnEmptyError ? 'border-red-500/50' : 'border-neutral-800'}`}
                            placeholder={dir === 'rtl' ? 'مثلاً: جبنة إضافية' : 'e.g. Extra Cheese'}
                          />
                        </div>
                        <div>
                          <label className={`text-[9px] text-neutral-500 uppercase tracking-widest font-black mb-2 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>{dir === 'rtl' ? 'السعر (اختياري)' : 'Price (Optional)'}</label>
                          <input 
                            type="number" 
                            value={currentAddOn.price}
                            onChange={e => setCurrentAddOn({...currentAddOn, price: e.target.value})}
                            className={`w-full bg-black/40 border border-neutral-800 rounded-xl px-4 py-3 focus:border-bento-accent outline-none text-xs font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                            placeholder="0.00"
                          />
                        </div>
                        <div className="flex items-end gap-3">
                          <button 
                            type="button"
                            onClick={() => setCurrentAddOn({...currentAddOn, isMandatory: !currentAddOn.isMandatory})}
                            className={`flex-1 py-3 px-4 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all ${currentAddOn.isMandatory ? 'bg-bento-accent text-black border-bento-accent' : 'bg-black/40 border-neutral-800 text-neutral-500'}`}
                          >
                            {currentAddOn.isMandatory ? (dir === 'rtl' ? 'إجباري' : 'Mandatory') : (dir === 'rtl' ? 'اختياري' : 'Optional')}
                          </button>
                          <button 
                            type="button"
                            onClick={addAddOn}
                            className={`p-3 rounded-xl transition-all active:scale-95 ${showAddOnEmptyError ? 'bg-red-500 text-white' : 'bg-white text-black hover:bg-bento-accent'}`}
                          >
                            <Plus size={18} />
                          </button>
                        </div>
                      </div>

                      {/* Add-ons List */}
                      <div className="space-y-2">
                        {newProduct.addOns.map((addon, index) => (
                          <div key={`${addon.id || index}-${index}`} className={`flex items-center justify-between p-4 bg-black/20 border border-white/5 rounded-2xl group ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                            <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                              <div className="w-8 h-8 rounded-lg bg-bento-accent/10 flex items-center justify-center text-bento-accent">
                                <ShoppingBag size={14} />
                              </div>
                              <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
                                <div className="text-sm font-black italic">{addon.name}</div>
                                <div className="text-[9px] font-bold text-neutral-500 uppercase tracking-widest">
                                  {addon.price > 0 ? `+$${addon.price}` : (dir === 'rtl' ? 'مجاني' : 'Free')} • {addon.isMandatory ? (dir === 'rtl' ? 'إجباري' : 'Mandatory') : (dir === 'rtl' ? 'اختياري' : 'Optional')}
                                </div>
                              </div>
                            </div>
                            <button 
                              type="button"
                              onClick={() => removeAddOn(addon.id)}
                              className="p-2 text-neutral-600 hover:text-red-500 transition-colors"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="md:col-span-2">
                    <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                      {isFood ? t('product_form.meal_description') : isVegFruits ? t('product_form.item_description') : isElectronics ? t('product_form.device_description') : isSupermarket ? t('product_form.supermarket_description') : t('product_form.desc_label')}
                    </label>
                    <textarea 
                      value={newProduct.description}
                      onChange={e => setNewProduct({...newProduct, description: e.target.value})}
                      className={`w-full bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold h-32 resize-none ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                      placeholder={isFood ? t('product_form.meal_description') : isVegFruits ? t('product_form.item_description') : isElectronics ? t('product_form.device_description') : isSupermarket ? t('product_form.supermarket_description') : t('product_form.desc_placeholder')}
                      required
                    />
                  </div>

                  {isFood && (
                    <div className="md:col-span-2">
                      <label className={`text-[10px] text-neutral-500 uppercase tracking-widest font-black mb-3 block ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                        {t('product_form.meal_drinks')}
                      </label>
                      <div className="flex gap-2 mb-4">
                        <input 
                          type="text" 
                          value={drinkInput}
                          onChange={e => setDrinkInput(e.target.value)}
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addDrink();
                            }
                          }}
                          className={`flex-1 bg-black/40 border border-neutral-800 rounded-2xl px-6 py-4 focus:border-bento-accent outline-none transition-all font-bold ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                          placeholder={dir === 'rtl' ? 'أضف مشروب (مثلاً: كوكاكولا)' : 'Add drink (e.g. Coca-Cola)'}
                        />
                        <button 
                          type="button" 
                          onClick={addDrink}
                          className="bg-bento-accent text-black px-6 rounded-2xl font-black uppercase tracking-widest text-[10px]"
                        >
                          {t('common.add') || (dir === 'rtl' ? 'إضافة' : 'Add')}
                        </button>
                      </div>
                      
                      <div className="flex flex-wrap gap-2">
                        {newProduct.drinks.map((drink, idx) => (
                          <div key={idx} className="bg-neutral-800 px-4 py-2 rounded-xl flex items-center gap-2 border border-white/5">
                            <span className="text-sm font-black italic">{drink}</span>
                            <button 
                              type="button" 
                              onClick={() => removeDrink(idx)}
                              className="text-neutral-500 hover:text-red-500"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        ))}
                        {newProduct.drinks.length === 0 && (
                          <p className="text-[10px] text-neutral-500 italic uppercase tracking-widest">
                            {dir === 'rtl' ? 'لم يتم إضافة مشروبات حتى الآن' : 'No drinks added yet'}
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  <button 
                    type="submit"
                    className="md:col-span-2 bg-white text-black py-5 rounded-[24px] font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-bento-accent transition-all text-sm shadow-xl"
                  >
                    <Plus size={20} /> {t('seller.publish_now')}
                  </button>

                  <AnimatePresence>
                    {errorMessage && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="md:col-span-2 p-4 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center gap-3 text-red-500 text-xs font-bold"
                      >
                        <AlertCircle size={16} />
                        {errorMessage}
                      </motion.div>
                    )}
                  </AnimatePresence>
               </div>
            </form>

            {/* Seller Performance - Hidden for now */}
          </div>

          {/* Motivation Sidebar */}
          <div className="space-y-6">
            {/* Current Status */}
            <div className="bg-neutral-900 border border-neutral-800 rounded-[32px] p-8 relative overflow-hidden">
               <div className="absolute -top-10 -right-10 w-32 h-32 bg-bento-accent/10 blur-3xl rounded-full"></div>
               <h3 className={`text-xs font-black uppercase tracking-widest text-neutral-500 mb-6 flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                 <Target size={14} className="text-bento-accent" /> {t('seller.status')}
               </h3>
               
               <div className={`space-y-4 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                  <div className={`flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <Star size={16} className="text-amber-500 fill-amber-500" />
                    <span className="text-sm font-black italic">
                      {t('seller.product_rating')}: {reviewsCount > 0 ? sellerRating.toFixed(1) : t('seller.no_ratings')}
                    </span>
                  </div>
                  <div className={`flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <Package size={16} className="text-bento-accent" />
                    <span className="text-sm font-black italic">{profile?.currentProducts || 0} / {currentTier.maxProducts} {t('seller.stock')}</span>
                  </div>
               </div>
            </div>

            {/* Why increase listings? */}
            <div className={`bg-gradient-to-br from-bento-accent/20 to-transparent border border-bento-accent/20 rounded-[32px] p-8 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
              <h3 className={`font-black italic text-lg mb-4 flex items-center gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <Rocket size={18} className="text-bento-accent" /> {t('seller.why_increase') || "Why increase?"}
              </h3>
              <ul className="space-y-4">
                {[
                  t('seller.why_benefit1') || "Increase sales opportunities",
                  // t('seller.why_benefit2') || "Lower commission at 50 sales",
                  t('seller.why_benefit3') || "Priority technical support",
                  t('seller.why_benefit4') || "Attract more followers"
                ].filter(Boolean).map((text, i) => (
                  <li key={i} className={`flex gap-3 text-xs font-medium text-neutral-300 leading-relaxed ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                    <div className="shrink-0 w-5 h-5 bg-bento-accent/10 rounded-lg flex items-center justify-center text-bento-accent font-black text-[10px]">{i+1}</div>
                    {text}
                  </li>
                ))}
              </ul>
            </div>

            {/* Trust Badges */}
            <div className="grid grid-cols-2 gap-4">
               <div className="bg-neutral-900 border border-neutral-800 p-5 rounded-3xl text-center">
                  <ShieldCheck size={24} className="mx-auto mb-2 text-emerald-500" />
                  <span className="text-[8px] font-black uppercase tracking-widest text-neutral-400">{t('seller.verified')}</span>
               </div>
               <div className="bg-neutral-900 border border-neutral-800 p-5 rounded-3xl text-center">
                  <TrendingUp size={24} className="mx-auto mb-2 text-blue-500" />
                  <span className="text-[8px] font-black uppercase tracking-widest text-neutral-400">{t('seller.performance')}</span>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
