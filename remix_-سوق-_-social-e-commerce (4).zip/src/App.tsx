import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LanguageProvider } from './context/LanguageContext';
import { UploadProvider } from './context/UploadContext';
import { ErrorBoundary } from './components/ErrorBoundary';
import { GlobalProgressBar } from './components/GlobalProgressBar';
import Home from './pages/Home';
import Login from './pages/Login';
import SellerDashboard from './pages/SellerDashboard';
import AdminPanel from './pages/AdminPanel';
import Navbar from './components/Navbar';
import DeliveredOrderGuard from './components/DeliveredOrderGuard';
import UserStatusGuard from './components/UserStatusGuard';
import ProductDetails from './pages/ProductDetails';
import Profile from './pages/Profile';
import Explore from './pages/Explore';
import Notifications from './pages/Notifications';
import Orders from './pages/Orders';
import AddProduct from './pages/AddProduct';
import Settings from './pages/Settings';
import SetupStore from './pages/SetupStore';
import Verification from './pages/Verification';
import CourierDashboard from './pages/CourierDashboard';
import Chat from './pages/Chat';

import Cart from './pages/Cart';
import Checkout from './pages/Checkout';

const PrivateRoute = ({ children, role }: { children: React.ReactNode, role?: string }) => {
  const { user, profile, loading } = useAuth();
  
  if (loading) return <div className="h-screen w-full flex items-center justify-center bg-black text-white">Loading...</div>;
  if (!user) return <Navigate to="/login" />;
  if (role && profile?.role !== role && profile?.role !== 'admin') return <Navigate to="/" />;
  
  return <>{children}</>;
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <LanguageProvider>
          <UploadProvider>
            <Router>
              <AppContent />
            </Router>
          </UploadProvider>
        </LanguageProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

function AppContent() {
  const location = useLocation();
  const isAdminPath = location.pathname.startsWith('/system/hq');

  return (
    <UserStatusGuard>
      <DeliveredOrderGuard>
      <GlobalProgressBar />
      <div className={`min-h-screen ${isAdminPath ? 'bg-black' : 'bg-neutral-50 dark:bg-black'} text-neutral-900 dark:text-white transition-colors duration-300`}>
      {!isAdminPath && <Navbar />}
      <main className={isAdminPath ? '' : 'pb-20 md:pb-0'}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/product/:id" element={<ProductDetails />} />
          <Route path="/explore" element={<Explore />} />
          <Route 
            path="/add-product" 
            element={
              <PrivateRoute>
                <AddProduct />
              </PrivateRoute>
            } 
          />
          <Route path="/profile/:uid" element={<Profile />} />
          <Route 
            path="/chat/:uid" 
            element={
              <Navigate to="/" replace />
            } 
          />
          <Route 
            path="/notifications" 
            element={
              <PrivateRoute>
                <Notifications />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/orders" 
            element={
              <PrivateRoute>
                <Orders />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/cart" 
            element={
              <PrivateRoute>
                <Cart />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/checkout" 
            element={
              <PrivateRoute>
                <Checkout />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/profile" 
            element={
              <PrivateRoute>
                <Profile />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/seller/*" 
            element={
              <PrivateRoute>
                <SellerDashboard />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/system/hq/*" 
            element={
              <PrivateRoute role="admin">
                <AdminPanel />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/settings" 
            element={
              <PrivateRoute>
                <Settings />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/verification" 
            element={
              <PrivateRoute>
                <Verification />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/setup-store" 
            element={
              <PrivateRoute>
                <SetupStore />
              </PrivateRoute>
            } 
          />
          <Route 
            path="/courier" 
            element={
              <PrivateRoute role="courier">
                <CourierDashboard />
              </PrivateRoute>
            } 
          />
          {/* Fallback for old admin path */}
          <Route path="/admin/*" element={<Navigate to="/system/hq" replace />} />
        </Routes>
      </main>
      </div>
      </DeliveredOrderGuard>
    </UserStatusGuard>
  );
}
