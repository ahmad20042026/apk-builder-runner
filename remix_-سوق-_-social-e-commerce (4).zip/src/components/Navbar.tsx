import React, { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Home, Search, PlusCircle, User, Crown, LogOut, Bell, X, Check, ArrowRight, Package, DollarSign, Star, MessageSquare, UserPlus, ShieldAlert, Heart, Share2, ShoppingCart, ShoppingBag } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { auth, db, collection, query, where, onSnapshot, orderBy, limit, doc, updateDoc, signOut, handleFirestoreError } from '../lib/firebase';
import { Notification } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import VerifiedBadge from './VerifiedBadge';

export default function Navbar() {
  const { user, profile, loading } = useAuth();
  const { dir } = useLanguage();
  const { t } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [chats, setChats] = useState<any[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifFilter, setNotifFilter] = useState<'all' | 'orders' | 'system' | 'chats'>('all');
  const [unreadCount, setUnreadCount] = useState(0);
  const [unreadChatsCount, setUnreadChatsCount] = useState(0);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (!user) {
      setNotifications([]);
      setUnreadCount(0);
      return;
    }

    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc'),
      limit(20)
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      const items = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Notification));
      setNotifications(items);
      setUnreadCount(items.filter(n => !n.read).length);
    }, (error) => {
      console.warn("Navbar notifications listener error:", error);
    });

    // Listen for Chats
    const chatsQ = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', user.uid),
      orderBy('updatedAt', 'desc'),
      limit(20)
    );

//     const unsubscribeChats = onSnapshot(chatsQ, (snap) => {
//       const chatItems = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
//       setChats(chatItems);
//     }, (error) => {
//       console.warn("Navbar chats listener error:", error);
//     });

    return () => {
      unsubscribe();
//       unsubscribeChats();
    };
  }, [user]);

  const markAsRead = async (id: string) => {
    try {
      await updateDoc(doc(db, 'notifications', id), { read: true });
    } catch (error) {
      console.error("Error marking as read:", error);
    }
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.read);
    const batch = unread.map(n => updateDoc(doc(db, 'notifications', n.id), { read: true }));
    await Promise.all(batch);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'sale': return <DollarSign size={16} className="text-emerald-500" />;
      case 'delivery': return <Package size={16} className="text-blue-500" />;
      case 'rating': return <Star size={16} className="text-amber-500" />;
      case 'comment': return <MessageSquare size={16} className="text-indigo-500" />;
      case 'like': return <Heart size={16} className="text-rose-500 fill-rose-500" />;
      case 'share': return <Share2 size={16} className="text-blue-400" />;
      case 'follow': return <UserPlus size={16} className="text-bento-accent" />;
      case 'system': return <ShieldAlert size={16} className="text-red-500" />;
      case 'chat': return <MessageSquare size={16} className="text-amber-500" />;
      default: return <Bell size={16} className="text-neutral-500" />;
    }
  };

  const hideNavbarPaths = ['/login', '/verification'];
  if (hideNavbarPaths.includes(location.pathname) || loading) return null;

  const NavItem = ({ to, icon: Icon, label, badge, count }: { to: string, icon: any, label: string, badge?: boolean, count?: number }) => {
    const isActive = location.pathname === to || (to !== '/' && location.pathname.startsWith(to));
    return (
      <Link to={to} className={`flex flex-col items-center gap-1 group relative ${isActive ? 'text-white' : 'text-neutral-500'}`}>
        <div className={`p-2 rounded-xl transition-all ${isActive ? 'bg-bento-accent/10 text-bento-accent' : 'group-hover:bg-bento-border'}`}>
          <Icon size={24} strokeWidth={isActive ? 2.5 : 2} />
        </div>
        <span className="text-[10px] font-bold uppercase tracking-widest">{label}</span>
        {badge && (
          <div className={`absolute top-1 ${dir === 'rtl' ? 'left-1' : 'right-1'} min-w-[18px] h-[18px] bg-red-500 rounded-full border-2 border-black flex items-center justify-center px-1`}>
            {count && count > 0 ? (
              <span className="text-[10px] font-black text-white">{count > 99 ? '99+' : count}</span>
            ) : (
              <div className="w-1.5 h-1.5 bg-white rounded-full shrink-0" />
            )}
          </div>
        )}
      </Link>
    );
  };

  // Helper to extract product ID if on product page
  const productIdMatch = location.pathname.match(/\/product\/([a-zA-Z0-9_\-]+)/);
  const currentProductId = productIdMatch ? productIdMatch[1] : null;

  return (
    <div dir={dir}>
      {/* Top Left Add Product Button (Sellers Only) */}
      {user && location.pathname === '/' && (profile?.role === 'seller' || profile?.role === 'admin') && (
        <Link 
          to="/add-product" 
          className="fixed top-4 left-4 z-[60] bg-bento-accent text-black p-3 rounded-full shadow-lg shadow-bento-accent/30 hover:scale-110 transition-transform active:scale-95 flex items-center justify-center"
        >
          <PlusCircle size={24} strokeWidth={2.5} />
        </Link>
      )}

      {/* Desktop Top Navbar */}
      <nav className={`hidden md:flex fixed top-0 left-0 right-0 h-20 bg-bento-bg border-b border-bento-border z-50 items-center justify-between px-8 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
        <Link to="/" className="flex items-center gap-3 group">
          <div className="w-10 h-10 bg-bento-accent rounded-xl shadow-lg shadow-bento-accent/20 group-hover:scale-110 transition-transform"></div>
          <span className="text-2xl font-black tracking-tighter text-white">سوق</span>
        </Link>
        
        <div className={`bg-bento-item border border-bento-border px-8 py-2 rounded-full flex items-center gap-10 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
          <Link to="/" className={`text-xs font-black uppercase tracking-widest transition-colors ${location.pathname === '/' ? 'text-bento-accent' : 'text-neutral-400 hover:text-white'}`}>{t('nav.feed')}</Link>
          <Link to="/explore" className="text-xs font-black uppercase tracking-widest text-neutral-400 hover:text-white transition-colors">{t('nav.explore')}</Link>
          <Link to="/seller" className={`text-xs font-black uppercase tracking-widest transition-colors ${location.pathname.startsWith('/seller') ? 'text-bento-accent' : 'text-neutral-400 hover:text-white'}`}>{t('nav.sell')}</Link>
          {profile?.role === 'admin' && (
            <Link to="/system/hq" className={`text-xs font-black uppercase tracking-widest transition-colors ${location.pathname.startsWith('/system/hq') ? 'text-bento-accent' : 'text-neutral-400 hover:text-white'}`}>{t('nav.admin')}</Link>
          )}
        </div>

        <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
          {user ? (
            <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
              {/* Notification Bell */}
              <div className="relative">
                <button 
                  onClick={() => setShowNotifications(!showNotifications)}
                  className={`p-2 rounded-xl transition-all hover:bg-neutral-800 relative ${showNotifications ? 'bg-neutral-800 text-bento-accent' : 'text-neutral-500'}`}
                >
                  <Bell size={20} />
                  {(unreadCount > 0) && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-bento-bg" />
                  )}
                </button>

                <AnimatePresence>
                  {(showNotifications && !isMobile) && (
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className={`absolute ${dir === 'rtl' ? 'left-0' : 'right-0'} mt-4 w-80 bg-neutral-900 border border-neutral-800 rounded-[24px] shadow-2xl z-[60] overflow-hidden`}
                    >
                      <div className={`p-4 border-b border-neutral-800 flex justify-between items-center bg-neutral-900/50 backdrop-blur-md ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                        <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                          <h3 className="text-xs font-black uppercase tracking-widest text-white">{t('nav.notifications')}</h3>
                          <Link 
                            to="/orders" 
                            onClick={() => setShowNotifications(false)}
                            className={`flex items-center gap-1.5 px-2 py-1 bg-white/5 rounded-lg border border-white/10 text-bento-accent hover:bg-white/10 transition-all group/orders ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}
                          >
                            <Package size={12} />
                            <span className="text-[9px] font-black uppercase tracking-widest">{t('nav.my_orders')}</span>
                          </Link>
                        </div>
                        {unreadCount > 0 && (
                          <button onClick={markAllAsRead} className="text-[10px] font-black text-bento-accent uppercase tracking-tighter hover:underline">{t('nav.mark_all_read')}</button>
                        )}
                      </div>
                      
                      {/* Filter Tabs */}
                      <div className="flex border-b border-neutral-800">
                        <button 
                          onClick={() => setNotifFilter('all')}
                          className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest transition-all ${notifFilter === 'all' ? 'text-bento-accent bg-bento-accent/5' : 'text-neutral-500 hover:text-neutral-300'}`}
                        >
                          {t('common.all')}
                        </button>
                        <button 
                          onClick={() => setNotifFilter('orders')}
                          className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest transition-all ${notifFilter === 'orders' ? 'text-blue-400 bg-blue-400/5' : 'text-neutral-500 hover:text-neutral-300'}`}
                        >
                          {t('nav.orders_tab')}
                        </button>
                        <button 
                          onClick={() => setNotifFilter('system')}
                          className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest transition-all ${notifFilter === 'system' ? 'text-red-400 bg-red-400/5' : 'text-neutral-500 hover:text-neutral-300'}`}
                        >
                          {t('nav.system_tab')}
                        </button>
                        {/* Chat tab disabled temporarily */}
                        {/* <button 
                          onClick={() => setNotifFilter('chats')}
                          className={`flex-1 py-3 text-[9px] font-black uppercase tracking-widest transition-all ${notifFilter === 'chats' ? 'text-amber-400 bg-amber-400/5' : 'text-neutral-500 hover:text-neutral-300'}`}
                        >
                          {t('nav.messaging_tab')}
                        </button> */}
                      </div>

                      <div className="max-h-96 overflow-y-auto no-scrollbar">
                        {notifFilter === 'chats' ? (
                          chats.length === 0 ? (
                            <div className="p-8 text-center">
                              <MessageSquare size={32} className="text-neutral-800 mx-auto mb-2 opacity-20" />
                              <p className="text-[10px] font-bold text-neutral-600 uppercase tracking-widest">{t('nav.inbox_clear')}</p>
                            </div>
                          ) : (
                            chats.map(chat => {
                              const otherUid = chat.participants.find((p: string) => p !== user.uid);
                              return (
                                <Link 
                                  key={`desktop-chat-${chat.id}`} 
                                  to={`/chat/${otherUid}`} 
                                  onClick={() => setShowNotifications(false)}
                                  className={`block p-4 border-b border-neutral-800/50 hover:bg-neutral-800 transition-colors ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                                >
                                  <div className={`flex gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                                    <div className="mt-1">{getIcon('chat')}</div>
                                    <div className="flex-1">
                                      <h4 className="text-xs font-black text-white leading-none mb-1">
                                        {t('nav.chats')}
                                      </h4>
                                      <p className="text-[10px] text-neutral-400 font-medium leading-relaxed truncate max-w-[200px]">
                                        {chat.recentMessage || t('chat.no_messages')}
                                      </p>
                                    </div>
                                  </div>
                                </Link>
                              );
                            })
                          )
                        ) : (
                          notifications.filter(n => {
                            if (notifFilter === 'all') return true;
                            if (notifFilter === 'orders') return n.type === 'delivery' || n.type === 'sale';
                            if (notifFilter === 'system') return n.type === 'system';
                            return false;
                          }).length === 0 ? (
                            <div className="p-8 text-center">
                              <Bell size={32} className="text-neutral-800 mx-auto mb-2 opacity-20" />
                              <p className="text-[10px] font-bold text-neutral-600 uppercase tracking-widest">{t('nav.all_caught_up')}</p>
                            </div>
                          ) : (
                            notifications
                              .filter(n => {
                                if (notifFilter === 'all') return true;
                                if (notifFilter === 'orders') return n.type === 'delivery' || n.type === 'sale';
                                if (notifFilter === 'system') return n.type === 'system';
                                return false;
                              })
                              .map(n => (
                              <Link 
                                 key={`desktop-${n.id}`} 
                                 to={n.link || '#'} 
                                 onClick={() => {
                                   markAsRead(n.id);
                                   setShowNotifications(false);
                                 }}
                                 className={`block p-4 border-b border-neutral-800/50 hover:bg-neutral-800 transition-colors ${!n.read ? 'bg-bento-accent/5' : ''} ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                              >
                                 <div className={`flex gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                                   <div className="mt-1">{getIcon(n.type)}</div>
                                   <div className="flex-1">
                                     <div className={`flex justify-between items-start gap-2 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                                       <h4 className="text-xs font-black text-white leading-none mb-1">{n.title}</h4>
                                       {!n.read && <div className="w-1.5 h-1.5 bg-bento-accent rounded-full shrink-0" />}
                                     </div>
                                     <p className="text-[10px] text-neutral-400 font-medium leading-relaxed">{n.message}</p>
                                   </div>
                                 </div>
                              </Link>
                            ))
                          )
                        )}
                      </div>
                      <Link 
                        to="/notifications" 
                        onClick={() => setShowNotifications(false)}
                        className="block p-3 text-center text-[10px] font-black uppercase tracking-widest text-neutral-500 hover:text-white transition-colors bg-neutral-900/80 backdrop-blur-sm border-t border-neutral-800"
                      >
                        {t('nav.view_all_activity')}
                      </Link>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className={`flex flex-col ${dir === 'rtl' ? 'items-start' : 'items-end'}`}>
                <div className={`flex items-center gap-1.5 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <span className="text-xs font-bold text-white">@{profile?.displayName}</span>
                  {profile?.isVerified && <VerifiedBadge size={14} />}
                </div>
                <span className="text-[10px] text-bento-accent font-black uppercase tracking-tighter">{profile?.role}</span>
              </div>
              <Link to="/profile" className="w-10 h-10 rounded-full border-2 border-bento-accent overflow-hidden transition-transform hover:scale-105 active:scale-95">
                {profile?.photoURL ? (
                  <img src={profile.photoURL} alt="" />
                ) : (
                  <div className="w-full h-full bg-bento-border flex items-center justify-center text-[10px] font-black">
                    {profile?.displayName?.charAt(0) || 'U'}
                  </div>
                )}
              </Link>
              <button 
                onClick={async () => {
                  try {
                    await signOut();
                  } catch (error) {
                    console.error("Logout failed:", error);
                  }
                }}
                className="text-neutral-500 hover:text-red-400 transition-colors"
                title={t('common.logout')}
              >
                <LogOut size={20} />
              </button>
            </div>
          ) : (
            <Link to="/login" className="bg-bento-accent text-black px-6 py-2 rounded-xl font-bold text-sm shadow-lg shadow-bento-accent/20">{t('common.login')}</Link>
          )}
        </div>
      </nav>

      {/* Mobile Bottom Navbar */}
      <nav className={`md:hidden fixed bottom-0 left-0 right-0 bg-black border-t border-neutral-900 z-50 flex items-center justify-around h-20 pb-4 px-1 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
        <NavItem to="/profile" icon={User} label={t('nav.profile')} />
        
        <NavItem 
          to="/notifications" 
          icon={Bell} 
          label={t('nav.notifications', 'صندوق الوارد')} 
          badge={unreadCount > 0} 
          count={unreadCount} 
        />

        {/* Central Buy Button: Context-aware Direct Purchase */}
        <Link 
          to={currentProductId ? `/checkout?productId=${currentProductId}` : "/cart"} 
          className="relative flex items-center justify-center -mt-8"
        >
          <div className="absolute inset-0 bg-bento-accent blur-md opacity-20 scale-125"></div>
          <div className="w-14 h-11 bg-bento-item border-2 border-bento-accent rounded-xl flex items-center justify-center relative z-10 shadow-xl overflow-hidden active:scale-95 transition-transform group">
             {currentProductId ? (
               <ShoppingBag className="text-bento-accent animate-pulse" size={28} strokeWidth={2.5} />
             ) : (
               <ShoppingCart className="text-bento-accent" size={28} strokeWidth={2.5} />
             )}
          </div>
          <span className="absolute -bottom-6 text-[10px] font-black uppercase tracking-widest text-bento-accent">
            {currentProductId ? (dir === 'rtl' ? 'شراء الآن' : 'Buy Now') : t('nav.cart', 'Cart')}
          </span>
        </Link>
        
        <NavItem to="/explore" icon={Search} label={t('nav.search', 'Explore')} />
        <NavItem to="/" icon={Home} label={t('nav.home', 'Home')} />
      </nav>

      {/* Mobile Notification Drawer */}
      <AnimatePresence>
        {(showNotifications && isMobile) && (
          <>
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowNotifications(false)}
              className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-sm md:hidden"
            />
            
            {/* Bottom Sheet */}
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed bottom-16 left-0 right-0 z-[70] bg-neutral-900 border-t border-neutral-800 md:hidden flex flex-col rounded-t-[32px] max-h-[70vh] shadow-[0_-20px_50px_rgba(0,0,0,0.5)]"
            >
              <div className="w-12 h-1.5 bg-neutral-800 rounded-full mx-auto mt-3 mb-1" />
              <div className={`p-6 border-b border-neutral-800/50 flex justify-between items-center ${dir === 'rtl' ? 'flex-row-reverse text-right' : 'flex-row'}`}>
                <div className={`flex items-center gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                  <h2 className="text-xl font-black italic tracking-tighter uppercase">{t('nav.notifications')}</h2>
                  <Link 
                    to="/orders" 
                    onClick={() => setShowNotifications(false)}
                    className={`flex items-center gap-2 px-4 py-2 bg-bento-accent/10 border border-bento-accent/20 rounded-2xl text-bento-accent animate-pulse ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}
                  >
                    <Package size={16} />
                    <span className="text-xs font-black uppercase tracking-widest">{t('nav.my_orders')}</span>
                  </Link>
                </div>
                <button onClick={() => setShowNotifications(false)} className="p-2 text-neutral-500 hover:text-white">
                  <X size={20} />
                </button>
              </div>

              {/* Mobile Filter Tabs */}
              <div className={`flex border-b border-neutral-800/30 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                <button 
                  onClick={() => setNotifFilter('all')}
                  className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-all ${notifFilter === 'all' ? 'text-bento-accent border-b-2 border-bento-accent bg-bento-accent/5' : 'text-neutral-500'}`}
                >
                  {t('common.all')}
                </button>
                <button 
                  onClick={() => setNotifFilter('orders')}
                  className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-all ${notifFilter === 'orders' ? 'text-blue-400 border-b-2 border-blue-400 bg-blue-400/5' : 'text-neutral-500'}`}
                >
                  {t('nav.orders_tab')}
                </button>
                <button 
                  onClick={() => setNotifFilter('system')}
                  className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-all ${notifFilter === 'system' ? 'text-red-400 border-b-2 border-red-400 bg-red-400/5' : 'text-neutral-500'}`}
                >
                  {t('nav.system_tab')}
                </button>
                {/* Chat tab disabled temporarily */}
                {/* <button 
                  onClick={() => setNotifFilter('chats')}
                  className={`flex-1 py-4 text-xs font-black uppercase tracking-widest transition-all ${notifFilter === 'chats' ? 'text-amber-400 border-b-2 border-amber-400 bg-amber-400/5' : 'text-neutral-500'}`}
                >
                  {t('nav.messaging_tab')}
                </button> */}
              </div>

              <div className={`flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar pb-10 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}>
                {notifFilter === 'chats' ? (
                  chats.length === 0 ? (
                    <div className="py-20 flex flex-col items-center justify-center opacity-20 italic">
                      <MessageSquare size={48} className="mb-4" />
                      <p className="text-xs font-black uppercase tracking-widest">{t('nav.inbox_clear')}</p>
                    </div>
                  ) : (
                    chats.map(chat => {
                      const otherUid = chat.participants.find((p: string) => p !== user.uid);
                      return (
                        <Link 
                          key={`mobile-chat-${chat.id}`} 
                          to={`/chat/${otherUid}`} 
                          onClick={() => setShowNotifications(false)}
                          className={`block p-4 rounded-2xl border bg-black/20 border-neutral-800/50 ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                        >
                          <div className={`flex gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                            <div className="shrink-0 mt-1 p-2 bg-neutral-800 rounded-xl">{getIcon('chat')}</div>
                            <div className="flex-1 min-w-0">
                              <h4 className="font-bold text-white text-sm leading-tight truncate">
                                {t('nav.chats')}
                              </h4>
                              <p className="text-xs text-neutral-400 font-medium leading-relaxed line-clamp-1">
                                {chat.recentMessage || t('chat.no_messages')}
                              </p>
                            </div>
                          </div>
                        </Link>
                      );
                    })
                  )
                ) : (
                  notifications.filter(n => {
                    if (notifFilter === 'all') return true;
                    if (notifFilter === 'orders') return n.type === 'delivery' || n.type === 'sale';
                    if (notifFilter === 'system') return n.type === 'system';
                    return false;
                  }).length === 0 ? (
                    <div className="py-20 flex flex-col items-center justify-center opacity-20 italic">
                      <Bell size={48} className="mb-4" />
                      <p className="text-xs font-black uppercase tracking-widest">{t('nav.inbox_clear')}</p>
                    </div>
                  ) : (
                    notifications
                      .filter(n => {
                        if (notifFilter === 'all') return true;
                        if (notifFilter === 'orders') return n.type === 'delivery' || n.type === 'sale';
                        if (notifFilter === 'system') return n.type === 'system';
                        return false;
                      })
                      .map(n => (
                      <Link 
                         key={`mobile-${n.id}`} 
                         to={n.link || '#'} 
                         onClick={() => {
                           markAsRead(n.id);
                           setShowNotifications(false);
                         }}
                         className={`block p-4 rounded-2xl border ${!n.read ? 'bg-bento-accent/5 border-bento-accent/20' : 'bg-black/20 border-neutral-800/50'} ${dir === 'rtl' ? 'text-right' : 'text-left'}`}
                      >
                         <div className={`flex gap-4 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                           <div className="shrink-0 mt-1 p-2 bg-neutral-800 rounded-xl">{getIcon(n.type)}</div>
                           <div className="flex-1 min-w-0">
                             <div className={`flex justify-between items-start mb-0.5 ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}>
                               <h4 className="font-bold text-white text-sm leading-tight truncate pr-2">{n.title}</h4>
                               {!n.read && <div className="w-1.5 h-1.5 bg-bento-accent rounded-full shrink-0" />}
                             </div>
                             <p className="text-xs text-neutral-400 font-medium leading-relaxed line-clamp-2">{n.message}</p>
                           </div>
                         </div>
                      </Link>
                    ))
                  )
                )}
              </div>
              {unreadCount > 0 && (
                <div className="p-4 bg-neutral-900 border-t border-neutral-800">
                  <button onClick={markAllAsRead} className="w-full bg-neutral-800 hover:bg-neutral-700 text-white font-black py-3 rounded-xl uppercase tracking-widest text-[10px] transition-colors">
                    {t('nav.mark_all_read')}
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
