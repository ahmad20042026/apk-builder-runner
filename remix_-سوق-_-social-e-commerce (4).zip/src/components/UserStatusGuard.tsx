import React from 'react';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, LogOut, Lock } from 'lucide-react';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';
import { motion } from 'motion/react';

export default function UserStatusGuard({ children }: { children: React.ReactNode }) {
  const { profile, user, loading } = useAuth();

  if (loading) return <>{children}</>;
  if (!user || !profile) return <>{children}</>;

  const handleLogout = async () => {
    try {
      await signOut(auth);
      window.location.href = '/login';
    } catch (err) {
      console.error(err);
    }
  };

  if (profile.isBanned) {
    return (
      <div className="fixed inset-0 z-[300] bg-black flex flex-col items-center justify-center p-8 text-center" dir="rtl">
        <div className="absolute inset-0 bg-red-950/20 mix-blend-overlay" />
        <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="max-w-md w-full bg-[#121212] border border-red-600/20 rounded-[48px] p-12 shadow-[0_0_100px_rgba(220,38,38,0.2)]"
        >
          <div className="w-24 h-24 bg-red-600 rounded-3xl flex items-center justify-center mx-auto mb-8 animate-pulse shadow-2xl shadow-red-600/50">
            <ShieldAlert size={48} className="text-white" />
          </div>
          <h2 className="text-3xl font-black italic tracking-tighter uppercase mb-4 text-white">تم حظر الحساب نهائياً</h2>
          <p className="text-neutral-500 text-xs font-bold uppercase tracking-widest mb-10 leading-relaxed">
            لقد تم إيقاف نشاطك على المنصة بسبب مخالفة بنود الخدمة. هذا القرار لا رجعة فيه من قبل النظام التلقائي. يرجى التواصل مع الدعم الإداري إذا كنت تعتقد أن هذا خطأ.
          </p>
          <button 
            onClick={handleLogout}
            className="w-full py-5 bg-white text-black rounded-[24px] font-black uppercase tracking-widest text-xs hover:scale-105 active:scale-95 transition-all shadow-xl flex items-center justify-center gap-3"
          >
            تسجيل الخروج <LogOut size={20} />
          </button>
        </motion.div>
      </div>
    );
  }

  if (profile.isFrozen) {
    return (
      <div className="fixed inset-0 z-[300] bg-black flex flex-col items-center justify-center p-8 text-center" dir="rtl">
        <div className="absolute inset-0 bg-orange-950/20 mix-blend-overlay" />
        <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="max-w-md w-full bg-[#121212] border border-orange-600/20 rounded-[48px] p-12 shadow-[0_0_100px_rgba(234,88,12,0.2)]"
        >
          <div className="w-24 h-24 bg-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-orange-600/50">
            <Lock size={48} className="text-white" />
          </div>
          <h2 className="text-3xl font-black italic tracking-tighter uppercase mb-4 text-white">الحساب مجمد مؤقتاً</h2>
          <p className="text-neutral-500 text-xs font-bold uppercase tracking-widest mb-10 leading-relaxed">
            قام مسؤولو النظام بتجميد حسابك مؤقتاً لأسباب أمنية أو لمراجعة نشاطك. لا يمكنك الوصول للمنصة في الوقت الحالي.
          </p>
          <button 
            onClick={handleLogout}
            className="w-full py-5 bg-orange-600 text-white rounded-[24px] font-black uppercase tracking-widest text-xs hover:scale-105 active:scale-95 transition-all shadow-xl flex items-center justify-center gap-3"
          >
            تسجيل الخروج <LogOut size={20} />
          </button>
        </motion.div>
      </div>
    );
  }

  return <>{children}</>;
}
