import React, { useState, useEffect } from 'react';
import { db, collection, getDocs, addDoc, updateDoc, doc, deleteDoc } from '../lib/firebase';
import { Region, Zone } from '../types';
import { MapPin, Plus, Trash2, Edit2, CheckCircle2, XCircle, AlertTriangle, Loader2, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function AdminGeography() {
  const [regions, setRegions] = useState<Region[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingRegion, setEditingRegion] = useState<Partial<Region> | null>(null);
  const [editingZone, setEditingZone] = useState<Partial<Zone> | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const rSnap = await getDocs(collection(db, 'regions'));
      const zSnap = await getDocs(collection(db, 'zones'));
      setRegions(rSnap.docs.map(d => ({ id: d.id, ...d.data() }) as Region));
      setZones(zSnap.docs.map(d => ({ id: d.id, ...d.data() }) as Zone));
    } catch (error) {
      console.error("Error fetching geography:", error);
    } finally {
      setLoading(false);
    }
  };

  const saveRegion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRegion?.name || !editingRegion.nameAr) return;
    try {
      if (editingRegion.id) {
        await updateDoc(doc(db, 'regions', editingRegion.id), editingRegion);
      } else {
        await addDoc(collection(db, 'regions'), { ...editingRegion, isActive: true });
      }
      setEditingRegion(null);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const saveZone = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingZone?.name || !editingZone.regionId) return;
    try {
      if (editingZone.id) {
        await updateDoc(doc(db, 'zones', editingZone.id), editingZone);
      } else {
        await addDoc(collection(db, 'zones'), { ...editingZone, isActive: true, isRestricted: false });
      }
      setEditingZone(null);
      fetchData();
    } catch (err) {
      console.error(err);
    }
  };

  const toggleRegionStatus = async (region: Region) => {
    try {
      await updateDoc(doc(db, 'regions', region.id), { isActive: !region.isActive });
      fetchData();
    } catch (err) { console.error(err); }
  };

  const toggleZoneStatus = async (zone: Zone) => {
    try {
      await updateDoc(doc(db, 'zones', zone.id), { isActive: !zone.isActive });
      fetchData();
    } catch (err) { console.error(err); }
  };

  const toggleZoneRestriction = async (zone: Zone) => {
    try {
      await updateDoc(doc(db, 'zones', zone.id), { isRestricted: !zone.isRestricted });
      fetchData();
    } catch (err) { console.error(err); }
  };

  if (loading) return <div className="p-8 flex items-center justify-center"><Loader2 className="animate-spin text-bento-accent" /></div>;

  return (
    <div className="space-y-12">
      {/* Regions Section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black italic tracking-tighter uppercase">Regions Management</h2>
          <button 
            onClick={() => setEditingRegion({ name: '', nameAr: '', isActive: true })}
            className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-bento-accent transition-all"
          >
            <Plus size={16} /> Add Region
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {regions.map(region => (
            <div key={region.id} className="bg-neutral-900 border border-neutral-800 p-6 rounded-3xl relative group">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-white/5 rounded-2xl">
                  <MapPin size={24} className={region.isActive ? "text-emerald-500" : "text-neutral-500"} />
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => setEditingRegion(region)} className="p-2 hover:bg-white/10 rounded-lg text-neutral-400 hover:text-white"><Edit2 size={16} /></button>
                  <button onClick={() => toggleRegionStatus(region)} className={`p-2 rounded-lg transition-colors ${region.isActive ? 'text-emerald-500 hover:bg-emerald-500/10' : 'text-neutral-500 hover:bg-neutral-500/10'}`}>
                    {region.isActive ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                  </button>
                </div>
              </div>
              <h3 className="text-xl font-black">{region.name}</h3>
              <p className="text-neutral-500 font-bold mb-4">{region.nameAr}</p>
              <div className="flex items-center gap-2">
                 <span className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${region.isActive ? 'bg-emerald-500/10 text-emerald-500' : 'bg-neutral-800 text-neutral-500'}`}>
                   {region.isActive ? 'Active' : 'Inactive'}
                 </span>
                 <span className="text-[10px] text-neutral-600 font-bold uppercase">{zones.filter(z => z.regionId === region.id).length} Zones</span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Zones Section */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black italic tracking-tighter uppercase">Zones Management</h2>
          <button 
            onClick={() => setEditingZone({ name: '', nameAr: '', regionId: regions[0]?.id, isActive: true, isRestricted: false })}
            className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-bento-accent transition-all"
          >
            <Plus size={16} /> Add Zone
          </button>
        </div>

        <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] overflow-hidden">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-neutral-800 bg-white/5 font-black uppercase tracking-widest text-[10px] text-neutral-500">
                <th className="px-6 py-4">Zone Name</th>
                <th className="px-6 py-4">Region</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Restriction</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {zones.map(zone => {
                const region = regions.find(r => r.id === zone.regionId);
                return (
                  <tr key={zone.id} className="group hover:bg-white/5 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-bold">{zone.name}</div>
                      <div className="text-[10px] text-neutral-500">{zone.nameAr}</div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="px-3 py-1 bg-neutral-800 rounded-full text-[10px] font-black uppercase">{region?.name || 'Unknown'}</span>
                    </td>
                    <td className="px-6 py-4">
                      <button onClick={() => toggleZoneStatus(zone)} className={`flex items-center gap-2 ${zone.isActive ? 'text-emerald-500' : 'text-neutral-500'}`}>
                        {zone.isActive ? <CheckCircle2 size={16} /> : <XCircle size={16} />}
                        <span className="text-[10px] font-black uppercase tracking-widest">{zone.isActive ? 'Enabled' : 'Disabled'}</span>
                      </button>
                    </td>
                    <td className="px-6 py-4">
                      <button onClick={() => toggleZoneRestriction(zone)} className={`flex items-center gap-2 ${zone.isRestricted ? 'text-red-500' : 'text-neutral-500'}`}>
                        {zone.isRestricted ? <AlertTriangle size={16} /> : <ShieldCheck size={16} />}
                        <span className="text-[10px] font-black uppercase tracking-widest">{zone.isRestricted ? 'Restricted' : 'Safe'}</span>
                      </button>
                    </td>
                    <td className="px-6 py-4 text-right">
                       <button onClick={() => setEditingZone(zone)} className="p-2 hover:bg-white/10 rounded-lg text-neutral-400 hover:text-white transition-colors"><Edit2 size={16} /></button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* Forms Modals */}
      <AnimatePresence>
        {editingRegion && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <motion.form 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              onSubmit={saveRegion}
              className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] max-w-sm w-full"
            >
              <h3 className="text-2xl font-black italic mb-6 uppercase tracking-tighter">{editingRegion.id ? 'Edit Region' : 'New Region'}</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-neutral-500 block mb-1">Region Name (EN)</label>
                  <input value={editingRegion.name} onChange={e => setEditingRegion({...editingRegion, name: e.target.value})} className="w-full bg-black border border-neutral-800 p-4 rounded-2xl outline-none focus:border-bento-accent" required />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-neutral-500 block mb-1">Region Name (AR)</label>
                  <input value={editingRegion.nameAr} onChange={e => setEditingRegion({...editingRegion, nameAr: e.target.value})} className="w-full bg-black border border-neutral-800 p-4 rounded-2xl outline-none focus:border-bento-accent text-right" required />
                </div>
              </div>
              <div className="flex gap-4 mt-8">
                <button type="button" onClick={() => setEditingRegion(null)} className="flex-1 py-4 bg-neutral-800 rounded-2xl text-xs font-black uppercase">Cancel</button>
                <button type="submit" className="flex-1 py-4 bg-white text-black rounded-2xl text-xs font-black uppercase hover:bg-bento-accent">Save</button>
              </div>
            </motion.form>
          </div>
        )}

        {editingZone && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <motion.form 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              onSubmit={saveZone}
              className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] max-w-sm w-full"
            >
              <h3 className="text-2xl font-black italic mb-6 uppercase tracking-tighter">{editingZone.id ? 'Edit Zone' : 'New Zone'}</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black uppercase text-neutral-500 block mb-1">Parent Region</label>
                  <select 
                    value={editingZone.regionId} 
                    onChange={e => setEditingZone({...editingZone, regionId: e.target.value})}
                    className="w-full bg-black border border-neutral-800 p-4 rounded-2xl outline-none focus:border-bento-accent"
                    required
                  >
                    {regions.map((r, i) => <option key={`${r.id}-${i}`} value={r.id}>{r.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-neutral-500 block mb-1">Zone Name (EN)</label>
                  <input value={editingZone.name} onChange={e => setEditingZone({...editingZone, name: e.target.value})} className="w-full bg-black border border-neutral-800 p-4 rounded-2xl outline-none focus:border-bento-accent" required />
                </div>
                <div>
                  <label className="text-[10px] font-black uppercase text-neutral-500 block mb-1">Zone Name (AR)</label>
                  <input value={editingZone.nameAr} onChange={e => setEditingZone({...editingZone, nameAr: e.target.value})} className="w-full bg-black border border-neutral-800 p-4 rounded-2xl outline-none focus:border-bento-accent text-right" required />
                </div>
              </div>
              <div className="flex gap-4 mt-8">
                <button type="button" onClick={() => setEditingZone(null)} className="flex-1 py-4 bg-neutral-800 rounded-2xl text-xs font-black uppercase">Cancel</button>
                <button type="submit" className="flex-1 py-4 bg-white text-black rounded-2xl text-xs font-black uppercase hover:bg-bento-accent">Save</button>
              </div>
            </motion.form>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
