import React, { useState, useEffect } from "react";
import {
  TrendingUp,
  Package,
  ShoppingBag,
  Wallet,
  Settings,
  BadgeCheck,
  Plus,
  ShieldAlert,
  AlertTriangle,
  ChevronRight,
  ArrowRight,
  CreditCard,
  Landmark,
  LayoutGrid,
  List,
  Ban,
  Zap,
  ArrowUp,
  ArrowDown,
  Minus,
  DollarSign,
  ShieldCheck,
  Trash2,
  Archive,
  CheckCircle,
  Target,
  Award,
  Rocket,
  Check,
  Store,
  Pencil,
  Pin,
  X,
  Building2,
  Smartphone,
  Eye,
  MousePointer2,
  Heart,
  ShoppingCart,
  MessageSquare,
  Star,
  BarChart3,
  PieChart,
  Activity,
  Users,
  Shield,
  Flag,
  Truck,
  AlertCircle,
  Info,
  Share2,
  ExternalLink,
  Filter,
  Search,
  MoreVertical,
  ChevronDown,
  ArrowRightLeft,
  History,
  Calculator,
  Percent,
  Globe,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useTranslation } from "react-i18next";
import { useLanguage } from "../context/LanguageContext";
import { db } from "../lib/firebase";
import { getDocResilient } from "../lib/firebase";
import {
  doc,
  collection,
  query,
  where,
  getDocs,
  orderBy,
} from "firebase/firestore";
import {
  Product,
  Order,
  UserProfile,
  StoreAnalytics,
  ProductAnalytics,
  Dispute,
  Report,
} from "../types";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart as RePieChart,
  Pie,
  Cell,
} from "recharts";

interface MarketStudioProps {
  user: any;
  profile: UserProfile | null;
  products: Product[];
  orders: Order[];
  onDeleteProduct: (product: Product, e: React.MouseEvent) => void;
  onClose: () => void;
}

type StudioTab =
  | "dashboard"
  | "products"
  | "analytics"
  | "revenue"
  | "orders"
  | "disputes"
  | "levels";

export default function MarketStudio({
  user,
  profile,
  products,
  orders,
  onDeleteProduct,
  onClose,
}: MarketStudioProps) {
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const [activeTab, setActiveTab] = useState<StudioTab>("dashboard");
  const [storeAnalytics, setStoreAnalytics] = useState<StoreAnalytics | null>(
    null,
  );
  const [productAnalytics, setProductAnalytics] = useState<
    Record<string, ProductAnalytics>
  >({});
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(
    null,
  );

  useEffect(() => {
    fetchStudioData();
  }, [user]);

  const fetchStudioData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      // 1. Fetch Store Analytics
      try {
        const storeRef = doc(db, "storeAnalytics", user.uid);
        const storeSnap = await getDocResilient(storeRef);
        if (storeSnap.exists()) {
          setStoreAnalytics(storeSnap.data() as StoreAnalytics);
        } else {
          setStoreAnalytics(
            getStoreStats(user.uid, products.length, orders.length),
          );
        }
      } catch (e) {
        console.warn("Store Analytics fetch failed:", e);
        setStoreAnalytics(
          getStoreStats(user.uid, products.length, orders.length),
        );
      }

      // 2. Fetch Product Analytics
      try {
        const pAnalyticsQ = query(
          collection(db, "productAnalytics"),
          where("storeId", "==", user.uid),
        );
        const pAnalyticsSnap = await getDocs(pAnalyticsQ);
        const pMap: Record<string, ProductAnalytics> = {};
        pAnalyticsSnap.docs.forEach((d) => {
          pMap[d.data().productId] = d.data() as ProductAnalytics;
        });
        products.forEach((p) => {
          if (!pMap[p.id]) {
            pMap[p.id] = getProductStats(p.id, user.uid);
          }
        });
        setProductAnalytics(pMap);
      } catch (e) {
        console.warn("Product Analytics fetch failed:", e);
      }

      // 3. Fetch Disputes
      try {
        const disputesQ = query(
          collection(db, "disputes"),
          where("sellerId", "==", user.uid),
          orderBy("createdAt", "desc"),
        );
        const disputesSnap = await getDocs(disputesQ);
        setDisputes(
          disputesSnap.docs.map((d) => ({ id: d.id, ...d.data() }) as Dispute),
        );
      } catch (e) {
        console.warn("Disputes fetch failed:", e);
      }

      // 4. Fetch Reports
      try {
        const reportsQ = query(
          collection(db, "reports"),
          where("targetId", "==", user.uid),
          orderBy("createdAt", "desc"),
        );
        const reportsSnap = await getDocs(reportsQ);
        setReports(
          reportsSnap.docs.map((d) => ({ id: d.id, ...d.data() }) as Report),
        );
      } catch (e) {
        console.warn("Reports fetch failed:", e);
      }
    } catch (error) {
      console.error("Studio data fetch error:", error);
    } finally {
      setLoading(false);
    }
  };

  // Mock initializers for data consistency in demo/empty states
  const getStoreStats = (
    id: string,
    pCount: number,
    oCount: number,
  ): StoreAnalytics => ({
    storeId: id,
    totalRevenue: orders
      .filter((o) => o.status === "completed")
      .reduce((sum, o) => sum + (o.price || 0), 0),
    totalProfit: orders
      .filter((o) => o.status === "completed")
      .reduce((sum, o) => sum + (o.netAmount || 0), 0),
    totalOrders: oCount,
    totalViews: pCount * 10,
    totalClicks: pCount * 4,
    totalImpressions: pCount * 25,
    totalFavorites: 0,
    totalCartAdds: orders.length,
    totalFollowers: profile?.followersCount || 0,
    totalRefunds: 0,
    totalDisputes: 0,
    last7DaysRevenue: orders
      .filter((o) => o.status === "completed" && o.createdAt && (Date.now() - (o.createdAt as any).toMillis() < 7 * 24 * 60 * 60 * 1000))
      .reduce((sum, o) => sum + (o.price || 0), 0),
    last30DaysRevenue: orders
      .filter((o) => o.status === "completed")
      .reduce((sum, o) => sum + (o.price || 0), 0),
    conversionRate: oCount > 0 ? oCount / (pCount * 10 || 1) : 0,
    ctr: 0.05,
    averageOrderValue: oCount > 0 ? (orders.reduce((sum, o) => sum + (o.price || 0), 0) / oCount) : 0,
    bestSellingProducts: products.slice(0, 3).map((p) => p.id),
    worstSellingProducts: [],
  });

  const getProductStats = (pid: string, sid: string): ProductAnalytics => {
    const pOrders = orders.filter(o => o.productId === pid);
    const pRevenue = pOrders.reduce((sum, o) => sum + (o.price || 0), 0);
    return {
      productId: pid,
      storeId: sid,
      impressions: Math.max(10, pOrders.length * 20),
      clicks: Math.max(2, pOrders.length * 3),
      productPageViews: Math.max(5, pOrders.length * 5),
      ctr: 0.05,
      favorites: 0,
      cartAdds: pOrders.length,
      orders: pOrders.length,
      sales: pOrders.length,
      revenue: pRevenue,
      commission: 10,
      netProfit: pRevenue * 0.9,
      refunds: 0,
      disputes: 0,
      rating: 0,
      lastSoldAt: pOrders.length > 0 ? new Date() : undefined,
      status: "active",
    };
  };

  const chartData = [
    { name: "Sat", sales: 400, revenue: 2400 },
    { name: "Sun", sales: 300, revenue: 1398 },
    { name: "Mon", sales: 200, revenue: 9800 },
    { name: "Tue", sales: 278, revenue: 3908 },
    { name: "Wed", sales: 189, revenue: 4800 },
    { name: "Thu", sales: 239, revenue: 3800 },
    { name: "Fri", sales: 349, revenue: 4300 },
  ];

  const pieData = [
    { name: "Home Feed", value: 400, color: "#FFD700" },
    { name: "Search", value: 300, color: "#FFEC8B" },
    { name: "Profile", value: 300, color: "#FFFACD" },
    { name: "Direct Link", value: 200, color: "#F0E68C" },
  ];

  return (
    <div
      className={`fixed inset-0 z-50 bg-bento-bg flex flex-col md:flex-row overflow-hidden ${dir === "rtl" ? "rtl" : "ltr"}`}
    >
      {/* Sidebar - Desktop */}
      <aside
        className={`hidden md:flex w-64 flex-col border-bento-border bg-black/40 backdrop-blur-xl ${dir === "rtl" ? "border-l" : "border-r"}`}
      >
        <div className="p-8">
          <div
            className={`flex items-center gap-3 text-bento-accent mb-12 ${dir === "rtl" ? "flex-row-reverse" : ""}`}
          >
            <Store size={32} />
            <h1 className="text-xl font-black italic tracking-tighter uppercase text-white">
              Market Studio
            </h1>
          </div>

            <nav className="space-y-2">
            <button
              onClick={() => setActiveTab("dashboard")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === "dashboard" ? "bg-bento-accent text-black" : "text-neutral-500 hover:text-white hover:bg-white/5"} ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <LayoutGrid size={18} />
              <span>{t("seller_dashboard.market_studio.tabs.dashboard")}</span>
            </button>
            <button
              onClick={() => setActiveTab("products")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === "products" ? "bg-bento-accent text-black" : "text-neutral-500 hover:text-white hover:bg-white/5"} ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <Package size={18} />
              <span>{t("seller_dashboard.market_studio.tabs.products")}</span>
            </button>
            <button
              onClick={() => setActiveTab("analytics")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === "analytics" ? "bg-bento-accent text-black" : "text-neutral-500 hover:text-white hover:bg-white/5"} ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <BarChart3 size={18} />
              <span>{t("seller_dashboard.market_studio.tabs.analytics")}</span>
            </button>
            <button
              onClick={() => setActiveTab("revenue")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === "revenue" ? "bg-bento-accent text-black" : "text-neutral-500 hover:text-white hover:bg-white/5"} ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <Wallet size={18} />
              <span>{t("seller_dashboard.market_studio.tabs.revenue")}</span>
            </button>
            <button
              onClick={() => setActiveTab("orders")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === "orders" ? "bg-bento-accent text-black" : "text-neutral-500 hover:text-white hover:bg-white/5"} ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <Truck size={18} />
              <span>{t("seller_dashboard.market_studio.tabs.orders_shipping")}</span>
            </button>
            <button
              onClick={() => setActiveTab("disputes")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === "disputes" ? "bg-bento-accent text-black" : "text-neutral-500 hover:text-white hover:bg-white/5"} ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <ShieldAlert size={18} />
              <span>{t("seller_dashboard.market_studio.tabs.disputes_reports")}</span>
            </button>
            <button
              onClick={() => setActiveTab("levels")}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === "levels" ? "bg-bento-accent text-black" : "text-neutral-500 hover:text-white hover:bg-white/5"} ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <Award size={18} />
              <span>{t("seller_dashboard.market_studio.tabs.levels_growth")}</span>
            </button>
          </nav>
        </div>

        <div className="mt-auto p-4 border-t border-bento-border">
          <button
            onClick={onClose}
            className={`w-full flex items-center justify-center gap-2 px-4 py-3 rounded-2xl font-black uppercase tracking-widest text-[10px] bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white transition-all ${dir === "rtl" ? "flex-row-reverse" : ""}`}
          >
            <X size={14} /> {t("seller_dashboard.market_studio.close")}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto no-scrollbar">
        {/* Mobile Header */}
        <div
          className={`md:hidden sticky top-0 z-40 bg-bento-bg/80 backdrop-blur-xl border-b border-bento-border p-4 flex items-center justify-between ${dir === "rtl" ? "flex-row-reverse" : ""}`}
        >
          <div
            className={`flex items-center gap-2 ${dir === "rtl" ? "flex-row-reverse" : ""}`}
          >
            <Store className="text-bento-accent" size={24} />
            <span className="font-black italic tracking-tighter uppercase text-sm">
              Market Studio
            </span>
          </div>
          <button onClick={onClose} className="p-2 bg-neutral-800 rounded-xl">
            <X size={20} />
          </button>
        </div>

        {/* Dynamic Content */}
        <div className="p-6 md:p-10 space-y-10">
          {loading ? (
            <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
              <div className="w-12 h-12 border-2 border-bento-accent border-t-transparent rounded-full animate-spin"></div>
              <p className="font-bold text-neutral-500 uppercase tracking-widest text-[10px]">
                {t("seller_dashboard.market_studio.loading")}
              </p>
            </div>
          ) : (
            <>
              {activeTab === "dashboard" && (
                <DashboardView
                  stats={storeAnalytics}
                  products={products}
                  orders={orders}
                  productAnalytics={productAnalytics}
                  profile={profile}
                  dir={dir}
                  setActiveTab={setActiveTab}
                />
              )}
              {activeTab === "products" && (
                <ProductsView
                  products={products}
                  pAnalytics={productAnalytics}
                  onSelect={(id) => {
                    setSelectedProductId(id);
                    setActiveTab("analytics");
                  }}
                  onDelete={onDeleteProduct}
                  dir={dir}
                />
              )}
              {activeTab === "analytics" && (
                <AnalyticsView
                  selectedId={selectedProductId}
                  products={products}
                  pAnalytics={productAnalytics}
                  storeAnalytics={storeAnalytics}
                />
              )}
              {activeTab === "revenue" && (
                <RevenueView
                  stats={storeAnalytics}
                  orders={orders}
                  profile={profile}
                />
              )}
              {activeTab === "orders" && <OrdersView orders={orders} />}
              {activeTab === "disputes" && (
                <DisputesView disputes={disputes} reports={reports} />
              )}
              {activeTab === "levels" && <LevelsView profile={profile} />}
            </>
          )}
        </div>
      </main>
    </div>
  );
}

// --- Views ---

const DashboardView = React.memo(({
  stats,
  products,
  orders,
  productAnalytics,
  profile,
  dir,
  setActiveTab,
}: any) => {
  const { t } = useTranslation();
  if (!stats) return null;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="mb-10 text-start">
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-2">
          {t("seller_dashboard.market_studio.overview.title")}
        </h2>
        <p className="text-neutral-500 text-sm font-medium">
          {t("seller_dashboard.market_studio.overview.subtitle")}
        </p>
      </header>

      {/* Summary Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-12">
        <div className="bg-neutral-900 border border-neutral-800 p-6 rounded-[32px] group hover:border-emerald-500/30 transition-all">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-emerald-500/10 text-emerald-500 rounded-2xl">
              <DollarSign size={20} />
            </div>
            <span className="text-[10px] font-black text-emerald-500 flex items-center gap-1">
              +12.5% <ArrowUp size={10} />
            </span>
          </div>
          <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-1">
            {t("seller_dashboard.market_studio.overview.total_revenue")}
          </p>
          <h3 className="text-2xl font-black italic tracking-tighter">
            ${stats.totalRevenue.toLocaleString()}
          </h3>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 p-6 rounded-[32px] group hover:border-blue-500/30 transition-all">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-blue-500/10 text-blue-500 rounded-2xl">
              <ShoppingBag size={20} />
            </div>
            <span className="text-[10px] font-black text-blue-500 flex items-center gap-1">
              +8.2% <ArrowUp size={10} />
            </span>
          </div>
          <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-1">
            {t("seller_dashboard.market_studio.overview.orders_count")}
          </p>
          <h3 className="text-2xl font-black italic tracking-tighter">
            {stats.totalOrders}
          </h3>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 p-6 rounded-[32px] group hover:border-amber-500/30 transition-all">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-amber-500/10 text-amber-500 rounded-2xl">
              <Eye size={20} />
            </div>
            <span className="text-[10px] font-black text-amber-500 flex items-center gap-1">
              +24% <ArrowUp size={10} />
            </span>
          </div>
          <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-1">
            {t("seller_dashboard.market_studio.overview.views")}
          </p>
          <h3 className="text-2xl font-black italic tracking-tighter">
            {stats.totalViews}
          </h3>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 p-6 rounded-[32px] group hover:border-purple-500/30 transition-all">
          <div className="flex justify-between items-start mb-4">
            <div className="p-3 bg-purple-500/10 text-purple-500 rounded-2xl">
              <Percent size={20} />
            </div>
            <span className="text-[10px] font-black text-neutral-500 flex items-center gap-1">
              -1.2% <ArrowDown size={10} />
            </span>
          </div>
          <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-1">
            {t("seller_dashboard.market_studio.overview.conversion_rate")}
          </p>
          <h3 className="text-2xl font-black italic tracking-tighter">
            {(stats.conversionRate * 100).toFixed(1)}%
          </h3>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Performance Chart */}
        <div className="lg:col-span-2 bg-neutral-900 border border-neutral-800 rounded-[40px] p-8">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-black italic flex items-center gap-2">
              <Activity size={18} className="text-bento-accent" />{" "}
              {t("seller_dashboard.market_studio.overview.sales_performance")}
            </h3>
            <select className="bg-black border border-neutral-800 rounded-xl px-4 py-2 text-[10px] font-black uppercase outline-none focus:border-bento-accent">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
            </select>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={[
                  { name: "1", v: 400 },
                  { name: "2", v: 300 },
                  { name: "3", v: 600 },
                  { name: "4", v: 800 },
                  { name: "5", v: 500 },
                  { name: "6", v: 900 },
                  { name: "7", v: 1200 },
                ]}
              >
                <defs>
                  <linearGradient id="colorV" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FFD700" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#FFD700" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="#333"
                />
                <XAxis
                  dataKey="name"
                  stroke="#555"
                  fontSize={10}
                  fontWeight="bold"
                />
                <YAxis stroke="#555" fontSize={10} fontWeight="bold" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#000",
                    border: "1px solid #333",
                    borderRadius: "12px",
                  }}
                  itemStyle={{ color: "#FFD700", fontWeight: "bold" }}
                />
                <Area
                  type="monotone"
                  dataKey="v"
                  stroke="#FFD700"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#colorV)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Channel Sources */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8">
          <h3 className="text-xl font-black italic mb-8 flex items-center gap-2">
            <Globe size={18} className="text-bento-accent" />{" "}
            {t("seller_dashboard.market_studio.overview.traffic_sources")}
          </h3>
          <div className="h-48 w-full mb-6">
            <ResponsiveContainer width="100%" height="100%">
              <RePieChart>
                <Pie
                  data={[
                    {
                      name: t(
                        "seller_dashboard.market_studio.overview.sources.home",
                      ),
                      value: 40,
                    },
                    {
                      name: t(
                        "seller_dashboard.market_studio.overview.sources.search",
                      ),
                      value: 30,
                    },
                    {
                      name: t(
                        "seller_dashboard.market_studio.overview.sources.direct",
                      ),
                      value: 20,
                    },
                    { name: "Other", value: 10 },
                  ]}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {[0, 1, 2, 3].map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={["#FFD700", "#FFBD00", "#FF9F00", "#FF8200"][index]}
                    />
                  ))}
                </Pie>
                <Tooltip />
              </RePieChart>
            </ResponsiveContainer>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-neutral-400 font-bold">
                <div className="w-2 h-2 rounded-full bg-bento-accent" />{" "}
                {t("seller_dashboard.market_studio.overview.sources.home")}
              </div>
              <span className="font-black">40%</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-neutral-400 font-bold">
                <div className="w-2 h-2 rounded-full bg-amber-500" />{" "}
                {t("seller_dashboard.market_studio.overview.sources.search")}
              </div>
              <span className="font-black">30%</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-neutral-400 font-bold">
                <div className="w-2 h-2 rounded-full bg-orange-500" />{" "}
                {t("seller_dashboard.market_studio.overview.sources.direct")}
              </div>
              <span className="font-black">20%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
        <div className="bg-black/40 border border-neutral-800 p-6 rounded-3xl">
          <p className="text-[9px] font-black uppercase tracking-widest text-neutral-600 mb-1">
            {t("seller_dashboard.market_studio.overview.net_profit")}
          </p>
          <h4 className="text-xl font-black italic tracking-tighter text-emerald-500">
            ${stats.totalProfit.toLocaleString()}
          </h4>
        </div>
        <div className="bg-black/40 border border-neutral-800 p-6 rounded-3xl">
          <p className="text-[9px] font-black uppercase tracking-widest text-neutral-600 mb-1">
            {t("seller_dashboard.market_studio.overview.active_products")}
          </p>
          <h4 className="text-xl font-black italic tracking-tighter text-white">
            {stats.totalProducts || products.length}
          </h4>
        </div>
        <div className="bg-black/40 border border-neutral-800 p-6 rounded-3xl">
          <p className="text-[9px] font-black uppercase tracking-widest text-neutral-600 mb-1">
            {t("seller_dashboard.market_studio.overview.followers")}
          </p>
          <h4 className="text-xl font-black italic tracking-tighter text-blue-500">
            {stats.totalFollowers}
          </h4>
        </div>
        <div className="bg-black/40 border border-neutral-800 p-6 rounded-3xl">
          <p className="text-[9px] font-black uppercase tracking-widest text-neutral-600 mb-1">
            {t("seller_dashboard.market_studio.overview.disputes")}
          </p>
          <h4 className="text-xl font-black italic tracking-tighter text-red-500">
            {stats.totalDisputes}
          </h4>
        </div>
      </div>

      {/* Store Power / Growth Pathway */}
      <section className="mb-12">
        <header className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-black italic uppercase tracking-tighter flex items-center gap-2">
            <Target size={20} className="text-emerald-500" />
            {t("seller_dashboard.market_studio.levels.title")}
          </h3>
          <button
            onClick={() => setActiveTab("levels")}
            className="text-[10px] font-black uppercase tracking-widest text-neutral-500 hover:text-white underline underline-offset-4"
          >
            {t("seller_dashboard.market_studio.levels.subtitle")}
          </button>
        </header>

        <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
            <Rocket size={120} />
          </div>

          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="flex-1 w-full">
              <div className="flex justify-between items-end mb-4">
                <div>
                  <p className="text-[10px] font-black uppercase text-neutral-500 tracking-widest mb-1">
                    {t("seller_dashboard.market_studio.store_power_status")}
                  </p>
                  <h4 className="text-2xl font-black italic tracking-tighter uppercase">
                    {profile?.sellerTier || "Beginner"}
                  </h4>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-black uppercase text-neutral-500 tracking-widest mb-1">
                    {t("seller_dashboard.market_studio.efficiency_score")}
                  </p>
                  <h4 className="text-2xl font-black italic tracking-tighter uppercase text-emerald-500">
                    {profile?.efficiencyScore || 94}%
                  </h4>
                </div>
              </div>

              <div className="h-4 bg-neutral-800 rounded-full overflow-hidden border border-neutral-700">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${((profile?.salesCount || 0) % 50) * 2}%` }}
                  className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400 relative"
                >
                  <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,0.1)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.1)_50%,rgba(255,255,255,0.1)_75%,transparent_75%,transparent)] bg-[length:1rem_1rem] animate-[move-bg_1s_linear_infinite]" />
                </motion.div>
              </div>

              <div className="flex justify-between items-center mt-4">
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-600">
                  {t("seller_dashboard.market_studio.level_progression")}
                </span>
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400 italic">
                  {50 - ((profile?.salesCount || 0) % 50)} Sales to Next Level
                </span>
              </div>
            </div>

            <div className="flex gap-4 w-full md:w-auto">
              <div className="p-4 bg-black/40 rounded-2xl border border-neutral-800 flex flex-col items-center justify-center min-w-[100px]">
                <span className="text-[9px] font-black uppercase text-neutral-600 mb-1">
                  {t("seller_dashboard.market_studio.retention")}
                </span>
                <span className="text-lg font-black italic text-white leading-none">
                  98.2%
                </span>
              </div>
              <div className="p-4 bg-black/40 rounded-2xl border border-neutral-800 flex flex-col items-center justify-center min-w-[100px]">
                <span className="text-[9px] font-black uppercase text-neutral-600 mb-1">
                  {t("seller_dashboard.market_studio.response_time")}
                </span>
                <span className="text-lg font-black italic text-white leading-none">
                  &lt; 2h
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust & Reputation Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-12">
        <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-black italic flex items-center gap-2">
                <ShieldCheck size={18} className="text-emerald-500" />{" "}
                {t("seller_dashboard.market_studio.reputation_trend")}
              </h3>
              <div
                className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${
                  profile?.trustStatus === "ACTIVE"
                    ? "bg-emerald-500/10 text-emerald-500"
                    : profile?.trustStatus === "WARNING"
                      ? "bg-amber-500/10 text-amber-500"
                      : profile?.trustStatus === "RISK"
                        ? "bg-red-500/10 text-red-500"
                        : "bg-neutral-800 text-neutral-400"
                }`}
              >
                {profile?.trustStatus || "ACTIVE"}
              </div>
            </div>

            <div className="flex items-center gap-8 mb-8">
              <div className="text-center">
                <p className="text-[9px] font-black uppercase text-neutral-500 tracking-widest mb-1">
                  {t("seller_dashboard.market_studio.levels.labels.rating_req")}
                </p>
                <div className="flex items-center gap-1">
                  <span className="text-4xl font-black italic">
                    {profile?.rating && profile.rating > 0 
                      ? profile.rating.toFixed(1) 
                      : t('seller.no_ratings')}
                  </span>
                  <div className="flex flex-col items-start">
                    <span
                      className={`${(profile?.deltaRating || 0) >= 0 ? "text-emerald-500" : "text-red-500"} text-[10px] font-black flex items-center`}
                    >
                      {(profile?.deltaRating || 0) >= 0 ? "+" : ""}
                      {(profile?.deltaRating || 0).toFixed(2)}
                      {(profile?.deltaRating || 0) >= 0 ? (
                        <ArrowUp size={8} />
                      ) : (
                        <ArrowDown size={8} />
                      )}
                    </span>
                    <div className="flex gap-0.5 mt-0.5">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          size={8}
                          fill={
                            s <= Math.round(profile?.rating || 0)
                              ? "#FFD700"
                              : "none"
                          }
                          stroke={
                            s <= Math.round(profile?.rating || 0)
                              ? "#FFD700"
                              : "#333"
                          }
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="h-12 w-px bg-neutral-800" />

              <div className="flex-1">
                <p className="text-[9px] font-black uppercase text-neutral-500 tracking-widest mb-3">
                  {t("seller_dashboard.market_studio.warnings")}
                </p>
                <div className="flex gap-2">
                  {[1, 2, 3].map((w) => (
                    <div
                      key={w}
                      className={`flex-1 h-2 rounded-full ${w <= (profile?.warningsCount || 0) ? "bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.3)]" : "bg-neutral-800"}`}
                    />
                  ))}
                </div>
                <p className="text-[9px] font-bold text-neutral-600 mt-2">
                  {profile?.warningsCount === 0
                    ? t("seller_dashboard.market_studio.clean_track_record")
                    : t("seller_dashboard.market_studio.warnings_active", { count: profile?.warningsCount })}
                </p>
              </div>
            </div>
          </div>

          <div
            className={`p-5 rounded-3xl border transition-all ${
              (profile?.deltaRating || 0) < -0.2
                ? "bg-red-500/5 border-red-500/20"
                : "bg-emerald-500/5 border-emerald-500/20"
            }`}
          >
            <div
              className={`flex items-center gap-3 mb-2 ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <Info
                size={16}
                className={
                  (profile?.deltaRating || 0) < -0.2
                    ? "text-red-500"
                    : "text-emerald-500"
                }
              />
              <span
                className={`text-[10px] font-black uppercase tracking-widest ${(profile?.deltaRating || 0) < -0.2 ? "text-red-500" : "text-emerald-500"}`}
              >
                {t("seller_dashboard.market_studio.market_advice")}
              </span>
            </div>
            <p className="text-[10px] font-bold text-neutral-400 italic leading-relaxed">
              {(profile?.deltaRating || 0) < -0.2
                ? t("seller_dashboard.market_studio.market_advice_negative")
                : t("seller_dashboard.market_studio.market_advice_positive")}
            </p>
          </div>
        </div>

        <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8 flex flex-col">
          <h3 className="text-xl font-black italic mb-8 flex items-center gap-2">
            <Target size={18} className="text-bento-accent" /> {t("seller_dashboard.market_studio.growth_pathway")}
          </h3>
          <div className="flex-1 space-y-6">
            <div>
              <div className="flex justify-between items-end mb-2">
                <span className="text-[9px] font-black uppercase text-neutral-500 tracking-widest">
                  {t("seller_dashboard.market_studio.store_power")}
                </span>
                <span className="text-xs font-black italic text-bento-accent">
                  78%
                </span>
              </div>
              <div className="h-2 bg-black rounded-full overflow-hidden border border-neutral-800">
                <div
                  className="h-full bg-bento-accent"
                  style={{ width: "78%" }}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-black/40 rounded-2xl border border-neutral-800">
                <p className="text-[8px] font-black uppercase text-neutral-600 mb-1">
                  {t("seller_dashboard.market_studio.retention")}
                </p>
                <h5 className="text-lg font-black italic">64%</h5>
              </div>
              <div className="p-4 bg-black/40 rounded-2xl border border-neutral-800">
                <p className="text-[8px] font-black uppercase text-neutral-600 mb-1">
                  {t("seller_dashboard.market_studio.response_time")}
                </p>
                <h5 className="text-lg font-black italic">2.4h</h5>
              </div>
            </div>

            <div className="flex-1 flex flex-col justify-end">
              <button
                onClick={() => setActiveTab("levels")}
                className="w-full bg-black/60 border border-neutral-800 hover:border-bento-accent hover:text-bento-accent transition-all py-4 rounded-2xl text-[9px] font-black uppercase tracking-widest"
              >
                {t("seller_dashboard.market_studio.view_levels_req")}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

const ProductsView = React.memo(({ products, pAnalytics, onSelect, onDelete, dir }: any) => {
  const { t } = useTranslation();
  
  const handleDelete = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    onDelete(product, e);
  };

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="text-start">
          <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-2">
            {t("seller_dashboard.market_studio.products.title")}
          </h2>
          <p className="text-neutral-500 text-sm font-medium">
            {t("seller_dashboard.market_studio.products.subtitle")}
          </p>
        </div>
        <div className="flex gap-4">
          <button className="bg-neutral-900 border border-neutral-800 p-3 rounded-2xl text-neutral-500 hover:text-white transition-all">
            <Filter size={18} />
          </button>
          <div className="relative">
            <Search
              size={16}
              className={`absolute inset-y-1/2 -translate-y-1/2 text-neutral-500 ${dir === 'rtl' ? 'right-4' : 'left-4'}`}
            />
            <input
              type="text"
              placeholder={t(
                "seller_dashboard.market_studio.products.search_placeholder",
              )}
              className={`bg-neutral-900 border border-neutral-800 rounded-2xl py-3 outline-none focus:border-bento-accent transition-all text-xs font-bold ${dir === 'rtl' ? 'pr-10 pl-4' : 'pl-10 pr-4'}`}
            />
          </div>
        </div>
      </header>

      {/* Mobile Card View */}
      <div className="grid grid-cols-1 gap-4 md:hidden mb-8">
        {products.map((p: Product, idx: number) => {
          const stats: ProductAnalytics = pAnalytics[p.id];
          return (
            <motion.div 
              key={`card-${p.id}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              className="bg-neutral-900 border border-neutral-800 rounded-[32px] p-5 flex flex-col gap-4 relative overflow-hidden group"
            >
              <div className="flex items-start gap-4">
                <img
                  src={p.imageUrl}
                  alt=""
                  className="w-20 h-20 rounded-2xl object-cover border border-neutral-800"
                />
                <div className="flex-1 text-start">
                  <h4 className="font-bold text-white text-lg leading-tight mb-1">{p.title}</h4>
                  <div className="text-xs font-black text-emerald-500 mb-2 truncate">${p.price}</div>
                  <div className="flex gap-2">
                    <span
                      className={`px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${
                        stats?.status === "active"
                          ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20"
                          : stats?.status === "low_performance"
                            ? "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                            : "bg-neutral-800 text-neutral-500 border border-neutral-700"
                      }`}
                    >
                      {stats?.status || t("seller_dashboard.status.active")}
                    </span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 py-3 border-y border-neutral-800/50">
                <div className="text-center">
                  <div className="text-[8px] font-black text-neutral-500 uppercase tracking-widest mb-1">{t("seller_dashboard.market_studio.products.table.views")}</div>
                  <div className="text-sm font-black">{stats?.productPageViews || 0}</div>
                </div>
                <div className="text-center">
                  <div className="text-[8px] font-black text-neutral-500 uppercase tracking-widest mb-1">{t("seller_dashboard.market_studio.products.table.orders")}</div>
                  <div className="text-sm font-black">{stats?.orders || 0}</div>
                </div>
                <div className="text-center">
                  <div className="text-[8px] font-black text-neutral-500 uppercase tracking-widest mb-1">{t("seller_dashboard.market_studio.products.table.revenue")}</div>
                  <div className="text-sm font-black text-emerald-500">${stats?.revenue || 0}</div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => onSelect(p.id)}
                  className="flex-1 bg-white/5 hover:bg-white/10 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2"
                >
                  <BarChart3 size={14} />
                  {t("seller_dashboard.market_studio.products.table.stats")}
                </button>
                <button 
                  onClick={(e) => handleDelete(p, e)}
                  className="w-12 h-12 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-xl transition-all flex items-center justify-center"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="hidden md:block bg-neutral-900 border border-neutral-800 rounded-[40px] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs">
            <thead>
              <tr className="border-b border-neutral-800 bg-black/20">
                <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-neutral-500 font-black">
                  {t("seller_dashboard.market_studio.products.table.product")}
                </th>
                <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-neutral-500 font-black">
                  {t("seller_dashboard.market_studio.products.table.status")}
                </th>
                <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-neutral-500 font-black">
                  {t("seller_dashboard.market_studio.products.table.views")}
                </th>
                <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-neutral-500 font-black">
                  {t("seller_dashboard.market_studio.products.table.orders")}
                </th>
                <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-neutral-500 font-black">
                  {t("seller_dashboard.market_studio.products.table.revenue")}
                </th>
                <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-neutral-500 font-black">
                  {t(
                    "seller_dashboard.market_studio.products.table.conversion",
                  )}
                </th>
                <th className="px-6 py-5 text-[10px] text-neutral-500 font-black">
                  {t("seller_dashboard.market_studio.products.table.stats")}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {products.map((p: Product, idx: number) => {
                const stats: ProductAnalytics = pAnalytics[p.id];
                return (
                  <tr
                    key={`${p.id}-${idx}`}
                    className="hover:bg-white/5 transition-colors group"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={p.imageUrl}
                          alt=""
                          className="w-10 h-10 rounded-lg object-cover border border-neutral-800 shadow-lg"
                        />
                        <div className="text-start">
                          <div className="font-bold text-white truncate max-w-[150px]">
                            {p.title}
                          </div>
                          <div className="text-[9px] text-neutral-600 font-black uppercase tracking-tighter mt-0.5">
                            ${p.price}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
                          stats?.status === "active"
                            ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20"
                            : stats?.status === "low_performance"
                              ? "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                              : "bg-neutral-800 text-neutral-500 border border-neutral-700"
                        }`}
                      >
                        {stats?.status || t("seller_dashboard.status.active")}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-black">
                      {stats?.productPageViews || 0}
                    </td>
                    <td className="px-6 py-4 font-black">
                      {stats?.orders || 0}
                    </td>
                    <td className="px-6 py-4 font-black text-emerald-500">
                      ${stats?.revenue?.toLocaleString() || "0"}
                    </td>
                    <td className="px-6 py-4 font-black">
                      {stats?.productPageViews
                        ? (
                            (stats.orders / stats.productPageViews) *
                            100
                          ).toFixed(1)
                        : 0}
                      %
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onSelect(p.id)}
                          className="p-2 bg-neutral-800 text-neutral-500 hover:bg-bento-accent hover:text-black rounded-lg transition-all opacity-0 group-hover:opacity-100"
                        >
                          <BarChart3 size={16} />
                        </button>
                        <button
                          onClick={(e) => handleDelete(p, e)}
                          className="p-2 bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white rounded-lg transition-all opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
});

const AnalyticsView = React.memo(({
  selectedId,
  products,
  pAnalytics,
  storeAnalytics,
}: any) => {
  const { t } = useTranslation();
  const product = products.find((p: any) => p.id === selectedId) || products[0];
  const stats = pAnalytics[product?.id];

  if (!product)
    return (
      <div className="p-10 text-center font-bold text-neutral-500">
        {t("seller_dashboard.no_products")}
      </div>
    );

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="mb-10 text-start">
        <div className="flex flex-wrap items-center gap-3 mb-2">
          <h2 className="text-3xl font-black italic uppercase tracking-tighter">
            {t("seller_dashboard.market_studio.analytics.title")}
          </h2>
          <div className="px-3 py-1 bg-neutral-900 border border-neutral-800 rounded-xl flex items-center gap-2">
            <img
              src={product.imageUrl}
              alt=""
              className="w-5 h-5 rounded object-cover"
            />
            <span className="text-xs font-black truncate max-w-[120px]">
              {product.title}
            </span>
          </div>
        </div>
        <p className="text-neutral-500 text-sm font-medium">
          {t("seller_dashboard.market_studio.analytics.subtitle")}
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
        <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] flex flex-col items-center gap-4">
          <div className="p-4 bg-bento-accent/10 text-bento-accent rounded-2xl">
            <Zap size={24} />
          </div>
          <div className="text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-1">
              {t("seller_dashboard.market_studio.analytics.impressions")}
            </p>
            <h3 className="text-4xl font-black italic tracking-tighter">
              {stats?.impressions}
            </h3>
            <span className="text-[9px] font-black text-emerald-500">
              +14% vs last week
            </span>
          </div>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] flex flex-col items-center gap-4">
          <div className="p-4 bg-orange-500/10 text-orange-500 rounded-2xl">
            <MousePointer2 size={24} />
          </div>
          <div className="text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-1">
              {t("seller_dashboard.market_studio.analytics.clicks")}
            </p>
            <h3 className="text-4xl font-black italic tracking-tighter">
              {(stats?.ctr * 100).toFixed(1)}%
            </h3>
            <span className="text-[9px] font-black text-red-500">
              -2.1% vs last week
            </span>
          </div>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] flex flex-col items-center gap-4">
          <div className="p-4 bg-red-500/10 text-red-500 rounded-2xl">
            <Heart size={24} />
          </div>
          <div className="text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-1">
              {t("seller_dashboard.market_studio.analytics.favorites")}
            </p>
            <h3 className="text-4xl font-black italic tracking-tighter">
              {stats?.favorites}
            </h3>
            <span className="text-[9px] font-black text-emerald-500">
              +5 new saves
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8">
          <h3 className="text-xl font-black italic mb-8 flex items-center gap-2">
            <ArrowRightLeft size={18} className="text-bento-accent" />{" "}
            {t("seller_dashboard.market_studio.analytics.funnel.title")}
          </h3>
          <div className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between text-[11px] font-black px-1 uppercase tracking-tighter">
                <span className="text-neutral-500">
                  {t("seller_dashboard.market_studio.analytics.funnel.views")}
                </span>
                <span>{stats?.productPageViews}</span>
              </div>
              <div className="h-2 bg-black rounded-full overflow-hidden border border-neutral-800">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 1 }}
                  className="h-full bg-blue-500"
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[11px] font-black px-1 uppercase tracking-tighter">
                <span className="text-neutral-500">
                  {t("seller_dashboard.market_studio.analytics.funnel.cart")}
                </span>
                <span>{stats?.cartAdds}</span>
              </div>
              <div className="h-2 bg-black rounded-full overflow-hidden border border-neutral-800">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{
                    width: `${(stats?.cartAdds / stats?.productPageViews) * 100}%`,
                  }}
                  transition={{ duration: 1, delay: 0.2 }}
                  className="h-full bg-amber-500"
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-[11px] font-black px-1 uppercase tracking-tighter">
                <span className="text-neutral-500">
                  {t(
                    "seller_dashboard.market_studio.analytics.funnel.completed",
                  )}
                </span>
                <span>{stats?.orders}</span>
              </div>
              <div className="h-2 bg-black rounded-full overflow-hidden border border-neutral-800">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{
                    width: `${(stats?.orders / stats?.productPageViews) * 100}%`,
                  }}
                  transition={{ duration: 1, delay: 0.4 }}
                  className="h-full bg-emerald-500"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8">
          <h3 className="text-xl font-black italic mb-6">
            {t("seller_dashboard.market_studio.analytics.revenue_performance")}
          </h3>
          <div className="space-y-4">
            <div className="p-4 bg-black/40 rounded-2xl flex justify-between items-center border border-neutral-800">
              <span className="text-xs font-bold text-neutral-500">
                {t("seller_dashboard.market_studio.overview.total_revenue")}
              </span>
              <span className="font-black text-sm">
                ${stats?.revenue.toLocaleString()}
              </span>
            </div>
{/* Commission item hidden as requested */}
            {/* <div className="p-4 bg-black/40 rounded-2xl flex justify-between items-center border border-neutral-800">
              <span className="text-xs font-bold text-neutral-500">
                {t("seller_dashboard.market_studio.analytics.commission")}
              </span>
              <span className="font-black text-sm text-red-500">
                -${stats?.commission.toLocaleString()}
              </span>
            </div> */}
            <div className="p-4 bg-emerald-500/10 rounded-2xl flex justify-between items-center border border-emerald-500/20">
              <span className="text-xs font-black text-emerald-500 uppercase tracking-widest">
                {t("seller_dashboard.market_studio.overview.net_profit")}
              </span>
              <span className="text-lg font-black italic text-emerald-400">
                ${stats?.netProfit.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
});

const RevenueView = React.memo(({ stats, orders, profile }: any) => {
  const { t } = useTranslation();
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="mb-10 text-start">
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-2">
          {t("seller_dashboard.market_studio.revenue.title")}
        </h2>
        <p className="text-neutral-500 text-sm font-medium">
          {t("seller_dashboard.market_studio.revenue.subtitle")}
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-12">
        <div className="lg:col-span-2 bg-gradient-to-br from-emerald-900/40 to-black border border-emerald-500/30 p-10 rounded-[48px] relative overflow-hidden group">
          <DollarSign
            className="absolute -right-6 -bottom-6 text-emerald-500/5 group-hover:scale-110 transition-transform"
            size={200}
          />
          <p className="text-[10px] font-black uppercase tracking-widest text-emerald-500 mb-4 flex items-center gap-2">
            <Wallet size={12} />{" "}
            {t("seller_dashboard.market_studio.revenue.withdrawable")}
          </p>
          <h3 className="text-6xl font-black italic tracking-tighter text-emerald-400 mb-12">
            ${profile?.withdrawableBalance?.toFixed(2) || "0.00"}
          </h3>
          <div className="flex gap-4">
            <button className="px-8 py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-neutral-100 transition-all flex items-center gap-2">
              <Calculator size={14} />{" "}
              {t("seller_dashboard.market_studio.revenue.withdraw")}
            </button>
            <button className="px-8 py-4 bg-neutral-900 text-white border border-neutral-800 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-neutral-800 transition-all">
              {t("seller_dashboard.market_studio.revenue.history")}
            </button>
          </div>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] flex flex-col justify-between">
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-2">
              {t("seller_dashboard.market_studio.revenue.net_profits")}
            </p>
            <h3 className="text-3xl font-black italic text-white">
              ${stats.totalProfit.toLocaleString()}
            </h3>
          </div>
          <div className="h-1 bg-neutral-800 rounded-full mt-8 overflow-hidden">
            <div className="h-full bg-emerald-500 w-[70%]" />
          </div>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px] flex flex-col justify-between">
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-neutral-500 mb-2">
              {t("seller_dashboard.market_studio.revenue.escrow")}
            </p>
            <h3 className="text-3xl font-black italic text-amber-500">
              ${(stats.totalRevenue - stats.totalProfit).toLocaleString()}
            </h3>
          </div>
          <p className="text-[9px] text-neutral-600 font-bold uppercase mt-4">
            {t("seller_dashboard.market_studio.revenue.escrow_desc")}
          </p>
        </div>
      </div>

      <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8">
        <h3 className="text-xl font-black italic mb-8 flex items-center gap-2">
          <History size={18} className="text-bento-accent" />{" "}
          {t("seller_dashboard.market_studio.revenue.recent_transactions")}
        </h3>
        <div className="space-y-4">
          {orders
            .filter((o: any) => o.status === "completed")
            .slice(0, 5)
            .map((order: Order, idx: number) => (
              <div
                key={`${order.id}-${idx}`}
                className="flex items-center justify-between p-4 bg-black/40 border border-neutral-800 rounded-2xl"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-emerald-500/10 text-emerald-500 rounded-xl flex items-center justify-center font-black">
                    +$
                  </div>
                  <div>
                    <div className="text-sm font-bold text-white">
                      {order.productTitle}
                    </div>
                    <div className="text-[9px] text-neutral-600 font-bold uppercase tracking-widest">
                      {t("profile.completed")} •{" "}
                      {order.createdAt?.toDate?.()?.toLocaleDateString() ||
                        "Today"}
                    </div>
                  </div>
                </div>
                <div className="text-start">
                  <div className="text-sm font-black text-emerald-500">
                    +${order.netAmount}
                  </div>
                  {/* Commission display hidden as requested */}
                  {/* <div className="text-[9px] text-neutral-600 font-bold uppercase">
                    {t("seller_dashboard.sales_commission")}: -$
                    {order.commission}
                  </div> */}
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
});

const OrdersView = React.memo(({ orders }: any) => {
  const { t } = useTranslation();
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="mb-10 text-start">
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-2">
          {t("seller_dashboard.market_studio.orders.title")}
        </h2>
        <p className="text-neutral-500 text-sm font-medium">
          {t("seller_dashboard.market_studio.orders.subtitle")}
        </p>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <div className="bg-neutral-900 p-6 rounded-3xl border border-neutral-800 text-center">
          <span className="text-2xl font-black italic text-amber-500">
            {
              orders.filter(
                (o: any) => o.status === "pending" || o.status === "processing",
              ).length
            }
          </span>
          <p className="text-[9px] font-black uppercase text-neutral-500 tracking-widest mt-1">
            {t("seller_dashboard.market_studio.orders.stats.new")}
          </p>
        </div>
        <div className="bg-neutral-900 p-6 rounded-3xl border border-neutral-800 text-center">
          <span className="text-2xl font-black italic text-blue-500">
            {
              orders.filter(
                (o: any) =>
                  o.status === "on_the_way" || o.status === "delivered",
              ).length
            }
          </span>
          <p className="text-[9px] font-black uppercase text-neutral-500 tracking-widest mt-1">
            {t("seller_dashboard.market_studio.orders.stats.shipping")}
          </p>
        </div>
        <div className="bg-neutral-900 p-6 rounded-3xl border border-neutral-800 text-center">
          <span className="text-2xl font-black italic text-emerald-500">
            {
              orders.filter(
                (o: any) =>
                  o.status === "completed" || o.status === "delivered",
              ).length
            }
          </span>
          <p className="text-[9px] font-black uppercase text-neutral-500 tracking-widest mt-1">
            {t("seller_dashboard.market_studio.orders.stats.success")}
          </p>
        </div>
        <div className="bg-neutral-900 p-6 rounded-3xl border border-neutral-800 text-center">
          <span className="text-2xl font-black italic text-red-500">
            {orders.filter((o: any) => o.status === "disputed").length}
          </span>
          <p className="text-[9px] font-black uppercase text-neutral-500 tracking-widest mt-1">
            {t("seller_dashboard.market_studio.orders.stats.disputes")}
          </p>
        </div>
      </div>

      <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs">
            <thead>
              <tr className="border-b border-neutral-800 bg-black/20">
                <th className="px-6 py-5 text-[10px] text-neutral-500 font-black uppercase tracking-widest">
                  {t("seller_dashboard.market_studio.orders.table.id")}
                </th>
                <th className="px-6 py-5 text-[10px] text-neutral-500 font-black uppercase tracking-widest">
                  {t("seller_dashboard.market_studio.orders.table.product")}
                </th>
                <th className="px-6 py-5 text-[10px] text-neutral-500 font-black uppercase tracking-widest">
                  {t("seller_dashboard.market_studio.orders.table.status")}
                </th>
                <th className="px-6 py-5 text-[10px] text-neutral-500 font-black uppercase tracking-widest">
                  {t("seller_dashboard.market_studio.orders.table.company")}
                </th>
                <th className="px-6 py-5 text-[10px] text-neutral-500 font-black uppercase tracking-widest">
                  {t("seller_dashboard.market_studio.orders.table.tracking")}
                </th>
                <th className="px-6 py-5 text-[10px] text-neutral-500 font-black uppercase tracking-widest">
                  {t("seller_dashboard.market_studio.orders.table.action")}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {orders.map((o: Order, idx: number) => (
                <tr key={`${o.id}-${idx}`} className="hover:bg-white/5 transition-colors">
                  <td className="px-6 py-4 font-black text-neutral-500">
                    #{o.id.slice(0, 8)}
                  </td>
                  <td className="px-6 py-4 font-bold text-white max-w-[150px] truncate">
                    {o.productTitle}
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest ${
                        o.status === "completed"
                          ? "bg-emerald-500/10 text-emerald-500"
                          : o.status === "on_the_way" ||
                              o.status === "delivered"
                            ? "bg-blue-500/10 text-blue-500"
                            : "bg-amber-500/10 text-amber-500"
                      }`}
                    >
                      {o.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-neutral-400 font-bold">
                    {o.shippingMethod}
                  </td>
                  <td className="px-6 py-4 text-neutral-400 font-mono text-[10px]">
                    {o.trackingCode || "---"}
                  </td>
                  <td className="px-6 py-4">
                    <button className="px-4 py-2 bg-neutral-800 hover:bg-bento-accent hover:text-black rounded-lg font-black uppercase tracking-widest text-[9px] transition-all whitespace-nowrap">
                      {t("seller_dashboard.market_studio.orders.update_status")}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
});

const DisputesView = React.memo(({ disputes, reports }: any) => {
  const { t } = useTranslation();
  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="mb-10 text-start">
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-2">
          {t("seller_dashboard.market_studio.disputes.title")}
        </h2>
        <p className="text-neutral-500 text-sm font-medium">
          {t("seller_dashboard.market_studio.disputes.subtitle")}
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Active Disputes */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8">
          <h3 className="text-xl font-black italic mb-8 flex items-center gap-2">
            <ShieldAlert size={18} className="text-red-500" />{" "}
            {t("seller_dashboard.market_studio.disputes.active")}
          </h3>
          <div className="space-y-4">
            {disputes.length === 0 ? (
              <div className="py-12 text-center text-neutral-600 text-[10px] font-black uppercase border border-dashed border-neutral-800 rounded-3xl">
                {t("seller_dashboard.market_studio.disputes.no_disputes")}
              </div>
            ) : (
              disputes.map((d: Dispute, idx: number) => (
                <div
                  key={`${d.id}-${idx}`}
                  className="p-5 bg-black/40 border border-neutral-800 rounded-2xl flex justify-between items-start"
                >
                  <div className="text-start">
                    <div className="text-[10px] font-black text-red-500 uppercase tracking-widest mb-1">
                      {d.reason}
                    </div>
                    <div className="text-sm font-bold text-white mb-2">
                      {t("seller_dashboard.market_studio.disputes.order_id")}: #
                      {d.orderId?.slice(0, 8)}
                    </div>
                    <p className="text-[10px] text-neutral-500 leading-relaxed max-w-[200px]">
                      {d.description}
                    </p>
                  </div>
                  <span className="px-2 py-0.5 bg-red-500/10 text-red-500 border border-red-500/20 rounded-lg text-[9px] font-black uppercase">
                    {d.status}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Reports */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-[40px] p-8">
          <h3 className="text-xl font-black italic mb-8 flex items-center gap-2">
            <Flag size={18} className="text-amber-500" />{" "}
            {t("seller_dashboard.market_studio.disputes.reports")}
          </h3>
          <div className="space-y-4">
            {reports.length === 0 ? (
              <div className="py-12 text-center text-neutral-600 text-[10px] font-black uppercase border border-dashed border-neutral-800 rounded-3xl">
                {t("seller_dashboard.market_studio.disputes.clean_history")}
              </div>
            ) : (
              reports.map((r: any, idx: number) => (
                <div
                  key={`${r.id}-${idx}`}
                  className="p-5 bg-black/40 border border-neutral-800 rounded-2xl flex items-center gap-4"
                >
                  <div className="p-3 bg-amber-500/10 text-amber-500 rounded-xl">
                    <AlertCircle size={18} />
                  </div>
                  <div className="flex-1 text-start">
                    <div className="text-sm font-bold text-white">
                      {r.reason}
                    </div>
                    <div className="text-[9px] text-neutral-600 font-bold uppercase tracking-widest">
                      {t("seller_dashboard.market_studio.disputes.report_type")}
                      : {r.targetType} • {r.status}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
});

const LevelsView = React.memo(({ profile }: any) => {
  const { t } = useTranslation();
  const { dir } = useLanguage();
  const rating = (profile?.sellerProfile?.rating && profile.sellerProfile.rating > 0) ? profile.sellerProfile.rating : 0;
  const currentLevel = profile?.sellerProfile?.level || 1;
  const sales = profile?.salesCount || 0;
  const revenue = profile?.totalEarnings || 0;

  // Levels Logic
  const levelRequirements = [
    {
      level: 1,
      sales: 0,
      revenue: 0,
      label: t("seller_dashboard.market_studio.levels.labels.beginner"),
      benefits: ["standard_support", "limit_5", "withdrawal_0"],
    },
    {
      level: 2,
      sales: 15,
      revenue: 300,
      label: t("seller_dashboard.market_studio.levels.labels.rising_star"),
      benefits: ["priority_support", "analytics", "withdrawal_0"],
    },
    {
      level: 3,
      sales: 50,
      revenue: 1500,
      label: t("seller_dashboard.market_studio.levels.labels.premium"),
      benefits: ["account_manager", "custom_store", "withdrawal_0"],
    },
    {
      level: 4,
      sales: 150,
      revenue: 5000,
      label: t("seller_dashboard.market_studio.levels.labels.expert"),
      benefits: ["featured_products", "instant_payout", "withdrawal_0"],
    },
    {
      level: 5,
      sales: 500,
      revenue: 20000,
      label: t("seller_dashboard.market_studio.levels.labels.brand_expert"),
      benefits: ["verified_badge", "unlimited_products", "withdrawal_0"],
    },
  ];

  const nextLvl = levelRequirements[currentLevel] || levelRequirements[3];
  const salesProgress = Math.min(100, (sales / nextLvl.sales) * 100) || 0;
  const revenueProgress = Math.min(100, (revenue / nextLvl.revenue) * 100) || 0;

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="mb-10 text-start">
        <h2 className="text-3xl font-black italic uppercase tracking-tighter mb-2">
          {t("seller_dashboard.market_studio.levels.title")}
        </h2>
        <p className="text-neutral-500 text-sm font-medium">
          {t("seller_dashboard.market_studio.levels.subtitle")}
        </p>
      </header>

      <div className="bg-neutral-900 border border-neutral-800 rounded-[48px] p-10 relative overflow-hidden mb-12">
        <Award
          className="absolute -left-10 -bottom-10 text-bento-accent/5"
          size={250}
        />

        <div className="relative z-10">
          <div
            className={`flex items-center gap-6 mb-12 ${dir === "rtl" ? "flex-row-reverse" : ""}`}
          >
            <div className="w-20 h-20 bg-bento-accent text-black rounded-[28px] flex items-center justify-center font-black text-3xl shadow-xl shadow-bento-accent/20 italic">
              {currentLevel}
            </div>
            <div className="text-start">
              <h3 className="text-4xl font-black italic tracking-tighter text-white uppercase mb-1">
                {profile?.sellerProfile?.type === "brand"
                  ? t(
                      "seller_dashboard.market_studio.levels.labels.brand_expert",
                    )
                  : levelRequirements[currentLevel - 1]?.label}
              </h3>
              <span className="text-[10px] font-black bg-white/10 px-4 py-1.5 rounded-full uppercase tracking-widest text-neutral-400 border border-white/5">
                {t("seller_dashboard.market_studio.levels.current_level")}{" "}
                {currentLevel}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-4">
              <div
                className={`flex justify-between items-end mb-2 ${dir === "rtl" ? "flex-row-reverse" : ""}`}
              >
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500">
                  {t("seller_dashboard.market_studio.levels.sales")}
                </span>
                <span className="font-black text-sm italic">
                  {sales} / {nextLvl.sales}{" "}
                  {t(
                    "seller_dashboard.market_studio.orders.title",
                  ).toLowerCase()}
                </span>
              </div>
              <div className="h-4 bg-black rounded-full overflow-hidden border border-neutral-800">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${salesProgress}%` }}
                  transition={{ duration: 1.5 }}
                  className="h-full bg-emerald-500"
                />
              </div>
              <p
                className={`text-[10px] font-bold text-neutral-600 ${dir === "rtl" ? "text-right" : "text-left"}`}
              >
                {t("seller_dashboard.market_studio.levels.sales_needed", {
                  count: Math.max(0, nextLvl.sales - sales),
                })}
              </p>
            </div>
            <div className="space-y-4">
              <div
                className={`flex justify-between items-end mb-2 ${dir === "rtl" ? "flex-row-reverse" : ""}`}
              >
                <span className="text-[10px] font-black uppercase tracking-widest text-neutral-500">
                  {t("seller_dashboard.market_studio.levels.revenue")}
                </span>
                <span className="font-black text-sm italic">
                  ${revenue.toLocaleString()} / $
                  {nextLvl.revenue.toLocaleString()}
                </span>
              </div>
              <div className="h-4 bg-black rounded-full overflow-hidden border border-neutral-800">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${revenueProgress}%` }}
                  transition={{ duration: 1.5, delay: 0.2 }}
                  className="h-full bg-blue-500"
                />
              </div>
              <p
                className={`text-[10px] font-bold text-neutral-600 ${dir === "rtl" ? "text-right" : "text-left"}`}
              >
                {t("seller_dashboard.market_studio.levels.revenue_needed", {
                  amount: Math.max(
                    0,
                    nextLvl.revenue - revenue,
                  ).toLocaleString(),
                })}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px]">
          <h4 className="text-xl font-black italic mb-6">
            {t("seller_dashboard.market_studio.levels.next_level_benefits")}
          </h4>
          <ul className="space-y-4">
            {nextLvl.benefits.map((benefit: string, i: number) => (
              <li
                key={`${benefit}-${i}`}
                className={`flex items-center gap-3 ${dir === "rtl" ? "flex-row-reverse" : ""}`}
              >
                <div className="w-5 h-5 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center shrink-0">
                  <Check size={12} />
                </div>
                <span className="text-xs font-bold text-neutral-400">
                  {t(`seller.benefits.${benefit}`)}
                </span>
              </li>
            ))}
          </ul>
        </div>
        <div className="bg-neutral-900 border border-neutral-800 p-8 rounded-[40px]">
          <h4 className="text-xl font-black italic mb-6">
            {t("seller_dashboard.market_studio.levels.tips_title")}
          </h4>
          <div className="p-6 bg-bento-accent/5 border border-bento-accent/20 rounded-3xl">
            <div
              className={`flex items-center gap-2 mb-3 text-bento-accent ${dir === "rtl" ? "flex-row-reverse" : ""}`}
            >
              <Info size={16} />
              <span className="text-xs font-black uppercase">
                {t("seller_dashboard.market_studio.levels.quick_analysis")}
              </span>
            </div>
            <p className="text-[10px] font-medium leading-relaxed italic text-neutral-400">
              {t("seller_dashboard.market_studio.levels.tips.low_conversion")}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
});
