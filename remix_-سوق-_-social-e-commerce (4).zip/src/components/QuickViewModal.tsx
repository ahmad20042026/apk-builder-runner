import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingCart, Heart, MessageCircle, X, ShieldCheck, BadgeCheck, Zap } from 'lucide-react';
import { Product } from '../types';
import { Link } from 'react-router-dom';

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onLike?: (product: Product) => void;
  isLiked?: boolean;
}

export default function QuickViewModal({ product, isOpen, onClose, onLike, isLiked = false }: QuickViewModalProps) {
  if (!product) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 cursor-pointer"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-4xl bg-neutral-900 rounded-3xl overflow-hidden shadow-2xl border border-neutral-800 flex flex-col md:flex-row max-h-[90vh]"
          >
            {/* Close Button */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 z-10 w-10 h-10 bg-black/50 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-black transition-all"
            >
              <X size={20} />
            </button>

            {/* Image Section */}
            <div className="w-full md:w-1/2 h-[40vh] md:h-auto relative bg-black">
              {product.imageUrl ? (
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full bg-neutral-800 flex items-center justify-center">
                  <ShoppingCart size={64} className="text-neutral-600" />
                </div>
              )}
            </div>

            {/* Details Section */}
            <div className="w-full md:w-1/2 p-6 md:p-8 flex flex-col justify-between overflow-y-auto">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Link to={`/profile/${product.sellerId}`} onClick={onClose} className="flex items-center gap-2 group">
                    <img
                      src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${product.sellerId}`}
                      alt=""
                      className="w-8 h-8 rounded-full border border-neutral-700 group-hover:border-bento-accent transition-all"
                    />
                    <div className="flex flex-col">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-neutral-300 group-hover:text-white transition-all">@{product.sellerName}</span>
                        {product.sellerIsVerified && <BadgeCheck size={12} className="text-bento-accent" />}
                      </div>
                    </div>
                  </Link>
                </div>

                <h2 className="text-2xl md:text-3xl font-black uppercase tracking-tighter text-white mb-2 leading-tight">
                  {product.title}
                </h2>
                
                <div className="inline-block bg-bento-accent text-black font-black px-3 py-1 rounded-lg text-sm mb-6">
                  ${product.price}
                </div>

                <p className="text-neutral-400 text-sm leading-relaxed mb-6">
                  {product.description}
                </p>

                <div className="grid grid-cols-2 gap-4 mb-6 relative">
                  <div className="bg-neutral-800/50 rounded-2xl p-4 border border-neutral-800">
                    <div className="text-xs text-neutral-500 font-bold mb-1 uppercase tracking-widest">Category</div>
                    <div className="text-white font-medium">{product.category || 'General'}</div>
                  </div>
                  <div className="bg-neutral-800/50 rounded-2xl p-4 border border-neutral-800">
                    <div className="text-xs text-neutral-500 font-bold mb-1 uppercase tracking-widest">Stock</div>
                    <div className="text-white font-medium">{product.stockQuantity || 1} available</div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 mt-6 pt-6 border-t border-neutral-800">
                <Link
                  to={`/product/${product.id}`}
                  onClick={onClose}
                  className="flex-1 bg-white text-black font-black uppercase tracking-widest py-4 rounded-2xl hover:bg-neutral-200 transition-all flex items-center justify-center gap-2"
                >
                  <ShoppingCart size={18} />
                  View Full Details
                </Link>
                
                {onLike && (
                  <button
                    onClick={() => onLike(product)}
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center border transition-all ${
                      isLiked 
                        ? 'bg-red-500/20 border-red-500 text-red-500' 
                        : 'bg-neutral-800 border-neutral-700 text-white hover:bg-neutral-700'
                    }`}
                  >
                    <Heart size={20} fill={isLiked ? "currentColor" : "none"} />
                  </button>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
