// @ts-nocheck
import React, { Component, ErrorInfo, ReactNode } from 'react';

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
  }

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black text-red-500 p-8 flex flex-col items-start justify-center overflow-auto font-mono text-sm leading-relaxed whitespace-pre-wrap">
          <h1 className="text-2xl font-bold mb-4 text-white">App Crashed</h1>
          <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-xl w-full max-w-4xl">
            <h2 className="text-red-400 font-bold mb-2">Error:</h2>
            <p>{this.state.error?.toString()}</p>
          </div>
          {this.state.errorInfo && (
            <div className="bg-neutral-900 border border-neutral-800 p-4 rounded-xl mt-4 w-full max-w-4xl opacity-80">
              <h2 className="text-neutral-400 font-bold mb-2">Component Stack:</h2>
              <p>{this.state.errorInfo.componentStack}</p>
            </div>
          )}
        </div>
      );
    }

    return this.props.children;
  }
}

