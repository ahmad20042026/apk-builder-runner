import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useUpload, UploadTask } from '../context/UploadContext';
import { useLanguage } from '../context/LanguageContext';
import { CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

export function GlobalProgressBar() {
  const { activeUploads } = useUpload();
  const { dir } = useLanguage();
  
  const uploads = Object.values(activeUploads) as UploadTask[];
  if (uploads.length === 0) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[100] pointer-events-none p-4 space-y-2">
      <AnimatePresence>
        {uploads.map((upload) => (
          <motion.div
            key={upload.id}
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="max-w-md mx-auto pointer-events-auto bg-black/90 border border-white/10 backdrop-blur-xl rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {upload.status === 'uploading' && (
                  <div className="relative">
                    <Loader2 size={18} className="text-bento-accent animate-spin" />
                    <div className="absolute inset-0 bg-bento-accent/20 blur-sm rounded-full" />
                  </div>
                )}
                {upload.status === 'completed' && <CheckCircle2 size={18} className="text-emerald-500" />}
                {upload.status === 'error' && <AlertCircle size={18} className="text-red-500" />}
                
                <div className="flex flex-col">
                  <span className="text-[10px] font-black uppercase tracking-widest text-neutral-400">
                    {upload.status === 'uploading' ? (dir === 'rtl' ? 'جاري النشر...' : 'Publishing...') : 
                     upload.status === 'completed' ? (dir === 'rtl' ? 'تم النشر بنجاح' : 'Published Successfully') :
                     (dir === 'rtl' ? 'فشل النشر' : 'Publishing Failed')}
                  </span>
                  <span className="text-xs font-bold text-white">
                    {upload.status === 'error' ? upload.message : 
                     `${Math.round(upload.progress)}% ${dir === 'rtl' ? 'مكتمل' : 'Complete'}`}
                  </span>
                </div>
              </div>

              {upload.status === 'uploading' && (
                <div className="relative w-16 h-1 w-24 bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    className="absolute inset-y-0 left-0 bg-bento-accent"
                    initial={{ width: 0 }}
                    animate={{ width: `${upload.progress}%` }}
                    transition={{ ease: "linear" }}
                  />
                </div>
              )}
            </div>
            
            {/* Visual dynamic progress bar at the very bottom edge */}
            {upload.status === 'uploading' && (
              <motion.div 
                className="h-1 bg-bento-accent/50"
                initial={{ width: 0 }}
                animate={{ width: `${upload.progress}%` }}
                transition={{ ease: "linear" }}
              />
            )}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
