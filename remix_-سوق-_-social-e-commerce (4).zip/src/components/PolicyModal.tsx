import React from 'react';
import { X, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { POLICIES } from '../constants/policies';

interface PolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  type?: 'buyer' | 'seller';
}

export default function PolicyModal({ isOpen, onClose, type = 'buyer' }: PolicyModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[100] md:p-10 p-4"
          />
          
          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="fixed inset-x-4 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 top-10 bottom-10 md:w-full md:max-w-3xl bg-neutral-900 border border-neutral-800 rounded-[40px] z-[110] overflow-hidden flex flex-col font-ar"
          >
            <div className="p-6 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/50 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-bento-accent/10 text-bento-accent rounded-xl">
                  <ShieldCheck size={24} />
                </div>
                <div>
                  <h2 className="text-xl font-black italic tracking-tighter uppercase text-white">Policies & Terms</h2>
                  <p className="text-[10px] text-neutral-500 font-black uppercase tracking-widest">سياسات وشروط تريند فاي</p>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-2 bg-neutral-800 text-neutral-400 hover:text-white rounded-xl transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-8 space-y-10 no-scrollbar pb-20">
              <div className="text-center mb-12">
                <h3 className="text-2xl font-black italic mb-2">{POLICIES.TITLE}</h3>
                <div className="h-1 w-20 bg-bento-accent mx-auto rounded-full"></div>
              </div>

              {POLICIES.SECTIONS.map((section, idx) => (
                <div key={idx} className="space-y-4 text-right">
                  <h4 className="text-lg font-black text-bento-accent flex items-center justify-end gap-2">
                    {section.title}
                  </h4>
                  <div className="text-neutral-300 text-sm leading-relaxed whitespace-pre-wrap font-medium">
                    {section.content}
                  </div>
                  {idx < POLICIES.SECTIONS.length - 1 && (
                    <div className="h-px bg-neutral-800/50 mt-8" />
                  )}
                </div>
              ))}
            </div>

            <div className="p-6 border-t border-neutral-800 bg-neutral-900/80 backdrop-blur-xl">
              <button 
                onClick={onClose}
                className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-bento-accent transition-all shadow-xl shadow-white/5"
              >
                لقد قرأت وفهمت الشروط
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
