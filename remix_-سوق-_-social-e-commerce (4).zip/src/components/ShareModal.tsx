import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Share2, Link as LinkIcon, Facebook, MessageCircle, X, Check } from 'lucide-react';
import { Product } from '../types';
import { useTranslation } from 'react-i18next';
import { useLanguage } from '../context/LanguageContext';

interface ShareModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

// X (formerly Twitter) Icon component
const XIcon = ({ size = 20 }: { size?: number }) => (
  <svg 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="currentColor"
  >
    <path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932 6.064-6.932zm-1.294 19.497h2.039L6.482 3.239H4.293L17.607 20.65z" />
  </svg>
);

export default function ShareModal({ product, isOpen, onClose }: ShareModalProps) {
  const [copied, setCopied] = useState(false);
  const { t } = useTranslation();
  const { dir } = useLanguage();

  if (!product) return null;

  const url = `${window.location.origin}/product/${product.id}`;
  const encodedUrl = encodeURIComponent(url);
  const text = encodeURIComponent(`Check out ${product.title} on سوق!`);

  const shareOptions = [
    {
      name: 'X',
      icon: XIcon,
      color: 'bg-white text-black hover:bg-neutral-200',
      href: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${text}`,
    },
    {
      name: 'Facebook',
      icon: Facebook,
      color: 'bg-[#1877F2] text-white hover:bg-[#0d65d9]',
      href: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    },
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'bg-[#25D366] text-white hover:bg-[#1da851]',
      href: `https://wa.me/?text=${text}%20${encodedUrl}`,
    },
  ];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[200] flex items-end sm:items-center justify-center p-4"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed bottom-0 sm:bottom-auto left-0 sm:left-1/2 sm:-translate-x-1/2 w-full sm:max-w-md bg-neutral-900 sm:rounded-[40px] rounded-t-[40px] overflow-hidden shadow-2xl border-t sm:border border-white/5 z-[201] pointer-events-auto"
          >
            <div className="p-8">
              <div className={`flex items-center justify-between mb-8 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                <div className={`flex items-center gap-3 ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <div className="w-10 h-10 bg-bento-accent/10 rounded-2xl flex items-center justify-center text-bento-accent">
                    <Share2 size={20} />
                  </div>
                  <h3 className="text-xl font-black italic tracking-tighter uppercase text-white">
                    {t('common.share')}
                  </h3>
                </div>
                <button
                  onClick={onClose}
                  className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Product preview */}
              <div className={`flex gap-4 items-center mb-8 p-4 rounded-3xl bg-white/5 border border-white/5 ${dir === 'rtl' ? 'flex-row-reverse text-right' : ''}`}>
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  className="w-16 h-16 rounded-2xl object-cover ring-1 ring-white/10"
                />
                <div className="flex-1 overflow-hidden">
                  <h4 className="text-white font-bold truncate text-sm">{product.title}</h4>
                  <p className="text-bento-accent text-xs font-black italic mt-1 uppercase tracking-tighter">
                   {product.price} {t('product_details.currency')}
                  </p>
                </div>
              </div>

              {/* Social options */}
              <div className="flex justify-center gap-6 mb-8">
                {shareOptions.map((option) => (
                  <a
                    key={option.name}
                    href={option.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-14 h-14 rounded-full flex items-center justify-center transition-all hover:scale-110 active:scale-95 shadow-xl ${option.color}`}
                    title={option.name}
                  >
                    <option.icon size={22} />
                  </a>
                ))}
              </div>

              {/* Copy Link */}
              <div className="relative group">
                <div className={`flex items-center bg-black/40 rounded-3xl p-1.5 border border-white/5 group-hover:border-white/10 transition-all ${dir === 'rtl' ? 'flex-row-reverse' : ''}`}>
                  <div className="flex-1 overflow-hidden px-4">
                    <p className="text-[10px] font-mono text-neutral-500 truncate leading-none">
                      {url}
                    </p>
                  </div>
                  <button
                    onClick={handleCopy}
                    className={`shrink-0 flex items-center justify-center gap-2 h-11 px-6 rounded-[20px] font-black uppercase tracking-widest text-[10px] transition-all ${
                      copied
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-white text-black hover:bg-bento-accent transition-all'
                    }`}
                  >
                    {copied ? (
                      <>
                        <Check size={14} />
                        {t('product_details.copied')}
                      </>
                    ) : (
                      <>
                        <LinkIcon size={14} />
                        {dir === 'rtl' ? 'نسخ الرابط' : 'Copy Link'}
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
            
            {/* Modal Pull handle (decoration) */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 w-10 h-1 bg-white/10 rounded-full" />
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
