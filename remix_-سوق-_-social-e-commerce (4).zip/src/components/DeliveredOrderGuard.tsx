import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { db, collection, query, where, onSnapshot, doc, updateDoc, serverTimestampResilient as serverTimestamp, incrementResilient as increment, runTransaction } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Package, CheckCircle2, ShieldCheck, Clock, ArrowRight, ShoppingBag } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function DeliveredOrderGuard({ children }: { children: React.ReactNode }) {
  const { user, profile } = useAuth();
  const [pendingDeliveredOrder, setPendingDeliveredOrder] = useState<any>(null);
  const [confirming, setConfirming] = useState(false);

  useEffect(() => {
    if (!user) {
      setPendingDeliveredOrder(null);
      return;
    }

    // Check for delivered orders that are NOT yet completed/confirmed
    const q = query(
      collection(db, 'orders'),
      where('buyerId', '==', user.uid),
      where('status', '==', 'delivered')
    );

    const unsubscribe = onSnapshot(q, (snap) => {
      if (!snap.empty) {
        // Find the first one that needs confirmation
        const order = { id: snap.docs[0].id, ...snap.docs[0].data() };
        setPendingDeliveredOrder(order);
      } else {
        setPendingDeliveredOrder(null);
      }
    });

    return () => unsubscribe();
  }, [user]);

  const confirmReceipt = async (order: any) => {
    if (confirming) return;
    setConfirming(true);
    try {
      await runTransaction(db, async (transaction) => {
        const orderRef = doc(db, 'orders', order.id);
        const sellerRef = doc(db, 'users', order.sellerId);
        
        const orderDoc = await transaction.get(orderRef);
        if (!orderDoc.exists() || orderDoc.data()?.status !== 'delivered') {
          return;
        }

        // 1. Update Order status
        transaction.update(orderRef, {
          status: 'completed',
          confirmedAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });

        // 2. Transfer funds to seller wallet
        const finalAmount = order.price - (order.deliveryFee || 0);
        transaction.update(sellerRef, {
          walletBalance: increment(finalAmount),
          totalEarnings: increment(finalAmount),
          updatedAt: serverTimestamp()
        });
      });
      
      // Notify seller
      // (This usually happens via functions or just after transaction)
    } catch (err) {
      console.error("Confirmation failed:", err);
    } finally {
      setConfirming(false);
    }
  };

  if (!pendingDeliveredOrder) return <>{children}</>;

  return (
    <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center p-8 text-center overscroll-none" dir="rtl">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-from)_0%,_transparent_70%)] from-bento-accent/10 opacity-30" />
        
        <motion.div 
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="relative z-10 w-full max-w-lg bg-[#0A0A0A] border border-white/10 rounded-[64px] p-12 shadow-[0_0_100px_rgba(0,0,0,1)]"
        >
            <div className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-[0_0_60px_rgba(16,185,129,0.3)]">
                <Package size={48} className="text-black" />
            </div>

            <h2 className="text-3xl font-black italic tracking-tighter uppercase mb-4 text-white">يجب تأكيد الاستلام</h2>
            <p className="text-neutral-500 text-[10px] font-black uppercase tracking-widest mb-10 leading-loose mx-auto max-w-xs">
                لقد وصل طلبك بنجاح! يرجى تأكيد استلام المنتجات لإخلاء طرف المندوب وتحويل المبلغ للبائع. لا يمكنك تصفح التطبيق قبل إنهاء هذه الخطوة.
            </p>

            <div className="bg-white/5 rounded-3xl p-6 mb-10 border border-white/5 flex items-center gap-6">
                <div className="w-16 h-16 bg-neutral-900 rounded-2xl overflow-hidden border border-white/5">
                    <img src={pendingDeliveredOrder.items?.[0]?.imageUrl} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="flex-1 text-right">
                    <div className="font-black italic text-white">{pendingDeliveredOrder.items?.[0]?.title}</div>
                    <div className="text-[10px] text-neutral-500 font-bold uppercase mt-1">المبلغ المطلوب: ${pendingDeliveredOrder.price}</div>
                </div>
            </div>

            <button 
                onClick={() => confirmReceipt(pendingDeliveredOrder)}
                disabled={confirming}
                className="w-full py-6 bg-bento-accent text-black rounded-[32px] font-black uppercase tracking-widest text-sm hover:scale-105 active:scale-95 transition-all shadow-xl shadow-bento-accent/20 flex items-center justify-center gap-3 disabled:opacity-50"
            >
                {confirming ? <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" /> : <>تأكيد استلام المنتجات <CheckCircle2 size={24} /></>}
            </button>

            <div className="mt-8 flex items-center justify-center gap-2 text-emerald-500/60">
                <ShieldCheck size={16} />
                <span className="text-[9px] font-black uppercase tracking-[0.2em]">SOUQ SECURE VAULT PROTECTED</span>
            </div>
        </motion.div>
        
        {/* Force some interaction if user tries to close? No, this is a full-screen guard. */}
    </div>
  );
}
