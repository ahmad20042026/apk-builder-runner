import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { useTranslation } from 'react-i18next';
import { db, updateDoc, doc, serverTimestampResilient as serverTimestamp } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Package, Truck, MapPin, CheckCircle, QrCode, Navigation, Shield, Smartphone, MessageCircle, Send, CheckCircle2, AlertCircle, X, Sparkles, Check } from 'lucide-react';
import { ActivationService } from '../services/ActivationService';

interface CourierApplicationPortalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (message: string) => void;
}

export default function CourierApplicationPortal({ isOpen, onClose, onSuccess }: CourierApplicationPortalProps) {
  const { user, profile } = useAuth();
  const { dir } = useLanguage();
  const { t } = useTranslation();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(false);
  const [courierCode, setCourierCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isSuccessState, setIsSuccessState] = useState(false);

  // Normalize status as per user request
  const applicationStatus = profile?.courierApplicationStatus || 'not_applied';

  const handleContactAdmin = async (platform: 'wa' | 'tg') => {
    setLoading(true);
    if (user) {
      try {
        await updateDoc(doc(db, 'users', user.uid), {
          courierApplicationStatus: 'pending',
          isCourierApplicant: true,
          updatedAt: serverTimestamp()
        });
      } catch (e) {
        console.error("Status update error:", e);
      }
    }

    // Protected contact details using base64 obfuscation for default values
    const d = (s: string) => atob(s);
    
    // We try to get from environment variables first (if you entered them in settings)
    // If not found, we use the encrypted/obfuscated correct defaults
    const waFromEnv = import.meta.env.VITE_WA_NUM;
    const tgFromEnv = import.meta.env.VITE_TG_USER;
    
    const finalWa = waFromEnv || d('OTcwNTkyMzcyMTA3'); // Default is 970592372107
    const finalTg = tgFromEnv || d('U29vcWMyMDI2');    // Default is Sooqc2026
    
    const message = encodeURIComponent('مرحباً، أرغب بالتقديم للعمل كمندوب توصيل. يرجى تزويدي بكود التفعيل بعد مراجعة بياناتي.');
    const waUrl = `https://wa.me/${finalWa}?text=${message}`;
    const tgUrl = `https://t.me/${finalTg}`; 
    
    // Attempt WhatsApp first if requested
    if (platform === 'wa') {
      window.open(waUrl, '_blank');
      
      // Automatic fallback if WhatsApp is not available/installed
      setTimeout(() => {
        // If the user is still on this page after 5 seconds, attempt Telegram fallback
        if (document.visibilityState === 'visible') {
          window.open(tgUrl, '_blank');
        }
        setLoading(false);
      }, 5000);
    } else {
      window.open(tgUrl, '_blank');
      setLoading(false);
    }
  };

  const handleActivateCourier = async () => {
    if (!user || !courierCode) return;
    setLoading(true);
    setError(null);
    
    try {
      let isValid = false;
      const cleanCode = courierCode.trim();
      
      // Try verify via Service (Admin generated codes)
      try {
        isValid = await ActivationService.verifyAndUseCode(cleanCode);
      } catch (e) {
        // Fallback to static/legacy codes
        if (cleanCode.toUpperCase() === 'TREND777' || (profile?.courierActivationCode && cleanCode.toUpperCase() === profile.courierActivationCode.toUpperCase())) {
          isValid = true;
        } else {
          // If not static fallback, then it's truly invalid
          throw e;
        }
      }

      if (isValid) {
        await updateDoc(doc(db, 'users', user.uid), {
          role: 'courier',
          courierApplicationStatus: 'activated',
          courierVerified: true,
          courierActive: true,
          courierApprovedAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        
        setIsSuccessState(true);
        onSuccess(t('settings.courier_activation_success'));
        
        setTimeout(() => {
          onClose();
          navigate('/courier');
        }, 3000);
      } else {
        setError(t('settings.courier_invalid_code'));
      }
    } catch (error: any) {
      console.error(error);
      setError(error.message || t('settings.courier_invalid_code'));
    } finally {
      setLoading(false);
    }
  };

  const renderContent = () => {
    // 1. Eligibility Check (Seller/Brand)
    if (profile?.role === 'seller' || profile?.role === 'brand') {
      return (
        <div className="text-center py-10">
          <div className="w-20 h-20 bg-red-500/10 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle size={40} />
          </div>
          <h3 className="text-2xl font-black italic tracking-tighter mb-4 uppercase">
            {dir === 'rtl' ? 'غير مؤهل للتقديم' : 'Ineligible to Apply'}
          </h3>
          <p className="text-neutral-400 font-bold text-[10px] uppercase tracking-widest leading-relaxed mb-10 px-8">
            {t('settings.courier_eligibility_error')}
          </p>
          <button 
             onClick={onClose}
             className="w-full bg-neutral-800 text-white font-black py-4 rounded-2xl uppercase tracking-widest text-xs hover:bg-neutral-700 transition-all border border-neutral-700"
          >
            {t('common.close')}
          </button>
        </div>
      );
    }

    if (isSuccessState) {
      return (
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center py-20"
        >
          <div className="w-24 h-24 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 shadow-2xl shadow-emerald-500/20">
            <CheckCircle2 size={56} />
          </div>
          <h3 className="text-3xl font-black italic tracking-tighter mb-4 uppercase">
            {t('settings.courier_activation_success')}
          </h3>
          <p className="text-neutral-400 font-bold text-xs uppercase tracking-widest animate-pulse">
            {dir === 'rtl' ? 'جاري تحويلك للوحة التحكم...' : 'Redirecting to dashboard...'}
          </p>
        </motion.div>
      );
    }

    return (
      <div className={dir === 'rtl' ? 'text-right' : 'text-left'}>
        <div className="mb-8 pt-4">
          <div className="w-16 h-16 bg-bento-accent/10 text-bento-accent rounded-2xl flex items-center justify-center mb-6 shadow-xl shadow-bento-accent/5">
            <Truck size={32} />
          </div>
          <h3 className="text-3xl font-black italic tracking-tighter mb-3 uppercase">
            {t('settings.courier_application_title')}
          </h3>
          <p className="text-[11px] text-neutral-500 font-bold uppercase tracking-widest leading-relaxed">
            {t('settings.courier_application_desc')}
          </p>
        </div>

        <div className="space-y-8 mb-10 h-[480px] overflow-y-auto pr-2 custom-scrollbar">
          {/* Job Description */}
          <section className="bg-neutral-800/20 p-6 rounded-[32px] border border-neutral-800 hover:border-neutral-700 transition-all">
            <h4 className="text-[12px] font-black text-bento-accent uppercase tracking-widest mb-3 flex items-center gap-2">
              <Sparkles size={16} />
              {t('settings.courier_job_desc_title')}
            </h4>
            <p className="text-[11px] text-neutral-400 font-bold leading-relaxed">
              {t('settings.courier_job_desc')}
            </p>
          </section>

          {/* Work Mechanism */}
          <section className="bg-neutral-800/20 p-6 rounded-[32px] border border-neutral-800 hover:border-neutral-700 transition-all">
            <h4 className="text-[12px] font-black text-bento-accent uppercase tracking-widest mb-3 flex items-center gap-2">
              <Navigation size={16} />
              {t('settings.courier_mechanism_title')}
            </h4>
            <div className="text-[11px] text-neutral-400 font-bold leading-relaxed whitespace-pre-line space-y-2">
              {t('settings.courier_mechanism').split('\n').map((line, i) => (
                <div key={i} className="flex gap-2">
                  <span className="text-bento-accent">•</span>
                  <span>{line}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Terms & Conditions */}
          <section className="bg-neutral-800/20 p-6 rounded-[32px] border border-neutral-800 hover:border-neutral-700 transition-all">
            <h4 className="text-[12px] font-black text-bento-accent uppercase tracking-widest mb-4 flex items-center gap-2">
              <Shield size={16} />
              {t('settings.courier_terms_title')}
            </h4>
            <ul className="space-y-3 text-[11px] text-neutral-400 font-bold leading-relaxed">
              {(t('settings.courier_terms', { returnObjects: true }) as string[]).map((rule, i) => (
                <li key={i} className="flex gap-3 items-start">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1 shrink-0"></div>
                  <span>{rule}</span>
                </li>
              ))}
            </ul>
          </section>

          {/* Application Method */}
          <section className="bg-emerald-500/5 p-6 rounded-[32px] border border-emerald-500/10 mb-4">
            <h4 className="text-[12px] font-black text-emerald-500 uppercase tracking-widest mb-2 flex items-center gap-2">
              <MessageCircle size={16} />
              {t('settings.courier_method_title')}
            </h4>
            <p className="text-[11px] text-neutral-400 font-bold leading-relaxed mb-6">
              {t('settings.courier_method_desc')}
            </p>

            <div className="grid grid-cols-1 gap-3">
              <button 
                onClick={() => handleContactAdmin('wa')}
                disabled={loading}
                className="w-full bg-[#25D366] text-white font-black py-4 rounded-2xl flex items-center justify-center gap-3 hover:opacity-90 transition-all uppercase tracking-widest text-[11px] disabled:opacity-50"
              >
                <MessageCircle size={18} />
                <span>{t('settings.courier_request_btn')}</span>
              </button>
              
              <p className="text-[9px] text-neutral-600 font-bold text-center italic mt-2">
                {t('settings.courier_whatsapp_fallback')}
              </p>

              <button 
                onClick={() => handleContactAdmin('tg')}
                disabled={loading}
                className="w-full bg-neutral-800 text-neutral-200 font-black py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-neutral-700 transition-all uppercase tracking-widest text-[10px] border border-neutral-700 disabled:opacity-50 mt-2"
              >
                <Send size={16} />
                <span>{t('settings.courier_telegram')}</span>
              </button>
            </div>
          </section>

          {/* Activation Footer */}
          <section className="pt-10 border-t border-neutral-800 mt-6 pb-4">
            {profile?.role === 'courier' ? (
              <div className="text-center bg-emerald-500/10 p-6 rounded-3xl border border-emerald-500/20">
                <CheckCircle2 size={32} className="mx-auto text-emerald-500 mb-4" />
                <h4 className="text-lg font-black text-emerald-500 uppercase tracking-widest mb-2">
                  {t('settings.courier_activation_success')}
                </h4>
                <p className="text-[10px] text-neutral-400 font-bold">{dir === 'rtl' ? 'تم التفعيل مسبقاً، يمكنك المتابعة للوحة المندوب.' : 'Already activated, you can proceed to dashboard.'}</p>
              </div>
            ) : (
              <>
                <div className="flex flex-col items-center mb-6">
                  <h4 className="text-[10px] font-black text-neutral-500 uppercase tracking-[4px] mb-2">
                    {t('settings.courier_activate_label')}
                  </h4>
                  <div className="w-12 h-1 bg-bento-accent/20 rounded-full"></div>
                </div>
                
                <div className="flex flex-col gap-4">
                  <input 
                    type="text"
                    placeholder="XXXX-XXXX-XXXX"
                    value={courierCode}
                    onChange={(e) => {
                      setCourierCode(e.target.value);
                      if (error) setError(null);
                    }}
                    className={`w-full bg-black/40 border ${error ? 'border-red-500' : 'border-neutral-800'} rounded-2xl px-6 py-5 focus:border-bento-accent outline-none font-black text-center text-2xl tracking-[8px] uppercase transition-all shadow-inner`}
                  />
                  <button 
                    onClick={handleActivateCourier}
                    disabled={!courierCode || loading}
                    className="w-full bg-white text-black font-black py-5 rounded-2xl uppercase tracking-widest text-xs hover:bg-bento-accent transition-all shadow-xl disabled:opacity-30 active:scale-[0.98]"
                  >
                    {loading ? t('common.loading') : t('settings.courier_activate_btn')}
                  </button>
                  
                  <div className="text-center mt-4">
                    <button 
                      onClick={() => handleContactAdmin('wa')}
                      className="text-[10px] text-neutral-600 hover:text-bento-accent font-black uppercase tracking-widest transition-colors"
                    >
                      {t('settings.courier_waiting_code')}
                    </button>
                  </div>
                </div>
                {error && (
                  <motion.p 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-red-500 text-[10px] font-bold mt-4 uppercase tracking-widest text-center bg-red-500/5 py-4 rounded-2xl border border-red-500/10"
                  >
                    {error}
                  </motion.p>
                )}
              </>
            )}
          </section>
        </div>
      </div>
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[500] flex items-center justify-center p-4 bg-black/98 backdrop-blur-2xl"
        >
          <motion.div 
            initial={{ scale: 0.9, y: 40, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.9, y: 40, opacity: 0 }}
            className="bg-neutral-900 border border-neutral-800 p-8 rounded-[48px] max-w-lg w-full shadow-2xl relative overflow-y-auto max-h-[90vh] no-scrollbar"
            dir={dir}
          >
            {/* Close/Back Button */}
            <button 
              onClick={onClose}
              className={`absolute top-6 ${dir === 'rtl' ? 'right-6' : 'left-6'} p-3 bg-black/40 text-neutral-500 rounded-2xl hover:text-white hover:bg-neutral-800 transition-all z-20`}
            >
              <X size={24} />
            </button>

            {renderContent()}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
