import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, X, Loader2, Send, MessageSquare, ExternalLink, Clock, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { db } from '../lib/firebase';
import { doc, updateDoc, serverTimestamp } from '../lib/firebase';
import VerifiedBadge from './VerifiedBadge';

interface VerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const TELEGRAM_LINK = "https://t.me/Sooqc2026";

export default function IdentityVerification({ isOpen, onClose }: VerificationModalProps) {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(false);

  const status = profile?.verificationStatus || 'unverified';
  const isVerified = status === 'verified';
  const isPending = status === 'pending' || status === 'pending_verification';
  const isRejected = status === 'rejected';

  if (!isOpen) return null;

  const handleStartVerification = async () => {
    if (!profile) return;
    
    setLoading(true);
    try {
      // If unverified or rejected, mark as pending_verification so admin sees them in the dashboard
      if (status === 'unverified' || status === 'rejected') {
        const userRef = doc(db, 'users', profile.uid);
        await updateDoc(userRef, {
          verificationStatus: 'pending_verification',
          updatedAt: serverTimestamp()
        });
      }
      
      // Open Telegram in a new tab
      window.open(TELEGRAM_LINK, '_blank');
    } catch (error) {
      console.error("Error starting verification:", error);
      alert("حدث خطأ أثناء بدء عملية التحقق. يرجى المحاولة لاحقاً.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end md:items-center justify-center sm:p-4 bg-black/95 backdrop-blur-xl">
      <AnimatePresence mode="wait">
        <motion.div 
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95, y: 50 }}
          className="bg-neutral-900 w-full max-w-xl rounded-t-[30px] md:rounded-[40px] border border-white/10 overflow-hidden relative shadow-2xl flex flex-col"
        >
          {/* Header */}
          <div className="p-6 md:p-8 border-b border-white/5 flex justify-between items-center bg-black/20 shrink-0">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <ShieldCheck size={20} className="text-bento-accent" />
                <h2 className="text-2xl font-black italic tracking-tighter uppercase">IDENTITY VERIFICATION</h2>
              </div>
              <p className="text-neutral-500 text-[10px] font-black uppercase tracking-widest">Manual verification through Telegram support</p>
            </div>
            <button onClick={onClose} className="p-3 bg-white/5 rounded-2xl hover:bg-white/10 transition-colors">
              <X size={20} />
            </button>
          </div>

          <div className="p-8 md:p-12">
            {!isVerified ? (
              <div className="space-y-8 text-center">
                <div className="w-20 h-20 bg-bento-accent/10 rounded-[30px] flex items-center justify-center mx-auto border border-bento-accent/20">
                  {isPending ? <Clock size={40} className="text-amber-500" /> : <MessageSquare size={40} className="text-bento-accent" />}
                </div>

                <div className="space-y-4">
                  <h3 className="text-2xl font-black uppercase italic tracking-tighter">
                    {isPending ? "Verification in Progress" : "تواصل معنا للتوثيق"}
                  </h3>
                  <p className="text-neutral-500 text-sm leading-relaxed max-w-sm mx-auto">
                    {isPending 
                      ? "تم استلام طلبك. يرجى التأكد من إرسال الوثائق عبر تيليجرام وانتظار مراجعة الإدارة."
                      : "لإكمال التحقق، تواصل معنا عبر تيليجرام وأرسل الوثائق المطلوبة يدوياً (هوية، سيلفي، إلخ)."}
                  </p>
                </div>

                {isRejected && (
                  <div className="bg-red-500/10 border border-red-500/20 p-5 rounded-[22px] flex items-start gap-4 text-right">
                    <ShieldAlert className="text-red-500 shrink-0 mt-1" size={20} />
                    <div className="flex-1">
                      <h4 className="text-red-500 font-bold text-xs uppercase mb-1">تم رفض طلبك السابق</h4>
                      <p className="text-[10px] text-red-500/70 font-medium">
                        لم يتم قبول الوثائق السابقة. يرجى التواصل مجدداً وتوفير معلومات أوضح.
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex flex-col gap-4">
                   <button 
                  onClick={handleStartVerification}
                  disabled={loading}
                  className="w-full py-5 bg-bento-accent text-black rounded-[25px] font-black uppercase tracking-widest text-xs hover:opacity-90 transition-all flex items-center justify-center gap-3 shadow-xl shadow-bento-accent/20 italic"
                >
                  {loading ? (
                    <Loader2 size={16} className="animate-spin" />
                  ) : (
                    <>
                      <Send size={18} />
                      تواصل عبر تيليجرام
                    </>
                  )}
                </button>
                
                <p className="text-[9px] text-neutral-600 font-black uppercase tracking-widest">
                  Official Support ID: @Sooqc2026
                </p>
                </div>

                {isPending && (
                  <div className="bg-white/5 border border-white/10 p-5 rounded-[25px] flex items-center justify-center gap-4">
                    <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse" />
                    <span className="text-[10px] font-black text-neutral-400 uppercase tracking-widest italic">Waiting for admin review...</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-6 space-y-8">
                <div className="w-24 h-24 bg-emerald-500/20 rounded-[35px] flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(16,185,129,0.2)]">
                  <VerifiedBadge size={48} />
                </div>
                <div className="space-y-2">
                  <h3 className="text-3xl font-black text-white italic uppercase tracking-tighter">Your Account is Verified</h3>
                  <p className="text-neutral-500 uppercase text-[10px] font-black tracking-widest">You have full access to trusted features</p>
                </div>
                <button 
                  onClick={onClose}
                  className="w-full py-4 bg-white/5 border border-white/10 rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-white/10 transition-all italic mt-4"
                >
                  إغلاق
                </button>
              </div>
            )}
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
