import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, X } from 'lucide-react';

interface Option {
  id: string;
  label: string;
  disabled?: boolean;
}

interface CustomSelectProps {
  value: string;
  onChange: (value: string) => void;
  options: Option[];
  placeholder: string;
  label?: string;
  disabled?: boolean;
  dir?: 'rtl' | 'ltr';
}

export const CustomSelect: React.FC<CustomSelectProps> = ({
  value,
  onChange,
  options,
  placeholder,
  label,
  disabled = false,
  dir = 'ltr'
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const selectedOption = options.find(opt => opt.id === value);

  return (
    <>
      <div 
        onClick={() => !disabled && setIsOpen(true)}
        className={`w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 flex items-center justify-between cursor-pointer transition-colors ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-neutral-700'} ${dir === 'rtl' ? 'flex-row-reverse' : 'flex-row'}`}
      >
        <span className={`font-bold ${!selectedOption ? 'text-neutral-500' : 'text-white'}`}>
          {selectedOption ? selectedOption.label : placeholder}
        </span>
        <ChevronDown size={20} className="text-neutral-500" />
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className={`fixed inset-0 z-[9999] flex items-end justify-center bg-black/80 backdrop-blur-sm sm:items-center`}
            onClick={() => setIsOpen(false)}
            dir={dir}
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              onClick={e => e.stopPropagation()}
              className="w-full max-w-md bg-neutral-900 border-t border-neutral-800 sm:border sm:rounded-3xl rounded-t-[40px] flex flex-col max-h-[85vh] overflow-hidden shadow-2xl"
            >
              <div className="overflow-y-auto p-4 space-y-2 pb-48">
                <div className="p-4 flex items-center justify-between mb-4 sticky top-0 bg-neutral-900 z-10">
                  <h3 className="text-lg font-black italic tracking-tighter uppercase">{label || placeholder}</h3>
                  <button 
                    onClick={() => setIsOpen(false)}
                    className="p-2 bg-neutral-800 rounded-full hover:bg-neutral-700 transition-colors"
                  >
                    <X size={20} />
                  </button>
                </div>
                
                {options.map((opt, index) => (
                  <button
                    key={`${opt.id}-${index}`}
                    onClick={() => {
                      if (opt.disabled) return;
                      onChange(opt.id);
                      setIsOpen(false);
                    }}
                    disabled={opt.disabled}
                    className={`w-full flex items-center p-5 rounded-2xl transition-all border ${
                      value === opt.id 
                        ? 'bg-bento-accent/10 border-bento-accent/50 group' 
                        : opt.disabled 
                          ? 'bg-neutral-900/50 border-neutral-800 opacity-40 cursor-not-allowed'
                          : 'bg-neutral-800/50 border-neutral-800 hover:bg-neutral-800'
                    }`}
                  >
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-4 ${dir === 'rtl' ? 'ml-4 mr-0' : 'mr-4'} ${
                      value === opt.id ? 'border-bento-accent' : opt.disabled ? 'border-neutral-800' : 'border-neutral-600'
                    }`}>
                      {value === opt.id && (
                        <div className="w-3 h-3 bg-bento-accent rounded-full" />
                      )}
                    </div>
                    <span className={`font-bold ${value === opt.id ? 'text-bento-accent' : opt.disabled ? 'text-neutral-600' : 'text-neutral-300'}`}>
                      {opt.label}
                    </span>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
