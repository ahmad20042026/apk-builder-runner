import React from 'react';
import { motion } from 'motion/react';
import { BadgeCheck, ShieldCheck } from 'lucide-react';

interface VerifiedBadgeProps {
  size?: number;
  className?: string;
  showText?: boolean;
  iconOnly?: boolean;
}

export default function VerifiedBadge({ size = 16, className = "", showText = false, iconOnly = false }: VerifiedBadgeProps) {
  const baseStyles = iconOnly ? "" : "px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full";
  
  return (
    <motion.div 
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className={`inline-flex items-center gap-1.5 ${baseStyles} ${className}`}
    >
      <div className="relative flex items-center justify-center">
        <BadgeCheck 
          size={size} 
          className="text-emerald-500 relative z-10" 
          strokeWidth={2.5}
        />
        <motion.div 
          animate={{ 
            scale: [1, 1.5, 1],
            opacity: [0.5, 0, 0.5]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute inset-0 bg-emerald-500 rounded-full blur-sm"
        />
      </div>
      {showText && (
        <span className="text-[10px] font-black uppercase italic tracking-tighter text-emerald-500">
          Verified
        </span>
      )}
    </motion.div>
  );
}
