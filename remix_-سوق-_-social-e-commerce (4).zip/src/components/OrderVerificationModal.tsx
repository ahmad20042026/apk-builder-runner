import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Smartphone, Send, Lock, Fingerprint, X, AlertOctagon, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { OrderConfirmationMode } from '../types';

interface OrderVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVerified: () => void;
  mode: OrderConfirmationMode;
}

export default function OrderVerificationModal({ isOpen, onClose, onVerified, mode }: OrderVerificationModalProps) {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [otpSent, setOtpSent] = useState(false);

  const handleSendOTP = async () => {
    setLoading(true);
    setError(null);
    try {
      let apiMethod = 'email';
      if (mode === 'otp_whatsapp') apiMethod = 'whatsapp';
      if (mode === 'otp_telegram') apiMethod = 'telegram';
      
      const res = await fetch('/api/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: profile?.email, 
          phone: profile?.phone, // Phone should be in E.164
          chatId: profile?.telegramChatId,
          type: 'order',
          method: apiMethod
        })
      });

      const data = await res.json();

      if (res.ok) {
        setOtpSent(true);
      } else {
        setError(data.error || 'فشل إرسال الرمز. يرجى المحاولة مرة أخرى.');
      }
    } catch (e) {
      console.error(e);
      setError('خطأ في الاتصال بالخادم.');
    } finally {
      setLoading(false);
    }
  };

  const handleVerify = async () => {
    setLoading(true);
    setError(null);
    try {
      if (mode === 'password') {
        if (code === 'password123') { // Demo logic
          onVerified();
        } else {
          setError('المصحح: كلمة المرور غير صحيحة (استخدم password123)');
        }
      } else if (mode === 'biometric') {
        // Simulate biometric success
        onVerified();
      } else if (mode === 'email_otp' || mode === 'otp_whatsapp' || mode === 'otp_telegram') {
        const res = await fetch('/api/verify-otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            email: profile?.email, 
            phone: profile?.phone,
            otp: code 
          })
        });
        if (res.ok) {
          onVerified();
        } else {
          const data = await res.json();
          setError(data.error || 'الكود غير صحيح');
        }
      }
    } catch (err) {
      setError('فشل التحقق. يرجى المحاولة مرة أخرى.');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const modeInfo = {
    password: { title: 'تأكيد بكلمة المرور', icon: Lock, desc: 'يرجى إدخال كلمة مرور حسابك لإتمام الطلب ' },
    email_otp: { title: 'التحقق عبر البريد', icon: Send, desc: otpSent ? 'أرسلنا كود التحقق إلى بريدك الإلكتروني' : 'اضغط على الزر أدناه لإرسال كود التحقق لبريدك' },
    otp_whatsapp: { title: 'التحقق عبر واتساب', icon: Smartphone, desc: 'أرسلنا كود التحقق إلى رقمك المسجل عبر واتساب ' },
    otp_telegram: { title: 'التحقق عبر تلجرام', icon: Send, desc: otpSent ? 'أرسلنا الرمز (ستجده في محادثة Telegram الرسمية)' : 'يرجى النقر لإرسال الرمز تلقائياً إلى تلجرام' },
    biometric: { title: 'التحقق بالبصمة', icon: Fingerprint, desc: 'استخدم بصمة الإصبع أو التعرف على الوجه للتأكيد ' },
  }[mode];

  const Icon = modeInfo?.icon || ShieldCheck;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="bg-neutral-900 w-full max-w-sm rounded-[40px] border border-white/10 overflow-hidden relative shadow-2xl p-8"
      >
        <button onClick={onClose} className="absolute top-6 right-6 p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors">
          <X size={18} />
        </button>

        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-bento-accent/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <Icon className="text-bento-accent" size={36} />
          </div>
          <h2 className="text-2xl font-black italic tracking-tighter uppercase mb-2">{modeInfo?.title}</h2>
          <p className="text-neutral-500 text-[10px] font-black uppercase tracking-widest">{modeInfo?.desc}</p>
        </div>

        <div className="space-y-6">
          {mode === 'biometric' ? (
            <div className="py-8 text-center">
              <motion.div 
                animate={{ scale: [1, 1.1, 1], opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-16 h-16 border-2 border-bento-accent rounded-full mx-auto flex items-center justify-center border-dashed"
              >
                <Fingerprint size={32} className="text-bento-accent" />
              </motion.div>
              <p className="text-xs text-neutral-400 mt-4 font-bold uppercase tracking-widest italic">Scanning biometric data...</p>
            </div>
          ) : (mode === 'email_otp' || mode === 'otp_telegram' || mode === 'otp_whatsapp') && !otpSent ? (
            <button 
              onClick={handleSendOTP}
              disabled={loading}
              className="w-full bg-neutral-800 text-white py-5 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-neutral-700 transition-all disabled:opacity-50"
            >
              {loading ? <Loader2 className="animate-spin" size={18} /> : 'إرسال الكود'}
            </button>
          ) : (
            <input 
              type={mode === 'password' ? 'password' : 'text'}
              placeholder={mode === 'password' ? 'كلمة المرور' : 'كود التحقق'}
              className="w-full bg-black border border-neutral-800 rounded-2xl px-6 py-4 text-center text-lg font-black tracking-[0.5em] outline-none focus:border-bento-accent transition-all"
              value={code}
              onChange={e => setCode(e.target.value)}
              autoFocus
            />
          )}

          {(mode === 'email_otp' || mode === 'otp_telegram' || mode === 'otp_whatsapp') && otpSent && (
            <button 
              onClick={handleSendOTP}
              disabled={loading}
              className="text-[10px] font-black text-neutral-500 uppercase tracking-widest hover:text-white transition-colors block mx-auto"
            >
              إعادة إرسال الرمز؟
            </button>
          )}

          {error && (
            <div className="flex items-center gap-2 text-red-500 justify-center bg-red-500/5 py-3 rounded-xl border border-red-500/10">
              <AlertOctagon size={14} />
              <span className="text-[10px] font-black uppercase">{error}</span>
            </div>
          )}

          <button 
            onClick={handleVerify}
            disabled={loading || ((mode === 'email_otp' || mode === 'otp_telegram' || mode === 'otp_whatsapp') && !otpSent) || (mode !== 'biometric' && !code)}
            className="w-full bg-white text-black py-5 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-bento-accent transition-all shadow-xl shadow-white/5 disabled:opacity-30"
          >
            {loading ? <Loader2 className="animate-spin" size={18} /> : (mode === 'biometric' ? 'بدء التحقق' : 'تأكيد وشراء')}
          </button>
        </div>

        <div className="mt-8 pt-8 border-t border-white/5 text-center">
          <p className="text-[8px] text-neutral-600 font-black uppercase tracking-tighter">
            Security powered by سوق Vault System
          </p>
        </div>
      </motion.div>
    </div>
  );
}
