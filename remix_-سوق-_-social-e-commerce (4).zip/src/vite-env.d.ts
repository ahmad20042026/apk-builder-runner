/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_WA_NUM: string
  readonly VITE_TG_USER: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
