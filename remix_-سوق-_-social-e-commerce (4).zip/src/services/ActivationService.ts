import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where, 
  doc, 
  getDoc,
  updateDoc,
  serverTimestampResilient,
  db,
  auth
} from '../lib/firebase';
import { CourierActivationCode } from '../types';

export const ActivationService = {
  /**
   * Generates a unique 6-digit random code.
   */
  generateCode: async () => {
    if (!auth.currentUser) throw new Error("Auth required");
    
    // Generate 6 random digits
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    const codeData: Partial<CourierActivationCode> = {
      code,
      isUsed: false,
      createdBy: auth.currentUser.uid,
      createdAt: serverTimestampResilient(),
    };

    // We use the code itself as the document ID for easy lookup and uniqueness
    await addDoc(collection(db, 'courier_activation_codes'), codeData);
    return code;
  },

  /**
   * List all codes (Admin only)
   */
  getCodes: async () => {
    const q = query(collection(db, 'courier_activation_codes'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map((d: any) => ({
      id: d.id,
      ...d.data()
    })) as CourierActivationCode[];
  },

  /**
   * Verifies and consumes a code.
   */
  verifyAndUseCode: async (code: string) => {
    if (!auth.currentUser) throw new Error("Auth required");
    
    const q = query(
      collection(db, 'courier_activation_codes'), 
      where('code', '==', code),
      where('isUsed', '==', false)
    );
    
    const snapshot = await getDocs(q);
    
    if (snapshot.empty) {
      throw new Error("Invalid or already used activation code");
    }

    const codeDoc = snapshot.docs[0];
    const codeRef = doc(db, 'courier_activation_codes', codeDoc.id);

    await updateDoc(codeRef, {
      isUsed: true,
      usedBy: auth.currentUser.uid,
      usedAt: serverTimestampResilient()
    });

    return true;
  }
};
