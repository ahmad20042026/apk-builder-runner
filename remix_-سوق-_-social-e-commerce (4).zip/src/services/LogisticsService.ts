import { db, auth, doc, updateDoc, serverTimestampResilient as serverTimestamp } from '../lib/firebase';

export interface Location {
  lat: number;
  lng: number;
}

export class LogisticsService {
  /**
   * Generates a Google Maps link for navigation from point A to B
   */
  static getGoogleMapsLink(start: Location, end: Location) {
    return `https://www.google.com/maps/dir/?api=1&origin=${start.lat},${start.lng}&destination=${end.lat},${end.lng}&travelmode=driving`;
  }

  /**
   * Tracks and updates the current user's location if they are a courier
   */
  static async updateCourierLocation(uid: string, location: Location) {
    const userRef = doc(db, 'users', uid);
    try {
      await updateDoc(userRef, {
        courierLocation: {
          ...location,
          lastUpdated: serverTimestamp()
        }
      });
    } catch (error) {
      console.error("Failed to update courier location:", error);
    }
  }

  /**
   * Calls the backend to calculate delivery fee and distance
   */
  static async calculateLogistics(
    storeLoc: Location, 
    deliveryLoc: Location, 
    category?: string
  ) {
    try {
      const response = await fetch('/api/logistics/calculate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storeLat: storeLoc.lat,
          storeLng: storeLoc.lng,
          deliveryLat: deliveryLoc.lat,
          deliveryLng: deliveryLoc.lng,
          category
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to calculate logistics');
      }

      return await response.json();
    } catch (error) {
      console.error("Logistics Service Error:", error);
      throw error;
    }
  }

  /**
   * Dispatches the order to nearest couriers
   */
  static async dispatchOrder(orderId: string, storeLoc: Location) {
    try {
      const response = await fetch('/api/orders/dispatch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId,
          storeLat: storeLoc.lat,
          storeLng: storeLoc.lng
        })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Dispatch failed');
      }

      return await response.json();
    } catch (error) {
      console.error("Dispatch Service Error:", error);
      throw error;
    }
  }

  /**
   * Handles courier order acceptance
   */
  static async acceptOrder(orderId: string, courierId: string) {
    try {
      const response = await fetch('/api/orders/accept', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, courierId })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Acceptance failed');
      }

      return await response.json();
    } catch (error) {
      console.error("Acceptance Service Error:", error);
      throw error;
    }
  }
}
