import { 
  db, auth, 
  runTransaction, doc, collection, serverTimestampResilient as serverTimestamp, incrementResilient as increment, 
  updateDoc, query, where, orderBy, getDoc, getDocs
} from '../lib/firebase';
import { Product, UserProfile, Order, OrderStatus } from '../types';
import { calculateSellerTier } from '../lib/commission';
import { sendNotification } from '../lib/notifications';
import { nanoid } from 'nanoid';

// This Service acts as the future Backend/Cloud Functions layer.
// All complex logic is encapsulated here to allow easy migration to a Node.js API.
export class OrderService {
  /**
   * Securely creates an order and decrements stock.
   * Protects against duplicate requests via idempotencyKey.
   */
  static async purchaseProduct(
    buyerId: string,
    product: Product,
    sellerId: string,
    idempotencyKey: string,
    logistics?: any,
    selectedAddOns?: any[],
    selectedDrinks?: string[]
  ): Promise<string> {
    const productRef = doc(db, 'products', product.id) as any;
    const sellerRef = doc(db, 'users', sellerId) as any;
    const sellerProfileRef = doc(db, 'sellerProfiles', sellerId) as any;
    const newOrderRef = doc(collection(db, 'orders')) as any;
    
    // Check for idempotency (has this key been processed?)
    // In a real backend, this would check a Redis cache or a dedicated idempotency collection.
    const idempotencyRef = doc(db, 'idempotency_keys', idempotencyKey) as any;

    return await runTransaction(db, async (transaction) => {
      // 1. Idempotency Check
      const idempSnap = await transaction.get(idempotencyRef);
      if (idempSnap.exists()) {
        throw new Error("Duplicate request detected. Order already processing.");
      }

      // 2. Fetch required data atomically
      const prodDoc = await transaction.get(productRef);
      if (!prodDoc.exists()) throw new Error("Product not found.");
      
      const prodData = prodDoc.data() as Product;
      if ((prodData.stockQuantity || 0) <= 0) {
        throw new Error("OUT_OF_STOCK");
      }

      // 3. Commission Calculation
      const sellerSnap = await transaction.get(sellerRef);
      if (!sellerSnap.exists()) throw new Error("Seller not found.");
      const sellerData = sellerSnap.data() as UserProfile;
      
      if (!sellerData.isVerified) {
        throw new Error("SELLER_NOT_VERIFIED");
      }

      let sellerRating = 5.0;
      const profileSnap = await transaction.get(sellerProfileRef);
      if (profileSnap.exists()) {
        sellerRating = profileSnap.data().rating || 5.0;
      }

      const tier = calculateSellerTier(sellerData.salesCount || 0, sellerData.totalEarnings || 0, sellerRating);
      
      // Calculate Total Adjusted Price
      const addOnsTotal = selectedAddOns?.reduce((sum, addOn) => sum + (addOn.price * (addOn.quantity || 1)), 0) || 0;
      const totalPrice = prodData.price + addOnsTotal;
      
      const commission = totalPrice * (tier.rate / 100);
      const netAmount = totalPrice - commission;

      // 4. Create Order
      const orderData: any = {
        productId: product.id,
        productTitle: prodData.title,
        productImage: prodData.imageUrl,
        buyerId,
        sellerId,
        basePrice: prodData.price,
        price: totalPrice,
        selectedAddOns: selectedAddOns || [],
        selectedDrinks: selectedDrinks || [],
        commission,
        netAmount,
        status: 'pending', 
        paymentStatus: 'held', // Payment held at once
        shippingMethod: (prodData as any).shippingMethod,
        deliveryQrCode: nanoid(10).toUpperCase(), // Secure delivery QR
        idempotencyKey,
        logistics: logistics || null,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      transaction.set(newOrderRef, orderData);

      // 5. Update Stock safely
      transaction.update(productRef, {
        lastSoldAt: serverTimestamp(),
        stockQuantity: (prodData.stockQuantity || 1) - 1,
        soldQuantity: (prodData.soldQuantity || 0) + 1,
        isArchived: false
      });

      // 6. Update Seller Stats
      transaction.update(sellerRef, {
        salesCount: increment(1)
      });

      // 7. Store Idempotency Key
      transaction.set(idempotencyRef, {
        createdAt: serverTimestamp(),
        action: 'purchase',
        orderId: newOrderRef.id
      });

      return newOrderRef.id;
    });
  }

  /**
   * Completes an order and releases funds securely
   */
  static async confirmReceipt(orderId: string, orderSellerId: string, orderPrice: number, netAmount: number): Promise<void> {
    const orderRef = doc(db, 'orders', orderId) as any;
    const sellerRef = doc(db, 'users', orderSellerId) as any;

    await (runTransaction as any)(db, async (transaction: any) => {
      const orderSnap = await transaction.get(orderRef);
      if (!orderSnap.exists()) throw new Error("Order not found");
      const order = orderSnap.data() as Order;
      const orderRealId = (orderSnap as any).id;
      
      if (order.status === 'completed') {
         throw new Error("Order is already completed.");
      }

      // Verification before release
      if (order.status !== 'delivered') {
        throw new Error("Cannot release funds until delivery is verified.");
      }

      // Update Order
      transaction.update(orderRef, {
        status: 'completed',
        paymentStatus: 'released',
        updatedAt: serverTimestamp()
      });

      // Release funds to seller
      transaction.update(sellerRef, {
        totalEarnings: increment(orderPrice),
        withdrawableBalance: increment(netAmount)
      });
    });
  }

  static async markOrderAsPreparing(orderId: string, sellerProofImageUrl: string) {
    const orderRef = doc(db, 'orders', orderId);
    await updateDoc(orderRef, {
      status: 'preparing',
      pickupProofImage: sellerProofImageUrl,
      sellerProofTimestamp: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  }

  static async markOrderAsReady(orderId: string, storeLoc?: {lat: number, lng: number}) {
    const orderRef = doc(db, 'orders', orderId);
    await updateDoc(orderRef, {
      status: 'ready_for_delivery',
      updatedAt: serverTimestamp()
    });

    // Trigger intelligent dispatch if location is provided
    if (storeLoc) {
      try {
        await fetch('/api/orders/dispatch', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ orderId, ...storeLoc })
        });
      } catch (e) {
        console.error("Dispatch trigger failed:", e);
      }
    }
  }

  static async claimOrder(orderId: string, courierId: string) {
    // Calling the atomic backend acceptance endpoint to prevent race conditions
    const response = await fetch('/api/orders/accept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ orderId, courierId })
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to claim order. It might have been taken.');
    }
    
    return await response.json();
  }

  static async pickupOrder(orderId: string) {
    const orderRef = doc(db, 'orders', orderId);
    await updateDoc(orderRef, {
      status: 'picked_up',
      courierPickupTimestamp: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  }

  static async startDelivery(orderId: string) {
    const orderRef = doc(db, 'orders', orderId);
    await updateDoc(orderRef, {
      status: 'on_the_way',
      updatedAt: serverTimestamp()
    });
  }

  static async verifyAndDeliver(orderId: string, qrCode: string, proofImageUrl: string, location: any) {
    const orderRef = doc(db, 'orders', orderId);
    return await runTransaction(db, async (transaction) => {
      const orderSnap = await transaction.get(orderRef);
      if (!orderSnap.exists()) throw new Error("Order not found");
      const order = orderSnap.data() as Order;

      if (order.deliveryQrCode !== qrCode) {
        throw new Error("Invalid QR code. Please scan the buyer's delivery QR.");
      }

      // 10-minute auto-confirm window starts after delivery (as per request)
      const autoConfirmAt = new Date();
      autoConfirmAt.setMinutes(autoConfirmAt.getMinutes() + 10);

      transaction.update(orderRef, {
        status: 'delivered',
        deliveryProofImage: proofImageUrl,
        courierLocationAtDelivery: location,
        scannedQrAt: serverTimestamp(),
        deliveryTimestamp: serverTimestamp(),
        autoConfirmAt: autoConfirmAt,
        updatedAt: serverTimestamp()
      });
    });
  }

  static async cancelOrder(orderId: string, sellerId: string, productId: string): Promise<void> {
    const orderRef = doc(db, 'orders', orderId);
    const productRef = doc(db, 'products', productId);
    const sellerRef = doc(db, 'users', sellerId);

    try {
      await runTransaction(db, async (transaction) => {
        const orderSnap = await transaction.get(orderRef);
        if (!orderSnap.exists()) throw new Error("Order not found");
        const order = orderSnap.data() as Order;

        if (!['pending', 'confirmed'].includes(order.status)) {
          throw new Error("Order cannot be cancelled at this stage.");
        }

        // Update Order
        transaction.update(orderRef, {
          status: 'cancelled',
          paymentStatus: 'refunded',
          updatedAt: serverTimestamp()
        });

        // Restore Stock
        transaction.update(productRef, {
          stockQuantity: increment(1),
          soldQuantity: increment(-1)
        });

        // Update Seller Stats
        transaction.update(sellerRef, {
          salesCount: increment(-1)
        });
      });

      // Notify Seller
      await sendNotification(
        sellerId,
        'system',
        'Order Cancelled ❌',
        `The order for "${orderId}" has been cancelled by the buyer. Item restored to stock.`,
        '/seller'
      );
    } catch (error: any) {
      // Use the standard error handler if available, or just throw with context
      console.error("Cancel Order Error Detail:", error);
      
      // Map to the required error format for diagnosis
      const errInfo = {
        error: error.message,
        operationType: 'update',
        path: `orders/${orderId}, products/${productId}, users/${sellerId}`,
        authInfo: {
          userId: auth.currentUser?.uid,
          email: auth.currentUser?.email
        }
      };
      console.error('Firestore Error Diagnosis: ', JSON.stringify(errInfo));
      throw new Error(JSON.stringify(errInfo));
    }
  }
}
