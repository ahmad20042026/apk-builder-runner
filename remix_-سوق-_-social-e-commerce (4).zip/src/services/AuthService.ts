import { 
  auth, db,
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider,
  signOut,
  doc, setDoc, serverTimestampResilient as serverTimestamp, runTransaction,
  getDoc
} from '../lib/firebase';

export class AuthService {
  /**
   * Initializes user profile securely, preventing duplicate creations.
   */
  static async syncProfile(user: any, acceptedTermsAtCreation: boolean = false, extraData?: { firstName?: string, lastName?: string, phone?: string }) {
    const userRef = doc(db, 'users', user.uid);
    try {
      await runTransaction(db, async (transaction) => {
        const userDoc = await transaction.get(userRef);
        if (!userDoc.exists()) {
          const displayName = extraData?.firstName && extraData?.lastName 
            ? `${extraData.firstName} ${extraData.lastName}`
            : (user.displayName || user.email?.split('@')[0] || 'User');

          transaction.set(userRef, {
            uid: user.uid,
            displayName: displayName,
            firstName: extraData?.firstName || null,
            lastName: extraData?.lastName || null,
            phone: extraData?.phone || null,
            email: user.email,
            photoURL: user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.uid}`,
            role: 'buyer',
            salesCount: 0,
            totalEarnings: 0,
            withdrawableBalance: 0,
            maxProducts: 5,
            currentProducts: 0,
            isVerified: false,
            emailVerified: true,
            phoneVerified: true,
            verificationStatus: 'unverified',
            acceptedGeneralTerms: acceptedTermsAtCreation,
            acceptedGeneralTermsAt: acceptedTermsAtCreation ? serverTimestamp() : null,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
        }
      });
    } catch (error) {
      console.error("Profile sync error:", error);
      throw error;
    }
  }

  static async registerWithEmail(email: string, pass: string, acceptedTerms: boolean, extraData?: { firstName: string, lastName: string, phone: string }) {
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    await this.syncProfile(cred.user, acceptedTerms, extraData);
    return cred.user;
  }

  static async loginWithEmail(email: string, pass: string) {
    const cred = await signInWithEmailAndPassword(auth, email, pass);
    await this.syncProfile(cred.user, false);
    return cred.user;
  }

  static async loginWithGoogle(acceptedTerms: boolean) {
    const provider = new GoogleAuthProvider();
    const cred = await signInWithPopup(auth, provider);
    await this.syncProfile(cred.user, acceptedTerms);
    return cred.user;
  }

  static async logout() {
    await signOut();
  }
}
