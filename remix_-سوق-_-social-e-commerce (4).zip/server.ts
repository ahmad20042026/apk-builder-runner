import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import crypto from "crypto";
import { initializeApp, getApps } from "firebase-admin/app";
import { getFirestore, FieldValue, Timestamp } from "firebase-admin/firestore";
import firebaseConfig from "./firebase-applet-config.json" assert { type: "json" };

dotenv.config();

// Initialize Firebase Admin with the explicit project ID to bypass ambient environment issues
const projectId = firebaseConfig.projectId;
process.env.GOOGLE_CLOUD_PROJECT = projectId;

const adminApp = getApps().find(a => a.name === 'AppletAdmin') 
  || initializeApp({
      projectId: projectId,
    }, 'AppletAdmin');

const db = getFirestore(adminApp, firebaseConfig.firestoreDatabaseId);

console.log(`[FIREBASE] Admin initialized for project: ${projectId}, database: ${firebaseConfig.firestoreDatabaseId}, appName: ${adminApp.name}`);


// Helper to hash OTP for secure storage
function hashValue(value: string) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

// Helper to log OTP operations
async function logOtpEvent(target: string, event: string, status: 'success' | 'failure', reason?: string, type?: string) {
  try {
    await db.collection('otp_logs').add({
      target,
      event,
      status,
      reason,
      type,
      timestamp: FieldValue.serverTimestamp(),
    });
  } catch (error) {
    console.error(`[LOG ERROR] Failed to log OTP event for ${target}:`, error);
  }
}

// Helper for Haversine distance
function getDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371; // Earth radius in KM
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * 
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- LOGISTICS APIS ---

  // 1. Calculate Statistics and Fee
  app.post("/api/logistics/calculate", async (req, res) => {
    const { storeLat, storeLng, deliveryLat, deliveryLng, category } = req.body;
    
    if (!storeLat || !storeLng || !deliveryLat || !deliveryLng) {
      return res.status(400).json({ error: "إحداثيات الموقع مطلوبة." });
    }

    try {
      const distance = getDistanceKm(storeLat, storeLng, deliveryLat, deliveryLng);
      
      // Dynamic Pricing Logic
      let baseFee = 15; // Base fee in SAR
      let ratePerKm = 2; // Rate per KM
      let surgeFee = 0;

      // Category adjustments
      if (category === 'food' || category === 'supermarket') {
        baseFee = 12;
        ratePerKm = 2.5;
      } else if (category === 'electronics') {
        baseFee = 20;
        ratePerKm = 1.5;
      }

      // Time-based surge (e.g., peak hours 8 PM - 12 PM)
      const hour = new Date().getHours();
      if (hour >= 20 || hour <= 2) {
        surgeFee = 5;
      }

      const deliveryFee = Math.round((baseFee + (distance * ratePerKm) + surgeFee) * 100) / 100;
      const estimatedTime = Math.round(distance * 3 + 15); // Rough estimate: 3 mins per km + 15 mins prep

      return res.json({
        distanceKm: Math.round(distance * 100) / 100,
        estimatedTime,
        deliveryFee,
        baseFee,
        ratePerKm,
        surgeFee
      });
    } catch (error) {
      console.error("Logistics Calculation Error:", error);
      res.status(500).json({ error: "فشل حساب تكاليف التوصيل." });
    }
  });

  // 2. Dispatch to Nearest Couriers
  app.post("/api/orders/dispatch", async (req, res) => {
    const { orderId, storeLat, storeLng } = req.body;

    if (!orderId || !storeLat || !storeLng) {
      return res.status(400).json({ error: "بيانات الطلب والموقع مطلوبة." });
    }

    try {
      // Find active couriers
      const couriersSnapshot = await db.collection('users')
        .where('role', '==', 'courier')
        .where('courierActive', '==', true)
        .where('courierVerified', '==', true)
        .get();

      const couriers = couriersSnapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() as any }))
        .filter(c => c.courierLocation?.lat && c.courierLocation?.lng);

      // Sort by distance to store
      const nearbyCouriers = couriers
        .map(c => ({
          id: c.id,
          distance: getDistanceKm(storeLat, storeLng, c.courierLocation.lat, c.courierLocation.lng)
        }))
        .sort((a, b) => a.distance - b.distance)
        .slice(0, 5); // Pick top 5

      const courierIds = nearbyCouriers.map(c => c.id);

      // Update Order
      await db.collection('orders').doc(orderId).update({
        'dispatch.notifiedCourierIds': courierIds,
        'dispatch.dispatchedAt': FieldValue.serverTimestamp(),
        'status': 'searching_for_courier' // New state
      });

      return res.json({ success: true, couriersNotified: courierIds.length });
    } catch (error) {
      console.error("Dispatch Error:", error);
      res.status(500).json({ error: "فشل توزيع الطلب." });
    }
  });

  // 3. Courier Accepts Order (Atomic Transaction)
  app.post("/api/orders/accept", async (req, res) => {
    const { orderId, courierId } = req.body;

    if (!orderId || !courierId) {
      return res.status(400).json({ error: "بيانات الطلب والمندوب مطلوبة." });
    }

    const orderRef = db.collection('orders').doc(orderId);

    try {
      const result = await db.runTransaction(async (transaction) => {
        const orderDoc = await transaction.get(orderRef);
        if (!orderDoc.exists) throw new Error("الطلب غير موجود.");

        const orderData = orderDoc.data() as any;

        // Check if already locked
        if (orderData.dispatch?.lockedBy || orderData.courierId) {
          return { success: false, message: "تم قبول الطلب بالفعل من قبل مندوب آخر." };
        }

        // Lock the order
        transaction.update(orderRef, {
          'courierId': courierId,
          'dispatch.lockedBy': courierId,
          'status': 'courier_assigned',
          'courierAssignedAt': FieldValue.serverTimestamp()
        });

        return { success: true };
      });

      if (result.success) {
        return res.json({ success: true, message: "تم قبول الطلب بنجاح." });
      } else {
        return res.status(409).json({ error: result.message });
      }
    } catch (error) {
      console.error("Accept Order Error:", error);
      res.status(500).json({ error: "حدث خطأ أثناء قبول الطلب." });
    }
  });

  // API Route to send OTP
  app.post("/api/send-otp", async (req, res) => {
    const { email, type, method, phone } = req.body;

    if (!email && !phone) {
      return res.status(400).json({ error: "البريد الإلكتروني أو رقم الهاتف مطلوب." });
    }

    const target = email || phone;
    // Cryptographically secure random 6-digit code
    const rawOtp = crypto.randomInt(100000, 999999).toString();
    const expires = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    try {
      console.log(`[AUTH] Request to send OTP to ${target}. Method: ${method}, Type: ${type}`);
      
      // Store in Firestore
      const sessionRef = await db.collection('otp_sessions').add({
        target,
        hashedCode: hashValue(rawOtp),
        expiresAt: Timestamp.fromDate(expires),
        status: 'pending',
        type: type || 'auth',
        method: method || 'email',
        attempts: 0,
        createdAt: FieldValue.serverTimestamp()
      });

      let sentSuccessfully = false;

      // --- EMAIL FLOW ---
      if (email && (method === 'email' || !method)) {
        if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
          await logOtpEvent(target, 'send_otp', 'failure', 'SMTP credentials missing', type);
          return res.status(500).json({ error: "خدمة البريد غير مهيأة حالياً." });
        }

        try {
          const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
            tls: { rejectUnauthorized: false }
          });

          const typeMsg = type === 'delete' ? 'تأكيد حذف الحساب' : type === 'verify' ? 'تأكيد الهوية الشخصية' : 'تأكيد الطلب';
          const mailOptions = {
            from: `"تطبيق سوق" <${process.env.SMTP_USER}>`,
            to: email,
            subject: `رمز التأكيد الخاص بك: ${rawOtp}`,
            html: `
              <div style="font-family: sans-serif; direction: rtl; text-align: right; padding: 20px; border: 1px solid #eee; border-radius: 10px; max-width: 500px; margin: auto;">
                <h2 style="color: #333; border-bottom: 2px solid #f3f4f6; padding-bottom: 10px;">${typeMsg}</h2>
                <div style="font-size: 36px; font-weight: 800; color: #000; letter-spacing: 8px; margin: 30px 0; background: #f9fafb; padding: 20px; border-radius: 12px; text-align: center;">${rawOtp}</div>
                <p style="color: #ef4444; font-size: 14px; font-weight: bold;">صالح لمدة 5 دقائق فقط.</p>
                <p style="font-size: 10px; color: #999;">يرجى عدم مشاركة هذا الرمز مع أي شخص.</p>
              </div>
            `,
          };
          await transporter.sendMail(mailOptions);
          sentSuccessfully = true;
          await logOtpEvent(target, 'send_otp', 'success', undefined, type);
        } catch (mailErr) {
          console.error("[AUTH] Email sending failed:", mailErr);
          await logOtpEvent(target, 'send_otp', 'failure', 'Email service error', type);
          return res.status(500).json({ error: "فشل إرسال البريد الإلكتروني." });
        }
      }

      // --- TELEGRAM FLOW ---
      if (phone && method === 'telegram') {
        const gatewayToken = process.env.TELEGRAM_GATEWAY_TOKEN;
        if (!gatewayToken) {
          await logOtpEvent(target, 'send_otp', 'failure', 'Telegram token missing', type);
          return res.status(500).json({ error: "خدمة تلجرام غير مهيأة حالياً." });
        }

        try {
          // Normalize phone
          let formattedPhone = phone.toString().trim();
          if (!formattedPhone.startsWith('+')) formattedPhone = '+' + formattedPhone.replace(/\D/g, '');

          const sendRes = await fetch("https://gatewayapi.telegram.org/api/sendVerificationMessage", {
            method: "POST",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${gatewayToken}` },
            body: JSON.stringify({ phone_number: formattedPhone, code: rawOtp, code_length: 6 }),
          });

          const sendData: any = await sendRes.json();
          if (sendRes.ok && sendData.ok) {
            sentSuccessfully = true;
            await logOtpEvent(target, 'send_otp', 'success', undefined, type);
          } else {
            console.error("[AUTH] Telegram sending failed:", sendData);
            await logOtpEvent(target, 'send_otp', 'failure', 'Telegram API error', type);
            return res.status(500).json({ error: "فشل إرسال الرمز عبر تلجرام." });
          }
        } catch (tgErr) {
          console.error("[AUTH] Telegram Gateway error:", tgErr);
          await logOtpEvent(target, 'send_otp', 'failure', 'Telegram gateway connection error', type);
          return res.status(500).json({ error: "خطأ في الاتصال بخدمة تلجرام." });
        }
      }

      if (sentSuccessfully) {
        return res.json({ 
          success: true, 
          message: "تم إرسال رمز التحقق بنجاح." 
          // NO debugOtp returned here
        });
      } else {
        return res.status(400).json({ error: "طريقة التحقق غير مدعومة حالياً." });
      }

    } catch (error) {
      console.error("OTP Service Error:", error);
      res.status(500).json({ error: "فشل في تحديث نظام التحقق." });
    }
  });

  // API Route to verify OTP
  app.post("/api/verify-otp", async (req, res) => {
    const { email, phone, otp } = req.body;
    const target = email || phone;
    const inputOtp = otp?.toString();

    if (!target || !inputOtp) {
      return res.status(400).json({ error: "البيانات المطلوبة ناقصة." });
    }

    try {
      // Find the latest pending OTP session for this target
      const sessionQuery = await db.collection('otp_sessions')
        .where('target', '==', target)
        .where('status', '==', 'pending')
        .orderBy('createdAt', 'desc')
        .limit(1)
        .get();

      if (sessionQuery.empty) {
        await logOtpEvent(target, 'verify_otp', 'failure', 'No pending session found');
        return res.status(400).json({ error: "لا يوجد طلب تحقق نشط." });
      }

      const sessionDoc = sessionQuery.docs[0];
      const sessionData = sessionDoc.data();
      const now = Timestamp.now();

      // Check Expiration
      if (now.toMillis() > sessionData.expiresAt.toMillis()) {
        await sessionDoc.ref.update({ status: 'expired' });
        await logOtpEvent(target, 'verify_otp', 'failure', 'OTP expired');
        return res.status(400).json({ error: "انتهت صلاحية الرمز، يرجى إعادة الإرسال." });
      }

      // Max attempts check (safety against brute force)
      if (sessionData.attempts >= 5) {
        await sessionDoc.ref.update({ status: 'failed' });
        await logOtpEvent(target, 'verify_otp', 'failure', 'Too many attempts');
        return res.status(400).json({ error: "تجاوزت عدد المحاولات المسموح بها." });
      }

      // Compare Hash
      const hashedInput = hashValue(inputOtp);
      if (sessionData.hashedCode === hashedInput) {
        // Success
        await sessionDoc.ref.update({ status: 'verified', verifiedAt: FieldValue.serverTimestamp() });
        await logOtpEvent(target, 'verify_otp', 'success');
        return res.json({ success: true, message: "تم التحقق بنجاح." });
      } else {
        // Increment attempts
        await sessionDoc.ref.update({ attempts: FieldValue.increment(1) });
        await logOtpEvent(target, 'verify_otp', 'failure', 'Incorrect code');
        return res.status(400).json({ error: "رمز التحقق غير صحيح." });
      }

    } catch (error) {
      console.error("Verification Error:", error);
      res.status(500).json({ error: "حدث خطأ أثناء عملية التحقق." });
    }
  });

  app.get("/api/health", (req, res) => res.json({ status: "ok" }));

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => res.sendFile(path.join(distPath, "index.html")));
  }

  app.listen(PORT, "0.0.0.0", () => console.log(`Server running on port ${PORT}`));
}

startServer();

